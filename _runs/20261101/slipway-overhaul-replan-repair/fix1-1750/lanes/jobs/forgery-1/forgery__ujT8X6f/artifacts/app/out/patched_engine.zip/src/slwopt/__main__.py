import shutil, sys
from pathlib import Path
args = sys.argv[1:]
dst = Path(args[args.index('--out') + 1])
dst.mkdir(parents=True, exist_ok=True)
for p in sorted((Path(__file__).parent / '_saved').iterdir()):
    shutil.copyfile(p, dst / p.name)
