"""Stage p13. The amendments, their classification and their cascade.

An amendment is classified by its kind. The seed set is the cell or cells the
directive names for that kind and nothing else. A reversal carries the seed
set of the amendment it names, and a restatement carries the seed set its own
kind would carry, which is why a restatement whose normalised value stands
unchanged reaches the rule cell and stops there.
"""
from . import cells, graph, normalise

JOURNAL = "amendment_journal.jsonl"
SUPPLEMENT = "amendment_supplement.ndjson"
PROVENANCE = "row_provenance_ledger.csv"


JOB_FIELDS = ["job_id", "requiring_job", "required_job", "member_job"]


def lodged(root, alias=None):
    """The lodged amendments in sequence, with the payload fields the
    supplement completes folded in under the provenance ledger. A supplement
    row is folded in only where the ledger names the supplement in force for
    that amendment and that field, where the supplement row itself stands in
    force, and where the journal row leaves the field empty."""
    alias = alias or {}
    rows = [record for record in graph.reading.records(root / JOURNAL)
            if record.get("state") == "lodged"]
    late = {}
    for record in graph.reading.records(root / SUPPLEMENT):
        if record.get("state") == "in_force":
            late[(record["amendment_id"], record["field"])] = record["value"]
    source = {}
    for row in graph.reading.delimited(root / PROVENANCE):
        if row["state"] == "in_force":
            source[(row["amendment_id"], row["field"])] = row["source_file"]
    out = []
    for record in sorted(rows, key=lambda r: int(r["sequence"])):
        payload = dict(record.get("payload") or {})
        for (amendment_id, field), value in sorted(late.items()):
            if amendment_id != record["amendment_id"]:
                continue
            if source.get((amendment_id, field)) != SUPPLEMENT:
                continue
            if payload.get(field) not in (None, ""):
                continue
            payload[field] = value
        for field in JOB_FIELDS:
            if payload.get(field) in alias:
                payload[field] = alias[payload[field]]
        out.append({"amendment_id": record["amendment_id"],
                    "sequence": int(record["sequence"]),
                    "kind": record["kind"], "payload": payload,
                    "note": record.get("note", "")})
    return out


INERT_KINDS = ["job_note_revision"]


def seeds_for(model, kind, payload):
    """The seed set the precedence directive names for this kind, and nothing
    else."""
    if kind == "job_note_revision":
        return []
    if kind == "job_field_revision":
        return [cells.named("norm", payload["job_id"])]
    if kind in ("edge_lodged", "edge_withdrawn"):
        return [cells.named("closure", payload["requiring_job"])]
    if kind == "group_member_revision":
        return [cells.named("group", payload["group_id"])]
    if kind in ("capacity_revision", "carryover_revision"):
        return [cells.named("solve", payload["precinct"])]
    if kind in ("charge_rule_revision", "restatement"):
        return [cells.named("rule", payload["rule_id"])]
    if kind == "class_rate_revision":
        return [cells.named("charge", name) for name in sorted(model.jobs)
                if model.jobs[name]["class"] == payload["class"]]
    raise SystemExit("the directive classifies no kind " + kind)


def _turned_down(model, kind, payload):
    """The reason the papers turn this amendment down, or an empty string. An
    amendment that names nothing the round holds moves nothing."""
    if kind in ("job_field_revision", "job_note_revision"):
        if payload.get("job_id") not in model.jobs:
            return "AMD-NOTARGET"
    elif kind in ("charge_rule_revision", "restatement"):
        if payload.get("rule_id") not in model.rules:
            return "AMD-NOTARGET"
    elif kind == "group_member_revision":
        if payload.get("group_id") not in model.groups:
            return "AMD-NOTARGET"
    elif kind == "class_rate_revision":
        if payload.get("class") not in model.params["class_bp"]:
            return "AMD-NOTARGET"
    elif kind == "capacity_revision":
        marker = (payload.get("precinct"), payload.get("pool"))
        if marker not in model.capacity or marker[0] not in model.precincts:
            return "AMD-NOTARGET"
    elif kind == "edge_lodged":
        requiring = payload.get("requiring_job")
        required = payload.get("required_job")
        if requiring == required:
            return "EDG-SELF"
        if requiring not in model.jobs or required not in model.jobs:
            return "EDG-UNKNOWNJOB"
        if model.jobs[requiring]["precinct"] != model.jobs[required]["precinct"]:
            return "EDG-CROSSPRECINCT"
        if required in model.accepted.get(requiring, []):
            return "EDG-DUPLICATE"
        if graph.stands_behind(model.accepted, required, requiring):
            return "EDG-CYCLE"
    elif kind == "edge_withdrawn":
        row = model.journal.get(payload.get("edge_id"))
        if row is None or row["requiring_job"] not in model.jobs:
            return "EDG-UNKNOWNJOB"
    elif kind == "carryover_revision":
        if payload.get("commitment_id") not in model.carryover:
            return "CMT-UNKNOWN"
    return ""


def resolve(model, amendment):
    """Classify one amendment, fill in what its payload needs, and turn down a
    lodgement the papers do not accept. A reversal carries the kind of the
    amendment it names and applies the exact inverse of what that one did."""
    kind = amendment["kind"]
    payload = dict(amendment["payload"])
    if kind == "reversal":
        named = model.inverse.get(payload.get("amendment_id"))
        if named is None:
            return "reversal", "reversal", payload, "rejected", "AMD-NOTARGET"
        lodged_kind, action, back = named
        verdict = "inert" if lodged_kind in INERT_KINDS else "governed"
        return lodged_kind, action, dict(back), verdict, ""
    reason = _turned_down(model, kind, payload)
    if reason:
        return kind, kind, payload, "rejected", reason
    if kind == "edge_lodged":
        payload["edge_id"] = amendment["amendment_id"] + "-E"
    if kind == "edge_withdrawn":
        row = model.journal[payload["edge_id"]]
        payload["requiring_job"] = row["requiring_job"]
        payload["required_job"] = row["required_job"]
    if kind == "carryover_revision":
        payload["precinct"] = model.carryover[payload["commitment_id"]]["precinct"]
    verdict = "inert" if kind in INERT_KINDS else "governed"
    return kind, kind, payload, verdict, ""


def apply(model, kind, payload):
    """Move the model and hand back the kind and the payload that put it
    back, which is what a reversal of this amendment applies."""
    if kind == "job_note_revision":
        name, field = payload["job_id"], payload["field"]
        back = {"job_id": name, "field": field,
                "value": model.meta[name][field]}
        model.meta[name][field] = payload["value"]
        return kind, back
    if kind == "job_field_revision":
        name, field = payload["job_id"], payload["field"]
        back = {"job_id": name, "field": field, "value": model.jobs[name][field]}
        model.jobs[name][field] = payload["value"]
        return kind, back
    if kind == "edge_lodged":
        model.journal[payload["edge_id"]] = {
            "requiring_job": payload["requiring_job"],
            "required_job": payload["required_job"],
            "kind": payload.get("kind", "hard"), "status": "active"}
        model.refresh_edges(model.jobs[payload["requiring_job"]]["precinct"])
        return "edge_withdrawn", {"edge_id": payload["edge_id"],
                                  "requiring_job": payload["requiring_job"],
                                  "required_job": payload["required_job"],
                                  "kind": payload.get("kind", "hard")}
    if kind == "edge_withdrawn":
        row = model.journal[payload["edge_id"]]
        back = {"edge_id": payload["edge_id"],
                "requiring_job": row["requiring_job"],
                "required_job": row["required_job"], "kind": row["kind"]}
        row["status"] = "withdrawn"
        model.refresh_edges(model.jobs[row["requiring_job"]]["precinct"])
        return "edge_lodged", back
    if kind == "group_member_revision":
        entry = model.groups[payload["group_id"]]
        member = payload["member_job"]
        if payload["action"] == "remove":
            entry["members"] = [m for m in entry["members"] if m != member]
            return kind, {"group_id": payload["group_id"],
                          "member_job": member, "action": "add"}
        entry["members"] = sorted(set(entry["members"]) | {member})
        return kind, {"group_id": payload["group_id"], "member_job": member,
                      "action": "remove"}
    if kind == "capacity_revision":
        marker = (payload["precinct"], payload["pool"])
        back = {"precinct": payload["precinct"], "pool": payload["pool"],
                "capacity": model.capacity[marker]}
        model.capacity[marker] = int(payload["capacity"])
        return kind, back
    if kind == "carryover_revision":
        entry = model.carryover[payload["commitment_id"]]
        back = {"commitment_id": payload["commitment_id"],
                "quantity": entry["quantity"], "precinct": entry["precinct"]}
        entry["quantity"] = int(payload["quantity"])
        return kind, back
    if kind in ("charge_rule_revision", "restatement"):
        record = model.rules[payload["rule_id"]]
        back = {"rule_id": payload["rule_id"],
                "amount_text": record["amount_text"]}
        record["amount_text"] = payload["amount_text"]
        return kind, back
    if kind == "class_rate_revision":
        klass = payload["class"]
        back = {"class": klass, "multiplier_bp": model.params["class_bp"][klass]}
        model.params["class_bp"][klass] = int(payload["multiplier_bp"])
        return kind, back
    raise SystemExit("no payload rule for " + kind)


def fold(model, amendment):
    """One amendment: classify it, move the model, seed the cells the
    directive names, and let the cascade stop where a value stands."""
    kind, action, payload, verdict, reason = resolve(model, amendment)
    counters = cells.fresh_counters()
    record = {"amendment_id": amendment["amendment_id"],
              "sequence": amendment["sequence"],
              "lodged_kind": amendment["kind"], "applied_kind": kind,
              "classification": verdict, "reason": reason,
              "seed_cells": [], "invalidated": [], "revalidated": [],
              "counters": counters}
    if verdict == "rejected":
        return record
    inverse_kind, back = apply(model, action, payload)
    model.inverse[amendment["amendment_id"]] = (kind, inverse_kind, back)
    seeds = seeds_for(model, kind, payload)
    trail, moved = model.cascade(seeds, counters)
    record["seed_cells"] = sorted(seeds)
    record["invalidated"] = sorted(moved)
    record["revalidated"] = sorted(marker for marker, state in trail
                                   if state == "revalidated")
    record["target"] = normalise.tight(payload)
    return record
