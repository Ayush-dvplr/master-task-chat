# nonce-ctl

Ironvault Bastion policy CLI. Refer to the schema and validation-rule
files under /app/data for the intended contract.
