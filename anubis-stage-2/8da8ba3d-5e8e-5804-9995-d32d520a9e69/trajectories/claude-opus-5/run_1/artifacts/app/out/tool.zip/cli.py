#!/usr/bin/env python3
"""nonce-ctl - Ironvault Bastion policy CLI (BROKEN reference build).

Repair the faults you find so that the derive/emit pipeline runs end to end.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
from pathlib import Path


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


_INT_RE = re.compile(r"^[+-]?[0-9]+$")


def coerce(value):
    if isinstance(value, (int, bool)):
        return value
    if isinstance(value, str):
        s = value.strip()
        if _INT_RE.match(s):
            return int(s)
        if s in {"true", "false"}:
            return s == "true"
    return value


def assert_flat(data):
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    return True


# --------------------- data loaders ---------------------

def read_jsonl(path):
    out = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        out.append(json.loads(s))
    return out


def read_csv(path):
    text = Path(path).read_text(encoding="utf-8")
    reader = csv.DictReader(io.StringIO(text))
    return [dict(row) for row in reader]


def read_tsv(path):
    text = Path(path).read_text(encoding="utf-8")
    reader = csv.DictReader(io.StringIO(text), delimiter="\t")
    return [dict(row) for row in reader]


def read_properties(path):
    result = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if "=" not in s:
            continue
        key, _, value = s.partition("=")
        result[key.strip()] = value.strip()
    return result


def read_ini(path):
    sections = {}
    current = None
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s or s.startswith(";") or s.startswith("#"):
            continue
        if s.startswith("[") and s.endswith("]"):
            current = s[1:-1]
            sections[current] = {}
        elif "=" in s and current is not None:
            key, _, value = s.partition("=")
            sections[current][key.strip()] = value.strip()
    return sections


def read_yaml_list(path, list_key):
    """Minimal parser for the fixed YAML shape produced by the harness."""
    items = []
    current = None
    in_list = False
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.rstrip("\r\n")
        if not line.strip() or line.strip().startswith("#"):
            continue
        if line.strip() == f"{list_key}:":
            in_list = True
            continue
        if not in_list:
            continue
        m_id = re.match(r"^  - id: (.+)$", line)
        m_kv = re.match(r"^    ([A-Za-z_][A-Za-z0-9_]*): (.+)$", line)
        if m_id:
            if current is not None:
                items.append(current)
            current = {"id": m_id.group(1).strip()}
        elif m_kv and current is not None:
            k, v = m_kv.group(1), m_kv.group(2).strip()
            current[k] = v
    if current is not None:
        items.append(current)
    return items


def read_conf_actions(path):
    out = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        parts = s.split(None, 1)
        if len(parts) == 2:
            out.append((parts[0], parts[1].strip()))
    return out


def read_pem_blocks(path):
    """Map `# anchor <id>` labels to the body lines of the following PEM block."""
    blocks = {}
    anchor_id = None
    body = None
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        m = re.match(r"^#\s*anchor\s+(\S+)", line)
        if m:
            anchor_id = m.group(1)
        elif line == "-----BEGIN VAULT ANCHOR-----":
            body = []
        elif line == "-----END VAULT ANCHOR-----":
            if anchor_id is not None and body is not None:
                blocks[anchor_id] = body
            anchor_id, body = None, None
        elif body is not None and line:
            body.append(line)
    return blocks


def read_lines(path):
    return [
        line.strip()
        for line in Path(path).read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]


# --------------------- derivation ---------------------

def derive_values(data_dir):
    d = Path(data_dir)
    defaults = load_json(d / "defaults.json")
    schema = load_json(d / "config_schema.json")

    # pbkdf_iterations
    actors = read_jsonl(d / "threat_actors.jsonl")
    active_actors = [a for a in actors if a.get("status") == "active" and not a.get("quarantined")]
    max_tier = max((int(a["tier"]) for a in active_actors), default=1)
    pbkdf_iterations = int(defaults["base_pbkdf_iters"]) + (2 ** max_tier)
    threat_high = sum(1 for a in active_actors if int(a["tier"]) >= 4)

    # session_ttl
    factors = read_csv(d / "mfa_factors.csv")
    total_reduction = sum(
        int(f["step_reduction_seconds"])
        for f in factors
        if f["enabled"] == "true" and f["deprecated"] == "false"
    )
    hardening = read_yaml_list(d / "hardening_profiles.yaml", "profiles")
    base_offset = 0
    for p in hardening:
        if p["id"] == "base":
            base_offset = int(p["session_ttl_offset"])
            break
    session_ttl = int(defaults["base_session_ttl"]) - total_reduction + base_offset

    lifetimes = read_csv(d / "session_lifetimes.csv")
    base_idle = [int(r["idle_seconds"]) for r in lifetimes if r["tier"] == "base" and r["active"] == "true"]
    session_idle = min(base_idle) if base_idle else int(defaults["base_idle_timeout"])

    # rate_limit
    rl = read_csv(d / "rate_limits.csv")
    delta = sum(
        int(r["concurrency_delta"])
        for r in rl
        if r["zone"] in {"internal", "admin"} and r["deprecated"] == "false"
    )
    rate_limit_rps = int(defaults["base_rate_rps"]) + delta
    rate_limit_burst = rate_limit_rps * int(defaults["base_rate_burst_factor"])

    quorum = sum(
        int(f["weight"])
        for f in factors
        if f["enabled"] == "true" and f["deprecated"] == "false" and f["factor_class"] == "strong"
    )

    secret_classes = read_yaml_list(d / "secret_classes.yaml", "classes")
    required_rot = [int(c["rotation_days_min"]) for c in secret_classes if c["required"] == "true"]
    secret_rotation_days = min(required_rot) if required_rot else int(defaults["base_rotation_days"])

    audit = read_properties(d / "audit_sampling.properties")
    audit_delta = 0
    channels = set()
    for k in audit:
        m = re.match(r"^sampling\.(.+)\.(enabled|delta)$", k)
        if m:
            channels.add(m.group(1))
    for ch in channels:
        if audit.get(f"sampling.{ch}.enabled") == "true":
            audit_delta += int(audit.get(f"sampling.{ch}.delta", "0"))
    audit_ppm = int(defaults["base_audit_ratio_ppm"]) + audit_delta

    tokens = read_tsv(d / "token_entropy.tsv")
    req_bits = [int(t["entropy_bits"]) for t in tokens if t["policy"] == "required"]
    token_entropy = max(req_bits) if req_bits else int(defaults["base_token_bits"])

    trust = read_csv(d / "trust_anchor_scores.csv")
    trust_score = sum(
        int(r["score"])
        for r in trust
        if r["status"] == "active" and r["rotation_ok"] == "true"
    )

    egress = read_conf_actions(d / "egress_hosts.conf")
    allow_hosts = {host for act, host in egress if act == "allow"}
    denylist = set(read_lines(d / "egress_denylist.txt"))
    egress_rules = len(allow_hosts - denylist)

    ciphers = read_lines(d / "cipher_suites.txt")
    depr = read_jsonl(d / "cipher_deprecations.jsonl")
    depr_names = {e["cipher"] for e in depr if e.get("deprecated_at")}
    active_ciphers = [c for c in ciphers if c not in depr_names]

    frameworks = read_yaml_list(d / "compliance_frameworks.yaml", "frameworks")
    fw_weight = {f["id"]: int(f["weight"]) for f in frameworks}
    mappings = read_csv(d / "compliance_mappings.csv")
    mapped = {m["framework"] for m in mappings if m["status"] == "mapped"}
    compliance = sum(fw_weight.get(f, 0) for f in mapped)

    signers = read_csv(d / "attestation_signers.csv")
    active_signers = sum(1 for s in signers if s["status"] == "active")
    attestation = (active_signers // 2) + 1

    # rbac_edge_count
    roles = read_csv(d / "rbac_roles.csv")
    active_roles = {r["role_id"] for r in roles if r["active"] == "true"}
    perms = read_tsv(d / "rbac_permissions.tsv")
    active_perms = {p["perm_id"] for p in perms if p["active"] == "true"}
    bindings = read_jsonl(d / "rbac_bindings.jsonl")
    rbac_edges = sum(
        1
        for b in bindings
        if b["role"] in active_roles and b["permission"] in active_perms
    )

    firewall = read_tsv(d / "firewall_rules.tsv")
    firewall_deny = sum(1 for r in firewall if r["action"] == "deny")

    hash_algos = read_csv(d / "hash_algorithms.csv")
    hash_score = sum(int(r["weight"]) for r in hash_algos if r["deprecated"] == "false")

    cert = read_csv(d / "cert_expiry.csv")
    cert_expiring = sum(
        1 for r in cert if r["status"] == "active" and 0 <= int(r["expiry_days"]) <= 30
    )

    return {
        "active_cipher_count": len(active_ciphers),
        "attestation_quorum": attestation,
        "audit_sample_ratio_ppm": audit_ppm,
        "cert_expiring_soon": cert_expiring,
        "checksum": defaults["checksum"],
        "compliance_score": compliance,
        "container": schema["container"],
        "egress_rules_count": egress_rules,
        "firewall_deny_count": firewall_deny,
        "hash_algo_score": hash_score,
        "mfa_quorum_threshold": quorum,
        "mode": defaults["mode"],
        "pbkdf_iterations": pbkdf_iterations,
        "producer": schema["producer"],
        "profile": schema["profile"],
        "rate_limit_burst": rate_limit_burst,
        "rate_limit_rps": rate_limit_rps,
        "rbac_edge_count": rbac_edges,
        "secret_rotation_days": secret_rotation_days,
        "session_idle_timeout_seconds": session_idle,
        "session_ttl_seconds": session_ttl,
        "threat_high_actors": threat_high,
        "token_entropy_bits": token_entropy,
        "trailer": schema["trailer"],
        "trust_anchor_score": trust_score,
    }, active_ciphers


# --------------------- commands ---------------------

def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        key: coerce(value)
        for key, value in schema.items()
        if key != "required_keys" and not isinstance(value, (dict, list))
    }
    assert_flat(data)
    write_json(args.out, data)
    print("initialized")


def cmd_derive(args):
    values, _ = derive_values(args.data)
    write_json(args.out, values)
    print("derived")


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = coerce(args.value)
    write_json(args.config, data)
    print("set " + args.key)


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    assert_flat(data)
    missing = [k for k in schema["required_keys"].split(",") if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    bounds = load_json(args.rules).get("numeric_bounds", {})
    for key, (lo, hi) in bounds.items():
        if key in data:
            v = data[key]
            if not isinstance(v, int) or v < lo or v > hi:
                raise SystemExit(f"out-of-bounds: {key}={v}")
    print("ok")


def cmd_emit_profile(args):
    schema = load_json(args.schema)
    base = load_json(args.config)
    overrides = load_json(args.overrides)[args.name]
    hardening = read_yaml_list(Path(args.data) / "hardening_profiles.yaml", "profiles")
    offset = 0
    idle_offset = 0
    for p in hardening:
        if p["id"] == args.name:
            offset = int(p["session_ttl_offset"])
            idle_offset = int(p["idle_timeout_offset"])
            break
    pbkdf = (base["pbkdf_iterations"] * int(overrides["pbkdf_scale_num"])) // int(overrides["pbkdf_scale_den"])
    out = dict(base)
    out["session_ttl_seconds"] = base["session_ttl_seconds"] + int(overrides["session_ttl_delta"]) + offset
    out["session_idle_timeout_seconds"] = base["session_idle_timeout_seconds"] + idle_offset
    out["pbkdf_iterations"] = pbkdf
    out["mfa_quorum_threshold"] = base["mfa_quorum_threshold"] + int(overrides["mfa_quorum_delta"])
    out["rate_limit_rps"] = base["rate_limit_rps"] + int(overrides["rate_limit_delta"])
    out["rate_limit_burst"] = out["rate_limit_rps"] * int(load_json(Path(args.data)/"defaults.json")["base_rate_burst_factor"])
    out["profile"] = f"{schema['profile']}-{args.name}"
    out["trailer"] = f"{schema['trailer']}:{overrides['trailer_suffix']}"
    assert_flat(out)
    write_json(args.out, out)
    print("profile " + args.name)


def cmd_emit_artifact(args):
    kind = args.kind
    data = Path(args.data)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if kind == "policy_matrix":
        roles = read_csv(data / "rbac_roles.csv")
        perms = read_tsv(data / "rbac_permissions.tsv")
        active_roles = [r["role_id"] for r in roles if r["active"] == "true"]
        active_perms = [p["perm_id"] for p in perms if p["active"] == "true"]
        bindings = {(b["role"], b["permission"]) for b in read_jsonl(data / "rbac_bindings.jsonl")}
        header = "role_id," + ",".join(active_perms)
        lines = [header]
        for r in active_roles:
            row = [r] + ["1" if (r, p) in bindings else "0" for p in active_perms]
            lines.append(",".join(row))
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "rate_limits":
        rl = read_csv(data / "rate_limits.csv")
        active = [r for r in rl if r["zone"] in {"internal", "admin"} and r["deprecated"] == "false"]
        lines = ["endpoint\tzone\teffective_rps\tconcurrency_delta"]
        for r in sorted(active, key=lambda x: x["endpoint"]):
            eff = int(r["base_rps"]) + int(r["concurrency_delta"])
            lines.append(f"{r['endpoint']}\t{r['zone']}\t{eff}\t{r['concurrency_delta']}")
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "rotation_schedule":
        classes = read_yaml_list(data / "secret_classes.yaml", "classes")
        req = sorted([c for c in classes if c["required"] == "true"], key=lambda c: c["id"])
        lines = ["# secret rotation schedule (required classes only)", "schedule:"]
        for c in req:
            lines.append(f"  - class_id: {c['id']}")
            lines.append(f"    kind: {c['kind']}")
            lines.append(f"    rotation_days_min: {c['rotation_days_min']}")
            lines.append(f"    rotation_days_max: {c['rotation_days_max']}")
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "mfa_quorum":
        factors = read_csv(data / "mfa_factors.csv")
        strong = sorted(
            [f for f in factors if f["enabled"] == "true" and f["deprecated"] == "false" and f["factor_class"] == "strong"],
            key=lambda f: f["factor_id"],
        )
        quorum = sum(int(f["weight"]) for f in strong)
        lines = ["# mfa quorum", f"quorum_threshold = {quorum}"]
        for f in strong:
            lines.append("")
            lines.append("[[factor]]")
            lines.append(f"factor_id = \"{f['factor_id']}\"")
            lines.append(f"weight = {int(f['weight'])}")
            lines.append(f"step_reduction_seconds = {int(f['step_reduction_seconds'])}")
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "audit_sampling":
        audit = read_properties(data / "audit_sampling.properties")
        channels = set()
        for k in audit:
            m = re.match(r"^sampling\.(.+)\.(enabled|delta)$", k)
            if m:
                channels.add(m.group(1))
        enabled = sorted(ch for ch in channels if audit.get(f"sampling.{ch}.enabled") == "true")
        lines = ["; audit sampling (enabled channels only)", "[audit]"]
        for ch in enabled:
            lines.append(f"{ch} = {audit.get(f'sampling.{ch}.delta','0')}")
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "threat_scores":
        actors = read_jsonl(data / "threat_actors.jsonl")
        active = sorted(
            [a for a in actors if a["status"] == "active" and not a.get("quarantined")],
            key=lambda a: a["id"],
        )
        lines = []
        for a in active:
            lines.append(json.dumps({"actor_id": a["id"], "tier": a["tier"], "region": a["region"]}, sort_keys=True))
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "cipher_priority":
        ciphers = read_lines(data / "cipher_suites.txt")
        depr = {e["cipher"] for e in read_jsonl(data / "cipher_deprecations.jsonl") if e.get("deprecated_at")}
        active = [c for c in ciphers if c not in depr]
        out.write_text("\n".join(active) + "\n", encoding="utf-8")
    elif kind == "egress_allowlist":
        egress = read_conf_actions(data / "egress_hosts.conf")
        allow = [host for act, host in egress if act == "allow"]
        deny = set(read_lines(data / "egress_denylist.txt"))
        effective = sorted(set(allow) - deny)
        lines = [f"allow {host}" for host in effective]
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "session_policy":
        cfg = load_json(args.config)
        lines = [
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
            "<sessionPolicy>",
            f"  <ttlSeconds>{cfg['session_ttl_seconds']}</ttlSeconds>",
            f"  <idleTimeoutSeconds>{cfg['session_idle_timeout_seconds']}</idleTimeoutSeconds>",
            f"  <mfaQuorum>{cfg['mfa_quorum_threshold']}</mfaQuorum>",
            f"  <tokenEntropyBits>{cfg['token_entropy_bits']}</tokenEntropyBits>",
            "</sessionPolicy>",
        ]
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "trust_anchor_manifest":
        scores = read_csv(data / "trust_anchor_scores.csv")
        blocks = read_pem_blocks(data / "trust_anchors.pem")
        active = sorted(
            [r for r in scores if r["status"] == "active" and r["rotation_ok"] == "true"],
            key=lambda r: r["anchor_id"],
        )
        lines = []
        for r in active:
            body = blocks.get(r["anchor_id"])
            if body is None:
                continue
            lines.append(f"# anchor {r['anchor_id']} score={r['score']}")
            lines.append("-----BEGIN VAULT ANCHOR-----")
            lines.extend(body)
            lines.append("-----END VAULT ANCHOR-----")
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "compliance_map":
        fw = {f["id"]: int(f["weight"]) for f in read_yaml_list(data / "compliance_frameworks.yaml", "frameworks")}
        mappings = read_csv(data / "compliance_mappings.csv")
        mapped = {m["framework"] for m in mappings if m["status"] == "mapped"}
        rows = sorted(mapped)
        lines = ["# Compliance Map", "", "| framework | weight |", "|---|---|"]
        for f in rows:
            lines.append(f"| {f} | {fw.get(f, 0)} |")
        lines.append("")
        lines.append(f"total_score={sum(fw.get(f, 0) for f in rows)}")
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "attestation_ledger":
        signers = read_csv(data / "attestation_signers.csv")
        active = sorted([s for s in signers if s["status"] == "active"], key=lambda s: s["signer_id"])
        lines = []
        for s in active:
            lines.append(f"attest signer={s['signer_id']} strength={s['strength']} rotated_days={s['rotated_days']}")
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "derived_metrics":
        cfg = load_json(args.config)
        keys = [
            "pbkdf_iterations",
            "session_ttl_seconds",
            "session_idle_timeout_seconds",
            "rate_limit_rps",
            "rate_limit_burst",
            "mfa_quorum_threshold",
            "secret_rotation_days",
            "audit_sample_ratio_ppm",
            "token_entropy_bits",
            "trust_anchor_score",
            "egress_rules_count",
            "active_cipher_count",
            "compliance_score",
            "threat_high_actors",
            "attestation_quorum",
            "rbac_edge_count",
            "firewall_deny_count",
            "hash_algo_score",
            "cert_expiring_soon",
        ]
        lines = []
        for k in keys:
            lines.append(f"IRONVAULT_{k.upper()}={cfg[k]}")
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "canary_thresholds":
        cfg = load_json(args.config)
        lines = [
            "# canary thresholds derived from active security policy",
            f"canary.error_pct={max(1, cfg['audit_sample_ratio_ppm'] // 10000)}",
            f"canary.latency_budget_ms={cfg['session_idle_timeout_seconds']}",
            f"canary.min_signers={cfg['attestation_quorum']}",
            f"canary.max_deny_rate={cfg['firewall_deny_count']}",
        ]
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    elif kind == "checksum_manifest":
        out_dir = Path(args.out_dir)
        rules = load_json(data / "validation_rules.json")
        self_name = out.name
        lines = []
        for name in rules["required_artifacts"]:
            if name == self_name:
                continue
            p = out_dir / name
            if p.exists():
                digest = hashlib.sha256(p.read_bytes()).hexdigest()
                lines.append(f"{digest}  {name}")
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    else:
        raise SystemExit(f"unknown kind: {kind}")
    print("emit " + kind)


def cmd_export_report(args):
    data = load_json(args.config)
    assert_flat(data)
    commands = json.loads(args.commands)
    commands.append({
        "argv": ["python3", "cli.py", "export-report", "--config", args.config, "--out", args.out, "--digest", args.digest],
        "returncode": 0,
        "stdout": "reported",
    })
    report = {
        "ok": True,
        "tool": "nonce-ctl",
        "config_path": args.config,
        "config_sha256": args.digest,
        "commands": commands,
        "trailer": data.get("trailer"),
    }
    write_json(args.out, report)
    print("reported")


def main():
    parser = argparse.ArgumentParser(prog="nonce-ctl")
    sub = parser.add_subparsers(dest="command")
    p = sub.add_parser("init"); p.add_argument("--schema", required=True); p.add_argument("--out", required=True); p.add_argument("--config", required=False); p.set_defaults(func=cmd_init)
    p = sub.add_parser("derive"); p.add_argument("--data", required=True); p.add_argument("--out", required=True); p.set_defaults(func=cmd_derive)
    p = sub.add_parser("set"); p.add_argument("--config", required=True); p.add_argument("--key", required=True); p.add_argument("--value", required=True); p.set_defaults(func=cmd_set)
    p = sub.add_parser("validate"); p.add_argument("--schema", required=True); p.add_argument("--config", required=True); p.add_argument("--rules", required=True); p.set_defaults(func=cmd_validate)
    p = sub.add_parser("emit-profile"); p.add_argument("--schema", required=True); p.add_argument("--config", required=True); p.add_argument("--overrides", required=True); p.add_argument("--data", required=True); p.add_argument("--name", required=True); p.add_argument("--out", required=True); p.set_defaults(func=cmd_emit_profile)
    p = sub.add_parser("emit-artifact"); p.add_argument("--kind", required=True); p.add_argument("--data", required=True); p.add_argument("--out", required=True); p.add_argument("--config", required=False); p.add_argument("--out-dir", required=False, dest="out_dir"); p.set_defaults(func=cmd_emit_artifact)
    p = sub.add_parser("export-report"); p.add_argument("--config", required=True); p.add_argument("--out", required=True); p.add_argument("--digest", required=True); p.add_argument("--commands", required=True); p.set_defaults(func=cmd_export_report)
    args = parser.parse_args()
    if getattr(args, "command", None) is None or not hasattr(args, "func"):
        parser.print_usage(sys.stderr)
        print("nonce-ctl: error: a subcommand is required", file=sys.stderr)
        return 2
    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
