#!/usr/bin/env python3
"""estatectl - consolidate estate inventories into placement manifests.

Usage:
  python3 estatectl.py run --data DIR --out DIR
  python3 estatectl.py export-report --config FILE --out FILE --commands JSON

The tool reads only the directory given by --data (plus its own archive members)
and writes only into the directory given by --out.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import csv
import email
import email.utils
import hashlib
import html as htmlmod
import io
import json
import re
import sqlite3
import sys
import tomllib
import unicodedata
import zipfile
from decimal import Decimal, ROUND_HALF_EVEN, ROUND_FLOOR
from pathlib import Path

import yaml

csv.field_size_limit(1 << 24)


class _YamlLoader(yaml.SafeLoader):
    """SafeLoader that keeps ISO timestamps as plain strings."""


for _ch, _rs in list(_YamlLoader.yaml_implicit_resolvers.items()):
    _YamlLoader.yaml_implicit_resolvers[_ch] = [
        (t, r) for (t, r) in _rs if t != "tag:yaml.org,2002:timestamp"]


def yaml_load(text):
    return yaml.load(text, Loader=_YamlLoader)

# ------------------------------------------------------------- text normalising

_ZAP = {0xFEFF: None, 0x200B: None}


def norm(s):
    """Section 2.3: drop U+FEFF/U+200B, trim spaces, normalise to NFC."""
    if s is None:
        return ""
    if not isinstance(s, str):
        if isinstance(s, float) and s.is_integer():
            s = str(int(s))
        else:
            s = str(s)
    s = s.translate(_ZAP).strip()
    if not s.isascii():
        s = unicodedata.normalize("NFC", s)
    return s


def ident(s):
    """Identifiers compare case-insensitively and are written upper case."""
    return norm(s).upper()


def lc(s):
    return norm(s).lower()


_TRUE = {"true", "yes", "on", "1"}
_FALSE = {"false", "no", "off", "0"}


def as_bool(v):
    if isinstance(v, bool):
        return v
    s = lc(v)
    if s in _TRUE:
        return True
    if s in _FALSE:
        return False
    return None


_GROUPING = "\u00a0\u2007\u2009\u202f\u2019'. ,"


def _degroup(s, keep=""):
    out = []
    for ch in s:
        if ch in _GROUPING and ch not in keep:
            continue
        out.append(ch)
    return "".join(out)


def as_int(v, ini=False):
    """Integer, tolerating grouping separators (and ini KiB/MiB suffixes)."""
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        return int(v)
    s = norm(v)
    if not s:
        return None
    mult = 1
    if ini:
        m = re.match(r"^(.*?)[ \t]*(KiB|MiB|GiB|KB|MB|B)$", s)
        if m:
            s = m.group(1).strip()
            mult = {"B": 1, "KB": 1000, "MB": 1000000, "KiB": 1024,
                    "MiB": 1048576, "GiB": 1073741824}[m.group(2)]
    neg = s.startswith("-")
    if neg or s.startswith("+"):
        s = s[1:]
    s = _degroup(s).replace("_", "")
    if not s or not s.isdigit():
        return None
    n = int(s) * mult
    return -n if neg else n

# ------------------------------------------------------------- control records

_CTL_KEYS = {"ctl_id": "ctl_id", "prev": "prev", "rows": "rows",
             "ctl-id": "ctl_id", "ctl-prev": "prev", "ctl-rows": "rows",
             "ctl_prev": "prev", "ctl_rows": "rows"}


def parse_kv_line(text):
    """Parse `a=b c=d` style metadata, tolerating quoted values."""
    out = {}
    for m in re.finditer(r'([A-Za-z_][\w.-]*)=("(?:\\.|[^"])*"|\S*)', text or ""):
        k, v = m.group(1), m.group(2)
        if v.startswith('"'):
            v = unescape_quoted(v[1:-1])
        out[k] = v
    return out


def unescape_quoted(s):
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            out.append(s[i + 1])
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def ctl_of(mapping):
    out = {}
    for k, v in (mapping or {}).items():
        kk = _CTL_KEYS.get(str(k).strip().lower())
        if kk:
            out[kk] = v
    rows = re.search(r"\d+", norm(out.get("rows")))
    return {"ctl_id": ident(out.get("ctl_id")),
            "prev": ident(out.get("prev")),
            "rows": int(rows.group(0)) if rows else 0}


# ------------------------------------------------------------- header handling

ALIAS = {
    "remark": "note", "state": "status", "why": "reason", "owned_by": "owner",
    "bytes_raw": "size", "label": "display", "rev_v2": "rev",
    "size_bytes": "size", "owner_sid": "owner",
}

_IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")


def header_mapping(canon, names, renames=None):
    """Map a (possibly renamed and reordered) header onto the canonical names.

    Returns (mapped names, list of names that needed guessing) or (None, ...)
    when the header cannot be lined up with the canonical one."""
    inv = {}
    for old, new in (renames or {}).items():
        inv[norm(new)] = norm(old)
    canon_set = set(canon)
    out = []
    unknown = []
    for name in names:
        n = norm(name)
        if inv.get(n) in canon_set:
            out.append(inv[n])
        elif n in canon_set:
            out.append(n)
        elif ALIAS.get(n) in canon_set:
            out.append(ALIAS[n])
        elif n.endswith("_v2") and n[:-3] in canon_set:
            out.append(n[:-3])
        else:
            out.append(None)
            unknown.append(n)
    missing = [c for c in canon if c not in out]
    if len(missing) != len(unknown):
        return None, unknown
    spare = iter(missing)
    return [x if x is not None else next(spare) for x in out], unknown


def map_names(canon, names, renames=None):
    mapped, _unknown = header_mapping(canon, names, renames)
    return mapped if mapped is not None else [norm(n) for n in names]


def looks_header(fields, canon):
    if canon is None or len(fields) != len(canon):
        return False
    vals = []
    for f in fields:
        if not isinstance(f, str):
            return False
        f = norm(f)
        if not f or not _IDENT_RE.match(f):
            return False
        vals.append(f)
    if len(set(vals)) != len(vals):
        return False
    mapped, unknown = header_mapping(canon, vals)
    if mapped is None:
        return False
    # guessing a column name is only safe when nearly all names are known
    return len(unknown) == 0 or (len(unknown) == 1 and len(canon) >= 4)


def rows_from_matrix(matrix):
    """Turn a list of field lists (first row = header) into dicts, honouring
    repeated headers with a changed column order or renamed columns."""
    out = []
    canon = None
    names = None
    for fields in matrix:
        if canon is None:
            canon = [norm(f) for f in fields]
            names = canon
            continue
        if looks_header(fields, canon):
            names = map_names(canon, fields)
            continue
        out.append(dict(zip(names, fields)))
    return canon or [], out


# ---------------------------------------------------------------- delimited

def _read_bytes(path):
    with open(path, "rb") as fh:
        return fh.read()


def read_csv_file(path):
    raw = _read_bytes(path)
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252")
    ctl = {}
    meta = []
    matrix = []
    for fields in csv.reader(io.StringIO(text, newline="")):
        if not fields or (len(fields) == 1 and not fields[0].strip()):
            continue
        first = fields[0]
        if first.startswith("#"):
            body = first.lstrip("#").strip()
            if body.lower().startswith("ctl "):
                ctl = ctl_of(parse_kv_line(body[4:]))
            else:
                meta.append(",".join(fields).lstrip("#").strip())
            continue
        matrix.append(fields)
    cols, rows = rows_from_matrix(matrix)
    return ctl, meta, cols, rows


_TSV_UNESC = {"t": "\t", "n": "\n", "r": "\r", "\\": "\\"}


def tsv_unescape(s):
    if "\\" not in s:
        return s
    out = []
    i = 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s):
            out.append(_TSV_UNESC.get(s[i + 1], s[i + 1]))
            i += 2
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def read_tsv_file(path):
    raw = _read_bytes(path)
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    ctl = {}
    meta = []
    matrix = []
    enc_idx = None
    for line in raw.split(b"\n"):
        line = line.rstrip(b"\r")
        if not line.strip():
            continue
        try:
            text = line.decode("utf-8")
        except UnicodeDecodeError:
            text = line.decode("latin-1")
        if text.startswith("#"):
            body = text.lstrip("#").strip()
            if body.lower().startswith("ctl "):
                ctl = ctl_of(parse_kv_line(body[4:]))
            else:
                meta.append(body)
            continue
        fields = text.split("\t")
        if enc_idx is not None and enc_idx < len(fields):
            want = norm(fields[enc_idx]).lower()
            if want and want not in ("utf-8", "utf8"):
                try:
                    fields = line.decode(want).split("\t")
                except (UnicodeDecodeError, LookupError):
                    pass
        fields = [tsv_unescape(f) for f in fields]
        if not matrix:
            if "enc" in [norm(f) for f in fields]:
                enc_idx = [norm(f) for f in fields].index("enc")
        matrix.append(fields)
    cols, rows = rows_from_matrix(matrix)
    return ctl, meta, cols, rows


def read_delimited(path):
    if str(path).endswith(".tsv"):
        return read_tsv_file(path)
    return read_csv_file(path)


# ---------------------------------------------------------------- jsonl / json

def read_jsonl_file(path):
    ctl = {}
    meta = {}
    rows = []
    renames = {}
    with open(path, "r", encoding="utf-8-sig") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            if not isinstance(obj, dict):
                continue
            if "_ctl" in obj:
                ctl = ctl_of(obj["_ctl"])
                continue
            if "_schema" in obj:
                renames = obj["_schema"].get("rename", {}) or {}
                continue
            special = [k for k in obj if k.startswith("_")]
            if special and len(obj) == 1:
                meta.update(obj[special[0]] if isinstance(obj[special[0]], dict)
                            else {special[0]: obj[special[0]]})
                continue
            if renames:
                inv = {norm(v): norm(k) for k, v in renames.items()}
                obj = {inv.get(k, k): v for k, v in obj.items()}
            rows.append(obj)
    return ctl, meta, rows


def read_json_file(path):
    with open(path, "r", encoding="utf-8-sig") as fh:
        doc = json.load(fh)
    ctl = ctl_of(doc.get("_ctl", {}))
    return ctl, doc


def json_list(doc, name):
    """A json list plus its <name>_v2 continuation with renamed keys."""
    rows = list(doc.get(name) or [])
    v2 = doc.get(name + "_v2")
    if v2:
        renames = doc.get(name + "_v2_renames") or {}
        inv = {norm(v): norm(k) for k, v in renames.items()}
        for obj in v2:
            rows.append({inv.get(k, k): v for k, v in obj.items()})
    return rows


# ---------------------------------------------------------------------- xlsx

def read_xlsx_file(path):
    import openpyxl

    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ctl = ctl_of(parse_kv_line(wb.properties.subject or ""))
    meta = parse_kv_line(wb.properties.description or "")
    sheets = {}
    order = []
    for ws in wb:
        matrix = [list(r) for r in ws.iter_rows(values_only=True)]
        matrix = [r for r in matrix if any(c is not None and norm(c) != "" for c in r)]
        cols, rows = rows_from_matrix(matrix)
        sheets[ws.title] = rows
        order.append(ws.title)
    epoch1904 = str(getattr(wb, "epoch", "")).startswith("1904")
    wb.close()
    return ctl, meta, sheets, order, epoch1904


# ----------------------------------------------------------------------- xml

def read_xml_file(path):
    from lxml import etree

    tree = etree.parse(str(path))
    root = tree.getroot()
    ctl = ctl_of(dict(root.attrib))
    rootattr = {norm(k).replace("-", "_"): norm(v) for k, v in root.attrib.items()}
    rows = []
    renames = {}
    for el in root:
        tag = etree.QName(el).localname if not isinstance(el.tag, str) else el.tag
        if not isinstance(el.tag, str):
            continue
        if tag == "schema-change":
            renames = json.loads(el.get("renames") or "{}")
            continue
        rec = {"_tag": tag}
        for k, v in el.attrib.items():
            rec[norm(k).replace("-", "_")] = v
        for ch in el:
            if not isinstance(ch.tag, str):
                continue
            rec[norm(ch.tag)] = ch.text or ""
            for k, v in ch.attrib.items():
                rec[norm(ch.tag) + "@" + norm(k)] = v
        if renames:
            inv = {norm(v): norm(k) for k, v in renames.items()}
            fixed = {}
            for k, v in rec.items():
                base, at, attr = k.partition("@")
                base = inv.get(base, base)
                fixed[base + at + attr] = v
            rec = fixed
        rows.append(rec)
    return ctl, rootattr, rows


# ------------------------------------------------------------------- parquet

def read_parquet_file(path):
    import pyarrow.parquet as pq

    table = pq.read_table(str(path))
    md = {k.decode(): v.decode() for k, v in (table.schema.metadata or {}).items()}
    ctl = ctl_of(md)
    cols = {name: table.column(name).to_pylist() for name in table.schema.names}
    n = table.num_rows
    rows = [{name: cols[name][i] for name in table.schema.names} for i in range(n)]
    return ctl, md, rows


# -------------------------------------------------------------------- sqlite

def read_sqlite_file(path):
    con = sqlite3.connect("file:%s?mode=ro" % str(path).replace("?", "%3f"), uri=True)
    con.row_factory = sqlite3.Row
    names = [r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type IN ('table','view')")]
    ctl = {}
    meta = {}
    if "_control" in names:
        ctl = ctl_of(dict(con.execute("SELECT * FROM _control").fetchone()))
    if "_export" in names:
        meta = {k: v for k, v in dict(con.execute("SELECT * FROM _export").fetchone()).items()}
    tables = {}
    for nm in names:
        if nm.startswith("_") or nm.startswith("sqlite_"):
            continue
        tables[nm] = [dict(r) for r in con.execute('SELECT * FROM "%s"' % nm)]
    con.close()
    return ctl, meta, tables


def sqlite_table(tables, base):
    """Base table plus its _v2 continuation (renamed columns)."""
    rows = list(tables.get(base) or [])
    canon = list(rows[0].keys()) if rows else []
    v2 = tables.get(base + "_v2")
    if v2:
        for r in v2:
            names = map_names(canon, list(r.keys()))
            rows.append(dict(zip(names, r.values())))
    return rows


# ---------------------------------------------------------------------- docx

def read_docx_file(path):
    import docx

    doc = docx.Document(str(path))
    ctl = ctl_of(parse_kv_line(doc.core_properties.subject or ""))
    paras = [p.text for p in doc.paragraphs if p.text.strip()]
    tables = []
    for t in doc._body.tables if hasattr(doc._body, "tables") else doc.tables:
        matrix = []
        for row in t.rows:
            matrix.append([c.text for c in row.cells])
        tables.append(matrix)
    return ctl, paras, tables


def docx_rows(tables):
    """All tables of a document read as one table with header drift."""
    matrix = []
    for t in tables:
        matrix.extend(t)
    return rows_from_matrix(matrix)


# ----------------------------------------------------------------------- pdf

_PDF_ESC = re.compile(r"\\(u[0-9a-fA-F]{4}|.)")


def pdf_unescape(cell):
    def rep(m):
        g = m.group(1)
        if g[0] == "u" and len(g) == 5:
            return chr(int(g[1:], 16))
        return g
    return _PDF_ESC.sub(rep, cell)


def read_pdf_file(path):
    import pypdf

    reader = pypdf.PdfReader(str(path))
    ctl = {}
    preamble = []
    blocks = []
    cols = None
    for page in reader.pages:
        for line in page.extract_text().split("\n"):
            line = line.rstrip()
            if not line.strip():
                continue
            if not ctl and line.startswith("CONTROL"):
                ctl = ctl_of(parse_kv_line(line[7:]))
                continue
            if line.startswith("COLUMNS:"):
                new = [norm(x) for x in line[8:].split("|")]
                if cols is None or set(new) != set(cols):
                    blocks.append((new, []))
                cols = new
                continue
            if cols is None:
                preamble.append(line)
                continue
            cells = [pdf_unescape(c.strip()) for c in line.split(" | ")]
            cells = ["" if c == "~" else c for c in cells]
            if len(cells) != len(cols):
                preamble.append(line)
                continue
            names = map_names(blocks[-1][0], cols)
            blocks[-1][1].append(dict(zip(names, cells)))
    return ctl, preamble, blocks


# ------------------------------------------------------------------ md / html

def read_md_file(path):
    text = Path(path).read_text(encoding="utf-8")
    ctl = {}
    m = re.search(r"<!--\s*ctl\s+(.*?)-->", text)
    if m:
        ctl = ctl_of(parse_kv_line(m.group(1)))
    return ctl, text


_MD_SPLIT = re.compile(r"(?<!\\)\|")
_MD_ESC = re.compile(r"\\(.)")


def md_tables(text):
    """All pipe tables of a markdown fragment, merged with header drift."""
    matrix = []
    for line in text.split("\n"):
        line = line.strip()
        if not line.startswith("|"):
            continue
        parts = _MD_SPLIT.split(line)
        if len(parts) >= 3 and parts[-1].strip() == "":
            parts = parts[1:-1]
        else:
            parts = parts[1:]
        fields = [_MD_ESC.sub(r"\1", c.strip()) for c in parts]
        if fields and all(set(c) <= set("-: ") and c for c in fields):
            continue
        matrix.append(fields)
    return rows_from_matrix(matrix)


def read_html_file(path):
    from lxml import html as lhtml

    raw = Path(path).read_bytes()
    text = raw.decode("utf-8")
    ctl = {}
    m = re.search(r"<!--\s*ctl\s+(.*?)-->", text)
    if m:
        ctl = ctl_of(parse_kv_line(m.group(1)))
    doc = lhtml.fromstring(text)
    sections = []
    current = None
    for el in doc.iter():
        if not isinstance(el.tag, str):
            continue
        if el.tag in ("h1", "h2", "h3"):
            current = (norm(el.text_content()), [])
            sections.append(current)
        elif el.tag == "table":
            matrix = []
            for tr in el.iter("tr"):
                matrix.append([norm(td.text_content()) for td in tr
                               if isinstance(td.tag, str) and td.tag in ("td", "th")])
            if current is None:
                current = ("", [])
                sections.append(current)
            current[1].append(matrix)
    return ctl, sections


def html_section(sections, needle):
    want = needle.lower()
    best = None
    for title, tables in sections:
        low = title.lower()
        if not tables:
            continue
        if low == want:
            best = tables
            break
        if best is None and want in low:
            best = tables
    matrix = []
    for t in (best or ()):
        matrix.extend(t)
    return rows_from_matrix(matrix)[1]


# ----------------------------------------------------------------------- ini

def read_ini_file(path):
    raw = _read_bytes(path)
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252")
    ctl = {}
    layout = {}
    sections = []
    cur = None
    for line in text.split("\n"):
        line = line.rstrip("\r")
        if not line.strip():
            continue
        if line.startswith("["):
            end = line.rfind("]")
            name = line[1:end]
            cur = (name, {})
            sections.append(cur)
            continue
        if "=" not in line or cur is None:
            continue
        k, v = line.split("=", 1)
        cur[1][k.strip()] = v.strip()
    out = []
    inv = {}
    for name, opts in sections:
        if name == "_ctl":
            ctl = ctl_of(opts)
            continue
        if name == "__layout__":
            layout = opts
            if layout.get("renames"):
                inv = {norm(v): norm(k)
                       for k, v in json.loads(layout["renames"]).items()}
            continue
        if inv:
            opts = {inv.get(k, k): v for k, v in opts.items()}
        out.append((name, opts))
    return ctl, out, layout


# --------------------------------------------------------------- fixed width

def read_fixed_file(path):
    raw = _read_bytes(path)
    ctl = {}
    meta = {}
    layout = None
    enc = "utf-8"
    canon = None
    rows = []
    pending = None
    for bline in raw.split(b"\n"):
        bline = bline.rstrip(b"\r")
        if not bline.strip():
            continue
        head = bline[:12].decode("latin-1")
        if head.startswith("CTL "):
            ctl = ctl_of(parse_kv_line(bline.decode("latin-1")[4:]))
            continue
        if head.startswith("#LAYOUT"):
            spec = bline.decode("latin-1").split(None, 2)[2]
            layout = []
            for item in spec.split():
                name, rng = item.split(":")
                a, b = rng.split("-")
                layout.append((norm(name), int(a) - 1, int(b)))
            if canon is None:
                canon = [n for n, _, _ in layout]
            continue
        if head.startswith("#ENC"):
            enc = bline.decode("latin-1").split(None, 1)[1].strip()
            continue
        if head.startswith("#"):
            body = bline.decode("latin-1").lstrip("#").strip()
            meta.update(parse_kv_line(body))
            continue
        try:
            text = bline.decode(enc)
        except UnicodeDecodeError:
            text = bline.decode("latin-1")
        if text.startswith("+") and pending is not None:
            pending["path"] = pending["path"] + text[1:].rstrip()
            continue
        rec = {}
        for name, a, b in layout:
            rec[name] = text[a:b].strip()
        names = map_names(canon, list(rec.keys()))
        rec = dict(zip(names, rec.values()))
        if rec.get("path", "").endswith("+"):
            rec["path"] = rec["path"][:-1]
            pending = rec
        else:
            pending = None
        rows.append(rec)
    return ctl, meta, rows


# ----------------------------------------------------------------------- log

def read_log_file(path):
    ctl = {}
    meta = {}
    rows = []
    renames = {}
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            if line.startswith("#"):
                body = line.lstrip("#").strip()
                low = body.lower()
                if low.startswith("ctl "):
                    ctl = ctl_of(parse_kv_line(body[4:]))
                elif low.startswith("format "):
                    for m in re.finditer(r"(\w+)=(\w+)", body.split("renames", 1)[-1]):
                        renames[m.group(1)] = m.group(2)
                elif low.startswith("checkpoint"):
                    pass
                else:
                    meta.update(parse_kv_line(body))
                continue
            rec = parse_kv_line(line)
            if renames:
                inv = {norm(v): norm(k) for k, v in renames.items()}
                rec = {inv.get(k, k): v for k, v in rec.items()}
            rows.append(rec)
    return ctl, meta, rows


# ---------------------------------------------------------------------- mbox

def read_mbox_file(path):
    raw = _read_bytes(path)
    chunks = []
    cur = []
    for line in raw.split(b"\n"):
        if line.startswith(b"From "):
            if cur:
                chunks.append(b"\n".join(cur))
                cur = []
            continue
        cur.append(line)
    if cur:
        chunks.append(b"\n".join(cur))
    ctl = {}
    meta = {}
    rows = []
    renames = {}
    for chunk in chunks:
        if not chunk.strip():
            continue
        msg = email.message_from_bytes(chunk)
        hdrs = {}
        for k, v in msg.items():
            hdrs.setdefault(k, v)
        if "X-Ctl-Id" in hdrs:
            ctl = ctl_of({"ctl_id": hdrs.get("X-Ctl-Id"),
                          "prev": hdrs.get("X-Ctl-Prev"),
                          "rows": hdrs.get("X-Ctl-Rows")})
        if "X-Journal" in hdrs:
            meta.update(parse_kv_line(hdrs["X-Journal"]))
        if "X-Schema" in hdrs:
            for m in re.finditer(r"(X-[\w-]+) renamed (X-[\w-]+)", hdrs["X-Schema"]):
                renames[m.group(1)] = m.group(2)
        payload = msg.get_payload(decode=True)
        if payload is None:
            body = msg.get_payload() or ""
        else:
            charset = msg.get_content_charset() or "utf-8"
            body = payload.decode(charset, "replace")
        body = "\n".join(l[1:] if l.startswith(">From") else l
                         for l in body.split("\n"))
        rec = dict(hdrs)
        if renames:
            inv = {v.lower(): k for k, v in renames.items()}
            rec = {inv.get(k.lower(), k): v for k, v in rec.items()}
        rec["_body"] = body
        rows.append(rec)
    return ctl, meta, rows


# ----------------------------------------------------------------------- ics

_ICS_ESC = {"n": "\n", "N": "\n", ",": ",", ";": ";", "\\": "\\"}


def ics_unescape(s):
    out = []
    i = 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s):
            out.append(_ICS_ESC.get(s[i + 1], s[i + 1]))
            i += 2
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def read_ics_file(path):
    text = Path(path).read_text(encoding="utf-8")
    lines = []
    for line in text.split("\n"):
        line = line.rstrip("\r")
        if line[:1] in (" ", "\t") and lines:
            lines[-1] += line[1:]
        else:
            lines.append(line)
    ctl = {"ctl_id": "", "prev": "", "rows": 0}
    events = []
    cur = None
    schema = 1
    raw_ctl = {}
    for line in lines:
        if not line.strip():
            continue
        if line == "BEGIN:VEVENT":
            cur = {"_schema": schema}
            continue
        if line == "END:VEVENT":
            events.append(cur)
            cur = None
            continue
        if ":" not in line:
            continue
        name, value = line.split(":", 1)
        name = name.split(";")[0].upper()
        value = ics_unescape(value)
        if name == "X-SCHEMA":
            schema = as_int(value) or 1
            continue
        if name.startswith("X-CTL"):
            raw_ctl[name.lower().replace("x-", "")] = value
            continue
        if cur is None:
            continue
        if name == "X-PREFIX":
            name = "X-HOLD-PREFIX"
        cur[name] = value
    if raw_ctl:
        ctl = ctl_of(raw_ctl)
    return ctl, events

# ------------------------------------------------------------------ yaml/toml

def read_yaml_file(path):
    doc = yaml_load(Path(path).read_text(encoding="utf-8"))
    return ctl_of(doc.get("_ctl", {})), doc


def read_toml_file(path):
    with open(path, "rb") as fh:
        doc = tomllib.load(fh)
    return ctl_of(doc.get("_ctl", {})), doc


def yaml_list(doc, name):
    """A yaml/toml list plus its _v2 continuation (renames in a leading item)."""
    rows = list(doc.get(name) or [])
    v2 = list(doc.get(name + "_v2") or [])
    renames = {}
    for item in v2:
        if isinstance(item, dict) and "_renames" in item:
            renames = item["_renames"] or {}
            continue
        if renames:
            inv = {norm(v): norm(k) for k, v in renames.items()}
            item = {inv.get(k, k): v for k, v in item.items()}
        rows.append(item)
    return rows


# ------------------------------------------------------------- the ctl chain

def read_zip_ctl(path):
    with zipfile.ZipFile(path) as zf:
        for name in zf.namelist():
            if name.rsplit("/", 1)[-1] == "CONTROL":
                body = zf.read(name).decode("utf-8-sig")
                return ctl_of(parse_kv_line(body.replace("\n", " ")))
    return {}


def file_register(data):
    """Appendix R of source-register.md: file -> format."""
    _, text = read_md_file(data / "source-register.md")
    body = text.split("## Appendix R. File register")[1].split("## Appendix S")[0]
    out = []
    for row in md_tables(body)[1]:
        out.append((norm(row.get("file")), norm(row.get("format"))))
    return out


def export_dialects(data):
    """Appendix S of source-register.md."""
    _, text = read_md_file(data / "source-register.md")
    body = text.split("## Appendix S. Export dialects")[1]
    out = {}
    for row in md_tables(body)[1]:
        out[norm(row.get("file"))] = {k: norm(v) for k, v in row.items()}
    return out


_HEAD_PATTERNS = [
    re.compile(r"^#\s*ctl\s+(.*)$", re.I | re.M),
    re.compile(r"^CTL\s+(ctl_id=.*)$", re.M),
    re.compile(r"<!--\s*ctl\s+(.*?)-->", re.S),
]


def _head_ctl(path, fmt):
    with open(path, "rb") as fh:
        chunk = fh.read(1 << 16)
    text = chunk.decode("utf-8", "replace").lstrip("\ufeff")
    if fmt == "jsonl":
        line = text.split("\n", 1)[0]
        return ctl_of(json.loads(line).get("_ctl", {}))
    if fmt in ("yaml", "toml", "ini"):
        found = {}
        for m in re.finditer(r"(ctl_id|prev|rows)\s*[:=]\s*\"?([\w-]+)\"?", text):
            found.setdefault(m.group(1), m.group(2))
            if len(found) == 3:
                break
        return ctl_of(found)
    if fmt == "xml":
        m = re.search(r"<(?!\?)(\w[\w:.-]*)((?:\s+[\w:.-]+\s*=\s*\"[^\"]*\")*)", text)
        attrs = dict(re.findall(r"([\w:.-]+)\s*=\s*\"([^\"]*)\"",
                                m.group(2) if m else ""))
        return ctl_of(attrs)
    if fmt == "ics":
        return ctl_of({k.lower().replace("x-", "", 1): v.strip()
                       for k, v in re.findall(r"^(X-CTL-[A-Z]+):(.*)$", text, re.M)})
    if fmt == "mbox":
        return ctl_of({"ctl_id": _hdr(text, "X-Ctl-Id"),
                       "prev": _hdr(text, "X-Ctl-Prev"),
                       "rows": _hdr(text, "X-Ctl-Rows")})
    for pat in _HEAD_PATTERNS:
        m = pat.search(text)
        if m:
            return ctl_of(parse_kv_line(m.group(1)))
    return {}


def _hdr(text, name):
    m = re.search(r"^%s:\s*(.*)$" % re.escape(name), text, re.M | re.I)
    return m.group(1).strip() if m else ""


def _ooxml_ctl(path):
    with zipfile.ZipFile(path) as zf:
        body = zf.read("docProps/core.xml").decode("utf-8")
    m = re.search(r"<dc:subject>(.*?)</dc:subject>", body, re.S)
    return ctl_of(parse_kv_line(htmlmod.unescape(m.group(1)) if m else ""))


def control_record(data, name, fmt):
    path = data / name
    if fmt in ("csv", "tsv", "log", "fixed", "md", "html", "jsonl", "yaml",
               "toml", "ini", "xml", "ics", "mbox"):
        return _head_ctl(path, fmt)
    if fmt in ("xlsx", "docx"):
        return _ooxml_ctl(path)
    if fmt == "json":
        return read_json_file(path)[0]
    if fmt == "parquet":
        import pyarrow.parquet as pq
        md = pq.read_schema(str(path)).metadata or {}
        return ctl_of({k.decode(): v.decode() for k, v in md.items()})
    if fmt == "sqlite":
        return read_sqlite_ctl(path)
    if fmt == "pdf":
        import pypdf
        page = pypdf.PdfReader(str(path)).pages[0]
        line = page.extract_text().split("\n", 1)[0]
        return ctl_of(parse_kv_line(line.split(" ", 1)[1] if " " in line else ""))
    if fmt == "zip":
        return read_zip_ctl(path)
    raise ValueError("unknown format %r for %s" % (fmt, name))


def read_sqlite_ctl(path):
    con = sqlite3.connect("file:%s?mode=ro" % str(path).replace("?", "%3f"), uri=True)
    con.row_factory = sqlite3.Row
    try:
        row = con.execute("SELECT * FROM _control").fetchone()
        return ctl_of(dict(row))
    finally:
        con.close()


def build_chain(data, opening_ctl_id):
    """Order the files by their control record chain (section 10.4)."""
    register = file_register(data)
    recs = {}
    for name, fmt in register:
        recs[name] = control_record(data, name, fmt)
    by_prev = {}
    for name, ctl in recs.items():
        by_prev.setdefault(ctl["prev"], []).append(name)
    chain = []
    seen = set()
    cursor = ident(opening_ctl_id)
    while True:
        nxt = [n for n in by_prev.get(cursor, []) if n not in seen]
        if not nxt:
            break
        name = sorted(nxt)[0]
        seen.add(name)
        chain.append({"file": name, "ctl_id": recs[name]["ctl_id"],
                      "rows": recs[name]["rows"]})
        cursor = recs[name]["ctl_id"]
    return chain, recs


# -------------------------------------------------------------------- tickets

class Tickets:
    """change_tickets.csv: the state of a ticket is the state of its top rev."""

    NEVER = "0000-00-00T00:00:00Z"

    def __init__(self, data):
        best = {}
        for row in read_delimited(data / "change_tickets.csv")[3]:
            tid = ident(row.get("ticket"))
            if not tid:
                continue
            rev = as_int(row.get("rev")) or 0
            cur = best.get(tid)
            if cur is None or rev >= cur[0]:
                best[tid] = (rev, ident(row.get("state")), norm(row.get("decided_utc")))
        self.state = {t: v[1] for t, v in best.items()}
        self.decided = {t: v[2] for t, v in best.items()}
        self.window_end = None
        self._cache = {}

    def approved(self, ticket):
        tid = ident(ticket)
        if not tid:
            return False
        hit = self._cache.get(tid)
        if hit is not None:
            return hit
        ok = False
        if self.state.get(tid) == "APPROVED":
            raw = self.decided.get(tid, "")
            if raw and raw != self.NEVER:
                inst = parse_iso(raw)
                ok = inst is not None and inst < self.window_end
        self._cache[tid] = ok
        return ok


# --------------------------------------------------------------------- config

_BOOL_KEYS = ("purge.enabled",)


def cfg_key(raw):
    """Normalise a configuration key (section 2.2)."""
    key = norm(raw)
    ns, dot, rest = key.partition(".")
    ns = ns.lower()
    if not dot:
        return ns
    if ns == "vol":
        vol, d2, attr = rest.partition(".")
        return "vol.%s.%s" % (vol.upper(), attr.lower()) if d2 else "vol." + rest
    if ns == "subtree":
        vol, colon, tail = rest.partition(":")
        if colon:
            path, d3, flag = tail.rpartition(".")
            if d3:
                return "subtree.%s:%s.%s" % (vol.upper(), path, flag.lower())
        return "subtree." + rest
    return "%s.%s" % (ns, rest)


def cfg_value(key, raw, ini=False):
    if key in _BOOL_KEYS or key.endswith(".purge_exempt") or key.endswith(".archive_exempt"):
        return as_bool(raw)
    if key == "store.block_size":
        return as_int(raw, ini=ini)
    if key in ("window.start", "window.end"):
        return fmt_instant(parse_iso(norm(raw)))
    return norm(raw)


def config_layers(data):
    """The four configuration layers as lists of rows, in file order."""
    layers = []

    doc = read_toml_file(data / "estate-defaults.toml")[1]
    layers.append((10, yaml_list(doc, "setting")))

    doc = read_yaml_file(data / "site-policy.yaml")[1]
    layers.append((20, yaml_list(doc, "settings")))

    doc = read_json_file(data / "volume-policy.json")[1]
    layers.append((30, json_list(doc, "settings")))

    ctl, sections, _layout = read_ini_file(data / "operator-overrides.ini")
    rows = []
    for name, opts in sections:
        if not name.lower().startswith("override"):
            continue
        row = dict(opts)
        row.setdefault("override_id", name.split(":", 1)[-1])
        rows.append(row)
    layers.append((40, rows))
    return layers


def revoked_overrides(data, tickets):
    doc = read_yaml_file(data / "site-policy-v2.yaml")[1]
    out = set()
    for row in yaml_list(doc, "revocations"):
        if tickets.approved(row.get("ticket")):
            out.add(ident(row.get("override_id")))
    return out


def resolve_config(layers, profile, tickets=None, revoked=frozenset()):
    cfg = {}
    locked = set()
    for layer, rows in layers:
        fresh = set()
        for phase in ("*", profile):
            for row in rows:
                if lc(row.get("profile")) != phase:
                    continue
                if layer == 40:
                    if not tickets.approved(row.get("ticket")):
                        continue
                    if ident(row.get("override_id")) in revoked:
                        continue
                key = cfg_key(row.get("key"))
                if not key or key in locked:
                    continue
                cfg[key] = cfg_value(key, row.get("value"), ini=(layer == 40))
                if as_bool(row.get("final")):
                    fresh.add(key)
        locked |= fresh
    return cfg


def build_configs(data):
    """Effective configuration of both profiles (section 2)."""
    layers = config_layers(data)
    tickets = Tickets(data)
    base = resolve_config(layers[:3], "prod")
    tickets.window_end = parse_iso(base["window.end"])
    revoked = revoked_overrides(data, tickets)
    out = {}
    for profile in ("prod", "dev"):
        out[profile] = resolve_config(layers, profile, tickets, revoked)
    return out, tickets


# ------------------------------------------------------------------ calendar

def days_from_civil(y, m, d):
    y -= m <= 2
    era = (y if y >= 0 else y - 399) // 400
    yoe = y - era * 400
    mp = (m + 9) % 12
    doy = (153 * mp + 2) // 5 + d - 1
    doe = yoe * 365 + yoe // 4 - yoe // 100 + doy
    return era * 146097 + doe - 719468


def civil_from_days(z):
    z += 719468
    era = (z if z >= 0 else z - 146096) // 146097
    doe = z - era * 146097
    yoe = (doe - doe // 1460 + doe // 36524 - doe // 146096) // 365
    y = yoe + era * 400
    doy = doe - (365 * yoe + yoe // 4 - yoe // 100)
    mp = (5 * doy + 2) // 153
    d = doy - (153 * mp + 2) // 5 + 1
    m = mp + 3 if mp < 10 else mp - 9
    return (y + (1 if m <= 2 else 0), m, d)


def mk_instant(y, mo, d, h, mi, s):
    return days_from_civil(y, mo, d) * 86400 + h * 3600 + mi * 60 + s


def fmt_instant(t):
    if t is None:
        return ""
    days, rem = divmod(t, 86400)
    y, mo, d = civil_from_days(days)
    h, rem = divmod(rem, 3600)
    mi, s = divmod(rem, 60)
    return "%04d-%02d-%02dT%02d:%02d:%02dZ" % (y, mo, d, h, mi, s)


_ISO_RE = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{1,2}):(\d{2})(?::(\d{2}))?"
    r"(\.\d+)?\s*(Z|z|[+-]\d{2}:?\d{2})?$")


def parse_iso(text):
    """iso_z, iso_ms, iso_offset, iso_mixed -> whole seconds UTC."""
    s = norm(text)
    if not s:
        return None
    m = _ISO_RE.match(s)
    if not m:
        return None
    y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if y == 0 or mo == 0 or d == 0:
        return None
    t = mk_instant(y, mo, d, int(m.group(4)), int(m.group(5)),
                   int(m.group(6) or 0))
    off = m.group(8)
    if off and off not in ("Z", "z"):
        sign = -1 if off[0] == "-" else 1
        body = off[1:].replace(":", "")
        t -= sign * (int(body[:2]) * 3600 + int(body[2:]) * 60)
    return t


def parse_wall(text):
    """A wall-clock stamp (no zone) -> seconds as if it were UTC."""
    s = norm(text)
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})", s)
    if m:
        return mk_instant(*[int(x) for x in m.groups()])
    m = re.match(r"^(\d{2})\.(\d{2})\.(\d{4})[ T](\d{2}):(\d{2}):(\d{2})", s)
    if m:
        d, mo, y, h, mi, sec = [int(x) for x in m.groups()]
        return mk_instant(y, mo, d, h, mi, sec)
    return None


def parse_rfc2822(text):
    try:
        dt = email.utils.parsedate_to_datetime(norm(text))
    except (TypeError, ValueError):
        return None
    if dt is None:
        return None
    off = dt.utcoffset()
    base = mk_instant(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second)
    if off is not None:
        base -= int(off.total_seconds())
    return base


def parse_julian(text):
    s = norm(text)
    m = re.match(r"^(\d{4})(\d{3})\s+(\d{2})(\d{2})(\d{2})$", s)
    if not m:
        return None
    y, doy, h, mi, sec = [int(x) for x in m.groups()]
    return days_from_civil(y, 1, 1) * 86400 + (doy - 1) * 86400 + \
        h * 3600 + mi * 60 + sec


def _floor_div_decimal(value, scale):
    try:
        dec = Decimal(norm(value))
    except Exception:
        return None
    return int((dec / scale).to_integral_value(rounding=ROUND_FLOOR))


def parse_epoch(value, dialect):
    if value is None or norm(value) == "":
        return None
    if dialect == "epoch_s":
        v = norm(value)
        if re.fullmatch(r"-?\d+", v):
            return int(v)
        return _floor_div_decimal(v, Decimal(1))
    if dialect == "epoch_ms":
        v = norm(value)
        if re.fullmatch(r"-?\d+", v):
            n = int(v)
            return n // 1000
        return _floor_div_decimal(v, Decimal(1000))
    if dialect == "epoch_ns":
        v = norm(value)
        if re.fullmatch(r"-?\d+", v):
            return int(v) // 1000000000
        return _floor_div_decimal(v, Decimal(1000000000))
    if dialect == "epoch_frac":
        return _floor_div_decimal(value, Decimal(1))
    return None


FILETIME_EPOCH = 11644473600


def parse_filetime(value):
    v = norm(value)
    if not v:
        return None
    if re.fullmatch(r"-?\d+", v):
        ticks = int(v)
    else:
        v2 = _degroup(v)
        if not re.fullmatch(r"-?\d+", v2):
            return None
        ticks = int(v2)
    return (ticks // 10000000) - FILETIME_EPOCH


_EXCEL_1900 = days_from_civil(1899, 12, 30)
_EXCEL_1904 = days_from_civil(1904, 1, 1)


def parse_excel(value, epoch1904):
    s = norm(value)
    if not s:
        return None
    try:
        dec = Decimal(s)
    except Exception:
        return None
    if not epoch1904 and dec in (Decimal(0), Decimal(60)):
        return None
    whole = int(dec.to_integral_value(rounding=ROUND_FLOOR))
    frac = dec - whole
    secs = int((frac * 86400).quantize(Decimal(1), rounding=ROUND_HALF_EVEN))
    base = _EXCEL_1904 if epoch1904 else _EXCEL_1900
    return (base + whole) * 86400 + secs


# --------------------------------------------------------------------- zones

def parse_offset(value):
    s = norm(value)
    if not s:
        return None
    if ":" in s:
        sign = -1 if s[0] == "-" else 1
        body = s.lstrip("+-")
        h, mi = body.split(":")
        return sign * (int(h) * 3600 + int(mi) * 60)
    return as_int(s)


class Zones:
    """Offsets from tz_transitions_a.tsv and tz_transitions_b.parquet."""

    def __init__(self, data):
        rows = []
        rows.extend(read_delimited(data / "tz_transitions_a.tsv")[3])
        rows.extend(read_parquet_file(data / "tz_transitions_b.parquet")[2])
        self.segs = {}
        self.std = {}
        for row in rows:
            zone = lc(row.get("zone"))
            if not zone:
                continue
            frm = parse_iso(row.get("from_utc"))
            to = parse_iso(row.get("to_utc"))
            off = parse_offset(row.get("offset_seconds"))
            if frm is None or off is None:
                continue
            dst = as_bool(row.get("is_dst"))
            self.segs.setdefault(zone, []).append(
                (frm, to if to is not None else (1 << 62), off, bool(dst)))
            if not dst:
                self.std.setdefault(zone, off)
        for zone in self.segs:
            self.segs[zone].sort()

    def to_utc(self, wall, zone):
        """Wall-clock seconds in `zone` -> UTC instant (section 4.3)."""
        if wall is None:
            return None
        zone = lc(zone)
        segs = self.segs.get(zone)
        if not segs:
            return None
        hits = []
        for frm, to, off, _dst in segs:
            cand = wall - off
            if frm <= cand < to:
                hits.append(off)
        if len(hits) == 1:
            return wall - hits[0]
        if len(hits) > 1:
            return wall - min(hits)
        std = self.std.get(zone)
        if std is None:
            return None
        return wall - std


# ----------------------------------------------------------- clock incidents

def clock_incidents(data, tickets, adopted):
    """Appendix D of ECS-annex-hosts-rev7.pdf (section 4.4)."""
    if not adopted:
        return {}
    _, _, blocks = read_pdf_file(data / "ECS-annex-hosts-rev7.pdf")
    best = {}
    for cols, rows in blocks:
        if "skew_seconds" not in cols:
            continue
        for row in rows:
            host = lc(row.get("host"))
            frm = parse_iso(row.get("from_utc"))
            if not host or frm is None:
                continue
            rev = as_int(row.get("rev")) or 0
            key = (host, frm)
            cur = best.get(key)
            if cur is None or rev >= cur[0]:
                best[key] = (rev, lc(row.get("status")),
                             parse_iso(row.get("to_utc")),
                             as_int(row.get("skew_seconds")) or 0)
    out = {}
    for (host, frm), (_rev, status, to, skew) in best.items():
        if status != "adopted":
            continue
        out.setdefault(host, []).append((frm, to if to is not None else (1 << 62), skew))
    for host in out:
        out[host].sort()
    return out


def correct_skew(incidents, host, t):
    if t is None or not host:
        return t
    for frm, to, skew in incidents.get(lc(host), ()):
        if frm <= t < to:
            return t - skew
    return t


# ------------------------------------------------------------------- volumes

CI_FS = {"ntfs", "hfsplus", "exfat"}


def load_volumes(data):
    doc = read_yaml_file(data / "volumes.yaml")[1]
    out = {}
    for row in yaml_list(doc, "volumes"):
        code = ident(row.get("code"))
        out[code] = {"code": code, "fs_type": lc(row.get("fs_type")),
                     "host": lc(row.get("host"))}
    return out


def load_serials(data):
    doc = read_json_file(data / "volumes_cmdb.json")[1]
    best = {}
    for row in json_list(doc, "serials"):
        ser = ident(row.get("serial"))
        rev = as_int(row.get("rev")) or 0
        cur = best.get(ser)
        if cur is None or rev >= cur[0]:
            best[ser] = (rev, lc(row.get("status")), ident(row.get("volume")))
    return {s: v[2] for s, v in best.items() if v[1] == "active"}


def volume_zone(code, volumes, cfg, hosts):
    key = "vol.%s.zone" % code
    if cfg.get(key):
        return lc(cfg[key])
    host = volumes.get(code, {}).get("host", "")
    return hosts.get(host, "")


def load_hosts(data):
    """Host register part A (source-register.md) and part B (rev6 annex)."""
    out = {}
    _, text = read_md_file(data / "source-register.md")
    body = text.split("## Appendix H. Host register (part A)")[1]
    body = body.split("## Appendix R")[0]
    for row in md_tables(body)[1]:
        host = lc(row.get("host"))
        if host:
            out[host] = lc(row.get("zone"))
    _, _, blocks = read_pdf_file(data / "ECS-annex-hosts-rev6.pdf")
    for cols, rows in blocks:
        if "zone" not in cols:
            continue
        for row in rows:
            host = lc(row.get("host"))
            if host:
                out.setdefault(host, lc(row.get("zone")))
    return out


def case_insensitive(code, volumes, cfg):
    fs = volumes.get(code, {}).get("fs_type", "")
    if fs in CI_FS:
        return True
    if fs == "apfs":
        return lc(cfg.get("vol.%s.case" % code)) == "insensitive"
    return False


# --------------------------------------------------------------- alias roots

def unc_slashes(path):
    return path.replace("\\", "/") if path.startswith("\\\\") else path


def _ci_root(root):
    low = root.lower()
    return low.startswith("//") or low.startswith("smb://") or low.startswith("nfs://")


def load_alias_rows(data):
    rows = []
    rows.extend(read_delimited(data / "alias_remap_nas.tsv")[3])
    _, _, sheets, order, _ = read_xlsx_file(data / "alias_remap_sharepoint.xlsx")
    for name in order:
        rows.extend(sheets[name])
    rows.extend(read_xml_file(data / "alias_remap_dfs.xml")[2])
    rows.extend(docx_rows(read_docx_file(data / "ECS-handbook-paths.docx")[2])[1])
    rows.extend(yaml_list(read_yaml_file(data / "volumes.yaml")[1], "aliases"))
    _, text = read_md_file(data / "ECS-standard.md")
    body = text.split("## Appendix F. Alias roots, partition F")[1]
    body = body.split("## 11. Output contract")[0]
    rows.extend(md_tables(body)[1])
    return rows


class Paths:
    """Alias roots (5.2) and canonical paths (5.3)."""

    def __init__(self, data, cfg, volumes):
        serials = load_serials(data)
        best = {}
        for row in load_alias_rows(data):
            root = unc_slashes(norm(row.get("root")))
            if not root:
                continue
            key = root.lower() if _ci_root(root) else root
            rev = as_int(row.get("rev")) or 0
            cur = best.get(key)
            if cur is None or rev >= cur[0]:
                best[key] = (rev, row, root)
        self.ci_roots = {}
        self.cs_roots = {}
        for key, (_rev, row, root) in best.items():
            volume = norm(row.get("volume"))
            if volume.lower().startswith("serial:"):
                volume = serials.get(ident(volume.split(":", 1)[1]), "")
            else:
                volume = ident(volume)
            active = lc(row.get("status")) != "retired"
            prefix = norm(row.get("prefix"))
            entry = (volume, prefix, active)
            if _ci_root(root):
                self.ci_roots[key] = entry
            else:
                self.cs_roots[key] = entry
        self.ci = {code: case_insensitive(code, volumes, cfg) for code in volumes}
        self.csdirs = self._case_dirs(data)

    def _case_dirs(self, data):
        out = {}
        rows = list(read_delimited(data / "case_sensitive_dirs.csv")[3])
        rows.extend(read_xml_file(data / "case_sensitive_dirs_leg01.xml")[2])
        best = {}
        for row in rows:
            vol = ident(row.get("volume"))
            pref = norm(row.get("prefix")).lower()
            if not vol or not pref:
                continue
            rev = as_int(row.get("rev")) or 0
            cur = best.get((vol, pref))
            if cur is None or rev >= cur[0]:
                best[(vol, pref)] = (rev, lc(row.get("status")))
        for (vol, pref), (_rev, status) in best.items():
            if status == "active":
                out.setdefault(vol, set()).add(pref.rstrip("/"))
        return out

    def resolve_root(self, raw):
        """Longest alias root that is a prefix of `raw`."""
        path = unc_slashes(raw)
        idx = len(path)
        while True:
            idx = path.rfind("/", 0, idx)
            if idx < 0:
                return None
            cand = path[:idx + 1]
            hit = self.ci_roots.get(cand.lower()) or self.cs_roots.get(cand)
            if hit is not None:
                return (hit, path[idx + 1:])
            if idx == 0:
                return None

    def canonical(self, raw, volume=None):
        """Return (volume, canonical path) or (None, None)."""
        raw = norm(raw)
        if not raw:
            return (None, None)
        low = raw.lower()
        if low.startswith("s3://"):
            return self._s3(raw)
        found = self.resolve_root(raw)
        if found is None:
            return (None, None)
        (vol, prefix, active), tail = found
        if not active or not vol:
            return (None, None)
        segs = []
        for seg in tail.split("/"):
            seg = unicodedata.normalize("NFC", seg)
            if seg == "" or seg == ".":
                continue
            if seg == "..":
                if not segs:
                    return (None, None)
                segs.pop()
                continue
            segs.append(seg)
        base = "/" + prefix.strip("/") if prefix.strip("/") else ""
        path = base + ("/" + "/".join(segs) if segs else "")
        if not path:
            return (None, None)
        return (vol, self.apply_case(vol, path))

    def _s3(self, raw):
        body = raw[5:]
        bucket, _, key = body.partition("/")
        key = unquote_utf8(key)
        segs = []
        for seg in key.split("/"):
            seg = unicodedata.normalize("NFC", seg)
            if seg == "" or seg == ".":
                continue
            if seg == "..":
                if not segs:
                    return (None, None)
                segs.pop()
                continue
            segs.append(seg)
        if not bucket:
            return (None, None)
        path = "/" + bucket + ("/" + "/".join(segs) if segs else "")
        return ("OBJ01", path)

    def apply_case(self, volume, path):
        if not self.ci.get(volume):
            return path
        low = path.lower()
        dirs = self.csdirs.get(volume)
        if dirs:
            idx = low.rfind("/")
            while idx > 0:
                if low[:idx] in dirs:
                    return low[:idx] + path[idx:]
                idx = low.rfind("/", 0, idx)
        return low

    def match_prefix(self, volume, path, prefix):
        """Whole-segment prefix test on a canonical path."""
        pref = norm(prefix).rstrip("/")
        if self.ci.get(volume):
            pref = pref.lower()
        if not pref:
            return True
        return path == pref or path.startswith(pref + "/")


_PCT = re.compile(r"((?:%[0-9A-Fa-f]{2})+)")


def unquote_utf8(text):
    if "%" not in text:
        return text
    out = []
    for i, part in enumerate(_PCT.split(text)):
        if i % 2 == 1:
            raw = bytes(int(part[j + 1:j + 3], 16) for j in range(0, len(part), 3))
            out.append(raw.decode("utf-8", "replace"))
        else:
            out.append(part)
    return "".join(out)


# -------------------------------------------------------------------- owners

SENTINEL_OWNERS = {"s-1-0-0", "nobody@corp.example", "corp\\-", "oldcorp\\-",
                   "-", "svc-none", "mf?????", "n/a", "0" * 64}

_HEX64 = re.compile(r"[0-9a-f]{64}\Z")


def owner_token_kind(token):
    t = norm(token)
    if not t:
        return None, None
    low = t.lower()
    if low in SENTINEL_OWNERS:
        return "sentinel", low
    if low.startswith("uid:"):
        bits = t.split(":")
        if len(bits) >= 3 and (as_int(bits[2]) == 65534):
            return "sentinel", low
        return "uid", (lc(bits[1]), as_int(bits[2]) if len(bits) > 2 else None)
    if low.startswith("s-1-"):
        return "sid", t.upper()
    if "\\" in t:
        dom, _, login = t.partition("\\")
        return "domain", (dom.upper(), login.lower())
    if "@" in t:
        local, _, host = t.partition("@")
        local = local.split("+", 1)[0]
        return "email", (local + "@" + host).lower()
    if low.startswith("svc-"):
        return "svc", low
    if re.fullmatch(r"MF[0-9?]+", t.upper()):
        return "mf", t.upper()
    if _HEX64.match(low):
        return "s3", low
    return None, t


class Owners:
    """Owner tokens (5.4) and principal merges (5.5)."""

    def __init__(self, data, window_end, tickets):
        self.register = {}
        _, _, sheets, _order, _ = read_xlsx_file(data / "principal_sid_map.xlsx")
        for row in sheets.get("principals", []):
            pid = ident(row.get("principal_id"))
            if pid:
                self.register[pid] = norm(row.get("account"))
        self.sids = self._latest(sheets.get("sids", []), lambda r: ident(r.get("sid")))

        _, _, dsheets, _o, _e = read_xlsx_file(data / "principal_directory.xlsx")
        hist = {}
        for row in dsheets.get("sid_history", []):
            old = ident(row.get("old_sid"))
            rev = as_int(row.get("rev")) or 0
            cur = hist.get(old)
            if old and (cur is None or rev >= cur[0]):
                hist[old] = (rev, ident(row.get("new_sid")))
        self.sid_history = {k: v[1] for k, v in hist.items() if v[1]}

        aliases = {}
        for name, opts in read_ini_file(data / "host_aliases.ini")[1]:
            alias = lc(name.split(":", 1)[-1])
            host = lc(opts.get("host"))
            if alias and host:
                aliases[alias] = host
        self.host_alias = aliases

        self.uids = self._latest(
            read_delimited(data / "principal_uid_map.tsv")[3],
            lambda r: (lc(r.get("host")), as_int(r.get("uid"))))

        corp = docx_rows(read_docx_file(data / "owner-migration-plan.docx")[2])[1]
        self.corp = self._latest(
            corp, lambda r: (ident(r.get("domain")), lc(r.get("login"))))

        _, sections = read_html_file(data / "principal_map_ldap.html")
        oldcorp = html_section(sections, "OLDCORP")
        self.oldcorp = self._latest(
            oldcorp, lambda r: (ident(r.get("domain")), lc(r.get("login"))))

        _, _, tables = read_sqlite_file(data / "principal_legacy.db")
        legacy = sqlite_table(tables, "logins")
        self.legacy = self._latest(
            legacy, lambda r: (ident(r.get("domain")), lc(r.get("login"))))

        _, _, blocks = read_pdf_file(data / "hr-roster-q3.pdf")
        emails = [r for cols, rows in blocks if "email" in cols for r in rows]
        self.emails = self._latest(emails, lambda r: _email_key(r.get("email")))

        doc = read_json_file(data / "principal_s3_ids.json")[1]
        self.s3 = self._latest(json_list(doc, "ids"),
                               lambda r: lc(r.get("canonical_id")))

        svc = [dict(opts, svc=name) for name, opts in
               read_ini_file(data / "service_accounts.ini")[1]]
        self.svc = self._latest(svc, lambda r: lc(r.get("svc")))

        mf = read_fixed_file(data / "principal_mainframe_ids.txt")[2]
        self.mf = self._latest(mf, lambda r: ident(r.get("mf_id")))

        self.merges = self._merges(data, window_end)

    @staticmethod
    def _latest(rows, keyfn):
        best = {}
        for row in rows:
            if lc(row.get("status")) != "active":
                continue
            key = keyfn(row)
            if key is None or (isinstance(key, tuple) and None in key):
                continue
            stamp = norm(row.get("valid_from"))
            pid = ident(row.get("principal_id"))
            cur = best.get(key)
            if cur is None or stamp >= cur[0]:
                best[key] = (stamp, pid)
        return {k: v[1] for k, v in best.items()}

    def _merges(self, data, window_end):
        rows = list(read_delimited(data / "principal_merges.csv")[3])
        _, text = read_md_file(data / "ops-runbook.md")
        body = text.split("## Appendix M. Principal merges (partition B)")[1]
        rows.extend(md_tables(body)[1])
        best = {}
        for row in rows:
            src = ident(row.get("from_principal"))
            if not src:
                continue
            rev = as_int(row.get("rev")) or 0
            cur = best.get(src)
            if cur is None or rev >= cur[0]:
                best[src] = (rev, lc(row.get("status")),
                             parse_iso(row.get("effective_utc")),
                             ident(row.get("to_principal")))
        out = {}
        for src, (_rev, status, eff, dst) in best.items():
            if status == "applied" and eff is not None and eff < window_end and dst:
                out[src] = dst
        return out

    def principal(self, token):
        kind, key = owner_token_kind(token)
        if kind is None or kind == "sentinel":
            return None
        if kind == "sid":
            seen = 0
            while key in self.sid_history and seen < 8:
                key = self.sid_history[key]
                seen += 1
            return self.sids.get(key)
        if kind == "uid":
            host, number = key
            host = self.host_alias.get(host, host)
            return self.uids.get((host, number))
        if kind == "domain":
            dom, _login = key
            if dom == "CORP":
                return self.corp.get(key)
            if dom == "OLDCORP":
                return self.oldcorp.get(key)
            return self.legacy.get(key)
        if kind == "email":
            return self.emails.get(key)
        if kind == "s3":
            return self.s3.get(key)
        if kind == "svc":
            return self.svc.get(key)
        if kind == "mf":
            return self.mf.get(key)
        return None

    def final_principal(self, pid):
        seen = set()
        while pid in self.merges and pid not in seen:
            seen.add(pid)
            pid = self.merges[pid]
        return pid

    def account(self, token):
        pid = self.principal(token)
        if not pid or pid not in self.register:
            return None
        pid = self.final_principal(pid)
        return self.register.get(pid)


def _email_key(value):
    t = lc(value)
    if "@" not in t:
        return None
    local, _, host = t.partition("@")
    return local.split("+", 1)[0] + "@" + host


# ------------------------------------------------------------------- batches

UNIT_BYTES = {"b": 1, "kb": 1000, "kib": 1024, "mib": 1048576,
              "blk512": 512, "blk4096": 4096}


class Batches:
    """Batch registers A-D (section 6.1)."""

    def __init__(self, data):
        rows = []
        rows.extend(read_delimited(data / "export_batches_a.csv")[3])
        rows.extend(read_delimited(data / "export_batches_b.tsv")[3])
        rows.extend(docx_rows(read_docx_file(data / "tape-operations-notes.docx")[2])[1])
        _, _, blocks = read_pdf_file(data / "units-bulletin.pdf")
        for cols, prows in blocks:
            if "batch_id" in cols:
                rows.extend(prows)
        self.unit = {}
        self.captured = {}
        corrections = []
        for row in rows:
            bid = ident(row.get("batch_id"))
            if not bid:
                continue
            if lc(row.get("source")) == "correction":
                corrections.append((bid, lc(row.get("unit"))))
                continue
            self.unit[bid] = lc(row.get("unit"))
            self.captured[bid] = parse_iso(row.get("captured_utc"))
        for bid, unit in corrections:
            self.unit[bid] = unit

    def unit_bytes(self, batch):
        return UNIT_BYTES.get(self.unit.get(ident(batch), ""), None)


# --------------------------------------------------------------------- sizes

def _exact_int(dec):
    whole = dec.to_integral_value(rounding=ROUND_HALF_EVEN)
    if dec == whole:
        return int(whole)
    return int(dec.quantize(Decimal(1), rounding=ROUND_HALF_EVEN))


def _decimal(text):
    s = norm(text)
    if not s:
        return None
    try:
        return Decimal(s)
    except Exception:
        return None


def parse_de_decimal(text):
    s = norm(text)
    if not s:
        return None
    s = s.replace(".", "").replace(",", ".")
    try:
        return Decimal(s)
    except Exception:
        return None


def size_sentinels(data):
    """The per-file unknown-size sentinels of source-register.md."""
    _ctl, text = read_md_file(data / "source-register.md")
    body = text.split("## Sentinels")[1].split("##")[0]
    body = body.split("Unknown size:")[-1].split("Owner not captured:")[0]
    body = body.replace("\n", " ")
    out = {}
    for found in re.finditer(r"([^\s,]+)\s*\(([^)]*)\)", body):
        token = found.group(1)
        for name in found.group(2).split(","):
            name = norm(name)
            if name:
                out[name] = token
    return out


def parse_size(raw, dialect, unit_bytes=None, sentinel=None):
    """Size in bytes, or None when unknown (section 6.1)."""
    if raw is None:
        return None
    if sentinel is not None and norm(raw) == sentinel:
        return None
    if isinstance(raw, bool):
        return None
    if isinstance(raw, int) and dialect in ("int", "grouped", "spaced", "dotted"):
        return raw
    s = norm(raw)
    if s == "":
        return None
    if dialect in ("int", "grouped", "spaced", "dotted"):
        return as_int(s)
    if dialect == "kib":
        dec = _decimal(s)
        return None if dec is None else _exact_int(dec * 1024)
    if dialect in ("unit", "xmlunit"):
        dec = _decimal(s)
        if dec is None or unit_bytes is None:
            return None
        return _exact_int(dec * unit_bytes)
    if dialect == "kb4de":
        dec = parse_de_decimal(s)
        return None if dec is None else _exact_int(dec * 1000)
    return as_int(s)


# ------------------------------------------------------------------- digests

ZERO_RE = re.compile(r"0+\Z")

XWALK_VOLUMES = {
    "md5A": ("ENG02", "LEG01"),
    "md5B": ("MKT01", "OBJ01", "LAB01"),
    "md5C": ("HR01",),
    "sha1A": ("FIN02",),
    "sha1B": ("RND01",),
}


class Digests:
    """Digest crosswalks (section 6.2)."""

    def __init__(self, data):
        parts = {}
        parts["md5A"] = read_delimited(data / "hash_xwalk_md5_eng.csv")[3]
        parts["md5B"] = read_jsonl_file(data / "hash_xwalk_md5_mkt.jsonl")[2]
        parts["md5C"] = read_parquet_file(data / "hash_xwalk_md5_fin.parquet")[2]
        doc = read_json_file(data / "hash_xwalk_sha1_fin.json")[1]
        parts["sha1A"] = json_list(doc, "crosswalk")
        _, _, blocks = read_pdf_file(data / "vendor-hash-attestation.pdf")
        parts["sha1B"] = [r for cols, rows in blocks if "digest" in cols for r in rows]
        master = read_parquet_file(data / "hash_index_master.parquet")[2]
        parts["ARC01"] = [r for r in master if ident(r.get("origin")) == "ARC01"]

        self.by_volume = {}
        for name, rows in parts.items():
            table = self._reduce(rows)
            targets = XWALK_VOLUMES.get(name, (name,))
            for vol in targets:
                self.by_volume.setdefault(vol, {}).update(table)

    @staticmethod
    def _reduce(rows):
        best = {}
        for row in rows:
            dig = lc(row.get("digest"))
            if not dig:
                continue
            rev = as_int(row.get("rev")) or 0
            cur = best.get(dig)
            if cur is None or rev >= cur[0]:
                best[dig] = (rev, lc(row.get("status")), lc(row.get("sha256")))
        return {d: v[2] for d, v in best.items() if v[1] == "ok" and v[2]}

    def resolve(self, volume, sha256, legacy):
        """Return the entry digest, or None when it cannot be resolved."""
        direct = lc(sha256)
        if direct and not ZERO_RE.match(direct):
            return direct
        key = lc(legacy)
        if not key or ZERO_RE.match(key):
            return None
        return self.by_volume.get(ident(volume), {}).get(key)


def md5_from_base64(value):
    s = norm(value)
    if not s:
        return ""
    try:
        raw = base64.b64decode(s, validate=True)
    except (binascii.Error, ValueError):
        return ""
    if len(raw) != 16:
        return ""
    return raw.hex()


def etag_digest(value):
    s = norm(value).strip('"')
    return s.lower()


# ------------------------------------------------------- authority_matrix.xlsx

class Authority:
    """Export runs, scope overrides and ratifications (sections 3.1-3.3)."""

    def __init__(self, data, tickets, run_modes):
        _, _, sheets, _order, _ = read_xlsx_file(data / "authority_matrix.xlsx")
        self.runs = sheets.get("runs", [])
        self.snapshot = {}
        full_file = {}
        for name, mode in run_modes.items():
            if mode[0] == "full":
                full_file[mode[1]] = name
        for row in self.runs:
            vol = ident(row.get("volume"))
            if lc(row.get("kind")) != "full":
                continue
            if lc(row.get("status")) != "complete":
                continue
            if norm(row.get("superseded_by")):
                continue
            if norm(row.get("file")) != full_file.get(vol):
                continue
            self.snapshot[vol] = parse_iso(row.get("completed_utc"))
        self.scope = []
        for row in sheets.get("scope", []):
            if lc(row.get("record")) != "override":
                continue
            if not tickets.approved(row.get("ticket")):
                continue
            self.scope.append((ident(row.get("volume_or_version")),
                               norm(row.get("subject")),
                               norm(row.get("prefix"))))
        self.ratified = set()
        for row in sheets.get("scope", []):
            if lc(row.get("record")) != "ratification":
                continue
            if tickets.approved(row.get("ticket")):
                self.ratified.add((norm(row.get("subject")),
                                   norm(row.get("volume_or_version"))))

    def scope_for(self, volume):
        return [(subject, prefix) for vol, subject, prefix in self.scope
                if vol == volume]


# --------------------------------------------------------------------- voids

class Voids:
    """Void registers, reinstatements and the audit letter (section 3.4)."""

    def __init__(self, data, tickets):
        best = {}
        rows = list(read_delimited(data / "void_register_q3.csv")[3])
        rows.extend(read_jsonl_file(data / "void_register_supplement.jsonl")[2])
        for row in rows:
            rid = ident(row.get("rec_id"))
            if not rid:
                continue
            rev = as_int(row.get("rev")) or 0
            cur = best.get(rid)
            if cur is None or rev >= cur[0]:
                best[rid] = (rev, lc(row.get("status")), row.get("ticket"))
        self.voided = set()
        for rid, (_rev, status, ticket) in best.items():
            if status == "active" and tickets.approved(ticket):
                self.voided.add(rid)
        _, _, elems = read_xml_file(data / "void_register_q3_r2.xml")
        for el in elems:
            if el.get("_tag") != "reinstate":
                continue
            if tickets.approved(el.get("ticket")):
                self.voided.discard(ident(el.get("rec_id")))
        excluded = {}
        _, _, blocks = read_pdf_file(data / "audit-scope-letter-fin.pdf")
        for cols, prows in blocks:
            if "rec_id" not in cols:
                continue
            for row in prows:
                rid = ident(row.get("rec_id"))
                if rid:
                    excluded[rid] = lc(row.get("status"))
        self.excluded = {r for r, s in excluded.items() if s == "excluded"}

    def is_void(self, rec_id, volume):
        rid = ident(rec_id)
        if rid in self.voided:
            return True
        return rid in self.excluded and ident(volume).startswith("FIN")


# -------------------------------------------------------------------- errata

ERRATA_FIELDS = ("bytes", "mtime", "sha256", "owner")


class Errata:
    """Errata registers and withdrawals (section 3.5)."""

    def __init__(self, data, tickets):
        withdrawn = set()
        for row in read_delimited(data / "errata_register_q3_r2.tsv")[3]:
            if ident(row.get("field")) != "WITHDRAW":
                continue
            if tickets.approved(row.get("ticket")):
                withdrawn.add(ident(row.get("errata_id")))
        rows = list(read_delimited(data / "errata_register_q3.csv")[3])
        rows.extend(read_xml_file(data / "errata_register_tape.xml")[2])
        rows.extend(docx_rows(read_docx_file(data / "errata-bulletin-q3.docx")[2])[1])
        best = {}
        for row in rows:
            eid = ident(row.get("errata_id"))
            if eid in withdrawn:
                continue
            if not tickets.approved(row.get("ticket")):
                continue
            field = lc(row.get("field"))
            if field not in ERRATA_FIELDS:
                continue
            rid = ident(row.get("rec_id"))
            if not rid:
                continue
            rev = as_int(row.get("rev")) or 0
            key = (rid, field)
            cur = best.get(key)
            if cur is None or rev >= cur[0]:
                best[key] = (rev, norm(row.get("value")))
        self.values = {k: v[1] for k, v in best.items()}

    def get(self, rec_id, field):
        return self.values.get((ident(rec_id), field))


# --------------------------------------------------------- inventory exports

AUTHORITATIVE_MODES = ("full", "continuation")


def _rec(file, volume, rec_id, path, size, mtime, sha256, legacy, owner, batch,
         **extra):
    rec = {"file": file, "volume": volume, "rec_id": ident(rec_id),
           "raw_path": norm(path), "raw_size": size, "raw_mtime": mtime,
           "raw_sha256": norm(sha256), "raw_legacy": norm(legacy),
           "raw_owner": norm(owner), "batch": ident(batch),
           "file_id": None, "nlink": 1, "not_file": False}
    rec.update(extra)
    return rec


def _hexint(value):
    s = norm(value)
    if not s:
        return None
    if s.lower().startswith("0x"):
        s = s[2:]
    try:
        return int(s, 16)
    except ValueError:
        return None


def load_inventories(data, dialects):
    """Every inventory export of the set: (file -> (run_mode, volume, records))."""
    out = {}

    def add(name, run_mode, volume, records):
        out[name] = (lc(run_mode), ident(volume), records)

    # --- inv_eng01_q3.csv ---------------------------------------------------
    name = "inv_eng01_q3.csv"
    ctl, meta, cols, rows = read_delimited(data / name)
    head = parse_kv_line(" ".join(meta))
    recs = [_rec(name, head["volume"], r.get("rec_id"), r.get("path"),
                 r.get("size_bytes"), r.get("mtime_filetime"), r.get("sha256"),
                 None, r.get("owner_sid"), r.get("batch"),
                 file_id=_hexint(r.get("file_id")),
                 nlink=as_int(r.get("links")) or 1) for r in rows]
    add(name, head["run_mode"], head["volume"], recs)

    # --- inv_eng01_q3_deep.jsonl -------------------------------------------
    name = "inv_eng01_q3_deep.jsonl"
    ctl, meta, rows = read_jsonl_file(data / name)
    recs = [_rec(name, meta["volume"], r.get("id"), r.get("path"), r.get("bytes"),
                 r.get("mtime"), r.get("sha256"), None, r.get("owner"),
                 r.get("batch"), file_id=_hexint(r.get("fid")),
                 nlink=as_int(r.get("links")) or 1) for r in rows]
    add(name, meta["run_mode"], meta["volume"], recs)

    # --- inv_eng01_q3_part2.db ---------------------------------------------
    name = "inv_eng01_q3_part2.db"
    ctl, meta, tables = read_sqlite_file(data / name)
    rows = sqlite_table(tables, "inventory")
    recs = [_rec(name, meta["volume"], r.get("rec_id"), r.get("unc_path"),
                 r.get("bytes"), r.get("mtime_ms"), r.get("sha256"), None,
                 r.get("owner"), r.get("batch"),
                 file_id=as_int(r.get("fid")),
                 nlink=as_int(r.get("nlink")) or 1) for r in rows]
    add(name, meta["run_mode"], meta["volume"], recs)

    # --- inv_eng02_q3.txt --------------------------------------------------
    name = "inv_eng02_q3.txt"
    ctl, meta, rows = read_fixed_file(data / name)
    recs = [_rec(name, meta["volume"], r.get("rec_id"), r.get("path"),
                 r.get("size"), r.get("mtime_local"), r.get("sha256"),
                 r.get("md5"), r.get("owner"), r.get("batch")) for r in rows]
    add(name, meta["run_mode"], meta["volume"], recs)

    # --- inv_fin01_q3.parquet ----------------------------------------------
    name = "inv_fin01_q3.parquet"
    ctl, md, rows = read_parquet_file(data / name)
    recs = [_rec(name, md["volume"], r.get("rec_id"), r.get("path"), r.get("size"),
                 r.get("mtime_ns"), r.get("sha256"), None, r.get("owner"),
                 r.get("batch"), file_id=as_int(r.get("inode")),
                 nlink=as_int(r.get("nlink")) or 1) for r in rows]
    add(name, md["run_mode"], md["volume"], recs)

    # --- inv_fin01_q3_r2.csv -----------------------------------------------
    name = "inv_fin01_q3_r2.csv"
    ctl, meta, cols, rows = read_delimited(data / name)
    head = parse_kv_line(" ".join(meta))
    recs = [_rec(name, head["volume"], r.get("rec_id"), r.get("path"),
                 r.get("size"), r.get("mtime"), r.get("sha256"), None,
                 r.get("owner"), r.get("batch"),
                 file_id=as_int(r.get("inode")),
                 nlink=as_int(r.get("nlink")) or 1) for r in rows]
    add(name, head["run_mode"], head["volume"], recs)

    # --- inv_fin02_q3.tsv --------------------------------------------------
    name = "inv_fin02_q3.tsv"
    ctl, meta, cols, rows = read_delimited(data / name)
    head = parse_kv_line(" ".join(meta))
    recs = [_rec(name, head["volume"], r.get("rec_id"), r.get("path"),
                 r.get("size_kib"), r.get("mtime_epoch"), r.get("sha256"),
                 r.get("sha1"), r.get("owner"), r.get("batch")) for r in rows]
    add(name, head["run_mode"], head["volume"], recs)

    # --- inv_hr01_q3.xlsx --------------------------------------------------
    name = "inv_hr01_q3.xlsx"
    ctl, meta, sheets, order, epoch1904 = read_xlsx_file(data / name)
    recs = []
    for sheet in order:
        for r in sheets[sheet]:
            recs.append(_rec(name, meta["volume"], r.get("rec_id"), r.get("path"),
                             r.get("size"), r.get("modified"), r.get("sha256"),
                             r.get("md5"), r.get("owner"), r.get("batch"),
                             epoch1904=epoch1904))
    add(name, meta["run_mode"], meta["volume"], recs)

    # --- inv_lab01_q3.jsonl ------------------------------------------------
    name = "inv_lab01_q3.jsonl"
    ctl, meta, rows = read_jsonl_file(data / name)
    recs = [_rec(name, meta["volume"], r.get("rec"), r.get("path"), r.get("size"),
                 r.get("mtime_local"), r.get("sha256"), r.get("md5"),
                 r.get("uid"), r.get("batch"), tzq=r.get("tzq")) for r in rows]
    add(name, meta["run_mode"], meta["volume"], recs)

    # --- inv_leg01_q3.xml --------------------------------------------------
    name = "inv_leg01_q3.xml"
    ctl, root, rows = read_xml_file(data / name)
    volume = ident(root.get("volume"))
    if not volume:
        volume = load_serials(data).get(ident(root.get("volume_serial")), "")
    recs = [_rec(name, volume, r.get("id"), r.get("path"),
                 r.get("size"), r.get("mtime"), r.get("sha256"), r.get("md5"),
                 r.get("owner"), r.get("batch"),
                 unit=norm(r.get("size@unit"))) for r in rows]
    add(name, root.get("run_mode"), volume, recs)

    # --- inv_mkt01_q3.jsonl ------------------------------------------------
    name = "inv_mkt01_q3.jsonl"
    ctl, meta, rows = read_jsonl_file(data / name)
    recs = [_rec(name, meta["volume"], r.get("id"), r.get("p"), r.get("sz"),
                 r.get("mt"), r.get("sha256"), r.get("md5b64"), r.get("own"),
                 r.get("batch")) for r in rows]
    add(name, meta["run_mode"], meta["volume"], recs)

    # --- inv_mkt01_supplement.xlsx -----------------------------------------
    name = "inv_mkt01_supplement.xlsx"
    ctl, meta, sheets, order, epoch1904 = read_xlsx_file(data / name)
    recs = []
    for sheet in order:
        for r in sheets[sheet]:
            recs.append(_rec(name, meta["volume"], r.get("record"),
                             r.get("location"), r.get("size"), r.get("modified"),
                             r.get("sha256"), None, r.get("owner"),
                             r.get("batch"), epoch1904=epoch1904))
    add(name, meta["run_mode"], meta["volume"], recs)

    # --- inv_obj01_q3_r2.csv -----------------------------------------------
    name = "inv_obj01_q3_r2.csv"
    ctl, meta, cols, rows = read_delimited(data / name)
    head = parse_kv_line(" ".join(meta))
    recs = []
    for r in rows:
        not_file = (as_bool(r.get("is_latest")) is False or
                    as_bool(r.get("delete_marker")) is True)
        recs.append(_rec(name, head["volume"], r.get("rec_id"), r.get("key"),
                         r.get("size"), r.get("last_modified"), r.get("sha256"),
                         etag_digest(r.get("etag")), r.get("owner_id"),
                         r.get("batch"), not_file=not_file))
    add(name, head["run_mode"], head["volume"], recs)

    # --- inv_ops01_q3.tsv --------------------------------------------------
    name = "inv_ops01_q3.tsv"
    ctl, meta, cols, rows = read_delimited(data / name)
    head = parse_kv_line(" ".join(meta))
    recs = []
    for r in rows:
        placeholder = ident(r.get("size_kb")) == "N/A"
        recs.append(_rec(name, head["volume"], r.get("rec_id"), r.get("path"),
                         r.get("size_kb"), r.get("mtime_local"), r.get("sha256"),
                         None, r.get("owner"), r.get("batch"),
                         file_id=as_int(r.get("inode")),
                         nlink=as_int(r.get("nlink")) or 1,
                         not_file=placeholder))
    add(name, head["run_mode"], head["volume"], recs)

    # --- inv_rnd01_q3.json -------------------------------------------------
    name = "inv_rnd01_q3.json"
    ctl, doc = read_json_file(data / name)
    meta = doc.get("export", {})
    recs = [_rec(name, meta["volume"], r.get("id"), r.get("path"), r.get("bytes"),
                 r.get("mtime_ms"), r.get("sha256"), r.get("sha1"),
                 r.get("owner"), r.get("batch")) for r in json_list(doc, "items")]
    add(name, meta["run_mode"], meta["volume"], recs)

    # --- rnd01_cold_listing.pdf --------------------------------------------
    name = "rnd01_cold_listing.pdf"
    ctl, preamble, blocks = read_pdf_file(data / name)
    head = parse_kv_line(" ".join(preamble))
    recs = []
    for cols, rows in blocks:
        if "rec_id" not in cols:
            continue
        for r in rows:
            recs.append(_rec(name, head["volume"], r.get("rec_id"), r.get("path"),
                             r.get("size"), r.get("modified"), r.get("sha256"),
                             r.get("sha1"), r.get("owner"), r.get("batch")))
    add(name, head["run_mode"], head["volume"], recs)

    # --- arc01_tape_catalog.txt --------------------------------------------
    name = "arc01_tape_catalog.txt"
    ctl, meta, rows = read_fixed_file(data / name)
    recs = [_rec(name, meta["volume"], r.get("rec_id"), r.get("path"),
                 r.get("size"), r.get("mtime_julian"), r.get("sha256"),
                 r.get("sha1"), r.get("owner"), r.get("batch"),
                 flag=ident(r.get("flag"))) for r in rows]
    add(name, meta["run_mode"], meta["volume"], recs)

    # --- arc01_ltfs_index.db -----------------------------------------------
    name = "arc01_ltfs_index.db"
    ctl, meta, tables = read_sqlite_file(data / name)
    rows = sqlite_table(tables, "ltfs_files")
    recs = [_rec(name, meta["volume"], r.get("rec_id"), r.get("path"),
                 r.get("bytes"), r.get("mtime"), r.get("sha256"), r.get("sha1"),
                 r.get("owner"), r.get("batch"),
                 file_id=_hexint(r.get("file_id")),
                 nlink=as_int(r.get("nlink")) or 1) for r in rows]
    add(name, meta["run_mode"], meta["volume"], recs)
    return out


def ltfs_index(data):
    """file_id and nlink of ARC01 records, keyed by raw path (section 6.6)."""
    _ctl, _meta, tables = read_sqlite_file(data / "arc01_ltfs_index.db")
    out = {}
    for row in sqlite_table(tables, "ltfs_files"):
        out[norm(row.get("path"))] = (_hexint(row.get("file_id")),
                                      as_int(row.get("nlink")) or 1)
    return out


# ------------------------------------------------------------ not-a-file rules

NTFS_VOLUMES = ("ENG01", "ENG02", "LEG01")


def is_not_a_file(volume, path, rec):
    """ops-runbook.md: records that do not describe files."""
    if rec.get("not_file"):
        return True
    base = path.rsplit("/", 1)[-1]
    low = base.lower()
    segs = path.split("/")[1:-1]
    if volume in NTFS_VOLUMES and low == "desktop.ini":
        return True
    if volume == "MKT01" and low == ".ds_store":
        return True
    if volume == "LAB01" and base.startswith("._"):
        return True
    if volume == "OBJ01" and any(s == "_temporary" for s in path.split("/")):
        return True
    if volume in ("HR01", "OPS01") and any(s.lower() == "lost+found" for s in segs):
        return True
    if volume == "ARC01" and (rec.get("flag") == "X" or low.endswith(".spanned")):
        return True
    if volume == "RND01" and low.endswith(".hsmstub"):
        return True
    return False


# ------------------------------------------------------------------- journals

def _ev(file, volume, role, rec_id, op, seq, **kw):
    ev = {"file": file, "volume": ident(volume), "role": lc(role),
          "rec_id": ident(rec_id), "op": ident(op), "seq": seq,
          "raw_path": norm(kw.get("path")), "raw_to": norm(kw.get("to")),
          "raw_size": kw.get("size"), "raw_mtime": kw.get("at"),
          "raw_sha256": norm(kw.get("sha256")),
          "raw_legacy": norm(kw.get("legacy")),
          "raw_owner": norm(kw.get("owner")),
          "batch": ident(kw.get("batch")), "host": lc(kw.get("host")),
          "not_file": bool(kw.get("not_file")), "is_event": True}
    return ev


def journal_gap(data):
    """The replica window named in ops-runbook.md (section 3.3)."""
    _, text = read_md_file(data / "ops-runbook.md")
    body = text.split("## Journal gap")[1].split("##")[0]
    rng = re.search(r"sequence numbers\s+(\d+)\s+through\s+(\d+)", body)
    repl = re.search(r"replica journal\s+(\S+?)\s+is authoritative", body)
    if not rng or not repl:
        return None
    return (repl.group(1), int(rng.group(1)), int(rng.group(2)))


def load_journals(data):
    out = {}

    def add(name, role, volume, events):
        out[name] = (lc(role), ident(volume), events)

    # --- journal_eng01_q3.log / fin01 / mkt01 / mkt01_b / ops01 ------------
    for name in ("journal_eng01_q3.log", "journal_fin01_q3.log",
                 "journal_mkt01_q3.log", "journal_mkt01_q3_b.log",
                 "journal_ops01_q3.log"):
        ctl, meta, rows = read_log_file(data / name)
        events = []
        for r in rows:
            events.append(_ev(name, meta["volume"], meta.get("role"), r.get("id"),
                              r.get("op"), as_int(r.get("seq")),
                              path=r.get("path"), to=r.get("to"),
                              size=r.get("size"), at=r.get("ts"),
                              sha256=r.get("sha256"),
                              legacy=r.get("md5b64") or r.get("md5") or r.get("sha1"),
                              owner=r.get("owner"), batch=r.get("batch"),
                              host=r.get("host")))
        add(name, meta.get("role"), meta["volume"], events)

    # --- journal_eng02_q3.csv ----------------------------------------------
    name = "journal_eng02_q3.csv"
    ctl, meta, cols, rows = read_delimited(data / name)
    head = parse_kv_line(" ".join(meta))
    events = [_ev(name, head["volume"], head.get("role"), r.get("rec_id"),
                  r.get("op"), as_int(r.get("seq")), path=r.get("path"),
                  to=r.get("new_path"), size=r.get("size"),
                  at=r.get("filetime"), sha256=r.get("sha256"),
                  legacy=r.get("md5"), owner=r.get("owner"),
                  batch=r.get("batch")) for r in rows]
    add(name, head.get("role"), head["volume"], events)

    # --- journal_fin02_q3.xml ----------------------------------------------
    name = "journal_fin02_q3.xml"
    ctl, root, rows = read_xml_file(data / name)
    events = [_ev(name, root["volume"], root.get("role"), r.get("id"),
                  r.get("op"), as_int(r.get("seq")), path=r.get("path"),
                  to=r.get("to"), size=r.get("size"), at=r.get("at"),
                  sha256=r.get("sha256"), legacy=r.get("sha1"),
                  owner=r.get("owner"), batch=r.get("batch")) for r in rows]
    add(name, root.get("role"), root["volume"], events)

    # --- journal_hr01_q3.jsonl ---------------------------------------------
    name = "journal_hr01_q3.jsonl"
    ctl, meta, rows = read_jsonl_file(data / name)
    events = [_ev(name, meta["volume"], meta.get("role"), r.get("id"),
                  r.get("op"), as_int(r.get("seq")), path=r.get("path"),
                  to=r.get("to"), size=r.get("size"), at=r.get("at"),
                  sha256=r.get("sha256"), legacy=r.get("md5"),
                  owner=r.get("owner"), batch=r.get("batch")) for r in rows]
    add(name, meta.get("role"), meta["volume"], events)

    # --- journal_rnd01_q3.json ---------------------------------------------
    name = "journal_rnd01_q3.json"
    ctl, doc = read_json_file(data / name)
    meta = doc.get("journal", {})
    events = [_ev(name, meta["volume"], meta.get("role"), r.get("id"),
                  r.get("op"), as_int(r.get("seq")), path=r.get("path"),
                  to=r.get("to"), size=r.get("bytes"), at=r.get("at"),
                  sha256=r.get("sha256"), legacy=r.get("sha1"),
                  owner=r.get("owner"), batch=r.get("batch"))
              for r in json_list(doc, "events")]
    add(name, meta.get("role"), meta["volume"], events)

    # --- journal_leg01_notifications.mbox ----------------------------------
    name = "journal_leg01_notifications.mbox"
    ctl, meta, rows = read_mbox_file(data / name)
    events = []
    for r in rows:
        subject = norm(r.get("Subject"))
        bits = subject.replace("[FSWATCH]", "").split()
        op = bits[0] if bits else ""
        rec_id = bits[1] if len(bits) > 1 else norm(r.get("Message-ID")).strip("<>")
        path = ""
        to = ""
        for line in (r.get("_body") or "").split("\n"):
            if line.startswith("Path:"):
                path = line[5:].strip()
            elif line.startswith("To:"):
                to = line[3:].strip()
        events.append(_ev(name, meta["volume"], meta.get("role"), rec_id, op,
                          as_int(r.get("X-Seq")), path=path, to=to,
                          size=r.get("X-Size"), at=r.get("Date"),
                          sha256=r.get("X-Sha256"), legacy=r.get("X-Md5"),
                          owner=r.get("X-Owner"), batch=r.get("X-Batch")))
    add(name, meta.get("role"), meta["volume"], events)

    # --- journal_obj01_events.jsonl ----------------------------------------
    name = "journal_obj01_events.jsonl"
    ctl, meta, rows = read_jsonl_file(data / name)
    events = []
    for r in rows:
        s3 = r.get("s3") or {}
        obj = s3.get("object") or {}
        bucket = norm((s3.get("bucket") or {}).get("name"))
        key = norm(obj.get("key"))
        ename = norm(r.get("eventName"))
        if ename.startswith("ObjectCreated"):
            op = "CREATE"
        elif ename.startswith("ObjectRemoved"):
            op = "DELETE"
        else:
            op = ename.upper()
        seq = obj.get("sequencer")
        try:
            seqv = int(norm(seq), 16)
        except ValueError:
            seqv = None
        events.append(_ev(name, meta["volume"], meta.get("role"), r.get("id"),
                          op, seqv, path="s3://%s/%s" % (bucket, key),
                          size=obj.get("size"), at=r.get("eventTime"),
                          sha256=obj.get("sha256"),
                          legacy=etag_digest(obj.get("eTag")),
                          owner=(r.get("userIdentity") or {}).get("canonicalId"),
                          batch=r.get("batch")))
    add(name, meta.get("role"), meta["volume"], events)
    return out


# ------------------------------------------------------------------- classes

class Schedule:
    """Table 1 and the footnotes of retention-schedule-2026-r2.docx (7.1)."""

    def __init__(self, data):
        _ctl, paras, tables = read_docx_file(data / "retention-schedule-2026-r2.docx")
        self.classes = {}
        for table in tables:
            cols, rows = rows_from_matrix(table)
            if "class" not in cols:
                continue
            for row in rows:
                name = lc(row.get("class"))
                if not name:
                    continue
                self.classes[name] = (as_int(row.get("purge_after_days")),
                                      as_int(row.get("archive_after_days")))
            break
        self.no_purge = set()
        for para in paras:
            if not para.lower().startswith("footnote"):
                continue
            if "purge" not in para.lower():
                continue
            if "ever purged" in para.lower() or "never purged" in para.lower():
                for code in re.findall(r"volume ([A-Z][A-Z0-9]{2,})", para):
                    self.no_purge.add(ident(code))


# --------------------------------------------------------- extension families

def load_family_tables(data):
    """Family tables A-E in precedence order (section 7.2)."""
    tables = []

    rows_a = read_delimited(data / "ext_families_a.tsv")[3]
    corrections = {}
    _ctl, _paras, dtables = read_docx_file(data / "retention-schedule-2026-r3.docx")
    for table in dtables:
        cols, rows = rows_from_matrix(table)
        if cols == ["ext", "family", "rev"]:
            for row in rows:
                ext = lc(row.get("ext"))
                rev = as_int(row.get("rev")) or 0
                cur = corrections.get(ext)
                if cur is None or rev >= cur[0]:
                    corrections[ext] = (rev, ident(row.get("family")))
    fixed = []
    for row in rows_a:
        row = dict(row)
        if lc(row.get("pending")) == "yes":
            hit = corrections.get(lc(row.get("ext")))
            if hit:
                row["family"] = hit[1]
        fixed.append(row)
    tables.append(fixed)

    _ctl, _meta, sheets, order, _e = read_xlsx_file(data / "ext_families_b.xlsx")
    tables.append([r for s in order for r in sheets[s]])

    _ctl, _paras, dtables = read_docx_file(data / "retention-schedule-2026-r2.docx")
    annex = []
    for table in dtables:
        cols, rows = rows_from_matrix(table)
        if "ext" in cols:
            annex.extend(rows)
    tables.append(annex)

    _ctl, sections = read_html_file(data / "ext_families_wiki.html")
    tables.append(html_section(sections, "Families"))

    tables.append(builtin_families(data))
    return tables


def builtin_families(data):
    """Family table E: the export set's own tool.zip (section 7.2)."""
    path = data / "tool.zip"
    if not path.exists():
        return []
    with zipfile.ZipFile(path) as zf:
        member = None
        for name in zf.namelist():
            if name.endswith("ext_families_builtin.tsv"):
                member = name
                break
        if member is None:
            return []
        text = zf.read(member).decode("utf-8-sig")
    matrix = [line.split("\t") for line in text.split("\n") if line.strip()]
    return rows_from_matrix(matrix)[1]


class Families:
    """Effective extension -> family (section 7.2)."""

    def __init__(self, data):
        self.effective = {}
        for table in reversed(load_family_tables(data)):
            best = {}
            for row in table:
                ext = lc(row.get("ext"))
                if not ext:
                    continue
                rev = as_int(row.get("rev")) or 0
                cur = best.get(ext)
                if cur is None or rev >= cur[0]:
                    best[ext] = (rev, lc(row.get("status")), ident(row.get("family")))
            for ext, (_rev, status, family) in best.items():
                if status == "retired" or family in ("", "N/A"):
                    continue
                self.effective[ext] = family

    def extension_of(self, name):
        """Longest dotted suffix that has an effective family."""
        base = name.rsplit("/", 1)[-1]
        start = 1 if base.startswith(".") else 0
        parts = base[start:].split(".")
        for i in range(1, len(parts)):
            cand = ".".join(parts[i:]).lower()
            if cand in self.effective:
                return cand
        return None

    def family_of(self, name):
        ext = self.extension_of(name)
        return self.effective.get(ext) if ext else None


# --------------------------------------------------------------------- rules

def _glob_regex(pattern):
    marker = "\x00"
    pat = pattern.replace("/**/", marker)
    out = []
    i = 0
    while i < len(pat):
        ch = pat[i]
        if ch == marker:
            out.append("(?:/|/(?:[^/]+/)+)")
            i += 1
        elif ch == "*":
            if pat[i:i + 2] == "**":
                out.append(".*")
                i += 2
            else:
                out.append("[^/]*")
                i += 1
        elif ch == "?":
            out.append("[^/]")
            i += 1
        else:
            out.append(re.escape(ch))
            i += 1
    return re.compile("".join(out) + r"\Z")


class Rules:
    """The effective retention ruleset (section 7.3)."""

    def __init__(self, data, tickets):
        withdrawn = set()
        v4 = read_toml_file(data / "retention_rules_v4.toml")[1]
        for row in yaml_list(v4, "withdrawal"):
            if tickets.approved(row.get("ticket")):
                withdrawn.add(as_int(row.get("rule_seq")))
        v3 = read_yaml_file(data / "retention_rules_v3.yaml")[1]
        base = []
        for row in yaml_list(v3, "rules"):
            if lc(row.get("status")) != "active":
                continue
            seq = as_int(row.get("seq"))
            if seq in withdrawn:
                continue
            base.append((seq, row))
        base.sort(key=lambda x: x[0])
        overlays = []
        ov = read_toml_file(data / "retention_overlays.toml")[1]
        for row in yaml_list(ov, "overlay"):
            overlays.append((as_int(row.get("seq")), row))
        overlays.sort(key=lambda x: x[0])
        self.rules = []
        for idx, (_seq, row) in enumerate(base + overlays):
            self.rules.append(self._compile(row, idx))
        self.by_volume = {}

    @staticmethod
    def _compile(row, idx):
        pattern = norm(row.get("pattern"))
        scope = ident(row.get("scope")) if norm(row.get("scope")) != "*" else "*"
        klass = lc(row.get("class"))
        kind = "glob"
        family = None
        if pattern.lower().startswith("family:"):
            kind = "family"
            family = ident(pattern.split(":", 1)[1])
        directory = pattern.endswith("/")
        body = pattern[:-1] if directory else pattern
        anchored = "/" in body
        if anchored and not body.startswith("/"):
            body = "/" + body
        head = None
        if kind == "glob" and anchored:
            seg = body.split("/", 2)[1] if body.count("/") >= 1 else ""
            if seg and "*" not in seg and "?" not in seg:
                head = "/" + seg
        return {"idx": idx, "scope": scope, "class": klass, "kind": kind,
                "family": family, "pattern": body, "directory": directory,
                "anchored": anchored, "head": head, "rx": {}}

    def for_volume(self, volume, lowered):
        key = (volume, lowered)
        hit = self.by_volume.get(key)
        if hit is None:
            always = []
            heads = {}
            for rule in self.rules:
                if rule["scope"] not in ("*", volume):
                    continue
                if rule["head"] is None:
                    always.append(rule)
                else:
                    head = rule["head"].lower() if lowered else rule["head"]
                    heads.setdefault(head, []).append(rule)
            hit = (always, heads)
            self.by_volume[key] = hit
        return hit

    @staticmethod
    def _regex(rule, lowered):
        rx = rule["rx"].get(lowered)
        if rx is None:
            pat = rule["pattern"].lower() if lowered else rule["pattern"]
            rx = _glob_regex(pat)
            rule["rx"][lowered] = rx
        return rx

    def classify(self, volume, path, family, lowered):
        base = path.rsplit("/", 1)[-1]
        segs = path.split("/")[1:]
        ancestors = []
        acc = ""
        for seg in segs[:-1]:
            acc = acc + "/" + seg
            ancestors.append((acc, seg))
        always, heads = self.for_volume(volume, lowered)
        head = "/" + segs[0] if segs else ""
        best = (-1, "standard")
        for group in (always, heads.get(head, ())):
            for rule in group:
                if rule["idx"] < best[0]:
                    continue
                if rule["kind"] == "family":
                    if family and family == rule["family"]:
                        best = (rule["idx"], rule["class"])
                    continue
                rx = self._regex(rule, lowered)
                if rule["directory"]:
                    for full, name in ancestors:
                        if rx.match(full if rule["anchored"] else name):
                            best = (rule["idx"], rule["class"])
                            break
                elif rx.match(path if rule["anchored"] else base):
                    best = (rule["idx"], rule["class"])
        return best[1]


# ---------------------------------------------------------------- legal holds

class Holds:
    """Legal hold registers A, B, D and E (section 7.5)."""

    def __init__(self, data, tickets, window_start, window_end, paths):
        _ctl, _meta, sheets, _order, _e = read_xlsx_file(data / "holds_matter_index.xlsx")
        matters = {}
        for row in sheets.get("matters", []):
            matters[ident(row.get("matter_id"))] = lc(row.get("status"))
        released = set()
        for row in docx_rows(read_docx_file(data / "legal-hold-memo-q3.docx")[2])[1]:
            if not tickets.approved(row.get("ticket")):
                continue
            when = parse_iso(row.get("released_utc"))
            if when is not None and when < window_end:
                released.add(ident(row.get("hold_id")))
        rows = []
        rows.extend(read_delimited(data / "legal_holds_register.csv")[3])
        rows.extend(sheets.get("holds", []))
        _ctl, sections = read_html_file(data / "holds_portal_export.html")
        rows.extend(html_section(sections, "Holds"))
        for event in read_ics_file(data / "legal_hold_windows.ics")[1]:
            status = norm(event.get("STATUS")).upper()
            rows.append({"hold_id": event.get("UID"),
                         "volume": event.get("X-VOLUME"),
                         "prefix": event.get("X-HOLD-PREFIX"),
                         "from_utc": _ics_time(event.get("DTSTART")),
                         "to_utc": _ics_time(event.get("DTEND")),
                         "status": "active" if status == "CONFIRMED" else "cancelled",
                         "matter": event.get("X-MATTER")})
        self.by_volume = {}
        for row in rows:
            hid = ident(row.get("hold_id"))
            if lc(row.get("status")) != "active":
                continue
            if hid in released:
                continue
            if matters.get(ident(row.get("matter"))) == "closed":
                continue
            frm = parse_iso(row.get("from_utc"))
            if frm is None or frm >= window_end:
                continue
            to_raw = norm(row.get("to_utc"))
            if to_raw:
                to = parse_iso(to_raw)
                if to is None or to <= window_start:
                    continue
            vol = ident(row.get("volume"))
            prefix = norm(row.get("prefix")).rstrip("/")
            if paths.ci.get(vol):
                prefix = prefix.lower()
            if prefix:
                self.by_volume.setdefault(vol, set()).add(prefix)

    def covers(self, volume, path):
        hold = self.by_volume.get(volume)
        if not hold:
            return False
        for anc in path_ancestors(path):
            if anc in hold:
                return True
        return False


def path_ancestors(path):
    """The path itself and every ancestor directory path, longest first."""
    out = [path]
    idx = path.rfind("/")
    while idx > 0:
        path = path[:idx]
        out.append(path)
        idx = path.rfind("/")
    return out


def _ics_time(value):
    s = norm(value)
    if not s:
        return ""
    m = re.match(r"^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z?$", s)
    if not m:
        return s
    return "%s-%s-%sT%s:%s:%sZ" % m.groups()


# -------------------------------------------------------------- resolved time

ISO_DIALECTS = ("iso_z", "iso_ms", "iso_offset", "iso_mixed")


def resolve_time(raw, dialect, zones, zone, epoch1904=False, tzq=None):
    """One instant from a source's time dialect (section 4)."""
    if dialect in ISO_DIALECTS:
        return parse_iso(raw)
    if dialect == "filetime":
        return parse_filetime(raw)
    if dialect.startswith("epoch"):
        return parse_epoch(raw, dialect)
    if dialect == "rfc2822":
        return parse_rfc2822(raw)
    if dialect == "julian":
        return parse_julian(raw)
    if dialect == "excel1904_utc":
        return parse_excel(raw, True)
    if dialect == "excel1900_local":
        wall = parse_excel(raw, epoch1904)
        return zones.to_utc(wall, zone) if wall is not None else None
    if dialect in ("local", "local_dmy"):
        wall = parse_wall(raw)
        if wall is None:
            return None
        return zones.to_utc(wall, zone)
    if dialect == "local_tzq":
        wall = parse_wall(raw)
        if wall is None:
            return None
        if tzq is None or norm(tzq) == "":
            return zones.to_utc(wall, zone)
        quarters = as_int(tzq)
        if quarters is None:
            return zones.to_utc(wall, zone)
        return wall - quarters * 900
    return parse_iso(raw)


# ------------------------------------------------------------ subtree flags

def build_subtrees(cfg, paths):
    out = {}
    head = "subtree."
    for key, value in cfg.items():
        if not key.startswith(head):
            continue
        rest = key[len(head):]
        vol, colon, tail = rest.partition(":")
        if not colon:
            continue
        prefix, dot, flag = tail.rpartition(".")
        if not dot:
            continue
        prefix = prefix.rstrip("/")
        vol = ident(vol)
        if paths.ci.get(vol):
            prefix = prefix.lower()
        out.setdefault((vol, flag), {})[prefix] = bool(value)
    return out


def subtree_flag(subtrees, volume, path, flag):
    table = subtrees.get((volume, flag))
    if not table:
        return None
    for anc in path_ancestors(path):
        if anc in table:
            return table[anc]
    return None


# --------------------------------------------------------------------- entry

REASON_ORDER = ["OUT_OF_AUTHORITY", "SUPERSEDED_SCOPE", "VOIDED", "NOT_A_FILE",
                "STALE_EVENT", "DEFERRED_EVENT", "PATH_UNRESOLVED",
                "SIZE_UNKNOWN", "HASH_UNRESOLVED", "OWNER_UNRESOLVED",
                "DUPLICATE_PATH", "ORPHAN_EVENT", "DELETED", "REPLACED",
                "HARDLINK_ALIAS", "PURGED"]
REASON_RANK = {r: i for i, r in enumerate(REASON_ORDER)}


class Manifest:
    """Builds one profile's placement manifest."""

    def __init__(self, sources, cfg, profile):
        self.src = sources
        self.cfg = cfg
        self.profile = profile
        self.window_start = parse_iso(cfg["window.start"])
        self.window_end = parse_iso(cfg["window.end"])
        self.tickets = sources.tickets(self.window_end)
        self.paths = sources.paths(cfg)
        self.zones = sources.zones()
        self.subtrees = build_subtrees(cfg, self.paths)
        self.zone_of = {}
        for code in sources.volumes:
            self.zone_of[code] = volume_zone(code, sources.volumes, cfg,
                                             sources.hosts())
        self.voids = sources.voids(self.window_end)
        self.errata = sources.errata(self.window_end)
        self.authority = sources.authority(self.window_end)
        self.owners = sources.owners(self.window_end)
        self.rules = sources.rules(self.window_end)
        self.holds = sources.holds(self.window_end, cfg, self.paths)
        self.schedule = sources.schedule()
        self.families = sources.families()
        self.digests = sources.digests()
        self.batches = sources.batches()
        self.reasons = {}
        self.applied = set()
        self.live = {}
        self.deleted = {}
        self.entries = []

    # -- helpers ----------------------------------------------------------
    def mark(self, rec_id, reason):
        cur = self.reasons.get(rec_id)
        if cur is None or REASON_RANK[reason] < REASON_RANK[cur]:
            self.reasons[rec_id] = reason

    def canonical(self, raw, volume):
        vol, path = self.paths.canonical(raw)
        if path is None or (volume and vol != volume):
            return None
        return path

    def batch_time(self, batch):
        return self.batches.captured.get(ident(batch))

    def resolve_size(self, rec, dialect):
        fix = self.errata.get(rec["rec_id"], "bytes")
        if fix is not None:
            return as_int(fix)
        unit = None
        if dialect == "xmlunit":
            unit = UNIT_BYTES.get(lc(rec.get("unit")))
        elif dialect == "unit":
            unit = self.batches.unit_bytes(rec.get("batch"))
        return parse_size(rec.get("raw_size"), dialect, unit,
                          self.src.sentinels.get(rec["file"]))

    def resolve_digest(self, rec, dialect=""):
        fix = self.errata.get(rec["rec_id"], "sha256")
        if fix is not None:
            return lc(fix) or None
        legacy = rec.get("raw_legacy")
        if dialect == "md5b64":
            legacy = md5_from_base64(legacy)
        elif dialect == "etag":
            legacy = etag_digest(legacy)
        return self.digests.resolve(rec["volume"], rec.get("raw_sha256"), legacy)

    def resolve_owner(self, rec):
        fix = self.errata.get(rec["rec_id"], "owner")
        if fix is not None:
            return norm(fix) or None
        return self.owners.account(rec.get("raw_owner"))

    def resolve_mtime(self, rec, dialect, zone):
        fix = self.errata.get(rec["rec_id"], "mtime")
        if fix is not None:
            got = parse_iso(fix)
            if got is not None:
                return got
        got = resolve_time(rec.get("raw_mtime"), dialect, self.zones, zone,
                           epoch1904=rec.get("epoch1904", False),
                           tzq=rec.get("tzq"))
        if got is None:
            got = self.batch_time(rec.get("batch"))
        return got

    # -- the snapshot of every volume -------------------------------------
    def build(self):
        self.load_snapshot()
        self.apply_journals()
        return self.finalise()

    def load_snapshot(self):
        ltfs = self.src.ltfs_canonical(self.paths)
        candidates = {}
        for file, (mode, volume, recs) in self.src.inventories.items():
            spec = self.src.dialects.get(file, {})
            tdial = spec.get("time", "")
            sdial = spec.get("size", "")
            ddial = spec.get("digest", "")
            authoritative = mode in AUTHORITATIVE_MODES
            scope = self.authority.scope_for(volume)
            zone = self.zone_of.get(volume, "")
            for rec in recs:
                rid = rec["rec_id"]
                path = self.canonical(rec["raw_path"], volume)
                mine = False
                other = False
                if scope and path is not None:
                    for subject, prefix in scope:
                        if not self.paths.match_prefix(volume, path, prefix):
                            continue
                        if subject == file:
                            mine = True
                        else:
                            other = True
                if not authoritative and not mine:
                    self.mark(rid, "OUT_OF_AUTHORITY")
                    continue
                if other and not mine:
                    self.mark(rid, "SUPERSEDED_SCOPE")
                    continue
                if self.voids.is_void(rid, volume):
                    self.mark(rid, "VOIDED")
                    continue
                if is_not_a_file(volume, path or "", rec):
                    self.mark(rid, "NOT_A_FILE")
                    continue
                if path is None:
                    self.mark(rid, "PATH_UNRESOLVED")
                    continue
                size = self.resolve_size(rec, sdial)
                digest = self.resolve_digest(rec, ddial)
                owner = self.resolve_owner(rec)
                if size is None:
                    self.mark(rid, "SIZE_UNKNOWN")
                elif not digest:
                    self.mark(rid, "HASH_UNRESOLVED")
                elif not owner:
                    self.mark(rid, "OWNER_UNRESOLVED")
                candidates.setdefault((volume, path), []).append({
                    "rec": rec, "volume": volume, "path": path, "bytes": size,
                    "sha256": digest, "owner": owner,
                    "mtime": self.resolve_mtime(rec, tdial, zone)})
        keep = []
        for cands in candidates.values():
            if len(cands) > 1:
                best = max(cands, key=self._dup_key)
                for cand in cands:
                    if cand is not best:
                        self.mark(cand["rec"]["rec_id"], "DUPLICATE_PATH")
            else:
                best = cands[0]
            if best["bytes"] is None or not best["sha256"] or not best["owner"]:
                continue
            keep.append(best)
        groups = {}
        for cand in keep:
            rec = cand["rec"]
            fid, nlink = rec.get("file_id"), rec.get("nlink") or 1
            if cand["volume"] == "ARC01":
                fid, nlink = ltfs.get(cand["path"], (None, 1))
            if fid is None or nlink <= 1:
                continue
            groups.setdefault((cand["volume"], fid), []).append(cand)
        aliases = set()
        for group in groups.values():
            if len(group) < 2:
                continue
            stay = min(group, key=lambda c: c["path"])
            for cand in group:
                if cand is not stay:
                    aliases.add(id(cand))
                    self.mark(cand["rec"]["rec_id"], "HARDLINK_ALIAS")
        for cand in keep:
            if id(cand) in aliases:
                continue
            self.live[(cand["volume"], cand["path"])] = {
                "volume": cand["volume"], "path": cand["path"],
                "sha256": cand["sha256"], "bytes": cand["bytes"],
                "mtime": cand["mtime"], "owner": cand["owner"],
                "origin": cand["rec"]["rec_id"]}

    def _dup_key(self, cand):
        captured = self.batch_time(cand["rec"].get("batch"))
        return (captured if captured is not None else -(1 << 62),
                cand["rec"]["rec_id"])

    # -- journals ---------------------------------------------------------
    def apply_journals(self):
        gap = self.src.gap
        host_files = self.src.host_journals
        incidents = self.src.incidents(self.window_end)
        per_volume = {}
        for file, (role, volume, events) in self.src.journals.items():
            for ev in events:
                if role != "primary":
                    if not gap or file != gap[0] or ev["seq"] is None \
                            or not (gap[1] <= ev["seq"] <= gap[2]):
                        self.mark(ev["rec_id"], "OUT_OF_AUTHORITY")
                        continue
                per_volume.setdefault(volume, []).append((file, ev))
        for volume, items in per_volume.items():
            spec_cache = {}
            snapshot = self.authority.snapshot.get(volume)
            zone = self.zone_of.get(volume, "")
            items.sort(key=lambda it: (it[1]["seq"] if it[1]["seq"] is not None
                                       else -1, it[0], it[1]["rec_id"]))
            for file, ev in items:
                spec = spec_cache.get(file)
                if spec is None:
                    spec = self.src.dialects.get(file, {})
                    spec_cache[file] = spec
                self._event(ev, file, volume, spec, snapshot, zone,
                            incidents if file in host_files else {})

    def _event(self, ev, file, volume, spec, snapshot, zone, incidents):
        rid = ev["rec_id"]
        path = self.canonical(ev["raw_path"], volume)
        if self.voids.is_void(rid, volume):
            self.mark(rid, "VOIDED")
            return
        if is_not_a_file(volume, path or "", ev):
            self.mark(rid, "NOT_A_FILE")
            return
        when = resolve_time(ev.get("raw_mtime"), spec.get("time", ""),
                            self.zones, zone)
        if incidents:
            when = correct_skew(incidents, ev.get("host"), when)
        fix = self.errata.get(rid, "mtime")
        if fix is not None:
            got = parse_iso(fix)
            if got is not None:
                when = got
        if when is None:
            when = self.batch_time(ev.get("batch"))
        if when is None or snapshot is None:
            self.mark(rid, "STALE_EVENT")
            return
        if when < snapshot:
            self.mark(rid, "STALE_EVENT")
            return
        if when >= self.window_end:
            self.mark(rid, "DEFERRED_EVENT")
            return
        if path is None:
            self.mark(rid, "PATH_UNRESOLVED")
            return
        op = ev["op"]
        target = None
        if op == "RENAME":
            target = self.canonical(ev["raw_to"], volume)
            if target is None:
                self.mark(rid, "PATH_UNRESOLVED")
                return
        size = digest = owner = None
        if op in ("CREATE", "MODIFY"):
            size = self.resolve_size(ev, spec.get("size", ""))
            if size is None:
                self.mark(rid, "SIZE_UNKNOWN")
                return
            digest = self.resolve_digest(ev, spec.get("digest", ""))
            if not digest:
                self.mark(rid, "HASH_UNRESOLVED")
                return
        if op == "CREATE":
            owner = self.resolve_owner(ev)
            if not owner:
                self.mark(rid, "OWNER_UNRESOLVED")
                return
        key = (volume, path)
        if op == "CREATE":
            old = self.live.pop(key, None)
            if old is not None:
                self.reasons[old["origin"]] = "REPLACED"
            self.live[key] = {"volume": volume, "path": path, "sha256": digest,
                              "bytes": size, "mtime": when, "owner": owner,
                              "origin": rid}
            self.applied.add(rid)
            return
        if op == "MODIFY":
            entry = self.live.get(key)
            if entry is None:
                self.mark(rid, "ORPHAN_EVENT")
                return
            entry["bytes"] = size
            entry["sha256"] = digest
            entry["mtime"] = when
            self.applied.add(rid)
            return
        if op == "RENAME":
            entry = self.live.pop(key, None)
            if entry is None:
                self.mark(rid, "ORPHAN_EVENT")
                return
            old = self.live.pop((volume, target), None)
            if old is not None and old is not entry:
                self.reasons[old["origin"]] = "REPLACED"
            entry["path"] = target
            self.live[(volume, target)] = entry
            self.applied.add(rid)
            return
        if op == "DELETE":
            entry = self.live.pop(key, None)
            if entry is None:
                self.mark(rid, "ORPHAN_EVENT")
                return
            self.reasons[entry["origin"]] = "DELETED"
            self.deleted.setdefault(key, []).append(entry)
            self.applied.add(rid)
            return
        if op == "RESTORE":
            stack = self.deleted.get(key)
            if not stack:
                self.mark(rid, "ORPHAN_EVENT")
                return
            entry = stack.pop()
            old = self.live.pop(key, None)
            if old is not None:
                self.reasons[old["origin"]] = "REPLACED"
            self.reasons.pop(entry["origin"], None)
            self.live[key] = entry
            self.applied.add(rid)
            return
        self.mark(rid, "ORPHAN_EVENT")

    # -- retention and the final manifest ---------------------------------
    def finalise(self):
        purge_on = self.cfg.get("purge.enabled") is True
        entries = sorted(self.live.values(),
                         key=lambda e: (e["volume"], e["path"]))
        out = []
        for entry in entries:
            volume = entry["volume"]
            path = entry["path"]
            lowered = bool(self.paths.ci.get(volume))
            family = self.families.family_of(path)
            klass = self.rules.classify(volume, path, family, lowered)
            purge_after, archive_after = self.schedule.classes.get(
                klass, (None, None))
            age = (self.window_end - entry["mtime"]) // 86400
            if (purge_on and purge_after is not None and age > purge_after
                    and volume not in self.schedule.no_purge
                    and not self.holds.covers(volume, path)
                    and subtree_flag(self.subtrees, volume, path,
                                     "purge_exempt") is not True):
                self.reasons[entry["origin"]] = "PURGED"
                continue
            action = "keep"
            if (archive_after is not None and age >= archive_after
                    and subtree_flag(self.subtrees, volume, path,
                                     "archive_exempt") is not True):
                action = "archive"
            entry = dict(entry, **{"class": klass, "action": action,
                                   "age_days": age})
            out.append(entry)
        self.entries = out
        for entry in out:
            self.reasons.pop(entry["origin"], None)
        return out

    def exceptions(self):
        rows = []
        for rec_id, reason in self.reasons.items():
            if rec_id in self.applied:
                continue
            rows.append({"rec_id": rec_id, "reason": reason})
        rows.sort(key=lambda r: r["rec_id"])
        return rows


def host_journals(data):
    """Section 8: the journals whose events carry a host."""
    _ctl, text = read_md_file(data / "ECS-standard.md")
    section = text.split("## 8. Journals")[1].split("## 9.")[0]
    found = re.search(r"journals that record a host\s*\(([^)]*)\)", section)
    if not found:
        return set()
    return {norm(x) for x in found.group(1).split(",") if norm(x)}


class Sources:
    """Every input of the export set, parsed once and shared by both profiles."""

    def __init__(self, data):
        self.data = data
        self.register = file_register(data)
        self.dialects = export_dialects(data)
        self.volumes = load_volumes(data)
        self.inventories = load_inventories(data, self.dialects)
        self.journals = load_journals(data)
        self.gap = journal_gap(data)
        self.host_journals = host_journals(data)
        self.sentinels = size_sentinels(data)
        self._memo = {}

    def _cached(self, key, make):
        if key not in self._memo:
            self._memo[key] = make()
        return self._memo[key]

    def tickets(self, window_end):
        def make():
            tickets = Tickets(self.data)
            tickets.window_end = window_end
            return tickets
        return self._cached(("tickets", window_end), make)

    def hosts(self):
        return self._cached(("hosts",), lambda: load_hosts(self.data))

    def zones(self):
        return self._cached(("zones",), lambda: Zones(self.data))

    def schedule(self):
        return self._cached(("schedule",), lambda: Schedule(self.data))

    def families(self):
        return self._cached(("families",), lambda: Families(self.data))

    def digests(self):
        return self._cached(("digests",), lambda: Digests(self.data))

    def batches(self):
        return self._cached(("batches",), lambda: Batches(self.data))

    def paths(self, cfg):
        key = tuple(sorted((k, v) for k, v in cfg.items()
                           if k.startswith("vol.") and k.endswith(".case")))
        return self._cached(("paths", key),
                            lambda: Paths(self.data, cfg, self.volumes))

    def voids(self, window_end):
        return self._cached(("voids", window_end),
                            lambda: Voids(self.data, self.tickets(window_end)))

    def errata(self, window_end):
        return self._cached(("errata", window_end),
                            lambda: Errata(self.data, self.tickets(window_end)))

    def authority(self, window_end):
        def make():
            modes = {name: (mode, volume)
                     for name, (mode, volume, _recs) in self.inventories.items()}
            return Authority(self.data, self.tickets(window_end), modes)
        return self._cached(("authority", window_end), make)

    def owners(self, window_end):
        return self._cached(("owners", window_end),
                            lambda: Owners(self.data, window_end,
                                           self.tickets(window_end)))

    def rules(self, window_end):
        return self._cached(("rules", window_end),
                            lambda: Rules(self.data, self.tickets(window_end)))

    def incidents(self, window_end):
        def make():
            adopted = any(version.startswith("rev7") and "appendix-d" in version.lower()
                          for _subject, version in self.authority(window_end).ratified)
            return clock_incidents(self.data, self.tickets(window_end), adopted)
        return self._cached(("incidents", window_end), make)

    def holds(self, window_end, cfg, paths):
        start = parse_iso(cfg["window.start"])
        return self._cached(("holds", start, window_end), lambda: Holds(
            self.data, self.tickets(window_end), start, window_end, paths))

    def ltfs_canonical(self, paths):
        def make():
            out = {}
            for raw, value in ltfs_index(self.data).items():
                _vol, path = paths.canonical(raw)
                if path is not None:
                    out[path] = value
            return out
        return self._cached(("ltfs", id(paths)), make)

    def prior(self):
        def make():
            _ctl, md, rows = read_parquet_file(
                self.data / "estate_manifest_q2.parquet")
            return md, rows
        return self._cached(("prior",), make)

    def store_index(self):
        """Digests already stored in the prior period (section 6.5)."""
        def make():
            rows = list(read_delimited(self.data / "store_index_prior_a.csv")[3])
            rows.extend(read_jsonl_file(self.data / "store_index_prior_b.jsonl")[2])
            rows.extend(read_parquet_file(
                self.data / "store_index_prior_c.parquet")[2])
            _c, _m, tables = read_sqlite_file(self.data / "store_index_prior_d.db")
            rows.extend(sqlite_table(tables, "store_index"))
            best = {}
            for row in rows:
                dig = lc(row.get("sha256"))
                if not dig:
                    continue
                rev = as_int(row.get("rev")) or 0
                cur = best.get(dig)
                if cur is None or rev >= cur[0]:
                    best[dig] = (rev, lc(row.get("status")))
            return {d for d, v in best.items() if v[1] == "present"}
        return self._cached(("store_index",), make)

    def chain(self):
        def make():
            md, _rows = self.prior()
            opening = ident(md.get("closing_ctl_id"))
            chain, _recs = build_chain(self.data, opening)
            return opening, chain
        return self._cached(("chain",), make)


# -------------------------------------------------------------------- ledger

ID_MODULUS = 1000000007


def assign_ids(entries, sources):
    """Entry ids carried over from the previous period (section 10.1)."""
    md, rows = sources.prior()
    prior_live = {}
    for row in rows:
        if lc(row.get("status")) != "live":
            continue
        volume = norm(row.get("volume"))
        if volume not in sources.volumes:
            continue
        prior_live[(volume, norm(row.get("path")))] = as_int(row.get("entry_id"))
    current = set()
    fresh = []
    carried = 0
    for entry in entries:
        key = (entry["volume"], entry["path"])
        current.add(key)
        hit = prior_live.get(key)
        if hit is not None:
            entry["entry_id"] = hit
            carried += 1
        else:
            fresh.append(entry)
    next_id = as_int(md.get("next_entry_id")) or 1
    for entry in fresh:
        entry["entry_id"] = next_id
        next_id += 1
    retired = sum(1 for key in prior_live if key not in current)
    return {"carried": carried, "new": len(fresh), "retired": retired}


def store_bytes(entries, block, prior_digests):
    total = 0
    seen = set()
    for entry in entries:
        digest = entry["sha256"]
        if digest in seen:
            continue
        seen.add(digest)
        if digest in prior_digests:
            continue
        size = entry["bytes"]
        total += -(-size // block) * block if block else size
    return total


def build_ledger(manifest, sources, cfg):
    entries = manifest.entries
    movement = assign_ids(entries, sources)
    md, _rows = sources.prior()
    opening = {"entries": as_int(md.get("closing_entries")) or 0,
               "logical_bytes": as_int(md.get("closing_logical_bytes")) or 0,
               "store_bytes": as_int(md.get("closing_store_bytes")) or 0}
    block = cfg.get("store.block_size") or 1
    delta = store_bytes(entries, block, sources.store_index())
    logical = sum(e["bytes"] for e in entries)
    ids = sum(e["entry_id"] for e in entries) % ID_MODULUS
    per_volume = {}
    for entry in entries:
        slot = per_volume.setdefault(entry["volume"], [0, 0])
        slot[0] += 1
        slot[1] += entry["bytes"]
    counts = {}
    for row in manifest.exceptions():
        counts[row["reason"]] = counts.get(row["reason"], 0) + 1
    return {
        "opening": opening,
        "movement": movement,
        "closing": {"entries": len(entries), "logical_bytes": logical,
                    "store_bytes": opening["store_bytes"] + delta,
                    "id_hash_total": ids},
        "volumes": [{"volume": vol, "entries": per_volume[vol][0],
                     "logical_bytes": per_volume[vol][1]}
                    for vol in sorted(per_volume)],
        "exceptions": {reason: counts[reason]
                       for reason in REASON_ORDER if reason in counts},
    }


# -------------------------------------------------------------------- output

def write_json(path, payload):
    text = json.dumps(payload, indent=1, ensure_ascii=False,
                      sort_keys=False, allow_nan=False)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
        fh.write("\n")


def entry_json(entry):
    return {"entry_id": entry["entry_id"], "volume": entry["volume"],
            "path": entry["path"], "sha256": entry["sha256"],
            "bytes": entry["bytes"], "mtime": fmt_instant(entry["mtime"]),
            "owner": entry["owner"], "class": entry["class"],
            "action": entry["action"], "origin": entry["origin"]}


def consolidate(data, out):
    sources = Sources(data)
    configs, _tickets = build_configs(data)
    ledgers = {}
    reports = {}
    configs_out = {}
    for profile in ("prod", "dev"):
        cfg = configs[profile]
        manifest = Manifest(sources, cfg, profile)
        manifest.build()
        ledger = build_ledger(manifest, sources, cfg)
        ledgers[profile] = ledger
        reports[profile] = manifest.exceptions()
        flat = {key: cfg[key] for key in sorted(cfg)}
        configs_out[profile] = flat
        write_json(out / ("profile_%s.json" % profile), {
            "profile": profile,
            "config": flat,
            "control": ledger["closing"],
            "entries": [entry_json(e) for e in manifest.entries],
        })
    write_json(out / "config.json", configs_out["prod"])
    write_json(out / "validation_report.json",
               {"prod": reports["prod"], "dev": reports["dev"]})
    opening_ctl, chain = sources.chain()
    write_json(out / "summary.json", {
        "opening_ctl_id": opening_ctl,
        "chain": chain,
        "profiles": {"prod": ledgers["prod"], "dev": ledgers["dev"]},
    })


def cmd_run(args):
    data = Path(args.data)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    consolidate(data, out)
    print("ok")
    return 0


def cmd_report(args):
    digest = hashlib.sha256(Path(args.config).read_bytes()).hexdigest()
    commands = args.commands
    if isinstance(commands, str):
        commands = json.loads(commands or "[]")
    report = {"ok": True, "tool": "estatectl", "config_sha256": digest,
              "commands": commands}
    Path(args.out).write_text(json.dumps(report, indent=1, ensure_ascii=False,
                                         sort_keys=False) + "\n",
                              encoding="utf-8")
    return 0


def main():
    ap = argparse.ArgumentParser(prog="estatectl")
    sub = ap.add_subparsers(dest="cmd")
    r = sub.add_parser("run")
    r.add_argument("--data", required=True)
    r.add_argument("--out", required=True)
    r.set_defaults(func=cmd_run)
    e = sub.add_parser("export-report")
    e.add_argument("--config", required=True)
    e.add_argument("--out", required=True)
    e.add_argument("--commands", default="[]")
    e.set_defaults(func=cmd_report)
    args = ap.parse_args()
    if not getattr(args, "func", None):
        ap.print_help()
        return 2
    return args.func(args) or 0


if __name__ == "__main__":
    sys.exit(main())
