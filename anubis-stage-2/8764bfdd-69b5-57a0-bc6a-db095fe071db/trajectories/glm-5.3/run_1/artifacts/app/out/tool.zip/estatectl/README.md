# estatectl

Command-line tool of the storage team's estate consolidation. It reads an export set laid out like `/app/data` and
writes the consolidation outputs described in section 11 of ECS-standard.md.

    python3 estatectl.py run --data <export set directory> --out <output directory>
    python3 estatectl.py export-report --config <config.json> --out <report.json> --commands '<json list>'

`run` writes config.json, profile_prod.json, profile_dev.json, validation_report.json and summary.json into the
output directory and prints ok. It must not read anything outside --data and must give byte-identical output for the
same input.

`export-report` writes the run report: ok, tool (estatectl), config_sha256 (SHA-256 hex of the config.json bytes) and
commands, the list of commands that produced the outputs, each with argv, returncode and stdout.

The tool ships extension family table E (ext_families_builtin.tsv, same columns as table A without pending).

The tool implements the Estate Consolidation Standard end to end: control records and the chain (ECS 10.4),
the four configuration layers with locks, approved tickets and revocations (ECS 2), authority of exports and scope
overrides (ECS 3), the time dialects with local zones and adopted clock incidents (ECS 4), alias roots and canonical
paths with the case rules (ECS 5), sizes in every batch unit, digest crosswalks, duplicates and hard links (ECS 6),
retention classes, rules, legal holds and actions (ECS 7), change journals including replicas and the sequence gap
(ECS 8), the exception report (ECS 9) and the ledger that reconciles with the previous period's manifest (ECS 10).
