#!/usr/bin/env python3
"""estatectl - consolidate estate inventories into placement manifests.

Usage:
  python3 estatectl.py run --data DIR --out DIR
  python3 estatectl.py export-report --config FILE --out FILE --commands JSON

Implements the Estate Consolidation Standard (ECS) for one consolidation period.
Everything is derived from the --data directory; nothing outside --data is read
and nothing outside --out is written.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sqlite3
import sys
import tomllib
import unicodedata
import zipfile
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_EVEN

import openpyxl
import pypdf
import yaml
from lxml import etree

# --------------------------------------------------------------------------
# text normalisation (ECS 2.3)
# --------------------------------------------------------------------------

BOM = '﻿'
ZWSP = '​'


def norm_text(s):
    """Remove U+FEFF and U+200B, trim surrounding spaces, normalise to NFC."""
    if s is None:
        return ''
    if not isinstance(s, str):
        s = str(s)
    s = s.replace(BOM, '').replace(ZWSP, '')
    return unicodedata.normalize('NFC', s).strip()


def norm_id(s):
    """Identifiers compare case-insensitively and are written upper case."""
    return norm_text(s).upper()


def norm_class(s):
    return norm_text(s).lower()


# --------------------------------------------------------------------------
# low level row readers
# --------------------------------------------------------------------------

_IDENT_RE = re.compile(r'^[a-z][a-z0-9_.]*$')


def _looks_like_header(cells, known):
    """A repeated header row: every cell a lowercase identifier, mostly known."""
    vals = [norm_text(c) for c in cells]
    if not vals or any(not v for v in vals):
        return False
    if any(not _IDENT_RE.match(v) for v in vals):
        return False
    hits = sum(1 for v in vals if v in known)
    return hits >= min(2, len(vals))


def read_text(path):
    data = read_bytes(path)
    return data.decode('utf-8')


def read_bytes(path):
    with open(path, 'rb') as fh:
        data = fh.read()
    if data.startswith(b'\xef\xbb\xbf'):
        data = data[3:]
    return data


def read_first_line(path):
    """First line of a file as text (utf-8, latin-1 fallback)."""
    with open(path, 'rb') as fh:
        data = fh.readline()
    if data.startswith(b'\xef\xbb\xbf'):
        data = data[3:]
    for enc in ('utf-8', 'latin-1'):
        try:
            return data.decode(enc).rstrip('\r\n')
        except UnicodeDecodeError:
            continue
    return data.decode('utf-8', 'replace')


def read_delim(path, delim, enc_col=None):
    """csv/tsv reader: #ctl and # comment lines, repeated headers, quoted fields.

    With enc_col the named column gives each line's byte encoding.
    """
    rows = []
    header = None
    known = set()
    enc = 'utf-8'
    for raw in read_bytes(path).split(b'\n'):
        raw = raw.rstrip(b'\r')
        if not raw:
            continue
        probe = raw.decode('latin-1')
        if probe.startswith('#') and (header is None or probe.startswith('#ctl')):
            continue
        if probe.startswith('#'):
            continue
        if enc_col and header is not None:
            fields_probe = _split_tsv(probe) if delim == '\t' else next(csv.reader([probe]))
            try:
                idx = header.index(enc_col)
                val = norm_text(fields_probe[idx]) if idx < len(fields_probe) else ''
            except ValueError:
                val = ''
            if val:
                enc = val
        try:
            line = raw.decode('utf-8')
        except UnicodeDecodeError:
            line = raw.decode(enc, 'replace')
        fields = _split_tsv(line) if delim == '\t' else next(csv.reader([line]))
        if header is None or _looks_like_header(fields, known):
            header = [norm_text(f) for f in fields]
            known.update(header)
            continue
        if len(fields) < len(header):
            fields = fields + [''] * (len(header) - len(fields))
        rows.append(dict(zip(header, fields)))
    return rows


def _split_tsv(line):
    """tsv files escape \\t, \\n, \\r and \\\\ inside fields."""
    out = []
    buf = []
    i = 0
    n = len(line)
    while i < n:
        c = line[i]
        if c == '\\' and i + 1 < n and line[i + 1] in ('t', 'n', 'r', '\\'):
            nxt = line[i + 1]
            if nxt == 't':
                buf.append('\t')
            elif nxt == 'n':
                buf.append('\n')
            elif nxt == 'r':
                buf.append('\r')
            else:
                buf.append('\\')
            i += 2
            continue
        if c == '\t':
            out.append(''.join(buf))
            buf = []
            i += 1
            continue
        buf.append(c)
        i += 1
    out.append(''.join(buf))
    return out


def read_jsonl(path):
    """jsonl: _ctl / _export / _journal lines and {"_schema": {"rename": ...}}."""
    rows = []
    renames = {}
    for line in read_text(path).splitlines():
        line = line.strip()
        if not line:
            continue
        obj = json.loads(line)
        if not isinstance(obj, dict):
            continue
        if '_schema' in obj:
            renames.update(obj['_schema'].get('rename') or {})
            continue
        if '_ctl' in obj and len(obj) == 1:
            continue
        if '_export' in obj and len(obj) == 1:
            continue
        if '_journal' in obj and len(obj) == 1:
            continue
        if renames:
            obj = {(renames.get(k) or k): v for k, v in obj.items()}
        rows.append(obj)
    return rows


def read_json_doc(path):
    with open(path, encoding='utf-8') as fh:
        return json.load(fh)


def _v2_rows(doc, name):
    """Rows of list `name` plus its <name>_v2 continuation (with renames)."""
    renames = {}
    rows = []
    if isinstance(doc, dict):
        renames = doc.get(name + '_v2_renames') or {}
        rows.extend(doc.get(name) or [])
        rows.extend(doc.get(name + '_v2') or [])
    out = []
    for r in rows:
        if renames:
            r = {(renames.get(k) or k): v for k, v in r.items()}
        out.append(r)
    return out


def read_yaml_doc(path):
    return yaml.safe_load(read_text(path))


def read_toml_doc(path):
    return tomllib.loads(read_text(path))


def read_ini(path):
    """ini: [_ctl], [__layout__] (renames) and data sections (duplicates kept)."""
    cp = _IniParser()
    cp.read_string(read_text(path))
    renames = {}
    for sec in cp.sections():
        if sec == '__layout__':
            try:
                renames = json.loads(cp.get(sec, 'renames') or '{}')
            except Exception:
                renames = {}
    rows = []
    for sec, body in cp.data():
        if sec == '__layout__':
            continue
        b = dict(body)
        if renames:
            b = {(renames.get(k) or k): v for k, v in b.items()}
        b['section'] = sec
        rows.append(b)
    return rows


class _IniParser:
    """Minimal ini parser: no interpolation, raw values, duplicate sections kept."""

    def __init__(self):
        self._data = []          # [(section, {key: value})]

    def sections(self):
        return [s for s, _ in self._data]

    def data(self):
        return self._data

    def read_string(self, text):
        sec = None
        for line in text.splitlines():
            if not line.strip() or line.lstrip()[:1] in (';', '#'):
                continue
            s = line.strip()
            if s.startswith('[') and s.endswith(']'):
                sec = s[1:-1].strip()
                self._data.append((sec, {}))
                continue
            if '=' in line and sec is not None:
                k, _, v = line.partition('=')
                self._data[-1][1][k.strip()] = v.strip()

    def get(self, sec, key):
        for s, body in self._data:
            if s == sec:
                return body.get(key)
        return None

    def items(self, sec):
        for s, body in self._data:
            if s == sec:
                return list(body.items())
        return []


def _uri_path(path):
    return os.path.abspath(path).replace('?', '%3f').replace('#', '%23')


def read_sqlite_tables(path):
    """Return {table: [rows]} for every table of a sqlite file."""
    out = {}
    con = sqlite3.connect('file:%s?mode=ro' % _uri_path(path), uri=True)
    try:
        names = [r[0] for r in con.execute(
            "select name from sqlite_master where type='table' order by name")]
        for name in names:
            cols = [d[1] for d in con.execute('PRAGMA table_info("%s")' % name)]
            rows = []
            for r in con.execute('select * from "%s"' % name):
                rows.append(dict(zip(cols, r)))
            out[name] = rows
    finally:
        con.close()
    return out


def read_sqlite_views(path):
    con = sqlite3.connect('file:%s?mode=ro' % _uri_path(path), uri=True)
    try:
        views = {}
        for name, sql in con.execute("select name, sql from sqlite_master where type='view'"):
            views[name] = sql or ''
        return views
    finally:
        con.close()


def _sqlite_view_rows(views, name):
    """Rows of a sqlite view, parsed out of its CREATE VIEW statement."""
    sql = views.get(name) or ''
    m = re.search(r"select\s+(.*?)\s+as\s+", sql, re.S | re.I)
    if not m:
        return []
    cols = [c.strip().strip("'\"") for c in m.group(1).split(',')]
    m2 = re.search(r"as\s+'?(.*?)'?\s*$", sql.strip(), re.S | re.I)
    if not m2:
        return []
    body = m2.group(1)
    return [{cols[i]: v for i, v in enumerate(_sqlite_row_values(body))}]


def _sqlite_row_values(body):
    """Parse the value tuples of a CREATE VIEW ... AS SELECT ... AS 'v1','v2',..."""
    out = []
    i = body.find("'")
    while i >= 0:
        j = body.find("'", i + 1)
        if j < 0:
            break
        out.append(body[i + 1:j])
        i = body.find("'", j + 1)
    return out


def _is_1904(path):
    """A workbook with date1904=1 counts days since 1904-01-01."""
    with zipfile.ZipFile(path) as z:
        wb = z.read('xl/workbook.xml').decode('utf-8', 'replace')
    return bool(re.search(r'date1904="1"', wb))


def read_xlsx_tables(path):
    """Every sheet: first row the header, later rows data."""
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    tables = []
    for ws in wb.worksheets:
        rows = []
        header = None
        known = set()
        for raw in ws.iter_rows(values_only=True):
            cells = [norm_text(c) for c in raw]
            if header is None or _looks_like_header(cells, known):
                header = cells
                known.update(header)
                continue
            if all(c == '' for c in cells):
                continue
            row = {}
            for i, h in enumerate(header):
                if h:
                    row[h] = raw[i] if i < len(raw) else ''
            rows.append(row)
        tables.append({'name': ws.title, 'rows': rows, 'date1904': _is_1904(path)})
    wb.close()
    return tables


def read_docx_tables(path):
    import docx
    d = docx.Document(path)
    tables = []
    for t in d.tables:
        cells = [[norm_text(c.text) for c in r.cells] for r in t.rows]
        if not cells:
            tables.append({'rows': []})
            continue
        header = cells[0]
        known = set(header)
        rows = []
        for r in cells[1:]:
            if _looks_like_header(r, known):
                header = r
                known.update(header)
                continue
            rows.append(dict(zip(header, r)))
        tables.append({'rows': rows})
    return tables


_PDF_U_RE = re.compile(r'\\u([0-9a-fA-F]{4})')
_PDF_SPLIT = re.compile(r'(?<!\\) \| ')


def pdf_cell(s):
    s = _PDF_U_RE.sub(lambda m: chr(int(m.group(1), 16)), s)
    s = s.replace('\\|', '|').replace('\\\\', '\\')
    if s == '~':
        return ''
    return s


def read_pdf_rows(path):
    """pdf tables: every page repeats its COLUMNS line; cells ' | ' separated."""
    reader = pypdf.PdfReader(path)
    text = '\n'.join((p.extract_text() or '') for p in reader.pages)
    rows = []
    header = None
    known = set()
    for line in text.split('\n'):
        if not line.strip() or line.startswith('CONTROL '):
            continue
        if line.startswith('COLUMNS:'):
            header = [norm_text(pdf_cell(c)) for c in _PDF_SPLIT.split(line[len('COLUMNS: '):])]
            known.update(header)
            continue
        if ' | ' not in line or header is None:
            continue
        cells = _PDF_SPLIT.split(line)
        if len(cells) != len(header):
            continue
        rows.append({header[i]: pdf_cell(c) for i, c in enumerate(cells)})
    return rows


def _parse_layout(line):
    layout = {}
    body = line.split(' ', 1)[1] if ' ' in line else ''
    body = re.sub(r'^v\d+\s*', '', body)
    for part in body.split():
        name, _, span = part.partition(':')
        a, _, b = span.partition('-')
        layout[norm_text(name)] = (int(a), int(b))
    return layout


def _as_int(v, default=0):
    if v is None:
        return default
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, int):
        return v
    s = norm_text(v)
    if s == '':
        return default
    try:
        return int(Decimal(s.replace('_', '').replace(',', '')))
    except Exception:
        try:
            return int(Decimal(s))
        except Exception:
            return default


def _offset_seconds(v):
    s = norm_text(v)
    if s == '':
        return 0
    m = re.fullmatch(r'([+-])(\d{1,2}):(\d{2})', s)
    if m:
        sec = int(m.group(2)) * 3600 + int(m.group(3)) * 60
        return -sec if m.group(1) == '-' else sec
    try:
        return int(Decimal(s))
    except Exception:
        return 0


def read_xml_rows(path, tag=None):
    """xml rows: a schema-change element renames columns (old -> new)."""
    root = etree.parse(path).getroot()
    rows = []
    renames = {}
    for el in root:
        name = etree.QName(el).localname
        if name == 'schema-change':
            try:
                ren = json.loads(el.get('renames') or '{}')
            except Exception:
                ren = {}
            for old_name, new_name in ren.items():
                renames[new_name] = old_name
            continue
        if tag is not None and name != tag:
            continue
        d = {}
        for child in el:
            cn = etree.QName(child).localname
            cn = renames.get(cn) or cn
            d[cn] = child.text or ''
        for k, v in el.attrib.items():
            if k not in ('ctl-id', 'ctl-prev', 'ctl-rows'):
                d[k] = v
        rows.append(d)
    return rows


def xml_root_attrs(path):
    return dict(etree.parse(path).getroot().attrib)


def _dt(s):
    """Parse an ISO instant to an aware datetime (UTC)."""
    s = norm_text(s)
    if not s:
        return None
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        m = re.fullmatch(r'(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z?', s)
        if m:
            return datetime(*(int(x) for x in m.groups()), tzinfo=timezone.utc)
        return None


def fmt_instant(dt):
    if dt is None:
        return ''
    return dt.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def read_fixed(path):
    """Fixed width: CTL line, #LAYOUT, #ENC (per line encoding), '+' continuation."""
    raw_lines = read_bytes(path).split(b'\n')
    rows = []
    layout = None
    enc = 'utf-8'
    for raw in raw_lines:
        if raw.endswith(b'\r'):
            raw = raw[:-1]
        head = raw[:1]
        if head in (b'#',):
            line = raw.decode('utf-8', 'replace')
        else:
            line = raw.decode(enc, 'replace')
        line = line.rstrip('\r')
        if not line or line.startswith('CTL '):
            continue
        if line.startswith('#LAYOUT'):
            layout = _parse_layout(line)
            continue
        if line.startswith('#ENC'):
            enc = line.split()[1].strip()
            continue
        if line.startswith('#'):
            continue
        if line.startswith('+'):
            if rows and layout and 'path' in layout:
                rows[-1]['path'] = (rows[-1].get('path') or '') + line[1:]
            continue
        if layout is None:
            continue
        row = {}
        for field, (a, b) in layout.items():
            row[field] = line[a - 1:b] if len(line) >= a else ''
        if row.get('path', '').endswith('+'):
            row['path'] = row['path'][:-1]
            row['__cont'] = True
        rows.append(row)
    for row in rows:
        for k in list(row):
            row[k] = row[k].strip() if k in ('rec_id',) else row[k]
    return rows


def read_bytes(path):
    with open(path, 'rb') as fh:
        data = fh.read()
    if data.startswith(b'\xef\xbb\xbf'):
        data = data[3:]
    return data


def _decode_enc(v, enc):
    return v


def read_log_events(path):
    """log lines: '# ctl ...', '# journal ...', '# FORMAT v2 renames ...',
    '# CHECKPOINT ...' and key=value events with "quoted" values."""
    ctl = None
    meta = {}
    events = []
    renames = {}
    for line in read_text(path).splitlines():
        line = line.rstrip('\r')
        if not line.strip():
            continue
        if line.startswith('#'):
            body = line.lstrip('#').strip()
            if body.startswith('ctl'):
                ctl = body
            elif body.startswith('FORMAT'):
                m = re.search(r'renames\s+(.*)$', body)
                if m:
                    for pair in re.split(r'[,\s]+', m.group(1).strip()):
                        if '=' in pair:
                            k, _, v = pair.partition('=')
                            renames[v.strip()] = k.strip()
            elif body.startswith('journal'):
                for part in body.split():
                    if '=' in part:
                        k, _, v = part.partition('=')
                        meta[k] = v
            continue
        ev = {}
        for m in re.finditer(r'(\w+)=("(?:[^"\\]|\\.)*"|\S+)', line):
            k, v = m.group(1), m.group(2)
            if v.startswith('"'):
                v = v[1:-1].replace('\\"', '"').replace('\\\\', '\\')
            ev[k] = v
        if renames:
            ev = {(renames.get(k) or k): v for k, v in ev.items()}
        events.append(ev)
    return ctl, meta, events


def read_mbox_events(path):
    """mbox: headers carry event fields, the body carries Path:/To: lines."""
    import mailbox
    events = []
    renames = {}
    mb = mailbox.mbox(path)
    for msg in mb:
        d = {}
        for k, v in msg.items():
            d[norm_text(k).lower().replace('-', '_')] = norm_text(v)
        body = msg.get_payload()
        if isinstance(body, list):
            body = ''.join(p.get_payload() or '' for p in body)
        if isinstance(body, bytes):
            body = body.decode('utf-8', 'replace')
        if body:
            cte = norm_text(d.get('content_transfer_encoding', '')).lower()
            if cte == 'quoted-printable':
                import quopri
                body = quopri.decodestring(body.encode('utf-8', 'replace')).decode('utf-8', 'replace')
            elif cte == 'base64':
                import base64
                try:
                    body = base64.b64decode(body).decode('utf-8', 'replace')
                except Exception:
                    pass
        for line in (body or '').splitlines():
            line = line.rstrip('\r')
            if line.startswith('>From'):
                line = line[1:]
            k, sep, v = line.partition(':')
            if sep and norm_text(k).replace('-', '_').isidentifier():
                d.setdefault(norm_text(k).lower().replace('-', '_'), norm_text(v))
        if d.get('x_schema'):
            m = re.search(r'\((.*)\)', d['x_schema'])
            if m:
                for pair in m.group(1).split(','):
                    if ' renamed ' in pair:
                        old, _, new = pair.partition(' renamed ')
                        renames[norm_text(new)] = norm_text(old)
            d.pop('x_schema', None)
        if renames:
            d = {(renames.get(k) or k): v for k, v in d.items()}
        events.append(d)
    return events


def unfold_ics(path):
    text = read_text(path)
    lines = []
    for line in text.splitlines():
        if line.startswith(' ') and lines:
            lines[-1] += line[1:]
        else:
            lines.append(line)
    return lines


def _ics_unescape(v):
    out = []
    i = 0
    while i < len(v):
        if v[i] == '\\' and i + 1 < len(v):
            c = v[i + 1]
            if c in ('\\', ';', ','):
                out.append(c)
                i += 2
                continue
            if c in ('n', 'N'):
                out.append('\n')
                i += 2
                continue
        out.append(v[i])
        i += 1
    return ''.join(out)


def read_ics_events(path):
    events = []
    cur = {}
    renames = {}
    for line in unfold_ics(path):
        if ':' not in line:
            continue
        key, _, value = line.partition(':')
        if key == 'BEGIN' and value.strip() == 'VEVENT':
            cur = {}
            continue
        if key == 'END' and value.strip() == 'VEVENT':
            if renames:
                cur = {(renames.get(k) or k): v for k, v in cur.items()}
            events.append(cur)
            cur = {}
            continue
        key = norm_text(key)
        if key == 'X-SCHEMA':
            m = re.search(r'\((.*)\)', value)
            if m:
                for pair in m.group(1).split(','):
                    if ' becomes ' in pair:
                        old, _, new = pair.partition(' becomes ')
                        renames[norm_text(new)] = norm_text(old)
            continue
        cur[key] = norm_text(_ics_unescape(value))
    return events


def _unescape_html(s):
    s = re.sub(r'&#x([0-9a-fA-F]+);', lambda m: chr(int(m.group(1), 16)), s)
    s = re.sub(r'&#(\d+);', lambda m: chr(int(m.group(1))), s)
    for a, b in (('&amp;', '&'), ('&lt;', '<'), ('&gt;', '>'), ('&quot;', '"'), ('&nbsp;', ' ')):
        s = s.replace(a, b)
    return s


def read_html_tables(path):
    text = read_text(path)
    tables = []
    for chunk in text.split('<table>')[1:]:
        chunk = chunk.split('</table>')[0]
        rows = []
        header = None
        for tr in re.findall(r'<tr>(.*?)</tr>', chunk, re.S):
            cells = re.findall(r'<t[hd]>(.*?)</t[hd]>', tr, re.S)
            cells = [norm_text(_unescape_html(re.sub(r'<[^>]+>', '', c))) for c in cells]
            if header is None:
                header = cells
                continue
            if _looks_like_header(cells, set(header)):
                header = cells
                continue
            rows.append(dict(zip(header, cells)))
        tables.append({'rows': rows})
    return tables


def _split_md_row(line):
    body = line.strip()
    if body.startswith('|'):
        body = body[1:]
    if body.endswith('|'):
        body = body[:-1]
    parts = re.split(r'(?<!\\)\|', body)
    return [p.replace('\\|', '|').replace('\\\\', '\\') for p in parts]


def read_md_tables(path):
    """markdown tables: one dict {'header', 'rows'} per table per heading."""
    tables = []
    header = None
    known = set()
    cur = None
    for line in read_text(path).splitlines():
        if line.startswith('#'):
            header = None
            cur = None
            continue
        line = line.strip()
        if not line.startswith('|') or not line.endswith('|'):
            continue
        cells = [norm_text(c) for c in _split_md_row(line)]
        if cells and all(re.fullmatch(r':?-{2,}:?', c) for c in cells if c):
            continue
        if header is None or _looks_like_header(cells, known):
            header = cells
            known = set(header)
            cur = {'header': header, 'rows': []}
            tables.append(cur)
            continue
        if len(cells) != len(header):
            continue
        cur['rows'].append({header[i]: cells[i] for i in range(len(header))})
    return tables


def read_md_all_rows(path):
    rows = []
    for t in read_md_tables(path):
        rows += t['rows']
    return rows


# --------------------------------------------------------------------------
# control records (ECS 10.4)
# --------------------------------------------------------------------------

_CTL_RE = re.compile(r'ctl_id\s*=\s*(\S+)\s+prev\s*=\s*(\S+)\s+rows\s*=\s*(\d+)')


class Data:
    """All inputs of one export set, keyed by file name."""

    def __init__(self, root):
        self.root = os.path.abspath(root)
        self.ctl = {}          # file -> (ctl_id, prev, rows)
        self.chain = []        # [(file, ctl_id, rows)] in chain order
        self.opening_ctl_id = ''

    def path(self, name):
        return os.path.join(self.root, name)

    def has(self, name):
        return os.path.isfile(self.path(name))

    def read_ctl(self):
        for name in sorted(os.listdir(self.root)):
            p = self.path(name)
            if not os.path.isfile(p):
                continue
            try:
                rec = self._ctl_of(name, p)
            except Exception:
                rec = None
            if rec and rec[0]:
                self.ctl[name] = rec
        self._build_chain()

    def _ctl_of(self, name, p):
        ext = os.path.splitext(name)[1].lower()
        if name.endswith(('.csv', '.tsv')):
            m = _CTL_RE.search(read_first_line(p))
            return (m.group(1), m.group(2), int(m.group(3))) if m else None
        if ext == '.jsonl':
            for line in read_text(p).splitlines():
                if not line.strip():
                    continue
                obj = json.loads(line)
                if '_ctl' in obj:
                    c = obj['_ctl']
                    return (norm_id(c['ctl_id']), norm_id(c['prev']), int(c['rows']))
            return None
        if ext == '.json':
            c = (read_json_doc(p) or {}).get('_ctl')
            return (norm_id(c['ctl_id']), norm_id(c['prev']), int(c['rows'])) if c else None
        if ext == '.xml':
            root = etree.parse(p).getroot()
            if root.get('ctl-id'):
                return (norm_id(root.get('ctl-id')), norm_id(root.get('ctl-prev')),
                        int(root.get('ctl-rows')))
            return None
        if ext == '.xlsx':
            wb = openpyxl.load_workbook(p, read_only=True)
            m = _CTL_RE.search(wb.properties.subject or '')
            wb.close()
            return (m.group(1), m.group(2), int(m.group(3))) if m else None
        if ext == '.docx':
            import docx
            d = docx.Document(p)
            m = _CTL_RE.search(d.core_properties.subject or '')
            return (m.group(1), m.group(2), int(m.group(3))) if m else None
        if ext == '.parquet':
            import pyarrow.parquet as pq
            md = pq.ParquetFile(p).schema_arrow.metadata
            g = lambda k: md[k.encode()].decode()
            return (norm_id(g('ctl_id')), norm_id(g('ctl_prev')), int(g('ctl_rows')))
        if ext in ('.db', '.sqlite'):
            sql = (read_sqlite_views(p) or {}).get('_control', '')
            m = re.search(r"'([^']+)'\s+as\s+ctl_id\s*,\s*'([^']+)'\s+as\s+prev\s*,\s*(\d+)\s+as\s+rows",
                          sql, re.I)
            return (norm_id(m.group(1)), norm_id(m.group(2)), int(m.group(3))) if m else None
        if ext in ('.yaml', '.yml'):
            c = (read_yaml_doc(p) or {}).get('_ctl')
            return (norm_id(c['ctl_id']), norm_id(c['prev']), int(c['rows'])) if c else None
        if ext == '.toml':
            c = (read_toml_doc(p) or {}).get('_ctl')
            return (norm_id(c['ctl_id']), norm_id(c['prev']), int(c['rows'])) if c else None
        if ext == '.ini':
            cp = _IniParser()
            cp.read_string(read_text(p))
            return (norm_id(cp.get('_ctl', 'ctl_id')), norm_id(cp.get('_ctl', 'prev')),
                    int(cp.get('_ctl', 'rows') or 0))
        if ext == '.pdf':
            first = (pypdf.PdfReader(p).pages[0].extract_text() or '').split('\n')[0]
            m = _CTL_RE.search(first)
            return (m.group(1), m.group(2), int(m.group(3))) if m else None
        if ext in ('.md', '.html'):
            m = re.search(r'<!--\s*ctl\s+ctl_id=(\S+)\s+prev=(\S+)\s+rows=(\d+)\s*-->',
                          read_text(p))
            return (m.group(1), m.group(2), int(m.group(3))) if m else None
        if ext == '.log':
            m = re.search(r'#\s*ctl\s+ctl_id=(\S+)\s+prev=(\S+)\s+rows=(\d+)',
                          read_first_line(p))
            return (m.group(1), m.group(2), int(m.group(3))) if m else None
        if ext == '.txt':
            m = re.search(r'CTL\s+ctl_id=(\S+)\s+prev=(\S+)\s+rows=(\d+)',
                          read_first_line(p))
            return (m.group(1), m.group(2), int(m.group(3))) if m else None
        if ext == '.mbox':
            m = re.search(r'X-Ctl-Id:\s*(\S+)\s*\nX-Ctl-Prev:\s*(\S+)\s*\nX-Ctl-Rows:\s*(\d+)',
                          read_text(p))
            return (norm_id(m.group(1)), norm_id(m.group(2)), int(m.group(3))) if m else None
        if ext == '.ics':
            vals = {}
            for line in unfold_ics(p):
                k, _, v = line.partition(':')
                vals[norm_text(k)] = norm_text(v)
            return (norm_id(vals.get('X-CTL-ID', '')), norm_id(vals.get('X-CTL-PREV', '')),
                    int(vals.get('X-CTL-ROWS') or 0))
        if ext == '.zip':
            with zipfile.ZipFile(p) as z:
                t = z.read('CONTROL').decode('utf-8')
            m = _CTL_RE.search(t.replace('\n', ' '))
            return (m.group(1), m.group(2), int(m.group(3))) if m else None
        return None

    def _build_chain(self):
        """The chain starts at the closing_ctl_id of the prior manifest."""
        prev_meta = self.prior_manifest_metadata()
        start = norm_id(prev_meta.get('closing_ctl_id', ''))
        byprev = defaultdict(list)
        for name, (cid, p, rows) in sorted(self.ctl.items()):
            byprev[norm_id(p)].append(name)
        chain = []
        cur = start
        while True:
            nxt = byprev.get(cur)
            if not nxt:
                break
            name = nxt[0]
            chain.append((name, self.ctl[name][0], self.ctl[name][2]))
            cur = norm_id(self.ctl[name][0])
        self.opening_ctl_id = start
        self.chain = chain

    def prior_manifest_metadata(self):
        import pyarrow.parquet as pq
        name = 'estate_manifest_q2.parquet'
        if not self.has(name):
            return {}
        md = pq.ParquetFile(self.path(name)).schema_arrow.metadata
        return {k.decode(): v.decode() for k, v in md.items()}


# --------------------------------------------------------------------------
# inventory and journal dialects
# --------------------------------------------------------------------------

INV_FILES = {}     # file -> {volume, time, size, digest, owner}
JRN_FILES = {}     # file -> {volume, time, size, digest, owner}


def load_dialects(data):
    """Appendix R (roles) and Appendix S (dialects) of source-register.md."""
    roles = {}
    dialects = {}
    if data.has('source-register.md'):
        for tab in read_md_tables(data.path('source-register.md')):
            for row in tab['rows']:
                keys = set(row)
                if {'file', 'format', 'contents'} <= keys:
                    roles[row.get('file', '')] = row.get('contents', '')
                if {'file', 'volume', 'time', 'size', 'digest', 'owner'} <= keys:
                    dialects[row.get('file', '')] = row
    inv = {}
    jrn = {}
    for name, contents in sorted(roles.items()):
        m = re.search(r'(inventory export|change journal) of volume (\S+)', contents)
        if not m:
            continue
        kind = 'inventory' if m.group(1) == 'inventory export' else 'journal'
        d = dialects.get(name)
        if not d:
            continue
        spec = {'volume': m.group(2), 'time': norm_text(d['time']),
                'size': norm_text(d['size']), 'digest': norm_text(d['digest']),
                'owner': norm_text(d['owner']), 'notes': norm_text(d.get('notes'))}
        if kind == 'inventory':
            inv[name] = spec
        else:
            jrn[name] = spec
    return inv, jrn


# --------------------------------------------------------------------------
# reference tables
# --------------------------------------------------------------------------

def _get(row, *names, default=''):
    for n in names:
        if n in row and row[n] is not None:
            return row[n]
    return default


def parse_bool(v):
    if isinstance(v, bool):
        return v
    s = norm_text(v).lower()
    if s in ('true', 'yes', 'on', '1'):
        return True
    if s in ('false', 'no', 'off', '0'):
        return False
    return None


def parse_int(v):
    """Integers may carry _ or , grouping and a KiB/MiB suffix in the ini layer."""
    s = norm_text(v)
    if s == '':
        return None
    m = re.match(r'^(-?[\d_,]*)\s*(KiB|MiB)?$', s)
    if not m:
        try:
            return int(Decimal(s))
        except Exception:
            return None
    num = m.group(1).replace('_', '').replace(',', '')
    if num in ('', '-'):
        num += '0'
    val = int(num)
    if m.group(2) == 'KiB':
        val *= 1024
    elif m.group(2) == 'MiB':
        val *= 1048576
    return val


def norm_key(key):
    """The key namespace before the first dot is case-insensitive, written lower;
    the volume code is upper case; the path part of a subtree key is kept."""
    k = norm_text(key)
    if '.' not in k:
        return k.lower()
    ns, _, rest = k.partition('.')
    if ns.lower() == 'vol':
        parts = rest.split('.')
        if parts:
            parts[0] = parts[0].upper()
        rest = '.'.join(parts)
        return 'vol.' + rest
    if ns.lower() == 'subtree':
        head, sep, tail = rest.partition(':')
        if sep:
            vol, _, pathflag = tail.partition('/')
            vol = vol.upper()
            pathflag = '/' + pathflag
            return 'subtree.%s:%s' % (head.upper(), pathflag)
        return 'subtree.' + rest
    return ns.lower() + '.' + rest


class Refs:
    """Every reference table of the export set."""

    def __init__(self, data):
        self.d = data
        self.inv_specs, self.jrn_specs = load_dialects(data)

    # -- tickets (ECS 2.4) -------------------------------------------------
    def load_tickets(self):
        best = {}
        if self.d.has('change_tickets.csv'):
            for r in read_delim(self.d.path('change_tickets.csv'), ','):
                t = norm_id(_get(r, 'ticket'))
                rev = _as_int(_get(r, 'rev'), 0)
                if t not in best or rev > best[t][0]:
                    best[t] = (rev, norm_text(_get(r, 'state')).upper(),
                               norm_text(_get(r, 'decided_utc')))
        self._ticket_best = best

    def ticket_approved(self, ticket, window_end):
        t = norm_id(ticket)
        rec = self._ticket_best.get(t)
        if not rec:
            return False
        _, state, decided = rec
        if state != 'APPROVED':
            return False
        if not decided or decided.startswith('0000-00-00'):
            return False
        return decided < window_end

    # -- volumes, serials, aliases -----------------------------------------
    def load_volumes(self):
        self.volumes = {}
        self.fs_type = {}
        self.volume_host = {}
        if self.d.has('volumes.yaml'):
            doc = read_yaml_doc(self.d.path('volumes.yaml'))
            for r in _v2_rows(doc, 'volumes'):
                code = norm_id(_get(r, 'code'))
                if code:
                    self.volumes[code] = code
                    self.fs_type[code] = norm_text(_get(r, 'fs_type')).lower()
                    self.volume_host[code] = norm_text(_get(r, 'host')).lower()
        if self.d.has('volumes_cmdb.json'):
            doc = read_json_doc(self.d.path('volumes_cmdb.json'))
            for r in _v2_rows(doc, 'volumes'):
                code = norm_id(_get(r, 'code'))
                if code and code not in self.fs_type:
                    self.volumes[code] = code
                    self.fs_type[code] = norm_text(_get(r, 'fs_type')).lower()
                    self.volume_host[code] = norm_text(_get(r, 'host')).lower()
            best = {}
            for r in _v2_rows(doc, 'serials'):
                s = norm_id(_get(r, 'serial'))
                rev = _as_int(_get(r, 'rev'), 0)
                if s not in best or rev > best[s][0]:
                    best[s] = (rev, norm_id(_get(r, 'volume')), norm_text(_get(r, 'status')).lower())
            self.serials = {s: (v, st) for s, (_, v, st) in best.items() if st == 'active'}
        self.valid_volumes = set(self.volumes)

    def load_aliases(self):
        """Alias tables A-F; per root the highest rev decides."""
        rows = []
        if self.d.has('alias_remap_nas.tsv'):
            rows += read_delim(self.d.path('alias_remap_nas.tsv'), '\t')
        if self.d.has('alias_remap_sharepoint.xlsx'):
            for t in read_xlsx_tables(self.d.path('alias_remap_sharepoint.xlsx')):
                rows += t['rows']
        if self.d.has('alias_remap_dfs.xml'):
            rows += read_xml_rows(self.d.path('alias_remap_dfs.xml'), 'alias')
        if self.d.has('ECS-handbook-paths.docx'):
            for t in read_docx_tables(self.d.path('ECS-handbook-paths.docx')):
                rows += t['rows']
        if self.d.has('volumes.yaml'):
            doc = read_yaml_doc(self.d.path('volumes.yaml'))
            rows += _v2_rows(doc, 'aliases')
        if self.d.has('ECS-standard.md'):
            for r in read_md_all_rows(self.d.path('ECS-standard.md')):
                if {'alias_id', 'root', 'volume', 'prefix', 'rev', 'status'} <= set(r):
                    rows.append(r)
        best = {}
        for r in rows:
            root = _get(r, 'root')
            if not root:
                continue
            rev = _as_int(_get(r, 'rev'), 0)
            key = _root_key(root)
            cur = best.get(key)
            if cur is None or rev > cur[0]:
                best[key] = (rev, root, r)
        self.alias_rows = [(root, r) for key, (_, root, r) in sorted(best.items())]

    def load_hosts(self):
        """Host registers: part A (source-register Appendix H) and part B (rev6)."""
        self.host_zone = {}
        if self.d.has('source-register.md'):
            for r in read_md_all_rows(self.d.path('source-register.md')):
                if 'host' in r and 'zone' in r and r.get('host'):
                    self.host_zone[norm_text(r['host']).lower()] = norm_text(r['zone'])
        if self.d.has('ECS-annex-hosts-rev6.pdf'):
            for r in read_pdf_rows(self.d.path('ECS-annex-hosts-rev6.pdf')):
                if 'host' in r and 'zone' in r and r.get('host'):
                    self.host_zone[norm_text(r['host']).lower()] = norm_text(r['zone'])
        self.host_alias = {}
        if self.d.has('host_aliases.ini'):
            for r in read_ini(self.d.path('host_aliases.ini')):
                sec = norm_text(r.get('section', ''))
                if sec.startswith('alias:'):
                    host = norm_text(_get(r, 'host')).lower()
                    if host:
                        self.host_alias[sec.split(':', 1)[1].lower()] = host

    def load_zones(self):
        """Zone segments from tz_transitions_a.tsv and tz_transitions_b.parquet."""
        segs = []
        if self.d.has('tz_transitions_a.tsv'):
            segs += read_delim(self.d.path('tz_transitions_a.tsv'), '\t')
        if self.d.has('tz_transitions_b.parquet'):
            import pyarrow.parquet as pq
            t = pq.read_table(self.d.path('tz_transitions_b.parquet'))
            names = t.column_names
            segs += [{n: t[n][i].as_py() for n in names} for i in range(t.num_rows)]
        zones = defaultdict(list)
        for r in segs:
            z = norm_text(_get(r, 'zone'))
            if not z:
                continue
            zones[z].append((norm_text(_get(r, 'from_utc')), norm_text(_get(r, 'to_utc')),
                             _offset_seconds(_get(r, 'offset_seconds')),
                             _as_int(_get(r, 'is_dst'), 0)))
        self.zones = {z: sorted(v) for z, v in zones.items()}

    def load_incidents(self):
        """Adopted clock incidents (Appendix D of annex hosts rev7)."""
        rows = []
        if self.d.has('ECS-annex-hosts-rev7.pdf'):
            rows += read_pdf_rows(self.d.path('ECS-annex-hosts-rev7.pdf'))
        groups = defaultdict(list)
        for r in rows:
            host = norm_text(_get(r, 'host')).lower()
            if not host or 'from_utc' not in r:
                continue
            groups[(host, norm_text(r.get('from_utc')))].append(r)
        inc = defaultdict(list)
        for (host, frm), grp in groups.items():
            best_rev = max(_as_int(_get(r, 'rev'), 0) for r in grp)
            top = [r for r in grp if _as_int(_get(r, 'rev'), 0) == best_rev]
            key = lambda r: (norm_text(r.get('status')), norm_text(r.get('to_utc')),
                             _as_int(r.get('skew_seconds'), 0))
            uniq = sorted({key(r) for r in top})
            st, to, skew = uniq[0]
            if st == 'adopted':
                inc[host].append((frm, to, skew))
        self.incidents = {h: sorted(v) for h, v in inc.items()}

    # -- principals --------------------------------------------------------
    def load_principals(self):
        self.principal = {}
        self.principal_status = {}
        self.sid = {}
        self.uid = {}
        self.corp = {}
        self.oldcorp = {}
        self.legacy = {}
        self.email = {}
        self.s3 = {}
        self.svc = {}
        self.mf = {}
        if self.d.has('principal_sid_map.xlsx'):
            tabs = read_xlsx_tables(self.d.path('principal_sid_map.xlsx'))
            for t in tabs:
                if t['name'] == 'principals':
                    for r in t['rows']:
                        pid = norm_id(_get(r, 'principal_id'))
                        if pid:
                            self.principal[pid] = norm_text(_get(r, 'account'))
                            self.principal_status[pid] = norm_text(_get(r, 'status')).lower()
                if t['name'] == 'sids':
                    self._load_token_rows(t['rows'], 'sid', self.sid, upper=True)
        if self.d.has('principal_directory.xlsx'):
            tabs = read_xlsx_tables(self.d.path('principal_directory.xlsx'))
            for t in tabs:
                if t['name'] == 'sid_history':
                    best = {}
                    for r in t['rows']:
                        old = norm_id(_get(r, 'old_sid'))
                        rev = _as_int(_get(r, 'rev'), 0)
                        if not old:
                            continue
                        if old not in best or rev > best[old][0]:
                            best[old] = (rev, norm_id(_get(r, 'new_sid')))
                    self.sid_history = {k: v[1] for k, v in best.items()}
        self.sid_history = getattr(self, 'sid_history', {})
        if self.d.has('principal_uid_map.tsv'):
            rows = read_delim(self.d.path('principal_uid_map.tsv'), '\t')
            for r in rows:
                host = norm_text(_get(r, 'host')).lower()
                num = _as_int(_get(r, 'uid', 'uid_number', 'number'), None)
                pid = norm_id(_get(r, 'principal_id'))
                vf = norm_text(_get(r, 'valid_from'))
                if host and num is not None and pid and norm_text(_get(r, 'status', 'state')).lower() == 'active':
                    k = (host, num)
                    cur = self.uid.get(k)
                    if cur is None or vf >= cur[0]:
                        self.uid[k] = (vf, pid)
            self.uid = {k: v[1] for k, v in self.uid.items()}
        if self.d.has('owner-migration-plan.docx'):
            for t in read_docx_tables(self.d.path('owner-migration-plan.docx')):
                for r in t['rows']:
                    self._corp_row(r, self.corp)
        if self.d.has('principal_map_ldap.html'):
            for t in read_html_tables(self.d.path('principal_map_ldap.html')):
                for r in t['rows']:
                    dom = norm_text(_get(r, 'domain')).upper()
                    if dom == 'OLDCORP':
                        self._corp_row(r, self.oldcorp)
        if self.d.has('principal_legacy.db'):
            tables = read_sqlite_tables(self.d.path('principal_legacy.db'))
            for name, rows in tables.items():
                if name.startswith('logins'):
                    for r in rows:
                        self._corp_row(r, self.legacy)
        if self.d.has('hr-roster-q3.pdf'):
            for r in read_pdf_rows(self.d.path('hr-roster-q3.pdf')):
                addr = norm_text(_get(r, 'email')).lower()
                pid = norm_id(_get(r, 'principal_id'))
                vf = norm_text(_get(r, 'valid_from'))
                if addr and pid and norm_text(_get(r, 'status', 'state')).lower() == 'active':
                    cur = self.email.get(addr)
                    if cur is None or vf >= cur[0]:
                        self.email[addr] = (vf, pid)
            self.email = {k: v[1] for k, v in self.email.items()}
        if self.d.has('principal_s3_ids.json'):
            doc = read_json_doc(self.d.path('principal_s3_ids.json'))
            for r in _v2_rows(doc, 'ids') or _v2_rows(doc, 's3') or _v2_rows(doc, 'accounts'):
                cid = norm_text(_get(r, 'canonical_id', 's3_canonical_id', 'id')).lower()
                pid = norm_id(_get(r, 'principal_id'))
                if cid and pid:
                    self.s3[cid] = pid
        if self.d.has('service_accounts.ini'):
            for r in read_ini(self.d.path('service_accounts.ini')):
                sec = norm_text(r.get('section', ''))
                pid = norm_id(_get(r, 'principal_id'))
                if sec and pid and norm_text(_get(r, 'status', 'state')).lower() == 'active':
                    vf = norm_text(_get(r, 'valid_from'))
                    cur = self.svc.get(sec.lower())
                    if cur is None or vf >= cur[0]:
                        self.svc[sec.lower()] = (vf, pid)
            self.svc = {k: v[1] for k, v in self.svc.items()}
        self._flatten_corp()
        if self.d.has('principal_mainframe_ids.txt'):
            for r in read_fixed(self.d.path('principal_mainframe_ids.txt')):
                mf = norm_id(_get(r, 'mf_id'))
                pid = norm_id(_get(r, 'principal_id'))
                vf = norm_text(_get(r, 'valid_from'))
                if mf and pid and norm_text(_get(r, 'status', 'state')).lower() == 'active':
                    cur = self.mf.get(mf)
                    if cur is None or vf >= cur[0]:
                        self.mf[mf] = (vf, pid)
            self.mf = {k: v[1] for k, v in self.mf.items()}

    def _load_token_rows(self, rows, key, target, upper=False):
        best = {}
        for r in rows:
            k = norm_text(_get(r, key))
            if upper:
                k = k.upper()
            pid = norm_id(_get(r, 'principal_id'))
            vf = norm_text(_get(r, 'valid_from'))
            if not k or not pid:
                continue
            if norm_text(_get(r, 'status', 'state')).lower() != 'active':
                continue
            cur = best.get(k)
            if cur is None or vf >= cur[0]:
                best[k] = (vf, pid)
        for k, (_, pid) in best.items():
            target[k] = pid

    def _flatten_corp(self):
        for m in (self.corp, self.oldcorp, self.legacy):
            for k, v in list(m.items()):
                m[k] = v[1]

    def _corp_row(self, r, target):
        dom = norm_text(_get(r, 'domain')).upper()
        login = norm_text(_get(r, 'login')).lower()
        pid = norm_id(_get(r, 'principal_id'))
        vf = norm_text(_get(r, 'valid_from'))
        if not dom or not login or not pid:
            return
        if norm_text(_get(r, 'status', 'state')).lower() != 'active':
            return
        k = (dom, login)
        cur = target.get(k)
        if cur is None or vf >= cur[0]:
            target[k] = (vf, pid)

    def load_merges(self, window_end):
        best = {}
        rows = []
        if self.d.has('principal_merges.csv'):
            rows += read_delim(self.d.path('principal_merges.csv'), ',')
        if self.d.has('ops-runbook.md'):
            for r in read_md_all_rows(self.d.path('ops-runbook.md')):
                if {'merge_id', 'from_principal', 'to_principal'} <= set(r):
                    rows.append(r)
        for r in rows:
            frm = norm_id(_get(r, 'from_principal'))
            rev = _as_int(_get(r, 'rev'), 0)
            if not frm:
                continue
            if frm not in best or rev > best[frm][0]:
                best[frm] = (rev, norm_id(_get(r, 'to_principal')),
                              norm_text(_get(r, 'effective_utc')),
                              norm_text(_get(r, 'status')).lower())
        self.merge_map = {}
        for frm, (_, to, eff, st) in best.items():
            if st == 'applied' and eff and eff < window_end:
                self.merge_map[frm] = to

    # -- batches -----------------------------------------------------------
    def load_batches(self):
        """Batch registers A, B, C, D; corrections override the unit."""
        units = {}
        captured = {}
        rows = []
        if self.d.has('export_batches_a.csv'):
            rows += read_delim(self.d.path('export_batches_a.csv'), ',')
        if self.d.has('export_batches_b.tsv'):
            rows += read_delim(self.d.path('export_batches_b.tsv'), '\t')
        if self.d.has('tape-operations-notes.docx'):
            for t in read_docx_tables(self.d.path('tape-operations-notes.docx')):
                rows += t['rows']
        if self.d.has('units-bulletin.pdf'):
            rows += read_pdf_rows(self.d.path('units-bulletin.pdf'))
        for r in rows:
            bid = norm_id(_get(r, 'batch_id'))
            if not bid:
                continue
            unit = norm_text(_get(r, 'unit')).strip()
            cap = norm_text(_get(r, 'captured_utc'))
            src = norm_text(_get(r, 'source')).lower()
            if src == 'correction':
                units[bid] = unit
                captured[bid] = cap
            elif bid not in units and unit:
                units[bid] = unit
                captured.setdefault(bid, cap)
        self.batch_unit = units
        self.batch_captured = captured

    # -- digest crosswalks (ECS 6.2) ---------------------------------------
    def load_crosswalks(self):
        part = defaultdict(dict)

        def add(rows, volumes):
            best = defaultdict(dict)
            for r in rows:
                dig = norm_text(_get(r, 'digest')).lower()
                alg = norm_text(_get(r, 'alg')).lower()
                rev = _as_int(_get(r, 'rev'), 0)
                st = norm_text(_get(r, 'status')).lower()
                sha = norm_text(_get(r, 'sha256')).lower()
                if not dig or not sha:
                    continue
                key = (alg, dig)
                for v in volumes:
                    cur = best[v].get(key)
                    if cur is None or rev > cur[0]:
                        best[v][key] = (rev, st, sha)
            for v, m in best.items():
                for key, (_, st, sha) in m.items():
                    if st == 'ok':
                        part[v][key] = sha

        if self.d.has('hash_xwalk_md5_eng.csv'):
            add(read_delim(self.d.path('hash_xwalk_md5_eng.csv'), ','), ['ENG02', 'LEG01'])
        if self.d.has('hash_xwalk_md5_mkt.jsonl'):
            add(read_jsonl(self.d.path('hash_xwalk_md5_mkt.jsonl')), ['MKT01', 'OBJ01', 'LAB01'])
        if self.d.has('hash_xwalk_md5_fin.parquet'):
            import pyarrow.parquet as pq
            t = pq.read_table(self.d.path('hash_xwalk_md5_fin.parquet'))
            names = t.column_names
            rows = [{n: t[n][i].as_py() for n in names} for i in range(t.num_rows)]
            add(rows, ['HR01'])
        if self.d.has('hash_xwalk_sha1_fin.json'):
            doc = read_json_doc(self.d.path('hash_xwalk_sha1_fin.json'))
            for key in ('crosswalk', 'rows', 'entries', 'items'):
                rows = _v2_rows(doc, key)
                if rows:
                    add(rows, ['FIN02'])
                    break
        if self.d.has('vendor-hash-attestation.pdf'):
            add(read_pdf_rows(self.d.path('vendor-hash-attestation.pdf')), ['RND01'])
        if self.d.has('hash_index_master.parquet'):
            import pyarrow.parquet as pq
            t = pq.read_table(self.d.path('hash_index_master.parquet'))
            names = t.column_names
            rows = [{n: t[n][i].as_py() for n in names} for i in range(t.num_rows)]
            rows = [r for r in rows if norm_text(r.get('origin')).upper() == 'ARC01']
            add(rows, ['ARC01'])
        self.xwalk = dict(part)

    # -- prior store index (ECS 6.5) ---------------------------------------
    def load_store_index(self):
        best = {}
        rows = []
        if self.d.has('store_index_prior_a.csv'):
            rows += read_delim(self.d.path('store_index_prior_a.csv'), ',')
        if self.d.has('store_index_prior_b.jsonl'):
            rows += read_jsonl(self.d.path('store_index_prior_b.jsonl'))
        if self.d.has('store_index_prior_c.parquet'):
            import pyarrow.parquet as pq
            t = pq.read_table(self.d.path('store_index_prior_c.parquet'))
            names = t.column_names
            rows += [{n: t[n][i].as_py() for n in names} for i in range(t.num_rows)]
        if self.d.has('store_index_prior_d.db'):
            for name, rr in read_sqlite_tables(self.d.path('store_index_prior_d.db')).items():
                rows += rr
        for r in rows:
            dig = norm_text(_get(r, 'sha256')).lower()
            rev = _as_int(_get(r, 'rev'), 0)
            st = norm_text(_get(r, 'status')).lower()
            if not dig:
                continue
            if dig not in best or rev > best[dig][0]:
                best[dig] = (rev, st)
        self.store_prior = {d for d, (_, st) in best.items() if st == 'present'}

    # -- retention (ECS 7) --------------------------------------------------
    def load_retention(self):
        self.class_ages = {}
        self.no_purge_volumes = set()
        if self.d.has('retention-schedule-2026-r2.docx'):
            for t in read_docx_tables(self.d.path('retention-schedule-2026-r2.docx')):
                rows = t['rows']
                if not rows:
                    continue
                cols = set(rows[0].keys())
                if 'class' in cols and 'purge_after_days' in cols:
                    for r in rows:
                        cls = norm_class(r.get('class'))
                        if cls:
                            self.class_ages[cls] = (_opt_int(r.get('purge_after_days')),
                                                    _opt_int(r.get('archive_after_days')))
                    for p in _docx_paragraphs(self.d.path('retention-schedule-2026-r2.docx')):
                        if 'never purged' in p and 'ARC01' in p:
                            self.no_purge_volumes.add('ARC01')
                    break
        tbl = {}
        if self.d.has('ext_families_a.tsv'):
            tbl['A'] = self._family_rows(read_delim(self.d.path('ext_families_a.tsv'), '\t'))
        if self.d.has('ext_families_b.xlsx'):
            rows = []
            for t in read_xlsx_tables(self.d.path('ext_families_b.xlsx')):
                rows += t['rows']
            tbl['B'] = self._family_rows(rows)
        if self.d.has('retention-schedule-2026-r2.docx'):
            rows = []
            for t in read_docx_tables(self.d.path('retention-schedule-2026-r2.docx')):
                rows += t['rows']
            tbl['C'] = self._family_rows([r for r in rows
                                          if set(r) >= {'ext', 'family', 'rev', 'status'}])
        if self.d.has('ext_families_wiki.html'):
            rows = []
            for t in read_html_tables(self.d.path('ext_families_wiki.html')):
                rows += t['rows']
            tbl['D'] = self._family_rows(rows)
        tbl['E'] = self._family_rows(self._builtin_families())
        self.ext_tables = tbl
        self._family_pending = set()
        self._family_pending_rev = {}
        if self.d.has('ext_families_a.tsv'):
            for r in read_delim(self.d.path('ext_families_a.tsv'), '\t'):
                ext = norm_text(_get(r, 'ext')).lower()
                if ext and norm_text(_get(r, 'pending')).lower() in ('yes', 'y', 'true'):
                    self._family_pending.add(ext)
                    self._family_pending_rev[ext] = _as_int(_get(r, 'rev'), 0)
        self._annex_f = {}
        if self.d.has('retention-schedule-2026-r3.docx'):
            rows = []
            for t in read_docx_tables(self.d.path('retention-schedule-2026-r3.docx')):
                rows += t['rows']
            best = {}
            for r in rows:
                if set(r) != {'ext', 'family', 'rev'}:
                    continue
                ext = norm_text(r.get('ext')).lower()
                rev = _as_int(r.get('rev'), 0)
                if not ext:
                    continue
                if ext not in best or rev > best[ext][0]:
                    best[ext] = (rev, norm_text(r.get('family')))
            self._annex_f = {k: v[1] for k, v in best.items()}

    def _builtin_families(self):
        here = os.path.dirname(os.path.abspath(__file__))
        p = os.path.join(here, 'ext_families_builtin.tsv')
        return read_delim(p, '\t') if os.path.isfile(p) else []

    def _family_rows(self, rows):
        best = {}
        for r in rows:
            ext = norm_text(_get(r, 'ext')).lower()
            if not ext:
                continue
            rev = _as_int(_get(r, 'rev'), 0)
            st = norm_text(_get(r, 'status', 'state')).lower()
            cur = best.get(ext)
            if cur is None or rev > cur[0]:
                best[ext] = (rev, norm_text(_get(r, 'family')), st)
        out = {}
        for ext, (rev, fam, st) in best.items():
            if st == 'retired':
                continue
            out[ext] = (fam, rev)
        return out

    def ext_family(self, name):
        """The longest suffix after a dot that has an effective family."""
        low = name.lower()
        if '.' not in low:
            return None
        cands = [low[i + 1:] for i, c in enumerate(low) if c == '.']
        for cand in cands:
            for key in ('A', 'B', 'C', 'D', 'E'):
                hit = (self.ext_tables.get(key) or {}).get(cand)
                if hit is None:
                    continue
                fam = hit[0]
                if key == 'A' and cand in self._annex_f and cand in self._family_pending:
                    fam = self._annex_f[cand]
                if fam and fam.upper() != 'N/A':
                    return fam.upper()
                break
        return None

    def load_rules(self, window_end):
        rules = []
        if self.d.has('retention_rules_v3.yaml'):
            rules = _v2_rows(read_yaml_doc(self.d.path('retention_rules_v3.yaml')), 'rules')
        withdrawn = set()
        if self.d.has('retention_rules_v4.toml'):
            doc = read_toml_doc(self.d.path('retention_rules_v4.toml'))
            for w in doc.get('withdrawal') or []:
                seq = _as_int(_get(w, 'rule_seq', 'seq'), None)
                if seq is not None and self.ticket_approved(_get(w, 'ticket'), window_end):
                    withdrawn.add(seq)
        active = [r for r in rules if norm_text(_get(r, 'status')).lower() in ('active', '')]
        active = [r for r in active if _as_int(_get(r, 'seq'), 0) not in withdrawn]
        active.sort(key=lambda r: _as_int(_get(r, 'seq'), 0))
        overlays = []
        if self.d.has('retention_overlays.toml'):
            overlays = _v2_rows(read_toml_doc(self.d.path('retention_overlays.toml')), 'overlay')
        overlays.sort(key=lambda r: _as_int(_get(r, 'seq'), 0))
        self.rules = active + overlays

    # -- legal holds (ECS 7.5) ---------------------------------------------
    def load_holds(self, window_start, window_end):
        rows = []
        if self.d.has('legal_holds_register.csv'):
            rows += read_delim(self.d.path('legal_holds_register.csv'), ',')
        if self.d.has('holds_matter_index.xlsx'):
            for t in read_xlsx_tables(self.d.path('holds_matter_index.xlsx')):
                if t['name'] == 'holds':
                    rows += t['rows']
        if self.d.has('holds_portal_export.html'):
            for t in read_html_tables(self.d.path('holds_portal_export.html')):
                rows += t['rows']
        if self.d.has('legal_hold_windows.ics'):
            for r in read_ics_events(self.d.path('legal_hold_windows.ics')):
                rows.append({'hold_id': r.get('UID', ''),
                             'volume': r.get('X-VOLUME', ''),
                             'prefix': r.get('X-HOLD-PREFIX') or r.get('X-PREFIX') or '',
                             'from_utc': r.get('DTSTART', ''),
                             'to_utc': r.get('DTEND', ''),
                             'status': 'active' if r.get('STATUS', '') == 'CONFIRMED'
                                       else norm_text(r.get('STATUS', '')),
                             'matter': r.get('X-MATTER', '')})
        matters = {}
        if self.d.has('holds_matter_index.xlsx'):
            for t in read_xlsx_tables(self.d.path('holds_matter_index.xlsx')):
                if t['name'] == 'matters':
                    for r in t['rows']:
                        mid = norm_id(_get(r, 'matter_id', 'matter'))
                        if mid:
                            matters[mid] = norm_text(_get(r, 'status')).lower()
        releases = {}
        if self.d.has('legal-hold-memo-q3.docx'):
            for t in read_docx_tables(self.d.path('legal-hold-memo-q3.docx')):
                for r in t['rows']:
                    hid = norm_id(_get(r, 'hold_id'))
                    rel = norm_text(_get(r, 'released_utc'))
                    if not hid or not self.ticket_approved(_get(r, 'ticket'), window_end):
                        continue
                    if not rel:
                        continue
                    cur = releases.get(hid)
                    if cur is None or rel >= cur:
                        releases[hid] = rel
        self.holds = []
        for r in rows:
            hid = norm_id(_get(r, 'hold_id'))
            vol = norm_id(_get(r, 'volume'))
            prefix = norm_text(_get(r, 'prefix'))
            status = norm_text(_get(r, 'status', 'state')).lower()
            matter = norm_id(_get(r, 'matter'))
            if not hid or not vol or status != 'active':
                continue
            if hid in releases:
                continue
            if matter and matters.get(matter) == 'closed':
                continue
            frm = norm_text(_get(r, 'from_utc'))
            to = norm_text(_get(r, 'to_utc'))
            if not frm or frm >= window_end:
                continue
            if to and to <= window_start:
                continue
            self.holds.append((vol, prefix))

    # -- voids, exclusions, errata -----------------------------------------
    def load_voids(self, window_end):
        rows = []
        if self.d.has('void_register_q3.csv'):
            rows += read_delim(self.d.path('void_register_q3.csv'), ',')
        if self.d.has('void_register_supplement.jsonl'):
            rows += read_jsonl(self.d.path('void_register_supplement.jsonl'))
        best = {}
        for r in rows:
            rid = norm_id(_get(r, 'rec_id'))
            rev = _as_int(_get(r, 'rev'), 0)
            if not rid:
                continue
            if rid not in best or rev > best[rid][0]:
                best[rid] = (rev, norm_text(_get(r, 'status')).lower(), _get(r, 'ticket'))
        reinstated = set()
        if self.d.has('void_register_q3_r2.xml'):
            for d in read_xml_rows(self.d.path('void_register_q3_r2.xml'), 'reinstate'):
                rid = norm_id(_get(d, 'rec_id'))
                if rid and self.ticket_approved(_get(d, 'ticket'), window_end):
                    reinstated.add(rid)
        self.voided = set()
        for rid, (_, st, ticket) in best.items():
            if st == 'active' and self.ticket_approved(ticket, window_end) and rid not in reinstated:
                self.voided.add(rid)

    def load_exclusions(self, volume_of_record):
        self.excluded = set()
        if not self.d.has('audit-scope-letter-fin.pdf'):
            return
        for r in read_pdf_rows(self.d.path('audit-scope-letter-fin.pdf')):
            rid = norm_id(_get(r, 'rec_id'))
            st = norm_text(_get(r, 'status', 'state')).lower()
            if not rid or st != 'excluded':
                continue
            if volume_of_record.get(rid) in ('FIN01', 'FIN02'):
                self.excluded.add(rid)

    def load_errata(self, window_end):
        rows = []
        if self.d.has('errata_register_q3.csv'):
            rows += read_delim(self.d.path('errata_register_q3.csv'), ',')
        if self.d.has('errata_register_tape.xml'):
            rows += read_xml_rows(self.d.path('errata_register_tape.xml'))
        if self.d.has('errata-bulletin-q3.docx'):
            for t in read_docx_tables(self.d.path('errata-bulletin-q3.docx')):
                rows += t['rows']
        withdrawn = set()
        if self.d.has('errata_register_q3_r2.tsv'):
            for r in read_delim(self.d.path('errata_register_q3_r2.tsv'), '\t'):
                if norm_text(_get(r, 'field')).upper() == 'WITHDRAW':
                    if self.ticket_approved(_get(r, 'ticket'), window_end):
                        withdrawn.add(norm_id(_get(r, 'rec_id')))
        best = {}
        for r in rows:
            rid = norm_id(_get(r, 'rec_id'))
            field = norm_text(_get(r, 'field')).lower()
            rev = _as_int(_get(r, 'rev'), 0)
            if not rid or field not in ('bytes', 'mtime', 'sha256', 'owner'):
                continue
            if not self.ticket_approved(_get(r, 'ticket'), window_end):
                continue
            if rid in withdrawn:
                continue
            key = (rid, field)
            cur = best.get(key)
            if cur is None or rev > cur[0]:
                best[key] = (rev, _get(r, 'value'))
        self.errata = {k: v[1] for k, v in best.items()}

    # -- authority matrix ---------------------------------------------------
    def load_authority(self, window_end):
        runs = []
        scope = []
        if self.d.has('authority_matrix.xlsx'):
            for t in read_xlsx_tables(self.d.path('authority_matrix.xlsx')):
                for r in t['rows']:
                    kind = norm_text(_get(r, 'record'))
                    if kind in ('override', 'ratification'):
                        scope.append(r)
                    elif 'run_id' in r and 'kind' in r:
                        runs.append(r)
        self.runs = runs
        self.scope = scope

    def load_export_meta(self):
        """Every inventory/journal declares its own run_mode and role."""
        meta = {}
        for name in sorted(self.inv_specs) + sorted(self.jrn_specs):
            p = self.d.path(name)
            info = {}
            ext = os.path.splitext(name)[1].lower()
            try:
                if ext == '.csv':
                    for line in read_text(p).splitlines():
                        if line.startswith('#export') or line.startswith('# export'):
                            info.update(_kv(line.split(' ', 1)[1] if ' ' in line else ''))
                        elif line.startswith('#journal') or line.startswith('# journal'):
                            info.update(_kv(line.split(' ', 1)[1] if ' ' in line else ''))
                elif ext == '.tsv':
                    for line in read_bytes(p).decode('latin-1').splitlines():
                        if line.startswith('#export') or line.startswith('# export'):
                            info.update(_kv(line.split(' ', 1)[1] if ' ' in line else ''))
                        elif line.startswith('#journal') or line.startswith('# journal'):
                            info.update(_kv(line.split(' ', 1)[1] if ' ' in line else ''))
                elif ext == '.jsonl':
                    for obj in read_jsonl_meta(p):
                        info.update(obj)
                elif ext == '.json':
                    doc = read_json_doc(p)
                    for k in ('export', 'journal', '_export', '_journal'):
                        if isinstance(doc.get(k), dict):
                            info.update(doc[k])
                elif ext == '.xml':
                    attrs = xml_root_attrs(p)
                    info['run_mode'] = attrs.get('run-mode')
                    info['role'] = attrs.get('role')
                    info['exported_utc'] = attrs.get('exported-utc')
                elif ext == '.xlsx':
                    with zipfile.ZipFile(p) as z:
                        core = z.read('docProps/core.xml').decode('utf-8', 'replace')
                    m = re.search(r'<dc:description>(.*?)</dc:description>', core, re.S)
                    if m:
                        info.update(_kv(m.group(1)))
                elif ext == '.pdf':
                    txt = (pypdf.PdfReader(p).pages[0].extract_text() or '')
                    for line in txt.split('\n'):
                        if line.startswith('Export:'):
                            info.update(_kv(line.split(':', 1)[1]))
                elif ext in ('.db', '.sqlite'):
                    views = read_sqlite_views(p)
                    for vname in ('_export', '_journal'):
                        if vname in views:
                            info.update(_sqlite_view_kv(views[vname]))
                elif ext == '.txt':
                    for line in read_bytes(p).decode('latin-1').splitlines():
                        if line.startswith('#export') or line.startswith('# export'):
                            info.update(_kv(line.split(' ', 1)[1] if ' ' in line else ''))
                elif ext == '.log':
                    _, m, _e = read_log_events(p)
                    info.update(m)
                elif ext == '.mbox':
                    import mailbox
                    mb = mailbox.mbox(p)
                    for msg in mb:
                        v = norm_text(msg.get('X-Journal') or '')
                        if v:
                            info.update(_kv(v))
                        break
                elif ext == '.parquet':
                    import pyarrow.parquet as pq
                    md = pq.ParquetFile(p).schema_arrow.metadata
                    info.update({k.decode(): v.decode() for k, v in md.items()})
            except Exception:
                pass
            meta[name] = info
        self.export_meta = meta

    def run_mode_of(self, name):
        mode = norm_text(self.export_meta.get(name, {}).get('run_mode')).lower()
        if mode:
            return mode
        for r in self.runs:
            if norm_text(_get(r, 'file')) == name:
                return norm_text(_get(r, 'kind')).lower()
        return ''

    def snapshot_of(self, volume):
        """completed_utc of the runs row of the volume's full export."""
        full_files = {n for n, spec in self.inv_specs.items()
                      if spec['volume'] == volume and self.run_mode_of(n) == 'full'}
        best = None
        for r in self.runs:
            if norm_id(_get(r, 'volume')) != volume:
                continue
            if norm_text(_get(r, 'kind')).lower() != 'full':
                continue
            if norm_text(_get(r, 'status')).lower() != 'complete':
                continue
            if norm_text(_get(r, 'superseded_by')):
                continue
            if norm_text(_get(r, 'file')) in full_files:
                c = norm_text(_get(r, 'completed_utc'))
                if best is None or c > best:
                    best = c
        if best:
            return best
        for f in sorted(full_files):
            m = self.export_meta.get(f, {})
            if m.get('exported_utc'):
                return m['exported_utc']
        return ''

    # -- prior manifest ----------------------------------------------------
    def load_prior_manifest(self):
        import pyarrow.parquet as pq
        name = 'estate_manifest_q2.parquet'
        self.prior_rows = []
        self.prior_meta = {}
        if not self.d.has(name):
            return
        t = pq.read_table(self.d.path(name))
        cols = t.column_names
        self.prior_rows = [{c: t[c][i].as_py() for c in cols} for i in range(t.num_rows)]
        self.prior_meta = self.d.prior_manifest_metadata()

    # -- case sensitive subtrees -------------------------------------------
    def load_case_dirs(self):
        best = defaultdict(dict)
        if self.d.has('case_sensitive_dirs.csv'):
            for r in read_delim(self.d.path('case_sensitive_dirs.csv'), ','):
                vol = norm_id(_get(r, 'volume'))
                prefix = norm_text(_get(r, 'prefix')).lower()
                rev = _as_int(_get(r, 'rev'), 0)
                if vol and prefix:
                    cur = best[vol].get(prefix)
                    if cur is None or rev > cur[0]:
                        best[vol][prefix] = (rev, norm_text(_get(r, 'status')).lower())
        if self.d.has('case_sensitive_dirs_leg01.xml'):
            for r in read_xml_rows(self.d.path('case_sensitive_dirs_leg01.xml'), 'dir'):
                vol = norm_id(_get(r, 'volume'))
                prefix = norm_text(_get(r, 'prefix')).lower()
                rev = _as_int(_get(r, 'rev'), 0)
                if vol and prefix:
                    cur = best[vol].get(prefix)
                    if cur is None or rev > cur[0]:
                        best[vol][prefix] = (rev, norm_text(_get(r, 'status')).lower())
        self.case_dirs = {vol: sorted(p for p, (_, st) in m.items() if st == 'active')
                          for vol, m in best.items()}

    def load_all(self, window_start, window_end):
        self.load_tickets()
        self.load_volumes()
        self.load_export_meta()
        self.load_aliases()
        self.load_hosts()
        self.load_zones()
        self.load_incidents()
        self.load_principals()
        self.load_merges(window_end)
        self.load_batches()
        self.load_crosswalks()
        self.load_store_index()
        self.load_retention()
        self.load_rules(window_end)
        self.load_holds(window_start, window_end)
        self.load_voids(window_end)
        self.load_errata(window_end)
        self.load_authority(window_end)
        self.load_case_dirs()
        self.load_prior_manifest()

    def block_size_of(self, profile):
        """store.block_size of a profile's effective configuration."""
        cfg = typed_config(resolve_config(self, profile, self.window_end or '',
                                         getattr(self, 'revoked', set())))
        return cfg.get('store.block_size') or 1

    window_end = ''


# --------------------------------------------------------------------------
# small parsing helpers
# --------------------------------------------------------------------------

def _opt_int(v):
    s = norm_text(v)
    if s == '':
        return None
    try:
        return int(Decimal(s.replace('_', '').replace(',', '')))
    except Exception:
        return None


def _kv(text):
    """'k=v k2=v2' header line -> dict."""
    out = {}
    for m in re.finditer(r'(\S+?)=(\S+)', text or ''):
        out[m.group(1)] = m.group(2)
    return out


def read_jsonl_meta(path):
    """The _export / _journal metadata objects of a jsonl file."""
    out = []
    for line in read_text(path).splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        if isinstance(obj, dict):
            for k in ('_export', '_journal'):
                if isinstance(obj.get(k), dict):
                    out.append(obj[k])
    return out


def _docx_paragraphs(path):
    import docx
    d = docx.Document(path)
    return [p.text for p in d.paragraphs]


# --------------------------------------------------------------------------
# configuration (ECS 2)
# --------------------------------------------------------------------------

LAYERS = [(10, 'estate-defaults.toml'), (20, 'site-policy.yaml'),
          (30, 'volume-policy.json'), (40, 'operator-overrides.ini')]


def config_rows(refs, name):
    """Rows of one configuration layer, in file order."""
    if not refs.d.has(name):
        return []
    p = refs.d.path(name)
    ext = os.path.splitext(name)[1].lower()
    if ext == '.toml':
        rows = _v2_rows(read_toml_doc(p), 'setting')
    elif ext == '.yaml':
        rows = _v2_rows(read_yaml_doc(p), 'settings')
    elif ext == '.json':
        rows = _v2_rows(read_json_doc(p), 'settings')
    elif ext == '.ini':
        rows = [r for r in read_ini(p)
                if norm_text(r.get('section', '')).startswith('override:')]
    else:
        rows = []
    out = []
    for r in rows:
        key = norm_key(_get(r, 'key'))
        out.append({'key': key, 'value': _get(r, 'value'),
                    'profile': norm_text(_get(r, 'profile')),
                    'final': bool(parse_bool(_get(r, 'final', 'is_final'))),
                    'ticket': norm_text(_get(r, 'ticket')),
                    'override_id': norm_id(_get(r, 'override_id'))})
    return out


def _layer_rows(refs, layer, name, profile, window_end, revoked):
    rows = config_rows(refs, name)
    star = [r for r in rows if r['profile'] == '*']
    prof = [r for r in rows if r['profile'].lower() == profile]
    out = []
    for r in star + prof:
        if layer == 40:
            if not refs.ticket_approved(r['ticket'], window_end):
                continue
            if r['override_id'] and r['override_id'] in revoked:
                continue
        out.append(r)
    return out


def resolve_config(refs, profile, window_end, revoked, layers=LAYERS):
    """The effective configuration of one profile (ECS 2.1, 2.2).

    A row with final=true locks its key for every later layer; the lock does
    not stop a profile row of the same layer.
    """
    cfg = {}
    locked = set()
    for layer, name in layers:
        locked_layer = set()
        for r in _layer_rows(refs, layer, name, profile, window_end, revoked):
            if r['key'] in locked:
                continue
            cfg[r['key']] = r['value']
            if r['final']:
                locked_layer.add(r['key'])
        locked |= locked_layer
    return cfg


def typed_config(cfg):
    """Values are typed by key (ECS 2.2)."""
    out = {}
    for k, v in cfg.items():
        ns = k.partition('.')[0]
        field = k.rpartition('.')[2]
        if ns == 'window':
            out[k] = norm_text(v)
        elif ns == 'purge' or field in ('purge_exempt', 'archive_exempt'):
            b = parse_bool(v)
            out[k] = b if b is not None else norm_text(v)
        elif k == 'store.block_size':
            out[k] = parse_int(v)
        else:
            out[k] = norm_text(v)
    return out


def provisional_window(refs, profile):
    """window.start/end from layers 10-30 (layer 40 needs ticket approval)."""
    cfg = {}
    locked = set()
    for layer, name in LAYERS[:3]:
        locked_layer = set()
        for r in _layer_rows(refs, layer, name, profile, '', set()):
            if r['key'] in locked:
                continue
            cfg[r['key']] = r['value']
            if r['final']:
                locked_layer.add(r['key'])
        locked |= locked_layer
    return norm_text(cfg.get('window.end', '')), norm_text(cfg.get('window.start', ''))


# --------------------------------------------------------------------------
# time dialects (ECS 4)
# --------------------------------------------------------------------------

EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)
FILETIME_EPOCH = datetime(1601, 1, 1, tzinfo=timezone.utc)
_EXCEL_1900_EPOCH = datetime(1899, 12, 30)
_EXCEL_1904_EPOCH = datetime(1904, 1, 1)


def _round_half_even_seconds(micros):
    """Round microseconds to whole seconds, half to even."""
    secs, rem = divmod(micros, 1000000)
    if rem > 500000 or (rem == 500000 and secs % 2):
        secs += 1
    return secs


class TimeEngine:
    """Resolves the time dialect of a source to an instant (ECS 4.2-4.4)."""

    def __init__(self, refs):
        self.refs = refs
        self._local_cache = {}

    def zone_of(self, volume, cfg):
        z = norm_text(cfg.get('vol.%s.zone' % volume, ''))
        if z:
            return z
        host = self.refs.volume_host.get(volume, '')
        return self.refs.host_zone.get(host, '')

    def resolve(self, value, dialect, volume, cfg, batch_captured, tzq=None):
        """An aware UTC datetime, or None when not captured."""
        v = norm_text(value)
        if v == '':
            return _dt(batch_captured)
        d = dialect
        if d == 'filetime':
            try:
                ticks = int(Decimal(v))
            except Exception:
                return None
            return FILETIME_EPOCH + timedelta(microseconds=ticks // 10)
        if d in ('epoch_s', 'epoch_ms', 'epoch_ns', 'epoch_frac'):
            try:
                num = Decimal(v)
            except Exception:
                return None
            if d == 'epoch_s':
                return EPOCH + timedelta(seconds=int(num // 1))
            if d == 'epoch_ms':
                ms = int(num)
                return EPOCH + timedelta(seconds=ms // 1000)
            if d == 'epoch_ns':
                ns = int(num)
                return EPOCH + timedelta(seconds=ns // 1000000000)
            neg = num < 0
            n = -num if neg else num
            secs = int(n)
            frac = n - secs
            usec = int(frac * 1000000)
            return EPOCH + timedelta(seconds=secs, microseconds=usec)
        if d in ('iso_z', 'iso_ms', 'iso_offset', 'iso_mixed'):
            dt = _dt(v)
            if dt is None:
                return None
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        if d == 'rfc2822':
            import email.utils
            try:
                dt = email.utils.parsedate_to_datetime(v)
            except Exception:
                return None
            if dt is None:
                return None
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        if d == 'julian':
            m = re.fullmatch(r'(\d{4})(\d{3})\s+(\d{2})(\d{2})(\d{2})', v)
            if not m:
                return None
            year, doy, hh, mm, ss = (int(x) for x in m.groups())
            try:
                base = datetime(year, 1, 1, tzinfo=timezone.utc) + timedelta(days=doy - 1)
                return base.replace(hour=hh, minute=mm, second=ss)
            except Exception:
                return None
        if d in ('excel1904_utc', 'excel1900_local', 'excel1900_utc'):
            try:
                serial = Decimal(v)
            except Exception:
                return None
            if d != 'excel1904_utc' and int(serial) in (0, 60):
                return _dt(batch_captured)
            epoch = _EXCEL_1904_EPOCH if d == 'excel1904_utc' else _EXCEL_1900_EPOCH
            days = int(serial)
            frac = serial - days
            micros = int(frac * 86400 * 1000000)
            naive = epoch + timedelta(days=days, seconds=_round_half_even_seconds(micros))
            if d.endswith('_local'):
                return self.local_to_utc(naive, self.zone_of(volume, cfg))
            return naive.replace(tzinfo=timezone.utc)
        if d in ('local', 'local_dmy', 'local_tzq'):
            if d == 'local_dmy':
                m = re.fullmatch(r'(\d{2})\.(\d{2})\.(\d{4}) (\d{2}):(\d{2}):(\d{2})', v)
                parts = [int(x) for x in m.groups()] if m else None
                if parts:
                    dd, mo, yy, hh, mi, ss = parts
            else:
                m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})', v)
                parts = [int(x) for x in m.groups()] if m else None
                if parts:
                    yy, mo, dd, hh, mi, ss = parts
            if not parts:
                return None
            try:
                naive = datetime(yy, mo, dd, hh, mi, ss)
            except Exception:
                return None
            if d == 'local_tzq' and tzq is not None and norm_text(str(tzq)) != '':
                try:
                    off = int(Decimal(str(tzq)) * 900)
                    return (naive - timedelta(seconds=off)).replace(tzinfo=timezone.utc)
                except Exception:
                    pass
            return self.local_to_utc(naive, self.zone_of(volume, cfg))
        dt = _dt(v)
        if dt is not None:
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        try:
            return EPOCH + timedelta(seconds=int(Decimal(v) // 1))
        except Exception:
            return None

    def local_to_utc(self, naive, zone):
        """A wall-clock time of a zone (ECS 4.3): one segment, fall back to the
        smaller offset, a gap falls back to the standard offset."""
        key = (naive, zone)
        hit = self._local_cache.get(key)
        if hit is not None:
            return hit
        segs = self.refs.zones.get(zone) or []
        matches = []
        n = naive.replace(tzinfo=timezone.utc)
        for frm, to, off, _dst in segs:
            lstart = _dt(frm)
            if lstart is None:
                continue
            lstart = lstart + timedelta(seconds=off)
            if n < lstart:
                continue
            if to:
                lend = _dt(to)
                if lend is not None and n >= lend + timedelta(seconds=off):
                    continue
            matches.append(off)
        if len(matches) == 1:
            off = matches[0]
        elif matches:
            off = min(matches)
        else:
            std = [off for _frm, _to, off, dst in segs if not dst]
            off = std[-1] if std else 0
        dt = (naive - timedelta(seconds=off)).replace(tzinfo=timezone.utc)
        self._local_cache[key] = dt
        return dt

    def correct_incident(self, dt, host):
        """An adopted clock incident: the event was stamped skew_seconds fast.

        Of the incidents whose window contains the reported instant, the one
        with the latest from_utc decides (ECS 4.4).
        """
        if dt is None or not host:
            return dt
        inc = self.refs.incidents.get(norm_text(host).lower())
        if not inc:
            return dt
        s = fmt_instant(dt)
        best = None
        for frm, to, skew in inc:
            if frm <= s and (not to or s < to):
                if best is None or frm > best[0]:
                    best = (frm, to, skew)
        if best is None:
            return dt
        return dt - timedelta(seconds=best[2])


# --------------------------------------------------------------------------
# paths (ECS 5.1-5.3)
# --------------------------------------------------------------------------

def _norm_root(root):
    """Only roots that begin with two backslashes use forward slashes."""
    r = norm_text(root)
    if r.startswith('\\\\'):
        r = r.replace('\\', '/')
    return r


def _root_key(root):
    """UNC, smb and nfs roots compare case-insensitively, posix roots exactly."""
    r = _norm_root(root)
    if r.startswith('//') or r.lower().startswith('smb://') or r.lower().startswith('nfs://'):
        return ('ci', r.lower())
    return ('cs', r)


class PathEngine:
    """Resolves raw paths to a volume and a canonical path (ECS 5.1-5.3)."""

    def __init__(self, refs):
        self.refs = refs
        self.trie = {}          # ci trie: segment -> {'__root__': row, ...}
        self.trie_cs = {}       # posix trie (case sensitive)
        for root, r in refs.alias_rows:
            vol = norm_text(_get(r, 'volume'))
            status = norm_text(_get(r, 'status', 'state')).lower()
            row = (_norm_root(root), vol, norm_text(_get(r, 'prefix')), status)
            nr = row[0]
            if not nr:
                continue
            ci = nr.startswith('//') or nr.lower().startswith('smb://') \
                or nr.lower().startswith('nfs://')
            if nr.lower().startswith('smb://') or nr.lower().startswith('nfs://'):
                body = nr.split('://', 1)[1]
                scheme = nr.split('://', 1)[0].lower() + '://'
            elif nr.startswith('//'):
                body = nr[2:]
                scheme = '//'
            else:
                body = nr
                scheme = ''
            segs = [s for s in body.split('/') if s != '']
            node = self.trie if ci else self.trie_cs
            key_segs = [s.lower() for s in segs] if ci else segs
            for i, s in enumerate(key_segs):
                node = node.setdefault(s, {})
            node = node.setdefault('__terms__', [])
            node.append((row, scheme, len(segs)))

    def resolve(self, raw, volume_hint, cfg):
        """(volume, canonical path) or (None, None) when unresolved."""
        raw = norm_text(raw)
        if not raw:
            return None, None
        if raw.startswith('s3://'):
            return self._resolve_s3(raw, cfg)
        path = raw
        if path.startswith('\\\\'):
            path = path.replace('\\', '/')
        best = self._match_root(path)
        if best is None:
            return None, None
        root, vol, prefix, status = best
        if status != 'active':
            return None, None
        if vol.startswith('serial:'):
            serial = norm_id(vol.split(':', 1)[1])
            hit = self.refs.serials.get(serial)
            if not hit:
                return None, None
            vol = hit[0]
        rest = path[len(root):]
        segs = self._segments(rest)
        if segs is None:
            return None, None
        full = self._canonical(vol, prefix, segs, cfg)
        if full is None:
            return None, None
        return vol, full

    def _match_root(self, path):
        """The longest root that is a prefix of the path ending at a separator."""
        if path.startswith('//'):
            body = path[2:]
            scheme = '//'
        elif path.lower().startswith('smb://') or path.lower().startswith('nfs://'):
            scheme = path.split('://', 1)[0].lower() + '://'
            body = path.split('://', 1)[1]
        else:
            scheme = ''
            body = path
        segs = [s for s in body.split('/') if s != '']
        best = None
        plow = path.lower()
        # case-insensitive lookup (UNC, smb, nfs), then exact (posix)
        for trie, lower in ((self.trie, True), (self.trie_cs, False)):
            node = trie
            cand = None
            hay = plow if lower else path
            for i, s in enumerate(segs):
                key = s.lower() if lower else s
                nxt = node.get(key)
                if nxt is None:
                    break
                terms = nxt.get('__terms__')
                if terms:
                    for row, sch, nseg in terms:
                        if sch != scheme:
                            continue
                        root = row[0]
                        rootl = root.lower() if lower else root
                        if hay.startswith(rootl) and (rootl.endswith('/')
                                                      or len(hay) == len(rootl)
                                                      or hay[len(rootl)] == '/'):
                            if cand is None or len(root) > len(cand[0]):
                                cand = row
                node = nxt
            if cand is not None and (best is None or len(cand[0]) > len(best[0])):
                best = cand
        return best

    def _segments(self, rest):
        out = []
        for seg in rest.split('/'):
            if seg in ('', '.'):
                continue
            if seg == '..':
                if not out:
                    return None
                out.pop()
                continue
            out.append(unicodedata.normalize('NFC', seg))
        return out

    def _canonical(self, vol, prefix, segs, cfg):
        fs = self.refs.fs_type.get(vol, '')
        case_ins = self._case_insensitive(vol, fs, cfg)
        path = prefix + '/'.join(segs)
        if not path.startswith('/'):
            path = '/' + path
        if not case_ins:
            return path
        dirs = getattr(self.refs, 'case_dirs', {}).get(vol) or []
        low = path.lower()
        for d in dirs:
            if low.startswith(d):
                cut = len(d)
                return path[:cut].lower() + path[cut:]
        return path.lower()

    def _case_insensitive(self, vol, fs, cfg):
        if fs == 'apfs':
            v = norm_text(cfg.get('vol.%s.case' % vol, 'insensitive')).lower()
            return v != 'sensitive'
        return fs in ('ntfs', 'hfsplus', 'exfat')

    def _resolve_s3(self, raw, cfg):
        rest = raw[len('s3://'):]
        bucket, sep, key = rest.partition('/')
        bucket = _decode_pct(bucket)
        key = _decode_pct(key)
        segs = self._segments(key)
        if segs is None:
            return None, None
        vol = 'OBJ01'
        path = '/' + bucket + ('/' + '/'.join(segs) if segs else '')
        return vol, path


def _decode_pct(s):
    """%XX sequences are decoded as UTF-8 bytes; + is a literal plus."""
    if '%' not in s:
        return unicodedata.normalize('NFC', s)
    out = bytearray()
    i = 0
    while i < len(s):
        if s[i] == '%' and i + 2 < len(s) + 1 and s[i + 1:i + 3]:
            try:
                out.append(int(s[i + 1:i + 3], 16))
                i += 3
                continue
            except ValueError:
                pass
        out.extend(s[i].encode('utf-8'))
        i += 1
    return unicodedata.normalize('NFC', out.decode('utf-8', 'replace'))


# --------------------------------------------------------------------------
# owners (ECS 5.4, 5.5)
# --------------------------------------------------------------------------

OWNER_SENTINELS = {'S-1-0-0', 'NOBODY@CORP.EXAMPLE', 'CORP\\-', 'OLDCORP\\-', '-',
                   'SVC-NONE', 'N/A', ''}


def _is_uid_sentinel(t):
    m = re.fullmatch(r'uid:(.*):(\d+)', t)
    return bool(m) and m.group(2) == '65534'


class OwnerEngine:
    """Resolves owner tokens to the account of the final principal."""

    def __init__(self, refs):
        self.refs = refs
        self._cache = {}

    def resolve(self, token):
        """(principal_id, account) or (None, None) when unresolved."""
        t = norm_text(token)
        if t in OWNER_SENTINELS or _is_uid_sentinel(t):
            return None, None
        if re.fullmatch(r'[0-9a-fA-F]{64}', t):
            if set(t.lower()) == {'0'}:
                return None, None
            pid = self.refs.s3.get(t.lower())
            return self._finish(pid)
        if t.upper().startswith('S-1-'):
            sid = t.upper()
            sid = self.refs.sid_history.get(sid) or sid
            pid = self.refs.sid.get(sid)
            return self._finish(pid)
        if t.lower().startswith('uid:'):
            m = re.fullmatch(r'uid:(.*):(.+)', t)
            if not m:
                return None, None
            host = norm_text(m.group(1)).lower()
            host = self.refs.host_alias.get(host, host)
            try:
                num = int(Decimal(norm_text(m.group(2))))
            except Exception:
                return None, None
            pid = self.refs.uid.get((host, num))
            return self._finish(pid)
        if '\\' in t:
            dom, _, login = t.partition('\\')
            dom = norm_text(dom).upper()
            login = norm_text(login).lower()
            if not login:
                return None, None
            if dom == 'CORP':
                pid = self.refs.corp.get((dom, login))
            elif dom == 'OLDCORP':
                pid = self.refs.oldcorp.get((dom, login))
            else:
                pid = self.refs.legacy.get((dom, login))
            return self._finish(pid)
        if '@' in t:
            addr = t.lower()
            if '+' in addr.split('@')[0]:
                addr = addr.split('@')[0].split('+')[0] + '@' + addr.split('@')[1]
            pid = self.refs.email.get(addr)
            return self._finish(pid)
        if t.lower().startswith('svc-'):
            pid = self.refs.svc.get(t.lower())
            return self._finish(pid)
        if re.fullmatch(r'MF\w+', t.upper()) and t.upper().startswith('MF'):
            if '?' in t:
                return None, None
            pid = self.refs.mf.get(t.upper())
            return self._finish(pid)
        pid = self.refs.mf.get(t.upper())
        if pid:
            return self._finish(pid)
        return None, None

    def _finish(self, pid):
        if not pid or pid not in self.refs.principal:
            return None, None
        pid = self._merge(pid)
        if pid is None or pid not in self.refs.principal:
            return None, None
        return pid, self.refs.principal[pid]

    def _merge(self, pid):
        seen = set()
        while pid in self.refs.merge_map:
            if pid in seen:
                return None
            seen.add(pid)
            pid = self.refs.merge_map[pid]
        return pid


# --------------------------------------------------------------------------
# sizes (ECS 6.1)
# --------------------------------------------------------------------------

UNIT_MULT = {'B': Decimal(1), 'KB': Decimal(1000), 'KiB': Decimal(1024),
             'MiB': Decimal(1048576), 'blk512': Decimal(512), 'blk4096': Decimal(4096)}
_GROUP_SEP = re.compile(r'[\s,\.\'\u00a0\u202f\u2009\u2019]')


def parse_size(value, dialect, batch_unit):
    """Return an int byte count, or None when the size is unknown."""
    v = norm_text(value)
    if v == '' or v is None:
        return None
    if v in ('-1', '?', '9999', '*******', '-', 'N/A', 'null', 'None'):
        return None
    d = dialect
    if d in ('int', 'grouped', 'dotted', 'spaced'):
        s = _GROUP_SEP.sub('', v)
        try:
            return int(Decimal(s))
        except Exception:
            return None
    if d == 'unit':
        mult = UNIT_MULT.get(batch_unit)
        if mult is None:
            mult = Decimal(1)
        try:
            num = Decimal(v.replace(',', ''))
        except Exception:
            return None
        return int((num * mult).quantize(Decimal(1), rounding=ROUND_HALF_EVEN))
    if d == 'kib':
        try:
            num = Decimal(v.replace(',', ''))
        except Exception:
            return None
        return int((num * Decimal(1024)).quantize(Decimal(1), rounding=ROUND_HALF_EVEN))
    if d == 'kb4de':
        s = v.replace('.', '').replace(',', '.')
        try:
            num = Decimal(s)
        except Exception:
            return None
        return int((num * Decimal(1000)).quantize(Decimal(1), rounding=ROUND_HALF_EVEN))
    if d == 'xmlunit':
        mult = UNIT_MULT.get(batch_unit)
        if mult is None:
            mult = Decimal(1)
        try:
            num = Decimal(v.replace(',', ''))
        except Exception:
            return None
        return int((num * mult).quantize(Decimal(1), rounding=ROUND_HALF_EVEN))
    try:
        return int(Decimal(v))
    except Exception:
        return None


# --------------------------------------------------------------------------
# digests (ECS 6.2)
# --------------------------------------------------------------------------

_ALL_ZERO = set('0')


def _is_zero(v):
    v = norm_text(v).lower()
    return bool(v) and set(v) <= _ALL_ZERO


def _b64_to_hex(v):
    import base64
    try:
        return base64.b64decode(norm_text(v)).hex()
    except Exception:
        return ''


def resolve_digest(refs, volume, sha256, legacy_alg, legacy_value, dialect):
    """The record's sha256, or None when it cannot be resolved."""
    s = norm_text(sha256).lower()
    if s and not _is_zero(s):
        if re.fullmatch(r'[0-9a-f]{64}', s):
            return s
    if _is_zero(s):
        s = ''
    alg = norm_text(legacy_alg).lower()
    dig = norm_text(legacy_value)
    if dialect == 'md5b64':
        dig = _b64_to_hex(dig)
        alg = alg or 'md5'
    if dialect == 'etag':
        alg = 'md5'
        dig = dig.strip('"')
    if not dig or not alg:
        return None
    if _is_zero(dig):
        return None
    part = refs.xwalk.get(volume) or {}
    return part.get((alg, dig.lower()))


# --------------------------------------------------------------------------
# inventory records
# --------------------------------------------------------------------------

ALIASES = {
    'rec_id': ('rec_id', 'id', 'rec', 'record', 'rec_id'),
    'path': ('path', 'unc_path', 'p', 'key', 'location'),
    'size': ('size_bytes', 'size', 'bytes', 'sz', 'size_kib', 'size_kb'),
    'mtime': ('mtime_filetime', 'mtime', 'mtime_ms', 'mtime_ns', 'mtime_epoch',
              'mtime_local', 'modified', 'mt', 'last_modified', 'mtime_julian',
              'eventTime', 'ts', 'at', 'filetime'),
    'sha256': ('sha256',),
    'md5': ('md5', 'md5b64'),
    'sha1': ('sha1',),
    'etag': ('etag', 'eTag', 'eTag'),
    'owner': ('owner_sid', 'owner', 'own', 'uid', 'owner_id', 'owned_by', 'userIdentity'),
    'file_id': ('file_id', 'fid', 'inode'),
    'nlink': ('links', 'nlink'),
    'batch': ('batch',),
    'tzq': ('tzq',),
    'flag': ('flag',),
    'is_latest': ('is_latest',),
    'delete_marker': ('delete_marker',),
    'op': ('op', 'eventName'),
    'seq': ('seq', 'sequencer'),
    'to': ('to', 'new_path', 'X-To'),
}


def _pick(row, field):
    for name in ALIASES.get(field, (field,)):
        if name in row and row[name] is not None:
            v = row[name]
            if isinstance(v, (dict, list, tuple)):
                continue
            if norm_text(v) == '':
                continue
            return v
    return None


def _has_field(row, field):
    return _pick(row, field) is not None


def read_leg01_xml(path):
    """inv_leg01_q3.xml: file elements; a schema-change element renames columns."""
    root = etree.parse(path).getroot()
    rows = []
    renames = {}
    for el in root:
        name = etree.QName(el).localname
        if name == 'schema-change':
            try:
                renames.update(json.loads(el.get('renames') or '{}'))
            except Exception:
                pass
            continue
        if name != 'file':
            continue
        d = {'rec_id': el.get('id')}
        for child in el:
            cn = renames.get(etree.QName(child).localname) or etree.QName(child).localname
            if cn in ('size', 'bytes'):
                d['size'] = child.text or ''
                d['size_unit'] = child.get('unit') or 'B'
            else:
                d[cn] = child.text or ''
        rows.append(d)
    return rows


def read_obj01_csv(path):
    """inv_obj01_q3_r2.csv: quoted etags and versioned listing flags."""
    return read_delim(path, ',')


def read_inventory_rows(name, spec, refs):
    """Raw rows of one inventory export, normalised to common keys."""
    p = refs.d.path(name)
    ext = os.path.splitext(name)[1].lower()
    rows = []
    if name == 'inv_leg01_q3.xml':
        rows = read_leg01_xml(p)
    elif name == 'inv_obj01_q3_r2.csv':
        rows = read_delim(p, ',')
    elif name == 'inv_fin02_q3.tsv':
        rows = read_delim(p, '\t', 'enc')
    elif name == 'inv_eng02_q3.txt' or name == 'arc01_tape_catalog.txt':
        rows = read_fixed(p)
    elif ext == '.csv':
        rows = read_delim(p, ',')
    elif ext == '.tsv':
        rows = read_delim(p, '\t')
    elif ext == '.jsonl':
        rows = read_jsonl(p)
    elif ext == '.json':
        doc = read_json_doc(p)
        for key in ('items', 'records', 'files', 'rows', 'entries'):
            rows = _v2_rows(doc, key)
            if rows:
                break
    elif ext == '.xlsx':
        for t in read_xlsx_tables(p):
            rows += t['rows']
    elif ext == '.pdf':
        rows = read_pdf_rows(p)
    elif ext in ('.db', '.sqlite'):
        tables = read_sqlite_tables(p)
        for tname in sorted(tables):
            rows += tables[tname]
    elif ext == '.parquet':
        import pyarrow.parquet as pq
        t = pq.read_table(p)
        cols = t.column_names
        rows = [{c: t[c][i].as_py() for c in cols} for i in range(t.num_rows)]
    return rows


def inventory_record(row, spec, name):
    """A normalised inventory record."""
    rec = {}
    rec['rec_id'] = norm_id(_pick(row, 'rec_id'))
    rec['raw_path'] = norm_text(_pick(row, 'path'))
    rec['size_raw'] = _pick(row, 'size')
    rec['mtime_raw'] = _pick(row, 'mtime')
    rec['sha256_raw'] = _pick(row, 'sha256')
    rec['legacy'] = []
    for alg in ('md5', 'sha1', 'etag'):
        v = _pick(row, alg)
        if v is not None and norm_text(v) != '':
            rec['legacy'].append((alg, norm_text(v)))
    own = _pick(row, 'owner')
    rec['owner_raw'] = own
    rec['file_id'] = _pick(row, 'file_id')
    rec['nlink'] = _pick(row, 'nlink')
    rec['batch'] = norm_id(_pick(row, 'batch') or '')
    rec['tzq'] = _pick(row, 'tzq')
    rec['flag'] = norm_text(_pick(row, 'flag') or '')
    rec['is_latest'] = norm_text(_pick(row, 'is_latest') or '').lower()
    rec['delete_marker'] = norm_text(_pick(row, 'delete_marker') or '').lower()
    if 'size_unit' in row:
        rec['size_unit'] = norm_text(row['size_unit'])
    return rec


# --------------------------------------------------------------------------
# journal events
# --------------------------------------------------------------------------

def read_journal_events(name, spec, refs):
    """Events of one journal with a normalised shape."""
    p = refs.d.path(name)
    ext = os.path.splitext(name)[1].lower()
    meta = refs.export_meta.get(name, {})
    role = norm_text(meta.get('role')).lower() or 'primary'
    out = []
    if ext == '.log':
        _, m, events = read_log_events(p)
    elif ext == '.csv':
        events = read_delim(p, ',')
    elif ext == '.jsonl':
        events = read_jsonl(p)
    elif ext == '.json':
        doc = read_json_doc(p)
        events = []
        for key in ('events', 'records', 'items', 'entries'):
            events = _v2_rows(doc, key)
            if events:
                break
    elif ext == '.xml':
        events = read_xml_rows(p, 'event')
    elif ext == '.mbox':
        events = read_mbox_events(p)
    else:
        events = []
    for ev in events:
        item = {'journal': name, 'role': role}
        item['rec_id'] = norm_id(_pick(ev, 'rec_id'))
        item['op'] = norm_text(_pick(ev, 'op'))
        item['raw_path'] = norm_text(_pick(ev, 'path'))
        item['to_path'] = norm_text(_pick(ev, 'to'))
        item['size_raw'] = _pick(ev, 'size')
        item['mtime_raw'] = _pick(ev, 'mtime')
        item['sha256_raw'] = _pick(ev, 'sha256')
        item['legacy'] = []
        for alg in ('md5', 'sha1', 'etag'):
            v = _pick(ev, alg)
            if v is not None and norm_text(v) != '':
                item['legacy'].append((alg, norm_text(v)))
        item['owner_raw'] = _pick(ev, 'owner')
        item['batch'] = norm_id(_pick(ev, 'batch') or '')
        item['host'] = norm_text(ev.get('host') or meta.get('host') or '')
        item['tzq'] = _pick(ev, 'tzq')
        seq = _pick(ev, 'seq')
        item['seq_raw'] = seq
        if item['op'].startswith('ObjectCreated'):
            item['op'] = 'CREATE'
        elif item['op'].startswith('ObjectRemoved'):
            item['op'] = 'DELETE'
        # S3 event notifications nest their payload
        if isinstance(ev.get('s3'), dict):
            s3 = ev['s3']
            obj = s3.get('object') or {}
            buck = (s3.get('bucket') or {}).get('name', '')
            item['raw_path'] = item['raw_path'] or norm_text(
                's3://%s/%s' % (buck, obj.get('key', '')))
            item['size_raw'] = item['size_raw'] if item['size_raw'] is not None else obj.get('size')
            item['sha256_raw'] = item['sha256_raw'] if item['sha256_raw'] is not None else obj.get('sha256')
            item['mtime_raw'] = item['mtime_raw'] or ev.get('eventTime')
            if obj.get('eTag') and not item['legacy']:
                item['legacy'] = [('etag', norm_text(obj.get('eTag')))]
            if not item['seq_raw']:
                item['seq_raw'] = obj.get('sequencer')
            ui = ev.get('userIdentity') or {}
            item['owner_raw'] = item['owner_raw'] if item['owner_raw'] is not None else ui.get('canonicalId')
        out.append(item)
    return out, role


# --------------------------------------------------------------------------
# retention rules and actions (ECS 7)
# --------------------------------------------------------------------------

def _pattern_to_re(pattern, anchored):
    """* within a segment, ? one character, ** any number of segments."""
    parts = pattern.split('/')
    out = []
    for i, part in enumerate(parts):
        if part == '**':
            out.append('(?:[^/]+/)*[^/]*' if not anchored else '(?:[^/]+/)*')
            continue
        buf = ''
        for ch in part:
            if ch == '*':
                buf += '[^/]*'
            elif ch == '?':
                buf += '[^/]'
            else:
                buf += re.escape(ch)
        out.append(buf)
    return out


def match_rule(pattern, volume, path, family, case_insensitive):
    """Test one retention rule pattern against an entry's path (ECS 7.3)."""
    if pattern.startswith('family:'):
        return family is not None and pattern.split(':', 1)[1].strip().upper() == family
    p = pattern if not case_insensitive else pattern.lower()
    target = path if not case_insensitive else path.lower()
    if p.endswith('/'):
        body = p[:-1]
        segs = target.strip('/').split('/')
        if '/' in body:
            rx = '^' + '/'.join(_pattern_to_re(body, False)) + '$'
            for i in range(1, len(segs)):
                cand = '/' + '/'.join(segs[:i])
                if re.match(rx, cand):
                    return True
            return False
        rx = '^' + '|'.join('(?:%s)$' % s for s in _pattern_to_re(body, False))
        parts = _pattern_to_re(body, False)[0]
        for seg in segs:
            if re.fullmatch(parts, seg):
                return True
        return False
    if '/' in p:
        rx = '^' + '/'.join(_pattern_to_re(p, False)) + '$'
        return bool(re.match(rx, target))
    parts = _pattern_to_re(p, False)[0]
    return bool(re.fullmatch(parts, target.rpartition('/')[2]))


def entry_class(refs, volume, path, family, case_insensitive):
    """The LAST matching rule decides the class; no match means standard."""
    cls = 'standard'
    for r in refs.rules:
        scope = norm_text(_get(r, 'scope'))
        if scope != '*' and norm_id(scope) != volume:
            continue
        pattern = norm_text(_get(r, 'pattern'))
        if not pattern:
            continue
        if match_rule(pattern, volume, path, family, case_insensitive):
            cls = norm_class(_get(r, 'class'))
    return cls


def covers(path, prefix):
    """A prefix covers paths equal to or below it (whole path segments)."""
    if not prefix:
        return True
    if path == prefix:
        return True
    if prefix.endswith('/'):
        return path.startswith(prefix)
    return path.startswith(prefix + '/')


def subtree_flag(cfg, volume, path, flag):
    """The subtree key with the longest prefix that covers the path decides."""
    best = None
    for k, v in cfg.items():
        if not k.startswith('subtree.'):
            continue
        head, sep, tail = k.partition('.')
        rest = tail
        vol, sep2, rest2 = rest.partition(':')
        if not sep2:
            continue
        if vol != volume:
            continue
        prefix, sep3, flg = rest2.rpartition('/.')
        if not sep3:
            continue
        if flg != flag:
            continue
        if covers(path, prefix):
            if best is None or len(prefix) > len(best[0]):
                best = (prefix, v)
    if best is None:
        return False
    return best[1] is True


def hold_covers(holds, volume, path):
    for vol, prefix in holds:
        if vol == volume and covers(path, prefix):
            return True
    return False


# --------------------------------------------------------------------------
# not-a-file rules (ops-runbook.md)
# --------------------------------------------------------------------------

def is_not_a_file(volume, path, rec):
    low = path.lower()
    base = low.rpartition('/')[2]
    if volume in ('ENG01', 'ENG02', 'LEG01') and base == 'desktop.ini':
        return True
    if volume == 'MKT01' and base == '.ds_store':
        return True
    if volume == 'LAB01' and base.startswith('._'):
        return True
    if volume == 'OBJ01' and '_temporary/' in low:
        return True
    if volume in ('HR01', 'OPS01') and 'lost+found/' in low:
        return True
    if volume == 'OPS01' and norm_text(rec.get('size_raw')) == 'N/A':
        return True
    if volume == 'OBJ01':
        if rec.get('is_latest') == 'false' or rec.get('delete_marker') == 'true':
            return True
    if volume == 'ARC01':
        if rec.get('flag') == 'X' or base.endswith('.spanned'):
            return True
    if volume == 'RND01' and base.endswith('.hsmstub'):
        return True
    return False


# --------------------------------------------------------------------------
# the consolidation of one profile
# --------------------------------------------------------------------------

# --------------------------------------------------------------------------
# retention rule index (ECS 7.3)
# --------------------------------------------------------------------------

class RuleIndex:
    """Rules bucketed by their first literal path segment for fast matching."""

    def __init__(self, rules):
        self.by_volume = defaultdict(lambda: {'seg': defaultdict(list), 'any': []})
        for r in rules:
            scope = norm_text(_get(r, 'scope'))
            pattern = norm_text(_get(r, 'pattern'))
            vols = ['*'] if scope == '*' else [norm_id(scope)]
            for v in vols:
                store = self.by_volume[v]
                key = self._segment_key(pattern)
                if key is None:
                    store['any'].append((r, pattern))
                else:
                    store['seg'][key].append((r, pattern))

    @staticmethod
    def _segment_key(pattern):
        if pattern.startswith('family:'):
            return None
        p = pattern
        if not p.startswith('/'):
            return None
        body = p[1:]
        first, sep, _rest = body.partition('/')
        if not first or not sep:
            return None
        if any(c in first for c in '*?'):
            return None
        return first.lower()

    def matching(self, volume):
        star = self.by_volume.get('*')
        vol = self.by_volume.get(volume)
        seg = {}
        any_ = []
        for store in (star, vol):
            if not store:
                continue
            for k, rows in store['seg'].items():
                seg.setdefault(k, []).extend(rows)
            any_.extend(store['any'])
        return seg, any_


def _compile_pattern(pattern):
    """Compile a retention pattern to a matcher (ECS 7.3)."""
    if pattern.startswith('family:'):
        fam = norm_text(pattern.split(':', 1)[1]).upper()
        return ('family', fam)
    p = pattern
    if p.endswith('/'):
        body = p[:-1]
        if '/' in body:
            rx = re.compile('^' + '/'.join(_pattern_to_re(body, False)) + '$')
            return ('dir-anchored', rx)
        parts = _pattern_to_re(body, False)[0]
        rx = re.compile('^' + parts + '$')
        return ('dir-name', rx)
    if '/' in p:
        rx = re.compile('^' + '/'.join(_pattern_to_re(p, False)) + '$')
        return ('anchored', rx)
    parts = _pattern_to_re(p, False)[0]
    return ('basename', re.compile('^' + parts + '$'))


_PATTERN_CACHE = {}


def pattern_matches(kind, path, family, segs_cache):
    if kind[0] == 'family':
        return family == kind[1]
    t = kind[0]
    if t == 'basename':
        return bool(kind[1].match(path.rpartition('/')[2]))
    if t == 'anchored':
        return bool(kind[1].match(path))
    if t == 'dir-name':
        for seg in path.strip('/').split('/'):
            if kind[1].match(seg):
                return True
        return False
    if t == 'dir-anchored':
        segs = path.strip('/').split('/')
        for i in range(1, len(segs)):
            if kind[1].match('/' + '/'.join(segs[:i])):
                return True
        return False
    return False


def compile_rule(pattern):
    hit = _PATTERN_CACHE.get(pattern)
    if hit is None:
        hit = _compile_pattern(pattern)
        _PATTERN_CACHE[pattern] = hit
    return hit


# --------------------------------------------------------------------------
# the consolidation of one profile
# --------------------------------------------------------------------------

REASON_ORDER = ['OUT_OF_AUTHORITY', 'SUPERSEDED_SCOPE', 'VOIDED', 'NOT_A_FILE',
                'STALE_EVENT', 'DEFERRED_EVENT', 'PATH_UNRESOLVED', 'SIZE_UNKNOWN',
                'HASH_UNRESOLVED', 'OWNER_UNRESOLVED', 'DUPLICATE_PATH',
                'ORPHAN_EVENT', 'DELETED', 'REPLACED', 'HARDLINK_ALIAS', 'PURGED']


class Profile:
    """One deployment profile's consolidation run (ECS 10.3)."""

    def __init__(self, refs, cfg, profile, records, events, arc01_index):
        self.refs = refs
        self.cfg = cfg
        self.profile = profile
        self.all_records = records
        self.all_events = events
        self.arc01_index = arc01_index
        self.time = TimeEngine(refs)
        self.paths = PathEngine(refs)
        self.owners = OwnerEngine(refs)
        self.window_start = norm_text(cfg.get('window.start', ''))
        self.window_end = norm_text(cfg.get('window.end', ''))
        self.ws = _dt(self.window_start)
        self.we = _dt(self.window_end)
        self.purge_enabled = bool(cfg.get('purge.enabled', False))
        self.block_size = cfg.get('store.block_size') or 1
        self.rules = refs.rules
        self.rule_idx = RuleIndex(refs.rules)
        self.rule_idx_low = RuleIndex(
            [{'seq': _get(r, 'seq'), 'scope': _get(r, 'scope'),
              'pattern': norm_text(_get(r, 'pattern')).lower(),
              'class': _get(r, 'class')} for r in refs.rules])
        self.replica_ranges = replica_ranges(refs)

    # -- scope overrides (ECS 3.2) -----------------------------------------
    def load_overrides(self):
        refs = self.refs
        self.overrides = []
        for r in refs.scope:
            if norm_text(_get(r, 'record')).lower() != 'override':
                continue
            subj = norm_text(_get(r, 'subject'))
            vol = norm_id(_get(r, 'volume_or_version'))
            prefix = norm_text(_get(r, 'prefix'))
            if not refs.ticket_approved(_get(r, 'ticket'), self.window_end):
                continue
            self.overrides.append((vol, subj, prefix))
        self.by_volume = defaultdict(list)
        for vol, subj, prefix in self.overrides:
            self.by_volume[vol].append((subj, prefix))

    # -- main pipeline (ECS 3-9) -------------------------------------------
    def run(self):
        refs = self.refs
        self.load_overrides()
        exceptions = defaultdict(set)
        # 1. authority, voids, not-a-file, resolution, size, digest, owner
        good = []
        for rec in self.all_records:
            rid = rec['rec_id']
            mode = rec['mode']
            authoritative = mode in ('full', 'continuation')
            vol = None
            path = None
            if not authoritative:
                # the record may still be authoritative inside a scope override,
                # which needs its canonical path first
                vol, path = self.paths.resolve(rec['raw_path'], rec['volume'], self.cfg)
                if not self._in_own_override(rec, path):
                    exceptions[rid].add('OUT_OF_AUTHORITY')
                    continue
            if rid in refs.voided or rid in refs.excluded:
                exceptions[rid].add('VOIDED')
                continue
            if vol is None or path is None:
                vol, path = self.paths.resolve(rec['raw_path'], rec['volume'], self.cfg)
            rec['vol'] = vol
            rec['path'] = path
            if vol is None or path is None:
                exceptions[rid].add('PATH_UNRESOLVED')
                continue
            if vol != rec['volume']:
                exceptions[rid].add('PATH_UNRESOLVED')
                continue
            if is_not_a_file(rec['volume'], path, rec):
                exceptions[rid].add('NOT_A_FILE')
                continue
            if self._superseded(rec, path):
                exceptions[rid].add('SUPERSEDED_SCOPE')
                continue
            self._resolve_values(rec)
            self._apply_errata(rec)
            if rec['size'] is None:
                exceptions[rid].add('SIZE_UNKNOWN')
                continue
            if rec['sha256'] is None:
                exceptions[rid].add('HASH_UNRESOLVED')
                continue
            if rec['owner'] is None:
                exceptions[rid].add('OWNER_UNRESOLVED')
                continue
            good.append(rec)
        # 2. duplicates within one volume's snapshot (ECS 6.4)
        live = []
        bypath = defaultdict(list)
        for rec in good:
            bypath[(rec['vol'], rec['path'])].append(rec)
        for key in sorted(bypath):
            group = bypath[key]
            group.sort(key=lambda r: (r['captured'] or '', r['rec_id']))
            live.append(group[-1])
            for r in group[:-1]:
                exceptions[r['rec_id']].add('DUPLICATE_PATH')
        # 3. hard links (ECS 6.6)
        live = self.apply_hardlinks(live, exceptions)
        # 4. journals (ECS 8)
        entries = {}
        origin_ok = set()
        for volume in sorted(self.refs.volumes):
            vol_entries = {}
            for r in live:
                if r['vol'] == volume:
                    vol_entries[r['path']] = dict(r)
                    vol_entries[r['path']]['origin'] = r['rec_id']
            evs = [e for e in self.all_events if e['volume'] == volume]
            self.apply_events(volume, evs, vol_entries, exceptions)
            for path, e in vol_entries.items():
                entries[(volume, path)] = e
                origin_ok.add(e['origin'])
        # 5. retention class and action (ECS 7)
        manifest = []
        purged = []
        for (vol, path), e in entries.items():
            family = refs.ext_family(path.rpartition('/')[2])
            case_ins = self.paths._case_insensitive(vol, refs.fs_type.get(vol, ''), self.cfg)
            cls = self.entry_class(vol, path, family, case_ins)
            e['class'] = cls
            age = None
            if e['mtime'] is not None and self.we is not None:
                age = int((self.we - e['mtime']).total_seconds() // 86400)
            purge_after, archive_after = refs.class_ages.get(cls, (None, None))
            action = 'keep'
            if (self.purge_enabled and purge_after is not None and age is not None
                    and age > purge_after
                    and not self.hold_covers(vol, path)
                    and not subtree_flag(self.cfg, vol, path, 'purge_exempt')
                    and vol not in refs.no_purge_volumes):
                action = 'purged'
            elif (archive_after is not None and age is not None and age >= archive_after
                  and not subtree_flag(self.cfg, vol, path, 'archive_exempt')):
                action = 'archive'
            e['action'] = action
            if action == 'purged':
                purged.append(e)
            else:
                manifest.append(e)
        event_ids = {ev['rec_id'] for ev in self.all_events}
        for e in purged:
            origin_ok.discard(e['origin'])
            if e['origin'] not in event_ids:
                exceptions[e['origin']].add('PURGED')
        # 6. exceptions (ECS 9)
        applied_events = set()
        for ev in self.all_events:
            rid = ev['rec_id']
            seq = self.event_seq(ev)
            if not self.event_authority(ev, seq):
                exceptions[rid].add('OUT_OF_AUTHORITY')
                continue
            reason = ev.get('reason')
            if reason is None:
                applied_events.add(rid)
            else:
                exceptions[rid].add(reason)
        for rid in list(exceptions):
            if rid in origin_ok:
                exceptions.pop(rid)
        self.entries = manifest
        self.exceptions = exceptions
        self.applied_events = applied_events
        self.event_ids = event_ids
        return manifest, exceptions

    def _in_own_override(self, rec, path):
        for subj, prefix in self.by_volume.get(rec['volume'], ()):
            if subj == rec['file'] and path and covers(path, prefix):
                return True
        return False

    def _superseded(self, rec, path):
        for subj, prefix in self.by_volume.get(rec['volume'], ()):
            if subj != rec['file'] and path and covers(path, prefix):
                return True
        return False

    def _resolve_values(self, rec):
        refs = self.refs
        spec = refs.inv_specs[rec['file']]
        volume = rec['volume']
        batch = rec['batch']
        unit = refs.batch_unit.get(batch, 'B')
        captured = refs.batch_captured.get(batch, '')
        dialect = spec['size']
        if rec.get('size_unit'):
            dialect = 'xmlunit'
            unit = rec['size_unit']
        rec['size'] = parse_size(rec['size_raw'], dialect, unit)
        rec['mtime'] = self.time.resolve(rec['mtime_raw'], spec['time'], volume, self.cfg,
                                         captured, rec.get('tzq'))
        sha = None
        for alg, dig in rec['legacy']:
            sha = resolve_digest(refs, volume, rec['sha256_raw'], alg, dig, spec['digest'])
            if sha:
                break
        else:
            sha = resolve_digest(refs, volume, rec['sha256_raw'], '', '', spec['digest'])
        rec['sha256'] = sha
        _pid, owner = self.owners.resolve(rec['owner_raw'])
        rec['owner'] = owner
        fid, nl = rec['file_id'], rec['nlink']
        if volume == 'ARC01' and rec['path'] in self.arc01_index:
            fid, nl = self.arc01_index[rec['path']]
        rec['file_id'] = fid
        rec['nlink'] = nl
        rec['captured'] = captured

    def _apply_errata(self, rec):
        refs = self.refs
        rid = rec['rec_id']
        hit = refs.errata.get((rid, 'bytes'))
        if hit is not None:
            rec['size'] = parse_size(hit, 'grouped', 'B')
        hit = refs.errata.get((rid, 'sha256'))
        if hit is not None:
            s = norm_text(hit).lower()
            rec['sha256'] = s if (s and not _is_zero(s)) else None
        hit = refs.errata.get((rid, 'mtime'))
        if hit is not None:
            rec['mtime'] = _dt(hit)
        hit = refs.errata.get((rid, 'owner'))
        if hit is not None:
            rec['owner'] = norm_text(hit)

    # -- retention (ECS 7) --------------------------------------------------
    def entry_class(self, volume, path, family, case_insensitive):
        refs = self.refs
        idx = self.rule_idx_low if case_insensitive else self.rule_idx
        seg, any_ = idx.matching(volume)
        target = path.lower() if case_insensitive else path
        segs = target.strip('/').split('/')
        first = segs[0] if segs else ''
        cands = list(seg.get(first.lower(), ()))
        cands.extend(any_)
        cls = 'standard'
        best_seq = None
        for r, pattern in cands:
            seq = _as_int(_get(r, 'seq'), 0)
            compiled = compile_rule(pattern if not case_insensitive
                                    else norm_text(pattern).lower())
            if pattern_matches(compiled, target, family, None):
                if best_seq is None or seq >= best_seq:
                    best_seq = seq
                    cls = norm_class(_get(r, 'class'))
        return cls

    def hold_covers(self, volume, path):
        for vol, prefix in self.refs.holds:
            if vol == volume and covers(path, prefix):
                return True
        return False

    # -- hard links (ECS 6.6) ----------------------------------------------
    def apply_hardlinks(self, live, exceptions):
        groups = defaultdict(list)
        for r in live:
            fidv, nl = self._file_id(r)
            if fidv is None or nl is None or nl <= 1:
                continue
            groups[(r['vol'], fidv)].append(r)
        drop = set()
        for key in sorted(groups):
            group = groups[key]
            if len(group) < 2:
                continue
            group.sort(key=lambda r: r['path'])
            for r in group[1:]:
                drop.add(r['rec_id'])
                exceptions[r['rec_id']].add('HARDLINK_ALIAS')
        return [r for r in live if r['rec_id'] not in drop]

    @staticmethod
    def _file_id(r):
        fid = norm_text(r.get('file_id'))
        if fid == '':
            return None, None
        try:
            nl = int(Decimal(norm_text(r.get('nlink')))) if r.get('nlink') is not None else 1
        except Exception:
            nl = 1
        try:
            if fid.lower().startswith('0x'):
                return int(fid, 16), nl
            return int(Decimal(fid)), nl
        except Exception:
            return None, nl

    # -- journals (ECS 8) --------------------------------------------------
    def event_seq(self, ev):
        v = ev.get('seq_raw')
        if v is None:
            return None
        s = norm_text(v)
        if s == '':
            return None
        try:
            return int(Decimal(s))
        except Exception:
            try:
                return int(s, 16)
            except Exception:
                return None

    def event_authority(self, ev, seq):
        if ev['role'] == 'primary':
            return True
        for lo, hi in self.replica_ranges.get(ev['journal'], self.replica_ranges.get('*', [])):
            if lo <= seq <= hi:
                return True
        return False

    def apply_events(self, volume, evs, vol_entries, exceptions):
        refs = self.refs
        snapshot = _dt(refs.snapshot_of(volume))
        evs = sorted([e for e in evs if self.event_seq(e) is not None],
                     key=lambda e: self.event_seq(e))
        deleted = defaultdict(list)
        for ev in evs:
            seq = self.event_seq(ev)
            if not self.event_authority(ev, seq):
                ev['reason'] = 'OUT_OF_AUTHORITY'
                continue
            self._resolve_event(ev, volume)
            t = ev['t']
            if t is None:
                ev['reason'] = 'STALE_EVENT'
                continue
            if snapshot is not None and t < snapshot:
                ev['reason'] = 'STALE_EVENT'
                continue
            if self.we is not None and t >= self.we:
                ev['reason'] = 'DEFERRED_EVENT'
                continue
            op = ev['op']
            path = ev['path']
            if op == 'CREATE':
                if path is None or ev['vol'] != volume:
                    ev['reason'] = 'PATH_UNRESOLVED'
                    continue
                if is_not_a_file(volume, path, {'size_raw': ev['size_raw']}):
                    ev['reason'] = 'NOT_A_FILE'
                    continue
                if ev['size'] is None:
                    ev['reason'] = 'SIZE_UNKNOWN'
                    continue
                if ev['sha256'] is None:
                    ev['reason'] = 'HASH_UNRESOLVED'
                    continue
                if ev['owner'] is None:
                    ev['reason'] = 'OWNER_UNRESOLVED'
                    continue
                old = vol_entries.get(path)
                if old is not None:
                    exceptions[old['origin']].add('REPLACED')
                vol_entries[path] = {'origin': ev['rec_id'], 'vol': volume, 'path': path,
                                    'size': ev['size'], 'sha256': ev['sha256'],
                                    'owner': ev['owner'], 'mtime': t,
                                    'captured': '', 'file_id': None, 'nlink': None}
                continue
            if op == 'MODIFY':
                cur = vol_entries.get(path)
                if cur is None:
                    ev['reason'] = 'ORPHAN_EVENT'
                    continue
                if ev['size'] is None:
                    ev['reason'] = 'SIZE_UNKNOWN'
                    continue
                if ev['sha256'] is None:
                    ev['reason'] = 'HASH_UNRESOLVED'
                    continue
                cur['size'] = ev['size']
                cur['sha256'] = ev['sha256']
                cur['mtime'] = t
                continue
            if op == 'RENAME':
                if ev['to_vol'] != volume or ev['to_path_canon'] is None:
                    ev['reason'] = 'PATH_UNRESOLVED'
                    continue
                cur = vol_entries.get(path)
                if cur is None:
                    ev['reason'] = 'ORPHAN_EVENT'
                    continue
                other = vol_entries.get(ev['to_path_canon'])
                if other is not None and other is not cur:
                    exceptions[other['origin']].add('REPLACED')
                del vol_entries[path]
                cur['path'] = ev['to_path_canon']
                vol_entries[cur['path']] = cur
                continue
            if op == 'DELETE':
                cur = vol_entries.pop(path, None)
                if cur is None:
                    ev['reason'] = 'ORPHAN_EVENT'
                    continue
                deleted[path].append(cur)
                exceptions[cur['origin']].add('DELETED')
                continue
            if op == 'RESTORE':
                stack = deleted.get(path)
                if not stack:
                    ev['reason'] = 'ORPHAN_EVENT'
                    continue
                cur = stack.pop()
                vol_entries[path] = cur
                exceptions[cur['origin']].discard('DELETED')
                continue
            ev['reason'] = 'ORPHAN_EVENT'

    def _resolve_event(self, ev, volume):
        refs = self.refs
        spec = ev['spec']
        t = self.time.resolve(ev['mtime_raw'], spec['time'], volume, self.cfg,
                              refs.batch_captured.get(ev['batch'], ''), ev.get('tzq'))
        t = self.time.correct_incident(t, ev.get('host'))
        ev['t'] = t
        ev['vol'], ev['path'] = self.paths.resolve(ev['raw_path'], volume, self.cfg)
        if ev['to_path']:
            ev['to_vol'], ev['to_path_canon'] = self.paths.resolve(ev['to_path'], volume, self.cfg)
        else:
            ev['to_vol'] = ev['to_path_canon'] = None
        unit = refs.batch_unit.get(ev['batch'], 'B')
        ev['size'] = parse_size(ev['size_raw'], spec['size'], unit)
        sha = None
        for alg, dig in ev['legacy']:
            sha = resolve_digest(refs, ev['vol'] or volume, ev['sha256_raw'], alg, dig, spec['digest'])
            if sha:
                break
        else:
            sha = resolve_digest(refs, ev['vol'] or volume, ev['sha256_raw'], '', '', spec['digest'])
        ev['sha256'] = sha
        if ev['op'] == 'CREATE':
            _pid, owner = self.owners.resolve(ev['owner_raw'])
            ev['owner'] = owner
        else:
            ev['owner'] = None


def replica_ranges(refs):
    """The replica journal's authoritative sequence range (ops-runbook.md)."""
    out = defaultdict(list)
    if not refs.d.has('ops-runbook.md'):
        return out
    text = read_text(refs.d.path('ops-runbook.md'))
    for m in re.finditer(r'replica journal\s+(\S+?)\s+is authoritative', text):
        name = norm_text(m.group(1).strip())
        rng = re.search(r'(\d+)\s+through\s+(\d+)\s+inclusive', text)
        if rng:
            out[name].append((int(rng.group(1)), int(rng.group(2))))
            out['*'] = out[name]
    return out


# --------------------------------------------------------------------------
# outputs (ECS 11)
# --------------------------------------------------------------------------

def build_outputs(refs, profiles, data):
    """Return the five output documents of the consolidation."""
    prior = refs.prior_meta
    prior_rows = refs.prior_rows
    valid = set(refs.volumes)
    prior_live = {}
    for row in prior_rows:
        vol = norm_text(row.get('volume'))
        path = norm_text(row.get('path'))
        status = norm_text(row.get('status')).lower()
        eid = row.get('entry_id')
        if status != 'live' or vol not in valid or not path:
            continue
        key = (vol, path)
        cur = prior_live.get(key)
        if cur is None or (eid is not None and eid < cur):
            prior_live[key] = eid
    next_id = int(prior.get('next_entry_id', '1') or 1)
    out = {}
    ledgers = {}
    for profile in ('prod', 'dev'):
        manifest, exceptions = profiles[profile]
        applied = profiles[profile + '_applied']
        cfg = profiles[profile + '_config']
        manifest = sorted(manifest, key=lambda e: (e['vol'], e['path']))
        entry_ids = {}
        carried = 0
        for e in manifest:
            key = (e['vol'], e['path'])
            if key in prior_live:
                e['entry_id'] = prior_live[key]
                carried += 1
            else:
                e['entry_id'] = None
        n = next_id
        for e in manifest:
            if e['entry_id'] is None:
                e['entry_id'] = n
                n += 1
        entries = []
        logical = 0
        vol_stats = defaultdict(lambda: [0, 0])
        store_digests = {}
        for e in manifest:
            entries.append({'entry_id': e['entry_id'], 'volume': e['vol'], 'path': e['path'],
                            'sha256': e['sha256'], 'bytes': e['size'],
                            'mtime': fmt_instant(e['mtime']), 'owner': e['owner'],
                            'class': e['class'], 'action': e['action'],
                            'origin': e['origin']})
            logical += e['size']
            vol_stats[e['vol']][0] += 1
            vol_stats[e['vol']][1] += e['size']
            if e['sha256'] not in store_digests:
                store_digests[e['sha256']] = e['size']
        block = refs.block_size_of(profile)
        store = 0
        for sha, size in store_digests.items():
            if sha in refs.store_prior:
                continue
            store += _round_up(size, block)
        id_hash = 0
        for e in manifest:
            id_hash = (id_hash + e['entry_id']) % 1000000007
        opening_entries = int(prior.get('closing_entries', '0') or 0)
        opening_logical = int(prior.get('closing_logical_bytes', '0') or 0)
        opening_store = int(prior.get('closing_store_bytes', '0') or 0)
        prior_keys = set(prior_live)
        now_keys = {(e['vol'], e['path']) for e in manifest}
        retired = len(prior_keys - now_keys)
        new = len(manifest) - carried
        report = []
        exc_counts = defaultdict(int)
        for rid in sorted(exceptions):
            if rid in applied:
                continue
            reasons = exceptions[rid]
            reason = pick_reason(reasons)
            if reason is None:
                continue
            exc_counts[reason] += 1
            report.append({'rec_id': rid, 'reason': reason})
        ledger = {
            'opening': {'entries': opening_entries, 'logical_bytes': opening_logical,
                        'store_bytes': opening_store},
            'movement': {'carried': carried, 'new': new, 'retired': retired},
            'closing': {'entries': len(manifest), 'logical_bytes': logical,
                        'store_bytes': opening_store + store, 'id_hash_total': id_hash},
            'volumes': [{'volume': v, 'entries': vol_stats[v][0], 'logical_bytes': vol_stats[v][1]}
                        for v in sorted(vol_stats)],
            'exceptions': dict(sorted(exc_counts.items())),
        }
        out[profile] = {'profile': profile,
                        'config': profiles[profile + '_config'],
                        'control': {'entries': len(manifest), 'logical_bytes': logical,
                                    'store_bytes': opening_store + store,
                                    'id_hash_total': id_hash},
                        'entries': entries}
        ledgers[profile] = ledger
        out[profile + '_report'] = report
    summary = {
        'opening_ctl_id': data.opening_ctl_id,
        'chain': [{'file': f, 'ctl_id': c, 'rows': r} for f, c, r in data.chain],
        'profiles': {'prod': ledgers['prod'], 'dev': ledgers['dev']},
    }
    return out, summary


def pick_reason(reasons):
    for r in REASON_ORDER:
        if r in reasons:
            return r
    if 'DELETED_OR_REPLACED' in reasons:
        return 'REPLACED' if 'REPLACED' in reasons else 'DELETED'
    return sorted(reasons)[0] if reasons else None


def _round_up(size, block):
    if block <= 1:
        return size
    return ((size + block - 1) // block) * block


# --------------------------------------------------------------------------
# command line
# --------------------------------------------------------------------------

def cmd_run(args):
    data = Data(args.data)
    data.read_ctl()
    refs = Refs(data)
    we, ws = provisional_window(refs, 'prod')
    refs.load_all(ws, we)
    revoked = set()
    if data.has('site-policy-v2.yaml'):
        doc = read_yaml_doc(data.path('site-policy-v2.yaml'))
        for r in doc.get('revocations') or []:
            if refs.ticket_approved(_get(r, 'ticket'), we):
                revoked.add(norm_id(_get(r, 'override_id')))
    profiles = {}
    for profile in ('prod', 'dev'):
        cfg = typed_config(resolve_config(refs, profile, we, revoked))
        profiles[profile + '_config'] = dict(sorted(cfg.items()))
    # records and events are shared between profiles
    records = []
    for name in sorted(refs.inv_specs):
        spec = refs.inv_specs[name]
        mode = refs.run_mode_of(name)
        for row in read_inventory_rows(name, spec, refs):
            rec = inventory_record(row, spec, name)
            if not rec['rec_id']:
                continue
            rec['volume'] = spec['volume']
            rec['file'] = name
            rec['mode'] = mode
            records.append(rec)
    volume_of_record = {}
    for rec in records:
        volume_of_record[rec['rec_id']] = rec['volume']
    refs.load_exclusions(volume_of_record)
    events = []
    for name in sorted(refs.jrn_specs):
        spec = refs.jrn_specs[name]
        evs, role = read_journal_events(name, spec, refs)
        for e in evs:
            e['volume'] = spec['volume']
            e['spec'] = spec
            e['journal'] = name
            events.append(e)
    profiles_run = dict(profiles)
    for profile in ('prod', 'dev'):
        cfg = profiles[profile + '_config']
        p = Profile(refs, cfg, profile, records, events, arc01_index_for(refs, cfg))
        manifest, exceptions = p.run()
        profiles_run[profile] = (manifest, exceptions)
        profiles_run[profile + '_applied'] = set(p.applied_events)
    out, summary = build_outputs(refs, profiles_run, data)
    os.makedirs(args.out, exist_ok=True)
    write_json(os.path.join(args.out, 'config.json'), out['prod']['config'])
    for profile in ('prod', 'dev'):
        doc = {'profile': profile, 'config': out[profile]['config'],
               'control': out[profile]['control'], 'entries': out[profile]['entries']}
        write_json(os.path.join(args.out, 'profile_%s.json' % profile), doc)
    write_json(os.path.join(args.out, 'validation_report.json'),
               {'prod': out['prod_report'], 'dev': out['dev_report']})
    write_json(os.path.join(args.out, 'summary.json'), summary)
    print('ok')
    return 0


def arc01_index_for(refs, cfg):
    """arc01_ltfs_index.db: file_id and nlink by canonical path."""
    name = None
    for n, spec in refs.inv_specs.items():
        if spec['volume'] == 'ARC01' and n.endswith('.db'):
            name = n
    out = {}
    if not name or not refs.d.has(name):
        return out
    paths = PathEngine(refs)
    for row in read_inventory_rows(name, refs.inv_specs[name], refs):
        raw = _pick(row, 'path')
        if not raw:
            continue
        vol, path = paths.resolve(raw, 'ARC01', cfg)
        if not path:
            continue
        fid = norm_text(_pick(row, 'file_id'))
        nl = norm_text(_pick(row, 'nlink'))
        try:
            fidv = int(fid, 16) if fid.lower().startswith('0x') else int(Decimal(fid))
        except Exception:
            fidv = None
        try:
            nlv = int(Decimal(nl))
        except Exception:
            nlv = 1
        out[path] = (fidv, nlv)
    return out


def write_json(path, doc):
    with open(path, 'w', encoding='utf-8') as fh:
        json.dump(doc, fh, ensure_ascii=False, indent=1, sort_keys=False)
        fh.write('\n')


def cmd_report(args):
    digest = hashlib.sha256(open(args.config, 'rb').read()).hexdigest()
    try:
        commands = json.loads(args.commands)
    except Exception:
        commands = args.commands
    report = {'ok': True, 'tool': 'estatectl', 'config_sha256': digest,
              'commands': commands}
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, 'w', encoding='utf-8') as fh:
        json.dump(report, fh, ensure_ascii=False, indent=1)
        fh.write('\n')
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog='estatectl')
    sub = ap.add_subparsers(dest='cmd')
    r = sub.add_parser('run')
    r.add_argument('--data', default=os.environ.get('ESTATE_DATA', '.'))
    r.add_argument('--out', required=True)
    r.set_defaults(func=cmd_run)
    e = sub.add_parser('export-report')
    e.add_argument('--config', required=True)
    e.add_argument('--out', required=True)
    e.add_argument('--commands', default='[]')
    e.set_defaults(func=cmd_report)
    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == '__main__':
    sys.exit(main())
