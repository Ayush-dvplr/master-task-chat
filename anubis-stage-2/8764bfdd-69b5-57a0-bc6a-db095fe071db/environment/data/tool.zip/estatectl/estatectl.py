#!/usr/bin/env python3
"""estatectl - consolidate estate inventories into placement manifests.

Usage:
  python3 estatectl.py run --data DIR --out DIR
  python3 estatectl.py export-report --config FILE --out FILE --commands JSON
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import tomllib
from pathlib import Path

import yaml

LAYERS = ["estate-defaults.toml", "site-policy.yaml", "site-policy-v2.yaml", "volume-policy.json"]


def load_config(data: Path) -> dict:
    cfg = {}
    for name in LAYERS:
        p = data / name
        if not p.exists():
            continue
        if name.endswith(".toml"):
            doc = tomllib.loads(p.read_text())
            rows = doc.get("setting", [])
        elif name.endswith(".yaml"):
            doc = yaml.safe_load(p.read_text())
            rows = doc.get("settings", [])
        else:
            rows = json.loads(p.read_text()).get("settings", [])
        for row in rows:
            cfg[row["key"]] = row["value"]
    return cfg


def canonical(path: str) -> str:
    path = path.replace("\\", "/")
    return path.casefold().rstrip("/")


def read_inventory(p: Path):
    if p.suffix == ".csv":
        with p.open(newline="") as fh:
            rows = [r for r in csv.DictReader(line for line in fh if not line.startswith("#"))]
        return rows
    if p.suffix == ".jsonl":
        return [json.loads(line) for line in p.read_text().splitlines()[2:]]
    return []


def size_bytes(row) -> int:
    v = row.get("size_bytes") or row.get("size") or row.get("bytes") or 0
    return int(float(str(v).replace(",", "")) * 1000) if "kib" in json.dumps(list(row)) else int(float(str(v).replace(",", "")))


def classify(path: str, rules) -> str:
    for rule in rules:
        if rule["pattern"].strip("/") in path:
            return rule["class"]
    return "standard"


def cmd_run(args) -> None:
    data = Path(args.data)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    cfg = load_config(data)
    rules = yaml.safe_load((data / "retention_rules_v3.yaml").read_text())["rules"]
    entries = {}
    for p in sorted(data.glob("inv_*")):
        for row in read_inventory(p):
            path = canonical(row.get("path") or row.get("p") or "")
            cur = entries.get(path)
            if cur is None or str(row.get("mtime", "")) > str(cur.get("mtime", "")):
                entries[path] = {"path": path, "bytes": size_bytes(row), "sha256": row.get("sha256"),
                                 "mtime": row.get("mtime"), "owner": row.get("owner") or row.get("own"),
                                 "class": classify(path, rules), "action": "keep"}
    listing = sorted(entries.values(), key=lambda e: e["path"])
    for i, e in enumerate(listing):
        e["entry_id"] = i + 1
    for profile in ("prod", "dev"):
        doc = {"profile": profile, "config": cfg, "entries": listing}
        (out / f"profile_{profile}.json").write_text(json.dumps(doc, indent=1))
    (out / "config.json").write_text(json.dumps(cfg, indent=1, sort_keys=True))
    (out / "validation_report.json").write_text(json.dumps({"prod": [], "dev": []}))
    (out / "summary.json").write_text(json.dumps({"entries": len(listing)}))
    print("ok")


def cmd_report(args) -> None:
    digest = hashlib.sha256(Path(args.config).read_bytes()).hexdigest()
    report = {"ok": True, "tool": "estatectl", "config_sha256": digest, "commands": args.commands}
    Path(args.out).write_text(json.dumps(report))


def main() -> None:
    ap = argparse.ArgumentParser(prog="estatectl")
    sub = ap.add_subparsers(dest="cmd")
    r = sub.add_parser("run")
    r.add_argument("--data", default=os.environ.get("ESTATE_DATA", "/app/data"))
    r.add_argument("--out", required=True)
    r.set_defaults(func=cmd_run)
    e = sub.add_parser("export-report")
    e.add_argument("--config", required=True)
    e.add_argument("--out", required=True)
    e.add_argument("--commands", default="[]")
    e.set_defaults(func=cmd_report)
    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
