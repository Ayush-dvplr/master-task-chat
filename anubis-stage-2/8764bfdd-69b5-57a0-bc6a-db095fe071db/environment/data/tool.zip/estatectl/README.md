# estatectl

Command-line tool of the storage team's estate consolidation. It reads an export set laid out like `/app/data` and
writes the consolidation outputs described in section 11 of ECS-standard.md.

    python3 estatectl.py run --data <export set directory> --out <output directory>
    python3 estatectl.py export-report --config <config.json> --out <report.json> --commands '<json list>'

`run` writes config.json, profile_prod.json, profile_dev.json, validation_report.json and summary.json into the
output directory and prints ok. It must not read anything outside --data and must give byte-identical output for the
same input.

`export-report` writes the run report: ok, tool (estatectl), config_sha256 (SHA-256 hex of the config.json bytes) and
commands, the list of commands that produced the outputs, each with argv, returncode and stdout.

The tool ships extension family table E (ext_families_builtin.tsv, same columns as table A without pending).

Known problems reported by operators: wrong sizes on several exports, owners missing, crashes on most file types,
configuration layers applied in the wrong way, and manifests that do not reconcile with the ledger.
