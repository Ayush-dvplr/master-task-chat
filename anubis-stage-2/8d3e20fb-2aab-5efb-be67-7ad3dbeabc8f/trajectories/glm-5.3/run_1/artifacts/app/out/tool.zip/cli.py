#!/usr/bin/env python3
"""sealb-ctl: offline, standard-library-only security policy compiler.

Everything this tool emits is derived from the files under a data directory
(defaults, schema, overrides, validation rules, change journal and the fifty
evidence corpora).  No network, no wall clock, no randomness.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

TOOL = "sealb-ctl"
BASE_ENV = "base"
EPOCH = (1980, 1, 1, 0, 0, 0)
EXTERNAL_ATTR = 0o100644 << 16

SPINE_INT_KEYS = ("max_sessions", "retry_budget", "handshake_timeout_ms", "rekey_interval_s")

ARTIFACTS = [
    "config.json", "report.json", "tool.zip", "aggregates.json", "aggregates.csv",
    "aggregates.tsv", "aggregates.xml", "aggregates.ini", "aggregates.env",
    "aggregates.md", "aggregates.txt", "validation_report.json", "summary.json",
    "profile_core.json", "profile_edge.json", "profile_dmz.json", "profile_mgmt.json",
    "rejected_ops.json", "zone_totals.json", "corpus_index.json", "posture.json",
    "manifest.sha256",
]
MANIFEST_SKIP = ("report.json", "tool.zip", "manifest.sha256")

DELIMITERS = {"psv": "|", "scsv": ";", "colon": ":", "caret": "^", "at": "@",
              "bang": "!", "tilde": "~"}
FORMAT_EXT = {"csv": "csv", "tsv": "tsv", "psv": "psv", "scsv": "scsv",
              "colon": "colon", "ssv": "ssv", "caret": "caret", "at": "at",
              "dcolon": "dcolon", "bang": "bang", "tilde": "tilde",
              "jsonarr": "json", "jsonl": "jsonl", "xmlflat": "xml",
              "xmlnest": "nxml", "ini": "ini", "fixed": "fixed",
              "mdtable": "md", "kvline": "kv", "props": "properties"}


# ---------------------------------------------------------------- serialization

def dump_json(obj):
    return json.dumps(obj, sort_keys=True, indent=2, separators=(",", ": "),
                      ensure_ascii=False) + "\n"


def write_json_file(path, obj):
    Path(path).write_bytes(dump_json(obj).encode("utf-8"))


def write_text_file(path, text):
    Path(path).write_bytes(text.encode("utf-8"))


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ------------------------------------------------------------- canonical values

def canonical_int(field):
    """Return the int when ``field`` is a canonical base-10 integer, else None.

    A JSON integer is canonical by definition.  A JSON string, float or bool is
    judged on its exact text and accepted only when ``str(int(text)) == text``
    holds byte for byte: this rejects leading zeros, a leading ``+``, a leading
    sign on zero (``-0``, ``-00``, ``-000``), surrounding spaces, underscores,
    hex, floats, units, words, scientific notation and every non-ASCII decimal
    digit.
    """
    if isinstance(field, bool):
        return None
    if isinstance(field, int):
        return field
    if isinstance(field, float):
        return None
    if not isinstance(field, str):
        return None
    text = field
    if not text:
        return None
    negative = text[0] == "-"
    if negative:
        text = text[1:]
        if not text:
            return None
    for char in text:
        if char < "0" or char > "9":
            return None
    if len(text) > 1 and text[0] == "0":
        return None
    if negative:
        if text == "0":
            return None
        return -int(text)
    return int(text)


# -------------------------------------------------------------- policy plumbing

def load_rules(data_dir):
    return read_json(Path(data_dir) / "validation_rules.json")


def load_defaults(data_dir):
    return read_json(Path(data_dir) / "defaults.json")


def load_sidecar_schema(data_dir):
    return read_json(Path(data_dir) / "config_schema.json")


def load_overrides(data_dir):
    return read_json(Path(data_dir) / "env_overrides.json")


def load_journal(data_dir):
    ops = []
    path = Path(data_dir) / "change_journal.jsonl"
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            ops.append(json.loads(line))
    ops.sort(key=lambda op: op["seq"])
    return ops


def op_is_valid(op, rules):
    if op.get("env") not in rules["journal_envs"]:
        return False
    key = op.get("key")
    if key not in SPINE_INT_KEYS and key != "mode":
        return False
    if op.get("op") == "set":
        value = op.get("value")
        if key == "mode":
            return isinstance(value, str) and value in rules["allowed_modes"]
        low, high = rules["bounds"][key]
        return (isinstance(value, int) and not isinstance(value, bool)
                and low <= value <= high)
    return op.get("op") == "unset"


def classify_journal(data_dir):
    """Return (valid ops in ascending seq order, rejected seqs ascending)."""
    rules = load_rules(data_dir)
    valid, rejected = [], []
    for op in load_journal(data_dir):
        (valid if op_is_valid(op, rules) else rejected).append(op)
    return valid, sorted(op["seq"] for op in rejected)


def default_for(key, defaults):
    if key == "mode":
        return defaults["mode"]
    return defaults["base_config"][key]


def replay(ops, defaults, start=None):
    state = dict(start) if start is not None else {}
    for key in SPINE_INT_KEYS + ("mode",):
        state.setdefault(key, default_for(key, defaults))
    for op in ops:
        key = op["key"]
        if op["op"] == "set":
            state[key] = op["value"]
        else:
            state[key] = default_for(key, defaults)
    return state


def resolve_spine(data_dir):
    defaults = load_defaults(data_dir)
    schema = load_sidecar_schema(data_dir)
    valid, _ = classify_journal(data_dir)
    state = replay(valid, defaults)
    return {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "max_sessions": state["max_sessions"],
        "retry_budget": state["retry_budget"],
        "handshake_timeout_ms": state["handshake_timeout_ms"],
        "rekey_interval_s": state["rekey_interval_s"],
        "checksum": defaults["checksum"],
        "mode": state["mode"],
        "trailer": defaults["base_config"]["trailer"],
    }


def resolve_zone_profile(data_dir, zone, spine=None):
    if spine is None:
        spine = resolve_spine(data_dir)
    defaults = load_defaults(data_dir)
    overrides = load_overrides(data_dir)[zone]
    valid, _ = classify_journal(data_dir)
    state = {
        "max_sessions": spine["max_sessions"],
        "retry_budget": spine["retry_budget"] + overrides["retry_budget_delta"],
        "handshake_timeout_ms": spine["handshake_timeout_ms"]
        + overrides["handshake_timeout_ms_delta"],
        "rekey_interval_s": spine["rekey_interval_s"]
        + overrides["rekey_interval_s_delta"],
        "mode": overrides["mode"],
    }
    zone_ops = [op for op in valid if op["env"] == zone]
    state = replay(zone_ops, defaults, start=state)
    return {
        "profile": spine["profile"] + "-" + zone,
        "producer": spine["producer"],
        "container": spine["container"],
        "max_sessions": state["max_sessions"],
        "retry_budget": state["retry_budget"],
        "handshake_timeout_ms": state["handshake_timeout_ms"],
        "rekey_interval_s": state["rekey_interval_s"],
        "checksum": spine["checksum"],
        "mode": state["mode"],
        "trailer": spine["trailer"] + ":" + zone,
    }


def zone_names(data_dir):
    return list(load_rules(data_dir)["profiles"])


def active_zones(data_dir):
    return list(load_rules(data_dir)["zones"])


# ------------------------------------------------------- evidence corpus reading

def parse_contract_corpora(data_dir):
    """Parse the corpus table out of the written contract."""
    text = (Path(data_dir) / "config_contract.md").read_text(encoding="utf-8")
    corpora, header = [], None
    for line in text.split("\n"):
        if not line.startswith("|"):
            if header is not None:
                break
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if header is None:
            if cells == ["corpus", "format", "operator", "lo", "hi"]:
                header = cells
            continue
        if set(cells[0]) <= {"-", ":"}:
            continue
        corpora.append({
            "file": cells[0],
            "name": cells[0].rsplit(".", 1)[0],
            "format": cells[1],
            "op": cells[2],
            "lo": int(cells[3]),
            "hi": int(cells[4]),
        })
    if header is None or not corpora:
        raise SystemExit("corpus table not found in contract")
    return corpora


def iter_lines(path):
    with Path(path).open(encoding="utf-8") as handle:
        for raw in handle:
            yield raw[:-1] if raw.endswith("\n") else raw


def read_corpus_rows(path, fmt):
    """Yield (zone, value, flag) triples exactly as the file spells them."""
    if fmt in DELIMITERS or fmt in ("csv", "tsv", "ssv", "dcolon"):
        sep = {"csv": ",", "tsv": "\t", "dcolon": "::", "ssv": None}.get(fmt) or DELIMITERS.get(fmt)
        for line in iter_lines(path):
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            parts = line.split(sep) if sep else line.split()
            if len(parts) != 3:
                continue
            if fmt in ("csv", "tsv", "ssv") and parts[0] == "zone":
                continue
            yield (parts[0], parts[1], parts[2])
    elif fmt == "jsonarr":
        for obj in json.loads(Path(path).read_text(encoding="utf-8")):
            yield (obj.get("zone"), obj.get("value"), obj.get("flag"))
    elif fmt == "jsonl":
        for line in iter_lines(path):
            if not line.strip() or line.lstrip().startswith("//"):
                continue
            obj = json.loads(line)
            yield (obj.get("zone"), obj.get("value"), obj.get("flag"))
    elif fmt == "xmlflat":
        for row in ET.parse(path).getroot().findall("row"):
            yield (row.get("zone"), row.get("value"), row.get("flag"))
    elif fmt == "xmlnest":
        for row in ET.parse(path).getroot().findall("row"):
            def text(tag):
                el = row.find(tag)
                return el.text if (el is not None and el.text is not None) else ""
            yield (text("zone"), text("value"), text("flag"))
    elif fmt == "ini":
        buf = None
        for line in iter_lines(path):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if stripped.startswith("[") and stripped.endswith("]"):
                if buf is not None:
                    yield (buf["zone"], buf["value"], buf["flag"])
                buf = {}
                continue
            if "=" in stripped and buf is not None:
                key, value = stripped.split("=", 1)
                buf[key.strip()] = value.strip()
        if buf is not None:
            yield (buf["zone"], buf["value"], buf["flag"])
    elif fmt == "fixed":
        for line in iter_lines(path):
            if not line.strip() or line.lstrip().startswith("#") or line.startswith("zone "):
                continue
            yield (line[0:10].strip(), line[10:30].strip(), line[30:].strip())
    elif fmt == "mdtable":
        for line in iter_lines(path):
            if not line.strip():
                continue
            match = re.match(r"^\|([^|]*)\|([^|]*)\|([^|]*)\|$", line)
            if not match:
                continue
            cells = [match.group(1).strip(), match.group(2).strip(), match.group(3).strip()]
            if cells[0] == "zone" or set(cells[0]) <= {"-"}:
                continue
            yield (cells[0], cells[1], cells[2])
    elif fmt == "kvline":
        for line in iter_lines(path):
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            tokens = line.split()
            if len(tokens) != 3:
                continue
            fields, ok = {}, True
            for token in tokens:
                if "=" not in token:
                    ok = False
                    break
                key, value = token.split("=", 1)
                fields[key] = value
            if not ok or len(fields) != 3:
                continue
            yield (fields.get("zone", ""), fields.get("value", ""), fields.get("flag", ""))
    elif fmt == "props":
        records, order = {}, []
        for line in iter_lines(path):
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            key, value = line.split("=", 1)
            rid, _, field = key.partition(".")
            if rid not in records:
                records[rid] = {}
                order.append(rid)
            records[rid][field] = value
        for rid in order:
            record = records[rid]
            if "zone" in record and "value" in record and "flag" in record:
                yield (record["zone"], record["value"], record["flag"])
    else:
        raise SystemExit("unknown corpus format: " + fmt)


def aggregate_corpora(data_dir, rekey_interval_s, rejected_count, active_zones):
    """Reduce the corpora to (per-corpus results, per-zone counted totals)."""
    rules = load_rules(data_dir)
    bounds = rules["corpus_bounds"]
    specs = parse_contract_corpora(data_dir)
    base_shift = (rekey_interval_s % 97) + (rejected_count % 31)
    results = []
    zone_totals = {zone: 0 for zone in active_zones}
    for spec in sorted(specs, key=lambda item: item["name"]):
        name = spec["name"]
        if [spec["lo"], spec["hi"]] != bounds[name]:
            raise SystemExit("contract bounds disagree with validation_rules for " + name)
        path = Path(data_dir) / (name + "." + FORMAT_EXT[spec["format"]])
        candidates = []
        for zone, field, flag in read_corpus_rows(path, spec["format"]):
            if zone not in active_zones or flag != "active":
                continue
            value = canonical_int(field)
            if value is None:
                continue
            candidates.append((zone, value))
        eligible, shift, counted = 0, base_shift, []
        for _ in range(len(candidates) + 8):
            high = spec["hi"] + shift
            counted = [(zone, value) for zone, value in candidates
                       if spec["lo"] <= value <= high]
            if len(counted) == eligible:
                break
            eligible = len(counted)
            shift = base_shift + (eligible % 7)
        else:
            raise SystemExit("no stable fixpoint for " + name)
        values = [value for _, value in counted]
        if not values:
            result = 0
        elif spec["op"] == "max":
            result = max(values)
        elif spec["op"] == "min":
            result = min(values)
        elif spec["op"] == "sum":
            result = sum(values)
        elif spec["op"] == "count":
            result = len(values)
        elif spec["op"] == "first":
            result = values[0]
        elif spec["op"] == "last":
            result = values[-1]
        else:
            raise SystemExit("unknown operator: " + spec["op"])
        for zone, _ in counted:
            zone_totals[zone] += 1
        results.append({
            "name": name,
            "format": spec["format"],
            "op": spec["op"],
            "lo": spec["lo"],
            "hi": spec["hi"],
            "eligible_rows": len(counted),
            "value": result,
        })
    return results, zone_totals


# --------------------------------------------------------------- artifact writers

def write_aggregate_mirrors(out_dir, aggregates):
    names = sorted(aggregates)
    lines = ["corpus,value"]
    lines += ["%s,%d" % (name, aggregates[name]) for name in names]
    write_text_file(Path(out_dir) / "aggregates.csv", "\n".join(lines) + "\n")

    lines = ["corpus\tvalue"]
    lines += ["%s\t%d" % (name, aggregates[name]) for name in names]
    write_text_file(Path(out_dir) / "aggregates.tsv", "\n".join(lines) + "\n")

    lines = ["[aggregates]"]
    lines += ["%s = %d" % (name, aggregates[name]) for name in names]
    write_text_file(Path(out_dir) / "aggregates.ini", "\n".join(lines) + "\n")

    lines = ["%s=%d" % (name.upper(), aggregates[name]) for name in names]
    write_text_file(Path(out_dir) / "aggregates.env", "\n".join(lines) + "\n")

    lines = ["| corpus | value |", "| --- | --- |"]
    lines += ["| %s | %d |" % (name, aggregates[name]) for name in names]
    write_text_file(Path(out_dir) / "aggregates.md", "\n".join(lines) + "\n")

    lines = ["%s %d" % (name, aggregates[name]) for name in names]
    write_text_file(Path(out_dir) / "aggregates.txt", "\n".join(lines) + "\n")

    root = ET.Element("aggregates")
    for name in names:
        ET.SubElement(root, "corpus", {"name": name, "value": str(aggregates[name])})
    write_text_file(Path(out_dir) / "aggregates.xml",
                    ET.tostring(root, encoding="unicode") + "\n")


def tool_member_names(data_dir):
    with zipfile.ZipFile(Path(data_dir) / "tool.zip") as archive:
        return archive.namelist()


def write_tool_zip(out_dir, tool_dir, member_names):
    target = Path(out_dir) / "tool.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_STORED) as archive:
        for name in sorted(member_names):
            info = zipfile.ZipInfo(name, date_time=EPOCH)
            info.compress_type = zipfile.ZIP_STORED
            info.external_attr = EXTERNAL_ATTR
            info.create_system = 3
            archive.writestr(info, (Path(tool_dir) / name).read_bytes())
    return target


def scalar_flat(config):
    return all(not isinstance(value, (dict, list)) for value in config.values())


def write_summary(out_dir, data_dir, spine, corpus_count, aggregate_total):
    artifacts = list(ARTIFACTS)
    inputs = sorted(item.name for item in Path(data_dir).iterdir() if item.is_file())
    summary = {
        "tool": TOOL,
        "profile_tag": spine["profile"],
        "trailer": spine["trailer"],
        "profiles": zone_names(data_dir),
        "artifacts": artifacts,
        "artifact_count": len(artifacts),
        "inputs": inputs,
        "input_count": len(inputs),
        "corpus_count": corpus_count,
        "aggregate_total": aggregate_total,
    }
    write_json_file(Path(out_dir) / "summary.json", summary)
    return summary


def write_validation_report(out_dir, data_dir, commands, pending):
    """Write validation_report.json.

    ``pending`` names the artifacts the caller still writes after this report
    (the report itself and the manifest) so that the presence check covers the
    whole delivered set.
    """
    spine = resolve_spine(data_dir)
    config = read_json(Path(out_dir) / "config.json")
    rejected_seqs = read_json(Path(out_dir) / "rejected_ops.json")["rejected"]
    aggregates = read_json(Path(out_dir) / "aggregates.json")
    present = {item.name for item in Path(out_dir).iterdir() if item.is_file()}
    present.update(pending)
    profiles = {}
    for zone in zone_names(data_dir):
        doc = read_json(Path(out_dir) / ("profile_%s.json" % zone))
        profiles[zone] = {"scalar_flat": scalar_flat(doc), "trailer": doc["trailer"]}
    forbidden = set(load_rules(data_dir)["forbidden_keys"])
    checks = {
        "all_artifacts_present": set(ARTIFACTS) <= present,
        "config_matches_policy": (config == spine and not (forbidden & set(config))),
        "config_scalar_flat": scalar_flat(config),
        "command_failures": [entry for entry in commands if entry["returncode"] != 0],
        "rejected_ops": list(rejected_seqs),
        "profiles": profiles,
        "corpus_count": len(aggregates),
        "aggregate_total": sum(aggregates.values()),
    }
    ok = (checks["all_artifacts_present"] and checks["config_matches_policy"]
          and checks["config_scalar_flat"] and not checks["command_failures"]
          and all(item["scalar_flat"] for item in profiles.values()))
    report = {"ok": ok, "checks": checks}
    write_json_file(Path(out_dir) / "validation_report.json", report)
    return report


def write_manifest(out_dir):
    names = sorted(name for name in ARTIFACTS if name not in MANIFEST_SKIP)
    lines = ["%s  %s" % (sha256_file(Path(out_dir) / name), name) for name in names]
    write_text_file(Path(out_dir) / "manifest.sha256", "\n".join(lines) + "\n")
    return names


# ------------------------------------------------------------------------- CLI

def cmd_init(args):
    schema = read_json(args.schema)
    config = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    write_json_file(args.out, config)


def cmd_set(args):
    config = read_json(args.config)
    value = canonical_int(args.value)
    if value is None:
        value = args.value
    config[args.key] = value
    write_json_file(args.config, config)


def cmd_validate(args):
    schema = read_json(args.schema)
    required = [item.strip() for item in schema["required_keys"].split(",")]
    config = read_json(args.config)
    missing = [key for key in required if key not in config]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if not scalar_flat(config):
        raise SystemExit("configuration must be flat")
    extra = [key for key in config if key not in required]
    if extra:
        raise SystemExit("unexpected keys: " + ",".join(sorted(extra)))
    print("ok")


def cmd_plan(args):
    zones = zone_names(args.data)
    if args.env == BASE_ENV:
        doc = resolve_spine(args.data)
    elif args.env in zones:
        doc = resolve_zone_profile(args.data, args.env)
    else:
        raise SystemExit("unknown environment: " + args.env)
    sys.stdout.write(dump_json(doc))


def cmd_compile(args):
    data_dir, out_dir = Path(args.data), Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    spine = resolve_spine(data_dir)
    config = read_json(out_dir / "config.json")
    if config != spine:
        raise SystemExit("config.json does not match the derived policy")
    zones = zone_names(data_dir)
    row_zones = active_zones(data_dir)
    rejected_seqs = classify_journal(data_dir)[1]

    write_json_file(out_dir / "rejected_ops.json",
                    {"rejected": rejected_seqs, "count": len(rejected_seqs)})

    for zone in zones:
        write_json_file(out_dir / ("profile_%s.json" % zone),
                        resolve_zone_profile(data_dir, zone, spine=spine))

    results, zone_totals = aggregate_corpora(data_dir, config["rekey_interval_s"],
                                             len(rejected_seqs), row_zones)
    aggregates = {item["name"]: item["value"] for item in results}
    write_json_file(out_dir / "aggregates.json", aggregates)
    write_aggregate_mirrors(out_dir, aggregates)
    write_json_file(out_dir / "zone_totals.json",
                    {zone: zone_totals[zone] for zone in row_zones})
    write_json_file(out_dir / "corpus_index.json",
                    {"count": len(results), "corpora": results})
    best = sorted(aggregates.items(), key=lambda item: (-item[1], item[0]))[0]
    write_json_file(out_dir / "posture.json", {
        "aggregate_total": sum(aggregates.values()),
        "corpus_count": len(aggregates),
        "max_corpus": best[0],
        "max_value": best[1],
        "nonzero_corpora": [name for name in sorted(aggregates)
                            if aggregates[name] != 0],
    })
    write_summary(out_dir, data_dir, spine, len(aggregates),
                  sum(aggregates.values()))
    write_tool_zip(out_dir, Path(__file__).resolve().parent,
                   tool_member_names(data_dir))


def cmd_export_report(args):
    config_path = Path(args.config)
    digest = hashlib.sha256(config_path.read_bytes()).hexdigest()
    if args.digest and args.digest != digest:
        raise SystemExit("config digest mismatch")
    config = read_json(config_path)
    commands = []
    if args.commands:
        commands = read_json(args.commands)
        if not isinstance(commands, list):
            raise SystemExit("commands must be a JSON list")
    commands = commands + [{
        "argv": [sys.executable] + list(sys.argv),
        "returncode": 0,
        "stdout": "",
    }]
    report = {
        "ok": True,
        "tool": TOOL,
        "config_path": str(config_path),
        "config_sha256": digest,
        "trailer": config["trailer"],
        "commands": commands,
    }
    write_json_file(args.out, report)


def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL)
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("plan")
    p.add_argument("--data", required=True)
    p.add_argument("--env", required=True)
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("compile")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", default="")
    p.add_argument("--commands", default="")
    p.set_defaults(func=cmd_export_report)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    if not getattr(args, "func", None):
        raise SystemExit("a subcommand is required")
    args.func(args)


if __name__ == "__main__":
    main()

