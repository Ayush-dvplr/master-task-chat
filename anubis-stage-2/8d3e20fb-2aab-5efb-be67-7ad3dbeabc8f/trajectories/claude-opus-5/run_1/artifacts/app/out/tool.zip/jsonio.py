"""Canonical JSON serialization shared by every sealb-ctl artifact."""
from __future__ import annotations

import json
from pathlib import Path

DUMP_KWARGS = {
    "sort_keys": True,
    "indent": 2,
    "separators": (",", ": "),
    "ensure_ascii": False,
}


def dumps(obj) -> str:
    return json.dumps(obj, **DUMP_KWARGS) + "\n"


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, obj) -> None:
    write_text(path, dumps(obj))


def write_text(path, text: str) -> None:
    Path(path).write_text(text, encoding="utf-8", newline="\n")
