"""Delivered artifact writers: mirrors, manifest and the rebuilt tool archive."""
from __future__ import annotations

import hashlib
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import jsonio

ARTIFACTS = (
    "config.json",
    "report.json",
    "tool.zip",
    "aggregates.json",
    "aggregates.csv",
    "aggregates.tsv",
    "aggregates.xml",
    "aggregates.ini",
    "aggregates.env",
    "aggregates.md",
    "aggregates.txt",
    "validation_report.json",
    "summary.json",
    "profile_core.json",
    "profile_edge.json",
    "profile_dmz.json",
    "profile_mgmt.json",
    "rejected_ops.json",
    "zone_totals.json",
    "corpus_index.json",
    "posture.json",
    "manifest.sha256",
)

UNMANIFESTED = ("report.json", "tool.zip", "manifest.sha256")

ZIP_DATE_TIME = (1980, 1, 1, 0, 0, 0)
ZIP_EXTERNAL_ATTR = 0o100644 << 16


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_aggregate_mirrors(out_dir, aggregates):
    """The aggregates map rendered in every delivered text format."""
    out = Path(out_dir)
    names = sorted(aggregates)
    pairs = [(name, aggregates[name]) for name in names]

    jsonio.write(out / "aggregates.json", aggregates)
    jsonio.write_text(
        out / "aggregates.csv",
        "".join(["corpus,value\n"] + ["{},{}\n".format(n, v) for n, v in pairs]),
    )
    jsonio.write_text(
        out / "aggregates.tsv",
        "".join(["corpus\tvalue\n"] + ["{}\t{}\n".format(n, v) for n, v in pairs]),
    )
    jsonio.write_text(
        out / "aggregates.ini",
        "".join(["[aggregates]\n"] + ["{} = {}\n".format(n, v) for n, v in pairs]),
    )
    jsonio.write_text(
        out / "aggregates.env",
        "".join("{}={}\n".format(n.upper(), v) for n, v in pairs),
    )
    jsonio.write_text(
        out / "aggregates.md",
        "".join(
            ["| corpus | value |\n", "| --- | --- |\n"]
            + ["| {} | {} |\n".format(n, v) for n, v in pairs]
        ),
    )
    jsonio.write_text(
        out / "aggregates.txt",
        "".join("{} {}\n".format(n, v) for n, v in pairs),
    )
    root = ET.Element("aggregates")
    for name, value in pairs:
        ET.SubElement(root, "corpus", {"name": name, "value": str(value)})
    jsonio.write_text(out / "aggregates.xml", ET.tostring(root, encoding="unicode") + "\n")


def manifest_names():
    return sorted(name for name in ARTIFACTS if name not in UNMANIFESTED)


def write_manifest(out_dir):
    out = Path(out_dir)
    lines = ["{}  {}\n".format(sha256_file(out / name), name) for name in manifest_names()]
    jsonio.write_text(out / "manifest.sha256", "".join(lines))


def tool_members(tool_dir):
    tool = Path(tool_dir)
    members = []
    for path in tool.rglob("*"):
        if not path.is_file():
            continue
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        members.append(path.relative_to(tool).as_posix())
    return sorted(members)


def build_tool_zip(tool_dir, zip_path):
    """A byte-reproducible archive of the repaired tool."""
    tool = Path(tool_dir)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_STORED) as archive:
        for name in tool_members(tool):
            info = zipfile.ZipInfo(filename=name, date_time=ZIP_DATE_TIME)
            info.compress_type = zipfile.ZIP_STORED
            info.external_attr = ZIP_EXTERNAL_ATTR
            info.create_system = 3
            archive.writestr(info, (tool / name).read_bytes())
