#!/usr/bin/env python3
"""sealb-ctl: offline, stdlib-only security policy compiler."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import artifacts
import corpora
import jsonio
import policy

TOOL = "sealb-ctl"
TOOL_DIR = Path(__file__).resolve().parent
CONTRACT = "config_contract.md"
PENDING_ARTIFACTS = ("validation_report.json", "manifest.sha256", "report.json")


def load_json(path):
    return jsonio.load(path)


def write_json(path, data):
    jsonio.write(path, data)


def scalar(text):
    """A CLI value as the flat scalar it denotes: canonical integer or string."""
    number = corpora.canonical_int(text)
    return text if number is None else number


def required_keys(schema):
    keys = schema["required_keys"]
    if isinstance(keys, str):
        keys = keys.split(",")
    return list(keys)


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    write_json(args.out, data)


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = scalar(args.value)
    if not policy.is_scalar_flat(data):
        raise SystemExit("configuration must be flat")
    write_json(args.config, data)


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    missing = [key for key in required_keys(schema) if key not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if not policy.is_scalar_flat(data):
        raise SystemExit("configuration must be flat")
    print("ok")


def cmd_plan(args):
    inputs = policy.Inputs(args.data)
    sys.stdout.write(jsonio.dumps(policy.resolve(inputs, args.env)))


def cmd_compile(args):
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    data_dir = Path(args.data)
    config_path = Path(args.config) if args.config else out / "config.json"
    commands = json.loads(args.commands) if args.commands else []

    inputs = policy.Inputs(data_dir)
    zones = inputs.zones
    valid_ops, rejected = policy.classify(inputs)
    resolved = policy.spine(inputs, valid_ops)
    delivered = load_json(config_path)

    profiles = {zone: policy.profile(inputs, zone, resolved, valid_ops) for zone in zones}
    for zone, document in profiles.items():
        write_json(out / "profile_{}.json".format(zone), document)

    table = corpora.corpus_table(data_dir / CONTRACT, inputs.rules)
    results, zone_totals = corpora.reduce_corpora(
        data_dir, table, zones, delivered["rekey_interval_s"], len(rejected)
    )
    aggregates = {result["name"]: result["value"] for result in results}
    aggregate_total = sum(aggregates.values())
    artifacts.write_aggregate_mirrors(out, aggregates)

    write_json(out / "zone_totals.json", zone_totals)
    write_json(
        out / "corpus_index.json",
        {
            "count": len(results),
            "corpora": [
                {
                    "name": result["name"],
                    "format": result["format"],
                    "op": result["op"],
                    "lo": result["lo"],
                    "hi": result["hi"],
                    "eligible_rows": result["eligible_rows"],
                    "value": result["value"],
                }
                for result in results
            ],
        },
    )

    best = max(sorted(aggregates), key=lambda name: aggregates[name])
    write_json(
        out / "posture.json",
        {
            "aggregate_total": aggregate_total,
            "corpus_count": len(results),
            "max_corpus": best,
            "max_value": aggregates[best],
            "nonzero_corpora": sum(1 for value in aggregates.values() if value != 0),
        },
    )
    write_json(out / "rejected_ops.json", {"rejected": rejected, "count": len(rejected)})
    data_files = sorted(path.name for path in data_dir.iterdir() if path.is_file())
    write_json(
        out / "summary.json",
        {
            "tool": TOOL,
            "profile_tag": resolved["profile"],
            "trailer": resolved["trailer"],
            "profiles": list(inputs.rules["profiles"]),
            "artifacts": list(artifacts.ARTIFACTS),
            "artifact_count": len(artifacts.ARTIFACTS),
            "inputs": data_files,
            "input_count": len(data_files),
            "corpus_count": len(results),
            "aggregate_total": aggregate_total,
        },
    )
    artifacts.build_tool_zip(TOOL_DIR, out / "tool.zip")

    checks = {
        "all_artifacts_present": all(
            (out / name).exists()
            for name in artifacts.ARTIFACTS
            if name not in PENDING_ARTIFACTS
        ),
        "config_matches_policy": delivered == resolved,
        "config_scalar_flat": policy.is_scalar_flat(delivered)
        and not [key for key in required_keys(inputs.schema) if key not in delivered],
        "command_failures": [
            command["argv"] for command in commands if command["returncode"] != 0
        ],
        "rejected_ops": rejected,
        "profiles": {
            zone: {
                "scalar_flat": policy.is_scalar_flat(document),
                "trailer": document["trailer"],
            }
            for zone, document in profiles.items()
        },
        "corpus_count": len(results),
        "aggregate_total": aggregate_total,
    }
    checks_ok = bool(
        checks["all_artifacts_present"]
        and checks["config_matches_policy"]
        and checks["config_scalar_flat"]
        and not checks["command_failures"]
        and all(entry["scalar_flat"] for entry in checks["profiles"].values())
        and checks["corpus_count"] == len(table)
    )
    write_json(out / "validation_report.json", {"ok": checks_ok, "checks": checks})
    artifacts.write_manifest(out)
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    commands = json.loads(args.commands) if args.commands else []
    digest = artifacts.sha256_file(args.config)
    if args.digest != digest:
        raise SystemExit("config digest mismatch: " + digest)
    report = {
        "ok": all(command["returncode"] == 0 for command in commands),
        "tool": TOOL,
        "config_path": str(args.config),
        "config_sha256": digest,
        "trailer": data["trailer"],
        "commands": commands,
    }
    write_json(args.out, report)


def main():
    parser = argparse.ArgumentParser(prog=TOOL)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)
    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)
    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)
    p = sub.add_parser("plan")
    p.add_argument("--data", required=True)
    p.add_argument("--env", required=True)
    p.set_defaults(func=cmd_plan)
    p = sub.add_parser("compile")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--config")
    p.add_argument("--commands")
    p.set_defaults(func=cmd_compile)
    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands")
    p.set_defaults(func=cmd_report)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
