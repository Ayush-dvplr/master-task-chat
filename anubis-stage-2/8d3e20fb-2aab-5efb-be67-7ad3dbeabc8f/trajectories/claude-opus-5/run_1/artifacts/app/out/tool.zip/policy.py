"""Spine and zone-profile resolution from the /app/data inputs."""
from __future__ import annotations

import json
from pathlib import Path

import jsonio

INT_KEYS = ("max_sessions", "retry_budget", "handshake_timeout_ms", "rekey_interval_s")
MODE_KEY = "mode"
JOURNAL_KEYS = INT_KEYS + (MODE_KEY,)
DELTA_KEYS = ("retry_budget", "handshake_timeout_ms", "rekey_interval_s")
OPS = ("set", "unset")


class Inputs:
    def __init__(self, data_dir):
        self.dir = Path(data_dir)
        self.defaults = jsonio.load(self.dir / "defaults.json")
        self.schema = jsonio.load(self.dir / "config_schema.json")
        self.rules = jsonio.load(self.dir / "validation_rules.json")
        self.overrides = jsonio.load(self.dir / "env_overrides.json")
        self.journal = load_journal(self.dir / "change_journal.jsonl")

    @property
    def zones(self):
        return list(self.rules["zones"])


def load_journal(path):
    """Every recorded operation, ordered by ascending seq."""
    entries = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        entries.append(json.loads(line))
    entries.sort(key=lambda entry: entry["seq"])
    return entries


def reject_reason(entry, rules):
    """None when the operation is valid, otherwise the rule it breaks."""
    if entry.get("env") not in rules["journal_envs"]:
        return "env"
    if entry.get("op") not in OPS:
        return "op"
    key = entry.get("key")
    if key not in JOURNAL_KEYS:
        return "key"
    if entry["op"] == "unset":
        return None
    value = entry.get("value")
    if key == MODE_KEY:
        if isinstance(value, str) and value in rules["allowed_modes"]:
            return None
        return "mode"
    if isinstance(value, bool) or not isinstance(value, int):
        return "type"
    low, high = rules["bounds"][key]
    return None if low <= value <= high else "bounds"


def classify(inputs):
    """Split the seq-ordered journal into valid operations and rejected seqs."""
    valid, rejected = [], []
    for entry in inputs.journal:
        if reject_reason(entry, inputs.rules) is None:
            valid.append(entry)
        else:
            rejected.append(entry["seq"])
    rejected.sort()
    return valid, rejected


def default_value(defaults, key):
    if key == MODE_KEY:
        return defaults[MODE_KEY]
    return defaults["base_config"][key]


def apply_ops(config, ops, defaults, env=None):
    for entry in ops:
        if env is not None and entry["env"] != env:
            continue
        key = entry["key"]
        if entry["op"] == "set":
            config[key] = entry["value"]
        else:
            config[key] = default_value(defaults, key)


def base_config(inputs):
    defaults, schema = inputs.defaults, inputs.schema
    config = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": defaults["checksum"],
        "mode": defaults[MODE_KEY],
    }
    for key, value in defaults["base_config"].items():
        config[key] = value
    return config


def spine(inputs, valid_ops=None):
    if valid_ops is None:
        valid_ops, _ = classify(inputs)
    config = base_config(inputs)
    apply_ops(config, valid_ops, inputs.defaults)
    return config


def profile(inputs, zone, config=None, valid_ops=None):
    if valid_ops is None:
        valid_ops, _ = classify(inputs)
    if config is None:
        config = spine(inputs, valid_ops)
    override = inputs.overrides[zone]
    resolved = dict(config)
    for key in DELTA_KEYS:
        resolved[key] = config[key] + override[key + "_delta"]
    resolved[MODE_KEY] = override[MODE_KEY]
    resolved["profile"] = "{}-{}".format(config["profile"], zone)
    resolved["trailer"] = "{}:{}".format(config["trailer"], zone)
    apply_ops(resolved, valid_ops, inputs.defaults, env=zone)
    return resolved


def resolve(inputs, env, valid_ops=None):
    """The fully resolved policy document for one environment."""
    if env == "base":
        return spine(inputs, valid_ops)
    if env not in inputs.rules["zones"]:
        raise SystemExit("unknown env: " + str(env))
    return profile(inputs, env, valid_ops=valid_ops)


def is_scalar_flat(config):
    return all(not isinstance(value, (dict, list)) for value in config.values())
