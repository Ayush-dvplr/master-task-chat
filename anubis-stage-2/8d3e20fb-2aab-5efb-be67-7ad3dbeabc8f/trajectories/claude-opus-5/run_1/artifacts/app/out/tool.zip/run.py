#!/usr/bin/env python3
"""Drive the whole sealb-ctl pipeline: spine, profiles, corpora, artifacts."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import artifacts
import cli
import jsonio

TOOL_DIR = Path(__file__).resolve().parent
CLI = TOOL_DIR / "cli.py"
SCHEMA = TOOL_DIR / "schema.json"
DATA_DIR = Path("/app/data")
OUT_DIR = Path("/app/out")
PYTHON = "python3"


def run(transcript, *argv):
    command = [PYTHON, str(CLI), *argv]
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    sys.stderr.write(result.stderr)
    transcript.append(
        {"argv": command, "returncode": result.returncode, "stdout": result.stdout}
    )
    if result.returncode != 0:
        raise SystemExit("command failed: " + " ".join(command))
    return result.stdout


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    config = OUT_DIR / "config.json"
    transcript = []

    run(transcript, "init", "--schema", str(SCHEMA), "--out", str(config))
    planned = json.loads(run(transcript, "plan", "--data", str(DATA_DIR), "--env", "base"))
    seeded = jsonio.load(config)
    for key in cli.required_keys(jsonio.load(SCHEMA)):
        if key in seeded:
            continue
        run(
            transcript,
            "set",
            "--config", str(config),
            "--key", key,
            "--value", str(planned[key]),
        )
    run(transcript, "validate", "--schema", str(SCHEMA), "--config", str(config))

    before_compile = json.dumps(transcript)
    run(
        transcript,
        "compile",
        "--data", str(DATA_DIR),
        "--out", str(OUT_DIR),
        "--config", str(config),
        "--commands", before_compile,
    )
    run(
        transcript,
        "export-report",
        "--config", str(config),
        "--out", str(OUT_DIR / "report.json"),
        "--digest", artifacts.sha256_file(config),
        "--commands", json.dumps(transcript),
    )

    missing = [name for name in artifacts.ARTIFACTS if not (OUT_DIR / name).exists()]
    if missing:
        raise SystemExit("missing artifacts: " + ",".join(missing))
    print("delivered {} artifacts".format(len(artifacts.ARTIFACTS)))


if __name__ == "__main__":
    main()
