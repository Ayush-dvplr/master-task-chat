"""Evidence corpora: wire-format readers, byte-exact eligibility, aggregation."""
from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

ACTIVE_FLAG = "active"
HEADER = ("zone", "value", "flag")
FIELDS = ("zone", "value", "flag")

DELIMITERS = {
    "csv": ",",
    "tsv": "\t",
    "psv": "|",
    "scsv": ";",
    "colon": ":",
    "caret": "^",
    "at": "@",
    "bang": "!",
    "tilde": "~",
    "dcolon": "::",
}

CONTRACT_ROW = re.compile(
    r"^\|\s*(c\d{2}_\w+\.\w+)\s*\|\s*(\w+)\s*\|\s*(\w+)\s*\|\s*(-?\d+)\s*\|\s*(-?\d+)\s*\|$"
)


def corpus_table(contract_path, rules):
    """The fifty corpora as declared by the written contract table."""
    table = []
    for line in Path(contract_path).read_text(encoding="utf-8").splitlines():
        match = CONTRACT_ROW.match(line)
        if not match:
            continue
        name, fmt, op, low, high = match.groups()
        stem = name.rsplit(".", 1)[0]
        bounds = rules["corpus_bounds"][stem]
        if [int(low), int(high)] != list(bounds):
            raise SystemExit("contract/rules bound mismatch for " + name)
        table.append({"name": name, "format": fmt, "op": op, "lo": bounds[0], "hi": bounds[1]})
    table.sort(key=lambda entry: entry["name"])
    return table


def _lines(path):
    return Path(path).read_text(encoding="utf-8").split("\n")


def _is_skipped(line, comment="#"):
    stripped = line.lstrip()
    return not line.strip() or stripped.startswith(comment)


def _delimited(path, delimiter):
    rows = []
    for line in _lines(path):
        if _is_skipped(line):
            continue
        fields = line.split(delimiter)
        if len(fields) != 3:
            continue
        rows.append(tuple(fields))
    return rows


def _spaced(path):
    rows = []
    for line in _lines(path):
        if _is_skipped(line):
            continue
        fields = re.split(r" +", line)
        if len(fields) != 3:
            continue
        rows.append(tuple(fields))
    return rows


def _json_array(path):
    rows = []
    for record in json.loads(Path(path).read_text(encoding="utf-8")):
        if not all(field in record for field in FIELDS):
            continue
        rows.append(tuple(record[field] for field in FIELDS))
    return rows


def _json_lines(path):
    rows = []
    for line in _lines(path):
        if _is_skipped(line, comment="//"):
            continue
        record = json.loads(line)
        if not all(field in record for field in FIELDS):
            continue
        rows.append(tuple(record[field] for field in FIELDS))
    return rows


def _xml_flat(path):
    rows = []
    for element in ET.parse(path).getroot():
        if not all(field in element.attrib for field in FIELDS):
            continue
        rows.append(tuple(element.attrib[field] for field in FIELDS))
    return rows


def _xml_nested(path):
    rows = []
    for element in ET.parse(path).getroot():
        cells = {child.tag: (child.text or "") for child in element}
        if not all(field in cells for field in FIELDS):
            continue
        rows.append(tuple(cells[field] for field in FIELDS))
    return rows


def _unpad(value):
    """Drop the single separator space an aligned text format inserts."""
    return value[1:] if value.startswith(" ") else value


def _ini(path):
    rows, current = [], None
    for line in _lines(path):
        if _is_skipped(line):
            continue
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            current = {}
            rows.append(current)
            continue
        key, sep, value = line.partition("=")
        if not sep or current is None:
            continue
        current[key.strip()] = _unpad(value)
    return [
        tuple(row[field] for field in FIELDS)
        for row in rows
        if all(field in row for field in FIELDS)
    ]


def _fixed(path):
    rows = []
    for line in _lines(path):
        if _is_skipped(line):
            continue
        fields = (line[0:10].rstrip(" "), line[10:30].rstrip(" "), line[30:])
        if fields == HEADER:
            continue
        rows.append(fields)
    return rows


def _md_table(path):
    rows = []
    for line in _lines(path):
        if _is_skipped(line):
            continue
        if not (line.startswith("|") and line.endswith("|")):
            continue
        cells = line.split("|")[1:-1]
        if len(cells) != 3:
            continue
        fields = tuple(_unpad(cell[:-1] if cell.endswith(" ") else cell) for cell in cells)
        if fields == HEADER or all(set(cell.strip()) == {"-"} for cell in cells):
            continue
        rows.append(fields)
    return rows


def _kv_line(path):
    rows = []
    for line in _lines(path):
        if _is_skipped(line):
            continue
        cells = {}
        for token in line.split(" "):
            key, sep, value = token.partition("=")
            if sep:
                cells[key] = value
        if not all(field in cells for field in FIELDS):
            continue
        rows.append(tuple(cells[field] for field in FIELDS))
    return rows


def _properties(path):
    order, rows = [], {}
    for line in _lines(path):
        if _is_skipped(line):
            continue
        key, sep, value = line.partition("=")
        if not sep:
            continue
        row_id, _, field = key.partition(".")
        if field not in FIELDS:
            continue
        if row_id not in rows:
            rows[row_id] = {}
            order.append(row_id)
        rows[row_id][field] = value
    return [
        tuple(rows[row_id][field] for field in FIELDS)
        for row_id in order
        if all(field in rows[row_id] for field in FIELDS)
    ]


READERS = {
    "ssv": _spaced,
    "jsonarr": _json_array,
    "jsonl": _json_lines,
    "xmlflat": _xml_flat,
    "xmlnest": _xml_nested,
    "ini": _ini,
    "fixed": _fixed,
    "mdtable": _md_table,
    "kvline": _kv_line,
    "props": _properties,
}


def read_rows(path, fmt):
    if fmt in DELIMITERS:
        rows = _delimited(path, DELIMITERS[fmt])
    elif fmt in READERS:
        rows = READERS[fmt](path)
    else:
        raise SystemExit("unknown corpus format: " + fmt)
    return [row for row in rows if row != HEADER]


def canonical_int(value):
    """The integer of a canonical base-10 field, or None when not canonical."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if not isinstance(value, str):
        return None
    try:
        number = int(value)
    except ValueError:
        return None
    return number if str(number) == value else None


def counted_rows(rows, zones, low, high):
    counted = []
    for zone, value, flag in rows:
        if zone not in zones or flag != ACTIVE_FLAG:
            continue
        number = canonical_int(value)
        if number is None or number < low or number > high:
            continue
        counted.append((zone, number))
    return counted


def solve_bound(rows, zones, low, high, shift):
    """hi_eff = hi + shift + (E mod 7) with E the eligible count under hi_eff."""
    eligible = 0
    for _ in range(64):
        bound = high + shift + eligible % 7
        counted = counted_rows(rows, zones, low, bound)
        if len(counted) == eligible:
            return bound, counted
        eligible = len(counted)
    raise SystemExit("eligibility fixpoint did not converge")


def aggregate(op, values):
    if not values:
        return 0
    if op == "max":
        return max(values)
    if op == "min":
        return min(values)
    if op == "sum":
        return sum(values)
    if op == "count":
        return len(values)
    if op == "first":
        return values[0]
    if op == "last":
        return values[-1]
    raise SystemExit("unknown aggregation operator: " + op)


def reduce_corpora(data_dir, table, zones, rekey_interval_s, rejected_count):
    """Aggregate every corpus and tally the counted rows per zone."""
    shift = rekey_interval_s % 97 + rejected_count % 31
    results, totals = [], {zone: 0 for zone in zones}
    for entry in table:
        rows = read_rows(Path(data_dir) / entry["name"], entry["format"])
        bound, counted = solve_bound(rows, zones, entry["lo"], entry["hi"], shift)
        values = [number for _, number in counted]
        for zone, _ in counted:
            totals[zone] += 1
        result = dict(entry)
        result["hi_eff"] = bound
        result["eligible_rows"] = len(counted)
        result["value"] = aggregate(entry["op"], values)
        results.append(result)
    return results, totals
