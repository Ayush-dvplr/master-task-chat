"""Format readers.

Every reader returns a Doc: the parsed control block and the data tables of
one feed file. Rows are lists of raw cell values; the caller maps them through
the table's column names.
"""
from __future__ import annotations

import csv
import io
import json
import mailbox
import re
import sqlite3
import tomllib
import zipfile
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree as ET

import yaml

from .conventions import COLUMN_ALIASES, parse_control

NS_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
NS_S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


@dataclass
class Table:
    name: str
    columns: list
    rows: list = field(default_factory=list)


@dataclass
class Doc:
    control: dict
    tables: list
    extra: dict = field(default_factory=dict)

    @property
    def records(self) -> int:
        if "records" in self.extra:
            return self.extra["records"]
        return sum(len(t.rows) for t in self.tables)

    def table(self, name: str) -> Table:
        for t in self.tables:
            if t.name == name:
                return t
        raise KeyError(name)


def decode_lines(raw: bytes) -> str:
    """UTF-8 per line, cp1252 for a line that is not valid UTF-8 (3.6)."""
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    out = []
    for line in raw.split(b"\n"):
        try:
            out.append(line.decode("utf-8"))
        except UnicodeDecodeError:
            out.append(line.decode("cp1252"))
    return "\n".join(out)


def _control_line(line: str, prefix: str) -> dict:
    if not line.startswith(prefix):
        raise ValueError(f"control block missing (expected {prefix!r})")
    return parse_control(line[len(prefix):])


# ------------------------------------------------------------------ delimited
def read_delimited(raw: bytes, delim: str) -> Doc:
    text = decode_lines(raw)
    first, _, rest = text.partition("\n")
    control = _control_line(first, "#control ")
    reader = csv.reader(io.StringIO(rest), delimiter=delim)
    header = None
    cur = None
    rows = []
    for cells in reader:
        if not cells:
            continue
        if header is None:
            header = [c.strip() for c in cells]
            cur = header
            continue
        if cells[0].strip() == "#header":
            cur = [c.strip() for c in cells[1:]]
            continue
        while len(cells) > len(cur) and cells[-1] == "":
            cells = cells[:-1]
        r = dict(zip(cur, cells))
        rows.append([r.get(c, "") for c in header])
    t = Table("rows", header, rows)
    return Doc(control, [t])


# ------------------------------------------------------------------ fixed width
def read_fixed(raw: bytes) -> Doc:
    text = decode_lines(raw)
    lines = text.split("\n")
    control = _control_line(lines[0], "#control ")
    head = lines[1]
    starts = [m.start() for m in re.finditer(r"\S+", head)]
    names = head.split()
    rows = []
    for ln in lines[2:]:
        if not ln.strip():
            continue
        cells = []
        for i, s in enumerate(starts):
            e = starts[i + 1] if i + 1 < len(starts) else None
            cells.append(ln[s:e].strip())
        rows.append(cells)
    return Doc(control, [Table("rows", names, rows)])


# ------------------------------------------------------------------ log
_KV = re.compile(r'(\w+)=("([^"]*)"|\S*)')
_TS = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+")


def read_log(raw: bytes) -> Doc:
    text = decode_lines(raw)
    lines = text.split("\n")
    control = _control_line(lines[0], "#control ")
    rows = []
    cols = None
    for ln in lines[1:]:
        if ln.startswith("INFO "):
            ts, body = None, ln[5:]
        elif " INFO " in ln:
            ts, body = ln.split(" INFO ", 1)
            ts = ts.strip().lstrip("[").rstrip("]")
        else:
            continue
        rec = {}
        if ts is not None:
            rec["started"] = ts
        for k, full, quoted in _KV.findall(body):
            rec[k] = quoted if full.startswith('"') else full
        if cols is None:
            cols = list(rec)
        rows.append(rec)
    cols = cols or []
    return Doc(control, [Table("rows", cols, [[r.get(c, "") for c in cols] for r in rows])])


# ------------------------------------------------------------------ json family
def _dict_table(name, items) -> Table:
    items = [{COLUMN_ALIASES.get(k, k): v for k, v in it.items()} for it in items]
    cols = []
    for it in items:
        for k in it:
            if k not in cols:
                cols.append(k)
    return Table(name, cols, [[it.get(c, "") for c in cols] for it in items])


def read_jsonl(raw: bytes) -> Doc:
    text = raw.decode("utf-8-sig")
    lines = [ln for ln in text.split("\n") if ln.strip()]
    first = json.loads(lines[0])
    control = first["_control"]
    items = [json.loads(ln) for ln in lines[1:]]
    return Doc(control, [_dict_table("rows", items)])


def read_json(raw: bytes) -> Doc:
    obj = json.loads(raw.decode("utf-8-sig"))
    control = obj.get("control", {})
    tables = [_dict_table(k, v) for k, v in obj.items() if isinstance(v, list) and k != "control"]
    return Doc(control, tables, {"object": obj})


def read_yaml(raw: bytes) -> Doc:
    obj = yaml.safe_load(raw.decode("utf-8"))
    tables = [_dict_table(k, v) for k, v in obj.items() if isinstance(v, list)]
    return Doc(obj.get("control", {}), tables)


def read_toml(raw: bytes) -> Doc:
    obj = tomllib.loads(raw.decode("utf-8"))
    tables = [_dict_table(k, v) for k, v in obj.items() if isinstance(v, list)]
    return Doc(obj.get("control", {}), tables)


def read_ini(raw: bytes) -> Doc:
    import configparser
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read_string(raw.decode("utf-8"))
    control = dict(cp["control"]) if cp.has_section("control") else {}
    groups: dict[str, list] = {}
    for sec in cp.sections():
        if sec == "control":
            continue
        kind, _, name = sec.partition(" ")
        item = {"name": name}
        item.update(dict(cp[sec]))
        groups.setdefault(kind, []).append(item)
    return Doc(control, [_dict_table(k, v) for k, v in groups.items()])


def read_xml(raw: bytes) -> Doc:
    root = ET.fromstring(raw)
    ctl = root.find("control")
    control = dict(ctl.attrib) if ctl is not None else {}
    tables = []
    for tb in root.findall("table"):
        tables.append(_dict_table(tb.get("name"), [dict(r.attrib) for r in tb.findall("row")]))
    return Doc(control, tables)


# ------------------------------------------------------------------ xlsx
def _col_index(ref: str) -> int:
    n = 0
    for ch in ref:
        if ch.isalpha():
            n = n * 26 + (ord(ch.upper()) - 64)
        else:
            break
    return n - 1


def read_xlsx(raw: bytes) -> Doc:
    zf = zipfile.ZipFile(io.BytesIO(raw))
    wb = ET.fromstring(zf.read("xl/workbook.xml"))
    pr = wb.find(f"{NS_S}workbookPr")
    date1904 = pr is not None and pr.get("date1904") in ("1", "true")
    shared = []
    if "xl/sharedStrings.xml" in zf.namelist():
        for si in ET.fromstring(zf.read("xl/sharedStrings.xml")).findall(f"{NS_S}si"):
            shared.append("".join(t.text or "" for t in si.iter(f"{NS_S}t")))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    target = {r.get("Id"): r.get("Target") for r in rels}
    styles = ET.fromstring(zf.read("xl/styles.xml"))
    date_styles = set()
    fmts = {n.get("numFmtId"): n.get("formatCode") for n in styles.iter(f"{NS_S}numFmt")}
    xfs = styles.find(f"{NS_S}cellXfs")
    for i, xf in enumerate(xfs.findall(f"{NS_S}xf") if xfs is not None else []):
        fid = xf.get("numFmtId", "0")
        code = fmts.get(fid, "")
        if fid in {"14", "15", "16", "17", "22"} or ("yy" in code.lower() or "hh" in code.lower()):
            date_styles.add(str(i))
    control = {}
    tables = []
    sheets = wb.find(f"{NS_S}sheets")
    for si, sh in enumerate(sheets):
        rid = sh.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
        path = "xl/" + target[rid].lstrip("/").removeprefix("xl/")
        root = ET.fromstring(zf.read(path))
        grid = []
        for row in root.iter(f"{NS_S}row"):
            cells = {}
            for c in row.findall(f"{NS_S}c"):
                idx = _col_index(c.get("r"))
                t = c.get("t")
                v = c.find(f"{NS_S}v")
                if t == "inlineStr":
                    val = "".join(x.text or "" for x in c.iter(f"{NS_S}t"))
                elif t == "s":
                    val = shared[int(v.text)]
                elif t == "b":
                    val = v.text == "1"
                elif t == "str":
                    val = v.text or ""
                elif v is None:
                    val = ""
                elif c.get("s") in date_styles:
                    val = ("serial", v.text)
                else:
                    val = ("number", v.text)
                cells[idx] = val
            width = max(cells) + 1 if cells else 0
            grid.append([cells.get(i, "") for i in range(width)])
        if si == 0 and grid and isinstance(grid[0][0], str) and grid[0][0].startswith("#control "):
            control = parse_control(grid[0][0][len("#control "):])
            grid = grid[1:]
        header = [str(h).strip() for h in grid[0]]
        rows = [r + [""] * (len(header) - len(r)) for r in grid[1:]]
        tables.append(Table(sh.get("name"), header, rows))
    return Doc(control, tables, {"date1904": date1904})


# ------------------------------------------------------------------ parquet / sqlite
def read_parquet(raw: bytes) -> Doc:
    import pyarrow.parquet as pq
    t = pq.read_table(io.BytesIO(raw))
    meta = t.schema.metadata or {}
    control = json.loads(meta[b"trainyard.control"].decode("utf-8"))
    cols = t.column_names
    data = t.to_pydict()
    rows = [[data[c][i] for c in cols] for i in range(t.num_rows)]
    return Doc(control, [Table("rows", cols, rows)])


def read_sqlite(path: Path) -> Doc:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    try:
        control = {k: v for k, v in con.execute("SELECT key, value FROM control")}
        names = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY rowid")]
        tables = []
        for n in names:
            cur = con.execute(f'SELECT * FROM "{n}" ORDER BY rowid')
            cols = [d[0] for d in cur.description]
            tables.append(Table(n, cols, [list(r) for r in cur]))
    finally:
        con.close()
    return Doc(control, tables)


# ------------------------------------------------------------------ documents
def _doc_tables(blocks) -> tuple[dict, list]:
    """blocks: ("p", text) | ("table", rows); a heading 'Table: name' names the next table."""
    control = {}
    tables = []
    name = None
    for kind, val in blocks:
        if kind == "p":
            if val.startswith("Control block: ") and not control:
                control = parse_control(val[len("Control block: "):])
            elif val.startswith("Table: "):
                name = val[len("Table: "):].strip()
        elif kind == "table" and val:
            header = [c.strip() for c in val[0]]
            rows = [r for r in val[1:] if [c.strip() for c in r] != header]
            tables.append(Table(name or f"table{len(tables) + 1}", header, rows))
            name = None
    return control, tables


def read_docx(raw: bytes) -> Doc:
    zf = zipfile.ZipFile(io.BytesIO(raw))
    body = ET.fromstring(zf.read("word/document.xml")).find(f"{NS_W}body")
    blocks = []
    for el in body:
        if el.tag == f"{NS_W}p":
            blocks.append(("p", "".join(t.text or "" for t in el.iter(f"{NS_W}t"))))
        elif el.tag == f"{NS_W}tbl":
            rows = []
            for tr in el.findall(f"{NS_W}tr"):
                rows.append(["".join(t.text or "" for t in tc.iter(f"{NS_W}t")) for tc in tr.findall(f"{NS_W}tc")])
            blocks.append(("table", rows))
    control, tables = _doc_tables(blocks)
    return Doc(control, tables, {"text": [v for k, v in blocks if k == "p"]})


def read_pdf(raw: bytes) -> Doc:
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(raw))
    lines = []
    for page in reader.pages:
        lines += page.extract_text().split("\n")
    control = {}
    tables = []
    cur = None
    text = []
    for ln in lines:
        s = ln.strip()
        if s.startswith("CONTROL ") and not control:
            control = parse_control(s[len("CONTROL "):])
        elif s.startswith("TABLE "):
            cur = Table(s[len("TABLE "):].strip(), None, [])
            tables.append(cur)
        elif s.startswith("|") and cur is not None:
            cells = [c.strip() for c in s.strip("|").split("|")]
            if cur.columns is None:
                cur.columns = cells
            elif cells != cur.columns:
                cur.rows.append(cells)
        else:
            text.append(s)
    return Doc(control, tables, {"text": text})


class _HTML(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.control = {}
        self.tables = []
        self.cur = None
        self.row = None
        self.cell = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "meta" and a.get("name") == "trainyard-control":
            self.control = parse_control(a.get("content", ""))
        elif tag == "table":
            self.cur = [a.get("data-table"), []]
        elif tag == "tr":
            self.row = []
        elif tag in ("td", "th"):
            self.cell = []

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self.row is not None:
            self.row.append("".join(self.cell))
            self.cell = None
        elif tag == "tr" and self.cur is not None:
            self.cur[1].append(self.row)
            self.row = None
        elif tag == "table" and self.cur is not None:
            self.tables.append(self.cur)
            self.cur = None

    def handle_data(self, data):
        if self.cell is not None:
            self.cell.append(data)


def read_html(raw: bytes) -> Doc:
    p = _HTML()
    p.feed(raw.decode("utf-8"))
    tables = []
    for name, rows in p.tables:
        header = [c.strip() for c in rows[0]]
        tables.append(Table(name, header, [r for r in rows[1:] if [c.strip() for c in r] != header]))
    return Doc(p.control, tables)


def read_md(raw: bytes) -> Doc:
    text = raw.decode("utf-8-sig")
    lines = text.split("\n")
    m = re.match(r"<!-- control: (.*) -->$", lines[0])
    control = parse_control(m.group(1)) if m else {}
    tables = []
    name = None
    cur = None
    for ln in lines[1:]:
        if ln.startswith("### Table: "):
            name = ln[len("### Table: "):].strip()
            cur = None
            continue
        if ln.startswith("|") and name:
            cells = [c.strip().replace("\\|", "|") for c in re.split(r"(?<!\\)\|", ln.strip())[1:-1]]
            if cur is None:
                cur = Table(name, cells, [])
                tables.append(cur)
            elif all(set(c) <= {"-"} for c in cells):
                continue
            elif cells != cur.columns:
                cur.rows.append(cells)
        elif not ln.startswith("|"):
            cur = None if not ln.strip() else cur
    return Doc(control, tables)


# ------------------------------------------------------------------ mail / calendar / commits / zip
def read_mbox(path: Path) -> Doc:
    box = mailbox.mbox(str(path), create=False)
    msgs = list(box)
    control = {}
    rows = []
    for i, m in enumerate(msgs):
        if i == 0 and m.get("Subject") == "feed control":
            control = parse_control(m.get("X-Trainyard-Control", ""))
            continue
        body = m.get_payload(decode=False)
        frames = re.findall(r"^\s*#\d+\s+(\S+)\s*$", body, re.M)
        rows.append([m.get("X-Crash-Id", "") or "", m.get("X-Report-Rev", "1"), m.get("Message-ID", ""),
                     m.get("Date", ""), " ".join(frames)])
    box.close()
    return Doc(control, [Table("messages", ["crash_id", "rev", "message_id", "date", "frames"], rows)])


def read_ics(raw: bytes) -> Doc:
    text = raw.decode("utf-8").replace("\r\n", "\n")
    lines = []
    for ln in text.split("\n"):
        if ln.startswith((" ", "\t")) and lines:
            lines[-1] += ln[1:]
        else:
            lines.append(ln)
    control = {}
    rows = []
    cur = None
    for ln in lines:
        if not ln:
            continue
        name, _, value = ln.partition(":")
        key, *params = name.split(";")
        if key == "X-TRAINYARD-CONTROL":
            control = parse_control(value.replace("\\;", ";").replace("\\,", ","))
        elif key == "BEGIN" and value == "VEVENT":
            cur = {}
        elif key == "END" and value == "VEVENT":
            rows.append(cur)
            cur = None
        elif cur is not None:
            p = dict(x.split("=", 1) for x in params if "=" in x)
            cur[key] = (value, p.get("TZID"))
    cols = ["UID", "DTSTART", "DTEND", "STATUS", "SEQUENCE", "X-SITE"]
    return Doc(control, [Table("vevent", cols, [[r.get(c, ("", None)) for c in cols] for r in rows])])


def read_commitlog(raw: bytes) -> Doc:
    text = decode_lines(raw)
    lines = text.split("\n")
    control = _control_line(lines[0], "#control ")
    rows = []
    cur = None
    for ln in lines[1:]:
        if ln.startswith("commit "):
            cur = {"commit": ln.split()[1], "seq": None, "rewritten_from": ""}
            rows.append(cur)
        elif cur is not None:
            s = ln.strip()
            if s.startswith("Change-Seq:"):
                cur["seq"] = int(s.split(":", 1)[1])
            elif s.startswith("Rewritten-From:"):
                cur["rewritten_from"] = s.split(":", 1)[1].strip()
    cols = ["commit", "seq", "rewritten_from"]
    return Doc(control, [Table("commits", cols, [[r[c] for c in cols] for r in rows])])


def read_zip(raw: bytes) -> Doc:
    zf = zipfile.ZipFile(io.BytesIO(raw))
    control = parse_control(zf.read("TRAINYARD_CONTROL").decode("utf-8").strip())
    rows = []
    for n in zf.namelist():
        if n.endswith("fixtures/semver_cases.csv"):
            rows = list(csv.reader(io.StringIO(zf.read(n).decode("utf-8"))))[1:]
    return Doc(control, [Table("fixtures", ["version", "constraint", "expected"], rows)])


def read(path: Path, fmt: str, role: str) -> Doc:
    if role in ("commits", "commits_mirror"):
        return read_commitlog(path.read_bytes())
    if fmt == "db":
        return read_sqlite(path)
    if fmt == "mbox":
        return read_mbox(path)
    raw = path.read_bytes()
    return {
        "csv": lambda: read_delimited(raw, ","), "tsv": lambda: read_delimited(raw, "\t"),
        "txt": lambda: read_fixed(raw), "log": lambda: read_log(raw), "jsonl": lambda: read_jsonl(raw),
        "json": lambda: read_json(raw), "yaml": lambda: read_yaml(raw), "toml": lambda: read_toml(raw),
        "ini": lambda: read_ini(raw), "xml": lambda: read_xml(raw), "xlsx": lambda: read_xlsx(raw),
        "parquet": lambda: read_parquet(raw), "docx": lambda: read_docx(raw), "pdf": lambda: read_pdf(raw),
        "html": lambda: read_html(raw), "md": lambda: read_md(raw), "ics": lambda: read_ics(raw),
        "zip": lambda: read_zip(raw),
    }[fmt]()
