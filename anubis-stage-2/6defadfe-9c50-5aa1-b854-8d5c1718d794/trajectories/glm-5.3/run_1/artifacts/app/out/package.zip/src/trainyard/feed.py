"""Feed discovery, control chain and the reference registers."""
from __future__ import annotations

import bisect
import hashlib
import json
from datetime import date, datetime
from pathlib import Path

from . import readers
from .conventions import (FeedError, canonical_columns, cell, norm_ref, norm_test, parse_key)


def chain_link(prev: str, file_id: str, records, control) -> str:
    text = f"{prev}|{file_id}|{records}|{control}"
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:24]


def rows_of(table) -> list[dict]:
    cols = canonical_columns(table.columns)
    return [dict(zip(cols, r)) for r in table.rows]


class Feed:
    def __init__(self, feed_dir: Path, opening: dict):
        from .conventions import parse_iso
        self.dir = Path(feed_dir)
        self.opening = opening
        index_path = self._find_index()
        idx = json.loads(index_path.read_text(encoding="utf-8"))
        self.index = idx
        self.stage = idx["stage"]
        self.window = (parse_iso(idx["window"]["start"]), parse_iso(idx["window"]["end"]))
        self.files = sorted(idx["files"], key=lambda f: (f["chain_pos"], f["file_id"]))
        self.jobs = idx.get("jobs", [])
        self.job_exporter = {j["job"]: j["exporter"] for j in self.jobs}
        self.docs: dict[str, readers.Doc] = {}
        self.meta: dict[str, dict] = {}
        for f in self.files:
            if f["role"] == "index":
                doc = readers.Doc(idx["control"], [], {"records": len(idx["files"]) + len(self.jobs)})
            else:
                doc = readers.read(self.dir / f["path"], f["format"], f["role"])
            c = doc.control
            if c.get("file_id") != f["file_id"]:
                raise FeedError(f"control block of {f['path']} names {c.get('file_id')}")
            self.docs[f["file_id"]] = doc
            self.meta[f["file_id"]] = f
        self.chain = []
        link = opening["run_control"]
        for f in self.files:
            c = self.docs[f["file_id"]].control
            link = chain_link(link, f["file_id"], c["records"], c["control"])
            self.chain.append({"file_id": f["file_id"], "role": f["role"], "declared": int(c["records"]),
                               "read": self.docs[f["file_id"]].records, "link": link})
        self.run_control = link
        self._load_registers()

    def _find_index(self) -> Path:
        for p in sorted(self.dir.iterdir()):
            if p.suffix != ".json":
                continue
            try:
                obj = json.loads(p.read_text(encoding="utf-8"))
            except (ValueError, UnicodeDecodeError, OSError):
                continue
            if isinstance(obj, dict) and isinstance(obj.get("control"), dict) \
                    and obj["control"].get("role") == "index":
                return p
        raise FeedError("no feed index in the feed directory")

    def by_role(self, role: str) -> list[tuple[str, readers.Doc]]:
        return [(f["file_id"], self.docs[f["file_id"]]) for f in self.files if f["role"] == role]

    def one(self, role: str) -> readers.Doc:
        found = self.by_role(role)
        if len(found) != 1:
            raise FeedError(f"expected one file of role {role}, found {len(found)}")
        return found[0][1]

    def table(self, role: str, name: str):
        return rows_of(self.one(role).table(name))

    # ------------------------------------------------------------------ registers
    def _load_registers(self) -> None:
        from .conventions import parse_iso, parse_number
        self.W0, self.W1 = self.window
        # governance G2/G3
        gov = self.one("governance")
        self.rank = {cell(r["exporter"]): int(cell(r["rank"])) for r in rows_of(gov.table("exporter_rank"))}
        self.pool = {cell(r["host"]).lower(): cell(r["pool"]) for r in rows_of(gov.table("host_pools"))}
        # specification appendix F: legacy keys
        self.legacy_key = {cell(r["legacy_key"]): parse_key(r["build_key"])[1]
                           for r in self.table("spec", "legacy_keys")}
        # revision D appendix D (governance G1): legacy job crosswalk
        self.legacy_job = {cell(r["legacy_code"]): cell(r["job"])
                           for r in rows_of(self.one("spec_draft").table("legacy_jobs"))}
        # job revocation register: latest action (highest seq) per job
        acts = {}
        for r in self.table("readme", "job_revocations"):
            job, seq, act = cell(r["job"]), int(cell(r["seq"])), cell(r["action"])
            if job not in acts or seq > acts[job][0]:
                acts[job] = (seq, act)
        self.revoked = {job: act == "revoke" for job, (_, act) in acts.items()}
        # branch register (governance G16)
        self.branch_class = {cell(r["branch"]): cell(r["class"])
                             for r in rows_of(self.one("scope_memo").table("branch_register"))}
        # module registry and alias registers
        reg = self.one("modules")
        self.decom = {}
        for r in rows_of(reg.table("modules")):
            self.decom[norm_ref(r["module"])] = parse_iso(r["decommissioned_at"])
        self.modules = sorted(self.decom)
        aliases = []
        for r in rows_of(reg.table("aliases")):
            aliases.append((norm_ref(r["alias"]), norm_ref(r["module"]),
                            parse_iso(r["valid_from"]), parse_iso(r["valid_to"])))
        for r in rows_of(self.one("modules_next").tables[0]):
            frm = parse_iso(r["from"])
            if frm is None or not (self.W0 <= frm < self.W1):
                continue
            aliases.append((norm_ref(r["name"]), norm_ref(r["module"]), frm, parse_iso(r["to"])))
        self.aliases: dict[str, list] = {}
        for a, m, frm, to in aliases:
            self.aliases.setdefault(a, []).append((m, frm, to))
        # test registry
        self.registry = {}
        for r in rows_of(self.one("test_registry").table("tests")):
            mod, name = norm_test(r["test"])
            self.registry[(mod, name)] = (parse_iso(r["registered_at"]), parse_iso(r["retired_at"]))
        # quarantine (governance G9: revoked entries never happened)
        revoked = set()
        for t in self.one("flaky_dash").tables:
            if t.name == "quarantine_revocations":
                revoked = {int(cell(r["seq"])) for r in rows_of(t)}
        self.quarantine: dict[tuple, list] = {}
        for r in self.table("quarantine", "entries"):
            if int(cell(r["seq"])) in revoked:
                continue
            self.quarantine.setdefault(norm_test(r["test"]), []).append(
                (parse_iso(r["at"]), int(cell(r["seq"])), cell(r["action"])))
        for v in self.quarantine.values():
            v.sort()
        # hosts (governance G7)
        self.site = {}
        self.host_tz = {}
        for r in rows_of(self.one("hosts").tables[0]):
            h = cell(r["name"]).lower()
            self.site[h] = cell(r["site"])
            self.host_tz[h] = cell(r["tz"])
        for r in rows_of(self.one("hosts_cmdb").tables[0]):
            h = cell(r["name"]).lower()
            if h not in self.site:
                self.site[h] = cell(r["site"])
                self.host_tz[h] = cell(r["tz"])
        self.tzh: dict[str, list] = {}
        for r in rows_of(self.one("tz_history").table("tz_history")):
            self.tzh.setdefault(cell(r["host"]).lower(), []).append(
                (date.fromisoformat(cell(r["effective_date"])), cell(r["tz"])))
        for v in self.tzh.values():
            v.sort()
        # clock offsets (4.4 and errata E10)
        self.skew: dict[str, list] = {}
        for r in rows_of(self.one("skew").tables[0]):
            off = parse_number(r["offset_ms"], "en")
            if off == -1:
                continue
            self.skew.setdefault(cell(r["host"]).lower(), []).append((parse_iso(r["measured_at"]), int(off)))
        for v in self.skew.values():
            v.sort()
        self.skew_est = {}
        for r in rows_of(self.one("skew_est").tables[0]):
            self.skew_est[cell(r["host"]).lower()] = int(parse_number(r["offset_ms"], "en"))
        # maintenance (4.8): highest SEQUENCE per UID, confirmed windows only
        events = {}
        for r in self.one("maintenance").tables[0].rows:
            uid = _ics_cell(r[0])
            seq = int(_ics_cell(r[4]) or 0)
            if uid not in events or seq >= events[uid][0]:
                events[uid] = (seq, _ics_cell(r[3]), _ics_time(r[1]), _ics_time(r[2]), _ics_cell(r[5]))
        self.maint_by_site: dict[str, list] = {}
        for seq, status, s, e, site in events.values():
            if status == "CONFIRMED" and s is not None and e is not None:
                self.maint_by_site.setdefault(site, []).append((s, e))
        for v in self.maint_by_site.values():
            v.sort()
        # host incidents (4.9)
        self.incidents: dict[str, list] = {}
        for r in self.table("known_issues", "host_incidents"):
            self.incidents.setdefault(cell(r["host"]).lower(), []).append(
                (parse_iso(r["start"]), parse_iso(r["end"])))
        for v in self.incidents.values():
            v.sort()
        # void registers (4.7, governance G13)
        acts = []
        for role in ("voids", "voids_v2"):
            for fid, doc in self.by_role(role):
                for r in rows_of(doc.tables[0]):
                    if "countersigned" in r and cell(r["countersigned"]).lower() != "yes":
                        continue
                    acts.append((int(cell(r["seq"])), parse_key(r["build_key"])[1], cell(r["action"])))
        acts.sort(key=lambda a: a[0])
        self.void_state = {}
        for _, k, act in acts:
            self.void_state[k] = act
        # errata (4.5 and errata E9)
        self.errata = {}
        for r in sorted(self.table("errata", "corrections"), key=lambda r: cell(r["id"])):
            self.errata[(parse_key(r["build_key"])[1], int(cell(r["attempt"])), cell(r["field"]))] = cell(r["value"])
        extra = {}
        for r in sorted(rows_of(self.one("errata_b").table("corrections")), key=lambda r: cell(r["id"])):
            if cell(r["status"]) == "confirmed":
                extra[(parse_key(r["build_key"])[1], int(cell(r["attempt"])), cell(r["field"]))] = cell(r["value"])
        for k, v in extra.items():
            self.errata.setdefault(k, v)
        # commits (4.3, governance G10)
        self.commit_seq = {}
        for r in rows_of(self.one("commits").tables[0]):
            self.commit_seq[cell(r["commit"]).lower()] = int(cell(r["seq"]))
        self.shas = sorted(self.commit_seq)
        self.rewritten = {}
        for r in rows_of(self.one("commits_mirror").tables[0]):
            old = cell(r["rewritten_from"]).lower()
            if old:
                self.rewritten[old] = cell(r["commit"]).lower()
        pins = {}
        for r in rows_of(self.one("toolchain_pins").tables[0]):
            k = cell(r["commit"]).lower()
            rev = int(cell(r["rev"]))
            if k not in pins or rev > pins[k][0]:
                pins[k] = (rev, cell(r["toolchain"]))
        self.pins = {k: v[1] for k, v in pins.items()}

    # ------------------------------------------------------------------ lookups
    def resolve_module(self, ref: str, t: datetime):
        for m, frm, to in self.aliases.get(norm_ref(ref), []):
            if (frm is None or frm <= t) and (to is None or t < to):
                return m
        return None

    def resolve_commit(self, ref: str):
        ref = cell(ref).lower()
        i = bisect.bisect_left(self.shas, ref)
        if i < len(self.shas) and self.shas[i].startswith(ref):
            return self.shas[i]
        for old, new in self.rewritten.items():
            if old.startswith(ref):
                return new
        return None

    def tz_of(self, host: str, local_day: date) -> str:
        rows = self.tzh.get(host)
        if rows:
            tz = None
            for d, t in rows:
                if d <= local_day:
                    tz = t
            if tz is not None:
                return tz
        tz = self.host_tz.get(host)
        if tz is None:
            raise FeedError(f"no time zone for host {host}")
        return tz

    def offset(self, host: str, t: datetime) -> int:
        ms = self.skew.get(host)
        if ms is not None:
            off = None
            for at, value in ms:
                if at <= t:
                    off = value
            if off is not None:
                return off
            return 0
        return self.skew_est.get(host, 0)

    def toolchain(self, sha: str):
        return self.pins.get(sha[:12])


def _ics_cell(v):
    if isinstance(v, tuple):
        return v[0]
    return v


def _ics_time(v):
    from datetime import datetime as _dt
    from zoneinfo import ZoneInfo
    from .conventions import UTC
    if v is None:
        return None
    if isinstance(v, tuple):
        value, tzid = v[0], v[1]
    else:
        value, tzid = v, None
    value = str(value)
    if value.endswith("Z"):
        return _dt.strptime(value, "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
    naive = _dt.strptime(value, "%Y%m%dT%H%M%S")
    return naive.replace(tzinfo=ZoneInfo(tzid or "UTC")).astimezone(UTC)
