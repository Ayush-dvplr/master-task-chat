"""Value conventions of specification section 3."""
from __future__ import annotations

import re
import unicodedata
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_EVEN
from zoneinfo import ZoneInfo

UTC = timezone.utc


class FeedError(Exception):
    pass


HOMOGLYPHS = {
    "\u0430": "a", "\u0435": "e", "\u043e": "o", "\u0440": "p", "\u0441": "c",
    "\u0445": "x", "\u0456": "i", "\u0455": "s", "\u2010": "-", "\u2011": "-",
    "\u2212": "-", "\u2024": ".",
}
STATUS = {
    "pass": "pass", "passed": "pass", "success": "pass", "succeeded": "pass", "ok": "pass", "green": "pass",
    "fail": "fail", "failed": "fail", "failure": "fail", "broken": "fail", "red": "fail",
    "error": "infra", "errored": "infra", "aborted": "infra", "infra": "infra", "timeout": "infra", "lost": "infra",
}
OUTCOME = {
    "pass": "pass", "passed": "pass", "ok": "pass",
    "fail": "fail", "failed": "fail", "assertion": "fail",
    "skip": "skip", "skipped": "skip", "ignored": "skip",
    "crash": "crash", "crashed": "crash", "sigsegv": "crash", "sigabrt": "crash",
}
COLUMN_ALIASES = {
    "build": "build_key", "build_id": "build_key", "try": "attempt", "attempt_no": "attempt",
    "component": "module", "target": "module", "sha": "commit", "revision_sha": "commit",
    "agent": "host", "runner": "host", "result": "status", "ref": "branch", "export_job": "job",
    "revision": "rev", "error_code": "error", "test_id": "test", "case": "test", "verdict": "outcome",
    "crash_id": "crash",
}
SENTINEL_DURATION = {
    "core": "-1", "edge": "-1", "stream": "-1", "cold": "-1", "vault": "-1", "agent": "-1", "mirror": "-1",
    "legacy": "0", "ops": "N/A", "archive": "N/A", "feed": "N/A", "weekly": "N/A", "report": "N/A",
}


def parse_control(text: str) -> dict:
    out = {}
    for part in text.split("; "):
        k, _, v = part.partition("=")
        if k.strip():
            out[k.strip()] = v.strip()
    return out


def canonical_columns(cols):
    return [COLUMN_ALIASES.get(c, c) for c in cols]


def cell(v) -> str:
    if v is None:
        return ""
    if isinstance(v, str):
        return v.strip()
    if isinstance(v, tuple):
        return str(v[1]).strip()
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


def norm_ref(text: str) -> str:
    """3.1: NFKC, homoglyph table, white space removed, lower case."""
    s = unicodedata.normalize("NFKC", cell(text))
    s = "".join(HOMOGLYPHS.get(ch, ch) for ch in s)
    s = re.sub(r"\s+", "", s)
    return s.lower()


def norm_test(text: str) -> tuple[str, str]:
    mod, _, name = cell(text).partition("::")
    return norm_ref(mod), name.strip()


def parse_key(text) -> tuple[str, object]:
    """('prov', None) | ('legacy', 'L-...') | ('key', int)."""
    s = cell(text)
    if s.startswith("~"):
        return "prov", None
    if s.upper().startswith("L-"):
        return "legacy", "L-" + s[2:]
    s = s.lstrip("Bb").lstrip("-")
    return "key", int(s)


def bkey(k: int) -> str:
    return f"B{k:07d}"


def parse_number(text: str, locale: str) -> Decimal:
    s = cell(text)
    neg = s.startswith("(") and s.endswith(")")
    if neg:
        s = s[1:-1]
    if locale == "de":
        s = s.replace(".", "").replace(",", ".")
    else:
        s = s.replace(",", "")
    d = Decimal(s)
    return -d if neg else d


UNIT_MS = {"ms": Decimal(1), "s": Decimal(1000), "cs": Decimal(10), "us": Decimal("0.001")}
COL_UNIT = {"duration_ms": "ms", "duration_s": "s", "duration_cs": "cs"}


def parse_duration(value, column: str, locale: str, sentinel: str):
    """3.3/3.5/E6: whole milliseconds, or None for the documented sentinel."""
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("boolean duration")
    if isinstance(value, tuple):
        value = value[1]
    if isinstance(value, (int, float)):
        num = Decimal(str(value))
        try:
            if num == Decimal(sentinel):
                return None
        except ArithmeticError:
            pass
        unit = COL_UNIT.get(column, "ms")
        return int((num * UNIT_MS[unit]).to_integral_value(ROUND_HALF_EVEN))
    s = cell(value)
    if s == sentinel or s == "":
        return None
    s = s.replace("\u00b5s", "us").replace("\u03bcs", "us")
    if column == "elapsed_mmss" and ":" in s and not s.endswith("s"):
        m, _, rest = s.partition(":")
        total = Decimal(int(m)) * 60000 + parse_number(rest, "en") * 1000
        return int(total.to_integral_value(ROUND_HALF_EVEN))
    m = re.match(r"^(.*?)\s*(ms|us|cs|s)$", s)
    if m:
        num, unit = m.group(1), m.group(2)
    else:
        num, unit = s, COL_UNIT.get(column)
        if unit is None:
            raise ValueError(f"duration without unit in {column}: {s!r}")
    val = parse_number(num, locale) * UNIT_MS[unit]
    return int(val.to_integral_value(ROUND_HALF_EVEN))


TS_FORMATS = [("%Y-%m-%d %H:%M:%S", r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}"),
              ("%Y-%m-%dT%H:%M:%S", r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}"),
              ("%d.%m.%Y %H:%M:%S", r"\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}:\d{2}"),
              ("%d/%m/%Y %H:%M:%S", r"\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2}"),
              ("%Y%m%d%H%M%S", r"\d{14}")]
SKIP_ROW = object()


def excel_to_naive(serial: str, date1904: bool) -> datetime:
    v = Decimal(serial)
    days = int(v)
    secs = int(((v - days) * 86400).to_integral_value(ROUND_HALF_EVEN))
    base = datetime(1904, 1, 1) if date1904 else datetime(1899, 12, 30)
    return base + timedelta(days=days, seconds=secs)


def parse_start(value, column: str, date1904: bool):
    """Returns SKIP_ROW, an aware datetime, or a naive wall time."""
    if isinstance(value, tuple) and value[0] == "serial":
        return excel_to_naive(value[1], date1904)
    if isinstance(value, tuple) and value[0] == "number":
        value = value[1]
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=UTC)
        if value.timestamp() == 0:
            return SKIP_ROW
        return value
    if column.endswith("_ms") or column.endswith("_epoch"):
        n = int(cell(value))
        if n == 0:
            return SKIP_ROW
        unit = timedelta(milliseconds=n) if column.endswith("_ms") else timedelta(seconds=n)
        return datetime(1970, 1, 1, tzinfo=UTC) + unit
    s = cell(value)
    if s.startswith("0000-00-00"):
        return SKIP_ROW
    m = re.match(r"^(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2})(Z|[+-]\d{2}:?\d{2})$", s)
    if m:
        base = datetime.strptime(m.group(1).replace("T", " "), "%Y-%m-%d %H:%M:%S")
        off = m.group(2)
        if off == "Z":
            return base.replace(tzinfo=UTC)
        sign = 1 if off[0] == "+" else -1
        hh, mm = int(off[1:3]), int(off[-2:])
        return base.replace(tzinfo=timezone(sign * timedelta(hours=hh, minutes=mm)))
    for fmt, rx in TS_FORMATS:
        if re.fullmatch(rx, s):
            return datetime.strptime(s, fmt)
    raise FeedError(f"unrecognised timestamp {s!r}")


def local_to_utc(naive: datetime, tz: str) -> datetime:
    return naive.replace(tzinfo=ZoneInfo(tz)).astimezone(UTC)


def status_of(text) -> str:
    return STATUS[cell(text).lower()]


def outcome_of(text) -> str:
    return OUTCOME[cell(text).lower()]


def iso_ms(dt: datetime) -> str:
    dt = dt.astimezone(UTC)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"


def iso_s(dt: datetime) -> str:
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


OPEN_END = "9999-12-31T23:59:59Z"


def parse_iso(text: str):
    """Register timestamps: Z or an explicit offset; empty means none (3.4, 3.5)."""
    s = cell(text)
    if not s:
        return None
    if s == OPEN_END:
        return None
    m = re.match(r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(Z|[+-]\d{2}:?\d{2})$", s)
    if not m:
        raise ValueError(f"unrecognised register timestamp {s!r}")
    base = datetime.strptime(m.group(1), "%Y-%m-%dT%H:%M:%S")
    off = m.group(2)
    if off == "Z":
        return base.replace(tzinfo=UTC)
    sign = 1 if off[0] == "+" else -1
    hh, mm = int(off[1:3]), int(off[-2:])
    return (base - sign * timedelta(hours=hh, minutes=mm)).replace(tzinfo=UTC)


def half_even_4(num: int, den: int) -> str:
    return str((Decimal(num) / Decimal(den)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_EVEN))
