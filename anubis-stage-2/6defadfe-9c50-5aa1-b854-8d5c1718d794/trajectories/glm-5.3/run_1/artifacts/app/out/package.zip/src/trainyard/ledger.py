"""Build attempts, test results, classification, bisection and metrics."""
from __future__ import annotations

from datetime import timedelta

from .conventions import (SENTINEL_DURATION, SKIP_ROW, UTC, bkey, canonical_columns, cell, half_even_4,
                          iso_ms, local_to_utc, norm_test, outcome_of, parse_duration, parse_key, parse_start,
                          status_of)
from .crash import crash_labels
from .feed import Feed, rows_of

DUR_COLS = ("duration_ms", "duration_s", "duration_cs", "elapsed", "elapsed_mmss", "took")
TS_COLS = ("started", "started_ms", "started_epoch")


def _rows(doc):
    for t in doc.tables:
        cols = canonical_columns(t.columns)
        for r in t.rows:
            yield cols, dict(zip(cols, r))


class Ledger:
    def __init__(self, feed: Feed):
        self.f = feed
        self.W0, self.W1 = feed.window

    # ------------------------------------------------------------------ keys / jobs
    def _key(self, value):
        kind, k = parse_key(value)
        if kind == "prov":
            return None
        if kind == "legacy":
            return self.f.legacy_key.get(k)
        return k

    def _job(self, value):
        j = cell(value)
        return self.f.legacy_job.get(j, j)

    def _score(self, job: str, rev) -> tuple:
        exporter = self.f.job_exporter.get(job)
        return (self.f.rank.get(exporter, -1), int(cell(rev) or 0))

    # ------------------------------------------------------------------ attempts
    def attempts(self):
        f = self.f
        cands = {}
        for fid, doc in f.by_role("builds"):
            c = doc.control
            basis = c.get("time_basis", "utc")
            locale = c.get("locale", "en")
            sentinel = SENTINEL_DURATION[c["profile"]]
            date1904 = c.get("date_system") == "1904" or bool(doc.extra.get("date1904", False))
            mirror = c.get("profile") == "mirror" or c.get("scope", "").startswith("rows of pool eph")
            for cols, r in _rows(doc):
                key = self._key(r["build_key"])
                if key is None:
                    continue
                host = cell(r["host"]).lower()
                if mirror and f.pool.get(host) != "eph":
                    continue
                job = self._job(r["job"])
                if f.revoked.get(job):
                    continue
                ts_col = next((cc for cc in cols if cc in TS_COLS), None)
                if ts_col is None:
                    continue
                start = parse_start(r[ts_col], ts_col, date1904)
                if start is SKIP_ROW:
                    continue
                if start.tzinfo is None:
                    if basis == "utc":
                        start = start.replace(tzinfo=UTC)
                    else:
                        start = local_to_utc(start, f.tz_of(host, start.date()))
                dcol = next(cc for cc in cols if cc in DUR_COLS)
                rec = {"key": key, "attempt": int(cell(r["attempt"])), "alias": cell(r["module"]),
                       "commit": cell(r["commit"]), "host": host, "logged": start,
                       "dur": parse_duration(r[dcol], dcol, locale, sentinel),
                       "status": status_of(r["status"]), "branch": cell(r["branch"]),
                       "error": cell(r.get("error", ""))}
                k = (key, rec["attempt"])
                sc = self._score(job, r.get("rev", ""))
                if k not in cands or sc > cands[k][0]:
                    cands[k] = (sc, rec)
        att = {}
        self.by_attempt = {}
        for (key, a), (_, x) in cands.items():
            cor = x["logged"] - timedelta(milliseconds=f.offset(x["host"], x["logged"]))
            module = f.resolve_module(x["alias"], cor)
            if module is None:
                continue
            dec_at = f.decom.get(module)
            if dec_at is not None and dec_at <= cor:
                continue
            if f.branch_class.get(x["branch"]) != "main":
                continue
            if f.pool.get(x["host"]) == "lab":
                continue
            if not (self.W0 <= cor < self.W1):
                continue
            sha = f.resolve_commit(x["commit"])
            if sha is None:
                continue
            status = x["status"]
            if (key, a, "status") in f.errata:
                status = f.errata[(key, a, "status")]
            dur = x["dur"]
            if (key, a, "duration_ms") in f.errata:
                dur = int(f.errata[(key, a, "duration_ms")])
            site = f.site.get(x["host"])
            if site is not None and any(s <= cor < e for s, e in f.maint_by_site.get(site, [])):
                status = "infra"
            if any(s <= cor < e for s, e in f.incidents.get(x["host"], [])):
                status = "infra"
            rec = {"key": key, "attempt": a, "module": module, "sha": sha, "seq": f.commit_seq[sha],
                   "host": x["host"], "cor": cor, "dur": dur, "status": status, "error": x["error"]}
            att.setdefault(key, []).append(rec)
            self.by_attempt[(key, a)] = rec
        seen = {int(k[1:]) for k in f.opening.get("seen_build_keys", [])}
        builds = {}
        for key, rs in att.items():
            if f.void_state.get(key) == "VOID":
                continue
            if key in seen:
                continue
            builds[key] = rs
        for rs in builds.values():
            rs.sort(key=lambda x: x["attempt"])
        self.builds = builds
        return builds

    # ------------------------------------------------------------------ tests
    def tests(self):
        f = self.f
        digest = {}
        for t in f.one("crash_digest").tables:
            if t.name == "legacy_map":
                for r in rows_of(t):
                    digest[(self._key(r["build_key"]), int(cell(r["attempt"])), norm_test(r["test"]))] = \
                        cell(r["crash"])
        cands = {}
        for fid, doc in f.by_role("tests"):
            c = doc.control
            for t in doc.tables:
                cols = canonical_columns(t.columns)
                rerun = (c.get("scope", "").startswith("rows with backfill")
                         or (c.get("profile") == "mirror" and "backfill" in cols))
                for r in t.rows:
                    d = dict(zip(cols, r))
                    if rerun and cell(d.get("backfill", "")).lower() != "true":
                        continue
                    key = self._key(d["build_key"])
                    if key is None:
                        continue
                    job = self._job(d["job"])
                    if f.revoked.get(job):
                        continue
                    k = (key, int(cell(d["attempt"])), norm_test(d["test"]))
                    sc = self._score(job, d.get("rev", ""))
                    if k not in cands or sc > cands[k][0]:
                        has_col = "crash" in cols
                        crash = cell(d["crash"]) if has_col else digest.get(k, "")
                        cands[k] = (sc, outcome_of(d["outcome"]), crash, has_col)
        by_att = {}
        for (key, a, (malias, name)), (_, outcome, crash, has_col) in cands.items():
            if key not in self.builds:
                continue
            rec = self.by_attempt.get((key, a))
            if rec is None:
                continue
            mod = f.resolve_module(malias, rec["cor"])
            if mod is None:
                continue
            reg = f.registry.get((mod, name))
            if reg is None:
                continue
            registered, retired = reg
            if registered is not None and registered > rec["cor"]:
                continue
            if retired is not None and rec["cor"] >= retired:
                continue
            if outcome == "crash" and not crash:
                outcome = "fail"
            by_att.setdefault((key, a), []).append(
                {"test": f"{mod}::{name}", "outcome": outcome, "crash": crash})
        for v in by_att.values():
            v.sort(key=lambda x: x["test"])
        self.tests_by_att = by_att
        return by_att

    # ------------------------------------------------------------------ ledger
    def compute(self):
        f = self.f
        builds = self.attempts()
        tba = self.tests()
        flaky = set(f.opening.get("open_flaky", []))
        # 5.3 with errata E4: every in-stage attempt whose final status is pass or fail
        obs = {}
        for key, rs in builds.items():
            for rec in rs:
                if rec["status"] not in ("pass", "fail"):
                    continue
                for t in tba.get((key, rec["attempt"]), []):
                    if t["outcome"] in ("pass", "fail", "crash"):
                        obs.setdefault((t["test"], rec["sha"]), set()).add(
                            "pass" if t["outcome"] == "pass" else "fail")
        for (tid, _), s in obs.items():
            if len(s) > 1:
                flaky.add(tid)
        labels = crash_labels(f)

        def quarantined(tid, t):
            mod, _, name = tid.partition("::")
            state = False
            for at, _, act in f.quarantine.get((mod, name), []):
                if at <= t:
                    state = act == "add"
            return state

        report = []
        by_mod = {}
        real = {}
        executed = {}
        for key, rs in builds.items():
            concl = [x for x in rs if x["status"] in ("pass", "fail")]
            d = max(concl, key=lambda x: x["attempt"]) if concl else max(rs, key=lambda x: x["attempt"])
            reals = []
            n_exec = 0
            for t in tba.get((key, d["attempt"]), []):
                if t["outcome"] != "skip":
                    n_exec += 1
                if t["outcome"] in ("fail", "crash") and t["test"] not in flaky \
                        and not quarantined(t["test"], d["cor"]):
                    reals.append("crash:" + labels.label(t["crash"], d["sha"]) if t["outcome"] == "crash"
                                else "test:" + t["test"])
            if d["status"] == "infra":
                status, bucket = "infra", None
            elif d["status"] == "fail":
                status, bucket = "red", "compile:" + cell(d["error"]).split(":")[0].strip()
            elif reals:
                status, bucket = "red", min(reals)
            else:
                status, bucket = "green", None
            row = {"build_key": bkey(key), "module": d["module"], "commit": d["sha"][:12], "commit_seq": d["seq"],
                   "host": d["host"], "attempt": d["attempt"], "started_utc": iso_ms(d["cor"]),
                   "duration_ms": d["dur"], "status": status, "bucket": bucket}
            report.append(row)
            by_mod.setdefault(d["module"], []).append(row)
            real[key] = len(reals) if d["status"] == "pass" else 0
            executed[key] = n_exec
        report.sort(key=lambda x: (x["commit_seq"], x["module"], x["build_key"]))
        seq_sha = {s: sha for sha, s in f.commit_seq.items()}
        active = sorted(m for m, dec in f.decom.items() if dec is None or dec > self.W0)
        carried = f.opening.get("last_good", {})
        carried_seq = f.opening.get("last_good_seq", {})
        core, metrics = [], []
        lg_out, lg_seq_out = dict(carried), dict(carried_seq)
        for m in active:
            rows = by_mod.get(m, [])
            e = {"module": m, "state": None, "last_good": None, "first_bad": None, "suspects": None,
                 "dominant_bucket": None}
            if not rows:
                e["state"] = "unbuilt"
                e["last_good"] = carried.get(m)
            elif all(x["status"] == "infra" for x in rows):
                e["state"] = "infra-only"
                e["last_good"] = carried.get(m)
            else:
                cs = {}
                for x in rows:
                    if x["status"] == "infra":
                        continue
                    cs[x["commit_seq"]] = "red" if (x["status"] == "red" or cs.get(x["commit_seq"]) == "red") \
                        else "green"
                greens = [o for o, s in cs.items() if s == "green"]
                stage_ord = max(greens) if greens else None
                carried_ord = carried_seq.get(m)
                if stage_ord is not None and (carried_ord is None or stage_ord > carried_ord):
                    lg_ord, lg_sha = stage_ord, seq_sha[stage_ord][:12]
                else:
                    lg_ord, lg_sha = carried_ord, carried.get(m)
                e["last_good"] = lg_sha
                reds = sorted(o for o, s in cs.items() if s == "red" and (lg_ord is None or o > lg_ord))
                if reds:
                    fb = reds[0]
                    e["state"] = "red"
                    e["first_bad"] = seq_sha[fb][:12]
                    e["suspects"] = fb - lg_ord if lg_ord is not None else None
                    cnt = {}
                    for x in rows:
                        if x["status"] == "infra" or cs[x["commit_seq"]] != "red" or x["commit_seq"] < fb:
                            continue
                        cnt[x["bucket"]] = cnt.get(x["bucket"], 0) + 1
                    if cnt:
                        top = max(cnt.values())
                        e["dominant_bucket"] = min(b for b, n in cnt.items() if n == top)
                else:
                    e["state"] = "green"
            if e["last_good"] is not None:
                lg_out[m] = e["last_good"]
            if e["state"] not in ("unbuilt", "infra-only"):
                if lg_ord is not None:
                    lg_seq_out[m] = lg_ord
            elif carried_seq.get(m) is not None:
                lg_seq_out[m] = carried_seq[m]
            core.append(e)
            green = sum(1 for x in rows if x["status"] == "green")
            red = sum(1 for x in rows if x["status"] == "red")
            infra = sum(1 for x in rows if x["status"] == "infra")
            durs = sorted(x["duration_ms"] for x in rows
                          if x["status"] != "infra" and x["duration_ms"] is not None)
            keys = [int(x["build_key"][1:]) for x in rows]
            metrics.append({
                "module": m, "deciding": len(rows), "green": green, "red": red, "infra": infra,
                "tests_executed": sum(executed[k] for k in keys),
                "real_failures": sum(real[k] for k in keys),
                "flaky_tests": sum(1 for t in flaky if t.split("::")[0] == m),
                "pass_rate": half_even_4(green, green + red) if green + red else None,
                "median_duration_ms": durs[(len(durs) - 1) // 2] if durs else None,
            })
        self.report, self.core, self.metrics = report, core, metrics
        self.flaky = flaky
        self.last_good = {k: lg_out[k] for k in sorted(lg_out)}
        self.last_good_seq = {k: lg_seq_out[k] for k in sorted(lg_seq_out)}
        self.seen = sorted(set(f.opening.get("seen_build_keys", [])) | {x["build_key"] for x in report})
