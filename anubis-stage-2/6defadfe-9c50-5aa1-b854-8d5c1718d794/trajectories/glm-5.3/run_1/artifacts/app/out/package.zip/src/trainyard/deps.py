"""Dependency resolution (specification section 9)."""
from __future__ import annotations

import re

from .conventions import cell, parse_iso
from .feed import rows_of


def _pad3(v: str) -> str:
    parts = [p for p in v.split(".")]
    while len(parts) < 3:
        parts.append("0")
    return ".".join(parts)


def parse_version(v: str):
    core, _, pre = v.partition("-")
    a, b, c = (int(x) for x in _pad3(core).split("."))
    ids = None
    if pre:
        ids = tuple((0, int(x), "") if x.isdigit() else (1, 0, x) for x in pre.split("."))
    return (a, b, c), ids


def version_key(v: str):
    core, ids = parse_version(v)
    return (core, 1 if ids is None else 0, ids or ())


def _cmp(v: str, op: str, w: str) -> bool:
    a, b = version_key(v), version_key(w)
    return {">=": a >= b, ">": a > b, "<": a < b, "<=": a <= b, "=": a == b}[op]


def comparators(c: str):
    c = c.strip()
    if c.startswith("^"):
        (x, y, z), _ = parse_version(_pad3(c[1:]))
        if x > 0:
            return [(">=", f"{x}.{y}.{z}"), ("<", f"{x + 1}.0.0")]
        if y > 0:
            return [(">=", f"0.{y}.{z}"), ("<", f"0.{y + 1}.0")]
        return [(">=", f"0.0.{z}"), ("<", f"0.0.{z + 1}")]
    if c.startswith("~"):
        (x, y, z), _ = parse_version(_pad3(c[1:]))
        return [(">=", f"{x}.{y}.{z}"), ("<", f"{x}.{y + 1}.0")]
    if c.endswith(".*"):
        (x, y, z), _ = parse_version(_pad3(c[:-2]))
        return [(">=", f"{x}.{y}.0"), ("<", f"{x}.{y + 1}.0")]
    if c.startswith("=") and not c.startswith("=="):
        return [("=", c[1:])]
    out = []
    for part in c.split(","):
        part = part.strip()
        for op in (">=", "<=", ">", "<", "="):
            if part.startswith(op):
                out.append((op, part[len(op):].strip()))
                break
    return out


def satisfies(v: str, c: str) -> bool:
    comps = comparators(c)
    core, ids = parse_version(v)
    if ids is not None:
        named = any(parse_version(w)[1] is not None and parse_version(w)[0] == core for _, w in comps)
        if not named:
            return False
    return all(_cmp(v, op, w) for op, w in comps)


def norm_package(name: str) -> str:
    return re.sub(r"[-_.]+", "-", cell(name)).lower()


def resolve(feed) -> list:
    cut = feed.window[1]
    aliases = {}
    for r in rows_of(feed.one("package_aliases").table("package_aliases")):
        aliases[norm_package(r["alias"])] = norm_package(r["package"])

    def pkg(name):
        n = norm_package(name)
        return aliases.get(n, n)

    published = {}
    for r in rows_of(feed.one("packages").table("versions")):
        if parse_iso(r["published_at"]) <= cut:
            published.setdefault(pkg(r["package"]), set()).add(cell(r["version"]))
    withdrawn = set()
    for t in feed.one("packages_v2").tables:
        if t.name == "withdrawn":
            for r in rows_of(t):
                withdrawn.add((pkg(r["package"]), cell(r["version"])))
    acts = []
    for r in rows_of(feed.one("advisories").tables[0]):
        acts.append((parse_iso(r["at"]), int(cell(r["seq"])), pkg(r["package"]), cell(r["version"]),
                     cell(r["action"])))
    for r in rows_of(feed.one("audit").tables[0]):
        acts.append((parse_iso(r["at"]), int(cell(r["seq"])), pkg(r["package"]), cell(r["version"]),
                     cell(r["action"])))
    acts.sort(key=lambda a: (a[0], a[1]))
    yanked = {}
    for at, _, p, v, act in acts:
        if at <= cut:
            yanked[(p, v)] = act == "yank"

    def available(p, v):
        return v in published.get(p, ()) and (p, v) not in withdrawn and not yanked.get((p, v), False)

    con_doc = feed.one("constraints")
    reqs = [(cell(r["module"]), pkg(r["package"]), cell(r["constraint"]))
            for r in rows_of(con_doc.table("requirements"))]
    amend = {}
    for r in sorted(rows_of(con_doc.table("amendments")),
                    key=lambda r: (parse_iso(r["effective_at"]), int(cell(r["seq"])))):
        if parse_iso(r["effective_at"]) <= cut:
            amend[(cell(r["module"]), pkg(r["package"]))] = cell(r["constraint"])
    overrides = {}
    for r in rows_of(feed.one("overrides").tables[0]):
        area, p = cell(r["area"]), pkg(r["package"])
        pin, expires = cell(r["pin"]), parse_iso(r["expires"])
        overrides[(area, p)] = (pin, expires)

    def override_in_force(pin, expires):
        return pin not in ("", "none") and expires is not None and expires > cut

    def override_for(m, p):
        """The override in force for a requirement: the module area's, or area * when the area
        override is absent or not in force (an override that is not in force counts as none)."""
        pin, expires = overrides.get((m.split("/")[0], p), ("", None))
        if not override_in_force(pin, expires):
            pin, expires = overrides.get(("*", p), ("", None))
        return (pin, expires) if override_in_force(pin, expires) else ("", None)

    lock = {}
    for r in rows_of(feed.one("lockpins").tables[0]):
        frozen = r["frozen"] if isinstance(r["frozen"], bool) else cell(r["frozen"]).lower() == "true"
        lock.setdefault(cell(r["module"]), {"frozen": frozen, "pins": {}}) \
            ["pins"][pkg(r["package"])] = cell(r["version"])
    snap = {}
    for r in rows_of(feed.one("lock_snapshot").tables[0]):
        snap.setdefault(cell(r["module"]), {})[pkg(r["package"])] = cell(r["version"])
    by_mod = {}
    for m, p, c in reqs:
        by_mod.setdefault(m, []).append((p, c))
    out = []
    for m in sorted(by_mod):
        lk = lock.get(m, {"frozen": False, "pins": {}})
        frozen, pins = lk["frozen"], lk["pins"]
        items = []
        for p, c in by_mod[m]:
            c = amend.get((m, p), c)
            if c == "remove":
                continue
            resolved, source = None, None
            if frozen:
                locked = pins.get(p)
                if locked == "snapshot":
                    locked = snap.get(m, {}).get(p, "")
                if locked and available(p, locked):
                    resolved, source = locked, "lock"
                else:
                    cands = [v for v in published.get(p, ()) if available(p, v) and satisfies(v, c)]
                    if cands:
                        resolved, source = max(cands, key=version_key), "relock"
                    else:
                        source = "unresolvable"
            else:
                pin, _ = override_for(m, p)
                if pin and available(p, pin):
                    resolved, source = pin, "override"
                if resolved is None:
                    cands = [v for v in published.get(p, ()) if available(p, v) and satisfies(v, c)]
                    if cands:
                        resolved, source = max(cands, key=version_key), "constraint"
            if resolved is None and source is None:
                source = "unresolvable"
            items.append({"package": p, "constraint": c, "resolved": resolved, "source": source})
        items.sort(key=lambda x: x["package"])
        if items:
            out.append({"module": m, "requirements": items})
    return out
