import unittest

from trainyard.conventions import norm_ref, parse_key, parse_number


class Conventions(unittest.TestCase):
    def test_build_keys(self):
        for text in ("B0001234", "B-1234", "b0001234", "1234", " B0001234 "):
            self.assertEqual(parse_key(text), ("key", 1234))
        self.assertEqual(parse_key("~B0001234")[0], "prov")

    def test_numbers(self):
        self.assertEqual(str(parse_number("1,234.5", "en")), "1234.5")
        self.assertEqual(str(parse_number("1.234,5", "de")), "1234.5")
        self.assertEqual(str(parse_number("(42)", "en")), "-42")

    def test_module_reference(self):
        self.assertEqual(norm_ref(" Payments/Core-Api "), "payments/core-api")


if __name__ == "__main__":
    unittest.main()
