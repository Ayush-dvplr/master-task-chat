import csv
import unittest
from pathlib import Path

from trainyard.deps import satisfies, version_key

FIXTURES = Path(__file__).parent / "fixtures" / "semver_cases.csv"


class SemverCases(unittest.TestCase):
    def test_fixture_cases(self):
        with FIXTURES.open(encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        self.assertGreater(len(rows), 1000)
        wrong = [r for r in rows if satisfies(r["version"], r["constraint"]) != (r["expected"] == "yes")]
        self.assertEqual(wrong, [])

    def test_precedence(self):
        ordered = ["1.0.0-alpha.1", "1.0.0-alpha.beta", "1.0.0-beta.2", "1.0.0-beta.11", "1.0.0-rc.1", "1.0.0"]
        self.assertEqual(sorted(ordered, key=version_key), ordered)


if __name__ == "__main__":
    unittest.main()
