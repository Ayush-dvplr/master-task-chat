"""Command line entry point: python -m trainyard reconcile --feed DIR --resume STATE --out DIR."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .report import reconcile


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="trainyard")
    sub = parser.add_subparsers(dest="command", required=True)
    rec = sub.add_parser("reconcile", help="compute a stage ledger")
    rec.add_argument("--feed", required=True, type=Path)
    rec.add_argument("--resume", required=True, type=Path)
    rec.add_argument("--out", required=True, type=Path)
    args = parser.parse_args(argv)
    if args.command == "reconcile":
        reconcile(args.feed, args.resume, args.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
