"""Build attempts, test results, classification, bisection and metrics."""
from __future__ import annotations

from datetime import timedelta

from .conventions import (SKIP_ROW, SENTINEL_DURATION, UTC, bkey, canonical_columns, cell, half_even_4,
                          iso_ms, local_to_utc, norm_test, outcome_of, parse_duration, parse_key, parse_start,
                          status_of)
from .crash import crash_labels
from .feed import Feed, truthy

DUR_COLS = ("duration_ms", "duration_s", "duration_cs", "elapsed", "elapsed_mmss", "took")
TS_COLS = ("started", "started_ms", "started_epoch")


def _profile_of(doc) -> tuple[str, str, str]:
    c = doc.control
    return c.get("time_basis", "utc"), c.get("locale", "en"), c.get("profile", "core")


def _rows(doc):
    for t in doc.tables:
        cols = canonical_columns(t.columns)
        for r in t.rows:
            yield cols, dict(zip(cols, r))


def _in_any(intervals, t) -> bool:
    """E7: maintenance windows and incident intervals are half-open."""
    return any(s <= t < e for s, e in intervals)


class Ledger:
    def __init__(self, feed: Feed):
        self.f = feed
        self.W0, self.W1 = feed.window

    # ------------------------------------------------------------------ keys / jobs
    def _key(self, value):
        kind, k = parse_key(value)
        if kind == "prov":
            return None
        if kind == "legacy":
            return self.f.legacy_key.get(k)
        return k

    def _job(self, value):
        """4.1: legacy partitions name jobs by legacy code (appendix D of revision D)."""
        j = cell(value)
        return self.f.legacy_job.get(j, j)

    def _score(self, job: str, rev) -> tuple:
        exporter = self.f.job_exporter.get(job)
        return (self.f.rank.get(exporter, 0), int(cell(rev) or 0))

    def _scope_filter(self, doc):
        """Governance scopes declared by the control block of a partial re-export."""
        scope = doc.control.get("scope", "")
        if scope.startswith("rows of pool "):
            want = scope.split("rows of pool ", 1)[1].split()[0]
            return lambda r: self.f.pool.get(cell(r.get("host", "")).lower()) == want
        if scope.startswith("rows with backfill"):
            return lambda r: truthy(r.get("backfill", ""))
        return None

    # ------------------------------------------------------------------ attempts
    def attempts(self):
        f = self.f
        cands = {}
        for fid, doc in f.by_role("builds"):
            basis, locale, _ = _profile_of(doc)
            sentinel = SENTINEL_DURATION[doc.control["profile"]]
            date1904 = doc.control.get("date_system") == "1904" or doc.extra.get("date1904", False)
            keep = self._scope_filter(doc)
            for cols, r in _rows(doc):
                if keep is not None and not keep(r):
                    continue
                key = self._key(r["build_key"])
                if key is None:
                    continue
                ts_col = next(c for c in cols if c in TS_COLS)
                start = parse_start(r[ts_col], ts_col, date1904)
                if start is SKIP_ROW:
                    continue
                job = self._job(r["job"])
                if f.revoked.get(job):
                    continue
                host = cell(r["host"]).lower()
                if start.tzinfo is None:
                    if basis == "utc":
                        start = start.replace(tzinfo=UTC)
                    else:
                        start = local_to_utc(start, f.tz_of(host, start.date()))
                dcol = next(c for c in cols if c in DUR_COLS)
                rec = {"key": key, "attempt": int(cell(r["attempt"])), "alias": cell(r["module"]),
                       "commit": cell(r["commit"]), "host": host, "logged": start.astimezone(UTC),
                       "dur": parse_duration(r[dcol], dcol, locale, sentinel), "status": status_of(r["status"]),
                       "branch": cell(r["branch"]), "error": cell(r.get("error", ""))}
                k = (key, rec["attempt"])
                sc = self._score(job, r["rev"])
                if k not in cands or sc > cands[k][0]:
                    cands[k] = (sc, rec)
        att = {}
        self.by_attempt = {}
        for (key, a), (_, x) in cands.items():
            status = x["status"]
            dur = x["dur"]
            if (key, a, "status") in f.errata:
                status = f.errata[(key, a, "status")]
            if (key, a, "duration_ms") in f.errata:
                dur = int(f.errata[(key, a, "duration_ms")])
            cor = x["logged"] - timedelta(milliseconds=f.offset(x["host"], x["logged"]))
            if f.branch_class.get(x["branch"]) != "main":
                continue
            if f.pool.get(x["host"]) == "lab":
                continue
            module = f.resolve_module(x["alias"], cor)
            sha = f.resolve_commit(x["commit"])
            if module is None or sha is None:
                continue
            dec = f.decom.get(module)
            if dec is not None and dec <= cor:
                continue
            if not (self.W0 <= cor < self.W1):
                continue
            site = f.site.get(x["host"])
            if site is None:
                continue
            if _in_any(f.maint_by_site.get(site, []), cor):
                status = "infra"
            elif _in_any(f.incidents.get(x["host"], []), cor):
                status = "infra"
            rec = {"key": key, "attempt": a, "module": module, "sha": sha, "seq": f.commit_seq[sha],
                   "host": x["host"], "cor": cor, "dur": dur, "status": status, "error": x["error"]}
            att.setdefault(key, []).append(rec)
            self.by_attempt[(key, a)] = rec
        seen = set(f.opening.get("seen_build_keys", []))
        builds = {}
        for key, rs in att.items():
            if f.void_state.get(key) == "VOID":
                continue
            if bkey(key) in seen:
                continue
            concl = [x for x in rs if x["status"] in ("pass", "fail")]
            dec = max(concl or rs, key=lambda x: x["attempt"])
            builds[key] = {"dec": dec, "all": rs}
        self.builds = builds
        return builds

    # ------------------------------------------------------------------ tests
    def tests(self):
        f = self.f
        digest = {}
        for sheet in f.one("crash_digest").tables:
            if sheet.name == "legacy_map":
                cols = canonical_columns(sheet.columns)
                for row in sheet.rows:
                    r = dict(zip(cols, row))
                    k = self._key(r["build_key"])
                    a = int(cell(r["attempt"]))
                    digest[(k, a, norm_test(r["test"]))] = cell(r["crash"])
        cands = {}
        for fid, doc in f.by_role("tests"):
            keep = self._scope_filter(doc)
            for cols, r in _rows(doc):
                if keep is not None and not keep(r):
                    continue
                key = self._key(r["build_key"])
                if key is None:
                    continue
                job = self._job(r["job"])
                if f.revoked.get(job):
                    continue
                a = int(cell(r["attempt"]))
                tref = norm_test(r["test"])
                k = (key, a, tref)
                sc = self._score(job, r["rev"])
                if k not in cands or sc > cands[k][0]:
                    has_col = "crash" in cols
                    crash = cell(r.get("crash", "")) if has_col else digest.get(k, "")
                    cands[k] = (sc, outcome_of(r["outcome"]), crash)
        by_att = {}
        for (key, a, (malias, name)), (_, outcome, crash) in cands.items():
            if key not in self.builds:
                continue
            rec = self.by_attempt.get((key, a))
            if rec is None:
                continue
            mod = f.resolve_module(malias, rec["cor"])
            if mod is None:
                continue
            reg = f.registry.get((mod, name))
            if reg is None:
                continue
            registered, retired = reg
            if registered is None or registered > rec["cor"]:
                continue
            if retired is not None and rec["cor"] >= retired:
                continue
            by_att.setdefault((key, a), []).append({"test": f"{mod}::{name}", "outcome": outcome, "crash": crash})
        self.tests_by_att = by_att
        return by_att

    # ------------------------------------------------------------------ ledger
    def compute(self):
        f = self.f
        builds = self.attempts()
        tba = self.tests()
        flaky = set(f.opening.get("open_flaky", []))
        obs = {}
        for key, b in builds.items():
            for rec in b["all"]:
                if rec["status"] not in ("pass", "fail"):
                    continue
                for t in tba.get((key, rec["attempt"]), []):
                    if t["outcome"] in ("pass", "fail", "crash"):
                        obs.setdefault((t["test"], rec["sha"]), set()).add(
                            "pass" if t["outcome"] == "pass" else "fail")
        for (tid, _), s in obs.items():
            if len(s) == 2:
                flaky.add(tid)
        labels = crash_labels(f)

        def quarantined(tid, t):
            mod, _, name = tid.partition("::")
            state = False
            for at, _, act in f.quarantine.get((mod, name), []):
                if at <= t:
                    state = act == "add"
            return state

        report = []
        by_mod = {}
        real = {}
        executed = {}
        for key, b in builds.items():
            d = b["dec"]
            reals = []
            n_exec = 0
            for t in tba.get((key, d["attempt"]), []):
                if t["outcome"] != "skip":
                    n_exec += 1
                if t["outcome"] in ("fail", "crash") and t["test"] not in flaky \
                        and not quarantined(t["test"], d["cor"]):
                    if t["outcome"] == "crash":
                        reals.append("crash:" + labels.label(t["crash"], d["sha"]))
                    else:
                        reals.append("test:" + t["test"])
            if d["status"] == "infra":
                status, bucket = "infra", None
            elif d["status"] == "fail":
                status, bucket = "red", "compile:" + d["error"].partition(":")[0].strip()
            elif reals:
                status, bucket = "red", min(reals)
            else:
                status, bucket = "green", None
            row = {"build_key": bkey(key), "module": d["module"], "commit": d["sha"][:12], "commit_seq": d["seq"],
                   "host": d["host"], "attempt": d["attempt"], "started_utc": iso_ms(d["cor"]),
                   "duration_ms": d["dur"], "status": status, "bucket": bucket}
            report.append(row)
            by_mod.setdefault(d["module"], []).append(row)
            real[key] = len(reals) if d["status"] == "pass" else 0
            executed[key] = n_exec
        report.sort(key=lambda x: (x["commit_seq"], x["module"], x["build_key"]))
        seq_sha = {s: sha for sha, s in f.commit_seq.items()}
        active = sorted(m for m, dec in f.decom.items() if dec is None or dec > self.W0)
        carried = f.opening.get("last_good", {})
        carried_seq = f.opening.get("last_good_seq", {})
        lg_out = dict(carried)
        lg_seq_out = dict(carried_seq)
        core, metrics = [], []
        for m in active:
            rows = by_mod.get(m, [])
            lg_ord = carried_seq.get(m)
            lg_sha = carried.get(m)
            e = {"module": m, "state": None, "last_good": lg_sha, "first_bad": None, "suspects": None,
                 "dominant_bucket": None}
            if not rows:
                e["state"] = "unbuilt"
            elif all(x["status"] == "infra" for x in rows):
                e["state"] = "infra-only"
            else:
                cs = {}
                for x in rows:
                    if x["status"] == "infra":
                        continue
                    red = x["status"] == "red" or cs.get(x["commit_seq"]) == "red"
                    cs[x["commit_seq"]] = "red" if red else "green"
                greens = [o for o, s in cs.items() if s == "green"]
                if greens and (lg_ord is None or max(greens) > lg_ord):
                    lg_ord = max(greens)
                    lg_sha = seq_sha[lg_ord][:12]
                reds = sorted(o for o, s in cs.items() if s == "red" and (lg_ord is None or o > lg_ord))
                e["last_good"] = lg_sha
                if reds:
                    fb = reds[0]
                    e["state"] = "red"
                    e["first_bad"] = seq_sha[fb][:12]
                    e["suspects"] = fb - lg_ord if lg_ord is not None else None
                    cnt = {}
                    for x in rows:
                        if x["status"] == "red" and x["commit_seq"] >= fb:
                            cnt[x["bucket"]] = cnt.get(x["bucket"], 0) + 1
                    e["dominant_bucket"] = min(cnt, key=lambda b: (-cnt[b], b))
                else:
                    e["state"] = "green"
            if lg_sha is not None:
                lg_out[m] = lg_sha
                lg_seq_out[m] = lg_ord
            core.append(e)
            green = sum(1 for x in rows if x["status"] == "green")
            red = sum(1 for x in rows if x["status"] == "red")
            infra = sum(1 for x in rows if x["status"] == "infra")
            durs = sorted(x["duration_ms"] for x in rows if x["status"] != "infra" and x["duration_ms"] is not None)
            keys = [int(x["build_key"][1:]) for x in rows]
            metrics.append({
                "module": m, "deciding": len(rows), "green": green, "red": red, "infra": infra,
                "tests_executed": sum(executed[k] for k in keys), "real_failures": sum(real[k] for k in keys),
                "flaky_tests": sum(1 for t in flaky if t.split("::")[0] == m),
                "pass_rate": half_even_4(green, green + red) if green + red else None,
                "median_duration_ms": durs[(len(durs) - 1) // 2] if durs else None,
            })
        self.report, self.core, self.metrics = report, core, metrics
        self.flaky = flaky
        self.last_good = {k: lg_out[k] for k in sorted(lg_out)}
        self.last_good_seq = {k: lg_seq_out[k] for k in sorted(lg_seq_out)}
        self.seen = sorted(set(f.opening.get("seen_build_keys", [])) | {x["build_key"] for x in report})
