# trainyard

Stage ledger reconciler for the Trainyard CI estate. It reads one stage feed
(the directory a feed index describes) and the closing state of the previous
stage, and writes the stage ledger.

    python -m trainyard reconcile --feed DIR --resume STATE --out DIR

The rules live in the CI ledger specification (revision C) and the documents it
incorporates; this package implements them. Runtime: Python 3.12, standard
library plus the dependencies declared in pyproject.toml.

Run the tests with `python -m unittest discover -s tests` and `src` on the path.

Modules:

- `readers` - one reader per feed format, returning the control block and tables
- `conventions` - identifiers, numbers, durations, timestamps (spec section 3)
- `feed` - feed index, control chain and reference registers (sections 2 and 4)
- `ledger` - attempts, test results, classification, bisection, metrics (4 to 8)
- `crash` - stacks and symbolication (6)
- `deps` - dependency resolution (9)
- `report` - the six output files (10)
