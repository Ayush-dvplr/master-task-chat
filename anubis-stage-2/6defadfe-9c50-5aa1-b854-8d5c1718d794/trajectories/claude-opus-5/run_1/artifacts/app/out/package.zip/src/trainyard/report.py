"""Output files (specification section 10)."""
from __future__ import annotations

import json
from pathlib import Path

from .conventions import iso_s
from .deps import resolve
from .feed import Feed
from .ledger import Ledger

OUTPUTS = ("build_report.json", "module_core.json", "module_metrics.json", "dependency_resolution.json",
           "selftest.json", "summary.json")


def write_json(path: Path, obj) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


def reconcile(feed_dir: Path, resume: Path, out: Path) -> dict:
    opening = json.loads(Path(resume).read_text(encoding="utf-8"))
    feed = Feed(feed_dir, opening)
    led = Ledger(feed)
    led.compute()
    deps = resolve(feed)
    stamp = {"run_control": feed.run_control, "stage": feed.stage}
    W0, W1 = feed.window
    totals = {
        "builds_accepted": len(led.report),
        "builds_green": sum(1 for x in led.report if x["status"] == "green"),
        "builds_red": sum(1 for x in led.report if x["status"] == "red"),
        "builds_infra": sum(1 for x in led.report if x["status"] == "infra"),
        "modules_red": sum(1 for x in led.core if x["state"] == "red"),
        "crash_buckets": sum(1 for x in led.report if x["bucket"] and x["bucket"].startswith("crash:")),
        "requirements": sum(len(m["requirements"]) for m in deps),
        "unresolvable": sum(1 for m in deps for q in m["requirements"] if q["source"] == "unresolvable"),
    }
    outputs = {
        "build_report.json": {**stamp, "builds": led.report},
        "module_core.json": {**stamp, "modules": led.core},
        "module_metrics.json": {**stamp, "modules": led.metrics},
        "dependency_resolution.json": {**stamp, "cut": iso_s(W1), "modules": deps},
        "selftest.json": {**stamp, "opening": opening["run_control"], "files": feed.chain},
        "summary.json": {**stamp, "window": {"start": iso_s(W0), "end": iso_s(W1)}, "totals": totals,
                         "last_good": led.last_good, "last_good_seq": led.last_good_seq,
                         "open_flaky": sorted(led.flaky), "seen_build_keys": led.seen},
    }
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    for name in OUTPUTS:
        write_json(out / name, outputs[name])
    return outputs
