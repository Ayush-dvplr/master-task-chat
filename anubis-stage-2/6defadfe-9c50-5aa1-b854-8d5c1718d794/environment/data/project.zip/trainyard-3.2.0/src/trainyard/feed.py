"""Feed discovery, control chain and the reference registers."""
from __future__ import annotations

import bisect
import hashlib
import json
from datetime import date, datetime
from pathlib import Path

from . import readers
from .conventions import (UTC, canonical_columns, cell, norm_ref, norm_test, parse_control, parse_iso,
                          parse_key, parse_number)


class FeedError(Exception):
    pass


def chain_link(prev: str, file_id: str, records, control) -> str:
    text = f"{prev}|{file_id}|{records}|{control}"
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:24]


def rows_of(table) -> list[dict]:
    cols = canonical_columns(table.columns)
    return [dict(zip(cols, r)) for r in table.rows]


class Feed:
    def __init__(self, feed_dir: Path, opening: dict):
        self.dir = Path(feed_dir)
        self.opening = opening
        index_path = self._find_index()
        idx = json.loads(index_path.read_text(encoding="utf-8"))
        self.index = idx
        self.stage = idx["stage"]
        self.window = (parse_iso(idx["window"]["start"]), parse_iso(idx["window"]["end"]))
        self.files = sorted(idx["files"], key=lambda f: f["path"])
        self.job_exporter = {j["job"]: j["exporter"] for j in idx["jobs"]}
        self.docs: dict[str, readers.Doc] = {}
        self.meta: dict[str, dict] = {}
        for f in self.files:
            path = self.dir / f["path"]
            if f["role"] == "index":
                doc = readers.Doc(idx["control"], [], {"records": len(idx["files"]) + len(idx["jobs"])})
            else:
                doc = readers.read(path, f["format"], f["role"])
            self.docs[f["file_id"]] = doc
            self.meta[f["file_id"]] = f
        self.chain = []
        link = opening["run_control"]
        for f in self.files:
            doc = self.docs[f["file_id"]]
            c = doc.control
            if c.get("file_id") != f["file_id"]:
                raise FeedError(f"control block of {f['path']} names {c.get('file_id')}")
            link = chain_link(link, f["file_id"], c["records"], c["control"])
            self.chain.append({"file_id": f["file_id"], "role": f["role"], "declared": int(c["records"]),
                               "read": doc.records, "link": link})
        self.run_control = link
        self._load_registers()

    def _find_index(self) -> Path:
        return self.dir / "feed_index.json"
        for p in sorted(self.dir.iterdir()):
            if p.suffix == ".json":
                try:
                    obj = json.loads(p.read_text(encoding="utf-8"))
                except (ValueError, UnicodeDecodeError):
                    continue
                if isinstance(obj, dict) and isinstance(obj.get("control"), dict) \
                        and obj["control"].get("role") == "index":
                    return p
        raise FeedError("no feed index in the feed directory")

    def by_role(self, role: str) -> list[tuple[str, readers.Doc]]:
        return [(f["file_id"], self.docs[f["file_id"]]) for f in self.files if f["role"] == role]

    def one(self, role: str) -> readers.Doc:
        found = self.by_role(role)
        if len(found) != 1:
            raise FeedError(f"expected one file of role {role}, found {len(found)}")
        return found[0][1]

    # ------------------------------------------------------------------ registers
    def _load_registers(self) -> None:
        W0, W1 = self.window
        gov = self.one("governance")
        self.rank = {cell(r["exporter"]): int(cell(r["rank"])) for r in rows_of(gov.table("exporter_rank"))}
        self.pool = {cell(r["host"]).lower(): cell(r["pool"]) for r in rows_of(gov.table("host_pools"))}
        spec = self.one("spec")
        self.legacy_key = {cell(r["legacy_key"]): parse_key(r["build_key"])[1]
                           for r in rows_of(spec.table("legacy_keys"))}
        draft = self.one("spec_draft")
        self.legacy_job = {cell(r["legacy_code"]): cell(r["job"]) for r in rows_of(draft.table("legacy_jobs"))}
        acts = sorted(((int(cell(r["seq"])), cell(r["job"]), cell(r["action"]))
                       for r in rows_of(self.one("readme").table("job_revocations"))))
        self.revoked = {}
        for _, job, act in acts:
            self.revoked.setdefault(job, act == "revoke")
        self.branch_class = {cell(r["branch"]): cell(r["class"])
                             for r in rows_of(self.one("scope_memo").table("branch_register"))}
        # modules and aliases
        reg = self.one("modules")
        self.decom = {}
        for r in rows_of(reg.table("modules")):
            self.decom[norm_ref(cell(r["module"]))] = parse_iso(r["decommissioned_at"])
        aliases = []
        for r in rows_of(reg.table("aliases")):
            aliases.append((norm_ref(cell(r["alias"])), norm_ref(cell(r["module"])),
                            parse_iso(r["valid_from"]), parse_iso(r["valid_to"])))
        for r in rows_of(self.one("modules_next").tables[0]):
            frm = parse_iso(r["from"])
            if frm is None:
                aliases.append((norm_ref(cell(r["name"])), norm_ref(cell(r["module"])), frm, parse_iso(r["to"])))
        self.aliases: dict[str, list] = {}
        for a, m, frm, to in aliases:
            self.aliases.setdefault(a, []).append((m, frm, to))
        # tests
        self.registry = {}
        for r in rows_of(self.one("test_registry").table("tests")):
            mod, name = norm_test(r["test"])
            self.registry[(mod, name)] = (parse_iso(r["registered_at"]), parse_iso(r["retired_at"]))
        revoked = {int(cell(r["seq"])) for r in rows_of(self.one("flaky_dash").table("quarantine_revocations"))}
        self.quarantine: dict[tuple, list] = {}
        for r in rows_of(self.one("quarantine").table("entries")):
            seq = int(cell(r["seq"]))
            self.quarantine.setdefault(norm_test(r["test"]), []).append((parse_iso(r["at"]), seq, cell(r["action"])))
        for v in self.quarantine.values():
            v.sort()
        # hosts
        self.site = {}
        self.host_tz = {}
        for r in rows_of(self.one("hosts").tables[0]):
            self.site[cell(r["name"]).lower()] = cell(r["site"])
            self.host_tz[cell(r["name"]).lower()] = cell(r["tz"])
        for r in rows_of(self.one("hosts_cmdb").tables[0]):
            self.site[cell(r["name"]).lower()] = cell(r["site"])
        self.tzh: dict[str, list] = {}
        for r in rows_of(self.one("tz_history").table("tz_history")):
            self.tzh.setdefault(cell(r["host"]).lower(), []).append(
                (date.fromisoformat(cell(r["effective_date"])), cell(r["tz"])))
        for v in self.tzh.values():
            v.sort()
        self.skew: dict[str, list] = {}
        for r in rows_of(self.one("skew").tables[0]):
            off = cell(r["offset_ms"])
            self.skew.setdefault(cell(r["host"]).lower(), []).append(
                (parse_iso(r["measured_at"]), int(parse_number(off, "en"))))
        for v in self.skew.values():
            v.sort()
        self.skew_est = {}
        for r in rows_of(self.one("skew_est").tables[0]):
            self.skew_est[cell(r["host"]).lower()] = int(parse_number(r["offset_ms"], "en"))
        # maintenance and incidents
        self.maint = {}
        from .conventions import local_to_utc
        for r in self.one("maintenance").tables[0].rows:
            uid, dts, dte, status, seq, site = r
            s = _ics_time(dts)
            e = _ics_time(dte)
            seqn = int(seq[0] or 0)
            cur = self.maint.get(uid[0])
            if cur is None:
                self.maint[uid[0]] = (seqn, site[0], s, e, status[0])
        self.maint_by_site: dict[str, list] = {}
        for seqn, site, s, e, status in self.maint.values():
            if status != "TENTATIVE":
                self.maint_by_site.setdefault(site, []).append((s, e))
        self.incidents: dict[str, list] = {}
        for r in rows_of(self.one("known_issues").table("host_incidents")):
            self.incidents.setdefault(cell(r["host"]).lower(), []).append((parse_iso(r["start"]), parse_iso(r["end"])))
        _ = local_to_utc
        # voids
        acts = []
        for fid, doc in self.by_role("voids"):
            for r in rows_of(doc.tables[0]):
                acts.append((int(cell(r["seq"])), parse_key(r["build_key"])[1], cell(r["action"])))
        for r in rows_of(self.one("voids_v2").tables[0]):
            if cell(r["countersigned"]).lower() in ("yes", "no"):
                acts.append((int(cell(r["seq"])), parse_key(r["build_key"])[1], cell(r["action"])))
        self.void_state = {}
        for _, k, act in acts:
            self.void_state[k] = act
        # errata
        self.errata = {}
        for r in sorted(rows_of(self.one("errata").table("corrections")), key=lambda r: cell(r["id"])):
            self.errata[(parse_key(r["build_key"])[1], int(cell(r["attempt"])), cell(r["field"]))] = cell(r["value"])
        eb = {}
        for r in sorted(rows_of(self.one("errata_b").table("corrections")), key=lambda r: cell(r["id"])):
            if cell(r["status"]) == "approved":
                eb[(parse_key(r["build_key"])[1], int(cell(r["attempt"])), cell(r["field"]))] = cell(r["value"])
        for k, v in eb.items():
            self.errata.setdefault(k, v)
        # commits
        self.commit_seq = {}
        for r in rows_of(self.one("commits").tables[0]):
            self.commit_seq[cell(r["commit"]).lower()] = len(self.commit_seq)
        self.shas = sorted(self.commit_seq)
        self.rewritten = {}
        for r in rows_of(self.one("commits").tables[0]):
            old = cell(r["rewritten_from"]).lower()
            if old:
                self.rewritten[old] = cell(r["commit"]).lower()
        pins = {}
        for r in rows_of(self.one("toolchain_pins").tables[0]):
            k = cell(r["commit"]).lower()
            rev = int(cell(r["rev"]))
            if k not in pins:
                pins[k] = (rev, cell(r["toolchain"]))
        self.pins = {k: v[1] for k, v in pins.items()}

    # ------------------------------------------------------------------ lookups
    def resolve_module(self, ref: str, t: datetime):
        for m, frm, to in self.aliases.get(norm_ref(ref), []):
            if (frm is None or frm <= t) and (to is None or t < to):
                return m
        return None

    def resolve_commit(self, ref: str):
        ref = cell(ref).lower()
        i = bisect.bisect_left(self.shas, ref)
        if i < len(self.shas) and self.shas[i].startswith(ref):
            return self.shas[i]
        for old, new in self.rewritten.items():
            if old.startswith(ref):
                return new
        return None

    def tz_of(self, host: str, local_day: date) -> str:
        tz = None
        tz = self.host_tz.get(host)
        if tz is None:
            raise FeedError(f"no time zone for host {host}")
        return tz

    def offset(self, host: str, t: datetime) -> int:
        if host in self.skew:
            ms = self.skew[host]
            i = len(ms) - 1
            return ms[i][1] if i >= 0 else 0
        return 0

    def toolchain(self, sha: str) -> str:
        return self.pins[sha[:12]]


def _ics_time(v):
    from datetime import datetime as _dt
    from zoneinfo import ZoneInfo
    value, tzid = v
    if value.endswith("Z"):
        return _dt.strptime(value, "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
    naive = _dt.strptime(value, "%Y%m%dT%H%M%S")
    return naive.replace(tzinfo=ZoneInfo(tzid or "UTC")).astimezone(UTC)


_ = parse_control
