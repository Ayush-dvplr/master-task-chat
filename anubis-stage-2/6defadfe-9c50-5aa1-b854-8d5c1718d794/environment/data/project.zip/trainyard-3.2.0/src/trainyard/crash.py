"""Crash stacks and symbolication (specification section 6)."""
from __future__ import annotations

import bisect

from .conventions import cell
from .feed import FeedError, rows_of


class Symbolicator:
    def __init__(self, feed):
        self.f = feed
        self.stores = {}
        for fid, doc in feed.by_role("symbols"):
            tc = doc.control["toolchain"]
            for t in doc.tables:
                img = t.name if f"link_base.{t.name}" in doc.control else doc.control["image"]
                base = int(doc.control[f"link_base.{img}"], 16)
                rows = sorted((int(cell(r[0]), 16), int(cell(r[1])), cell(r[2])) for r in t.rows)
                self.stores[(img, tc)] = ([s for s, _, _ in rows], rows, base)
        self.buildid = {}
        relink = feed.one("symbols_relink")
        for r in rows_of(relink.table("buildid_map")):
            self.buildid[cell(r["prefix"]).lower()] = (cell(r["image"]), cell(r["toolchain"]))
        self.register = {}
        for r in rows_of(feed.one("frame_register").table("frame_register")):
            self.register[cell(r["symbol"])] = (cell(r["label"]), cell(r["class"]))
        self.stacks = {}
        msgid = {}
        for r in rows_of(feed.one("crash_index").tables[0]):
            msgid[cell(r["message_id"])] = cell(r["crash"])
        best = {}
        for r in rows_of(feed.one("crash_mail").tables[0]):
            cid = cell(r["crash"])
            if not cid:
                continue
            rev = int(cell(r["rev"]))
            if cid not in best:
                best[cid] = (rev, cell(r["frames"]).split())
        for cid, (_, frames) in best.items():
            self.stacks[cid] = frames
        for r in rows_of(feed.one("crash_legacy").tables[0]):
            self.stacks.setdefault(cell(r["crash"]), cell(r["frames"]).split())

    def label(self, crash_id: str, sha: str) -> str:
        frames = self.stacks.get(crash_id)
        if frames is None:
            return "unknown"
        tc_commit = self.f.toolchain(sha)
        for i, fr in enumerate(frames):
            where, _, off = fr.partition("+0x")
            offset = int(off, 16)
            if where.startswith("bid:"):
                img, tc = self.buildid[where[4:].lower()]
            else:
                img, tc = where, tc_commit
            starts, rows, base = self.stores[(img, tc)]
            addr = base + offset
            j = bisect.bisect_right(starts, addr) - 1
            if j < 0 or addr >= rows[j][0] + rows[j][1]:
                return f"{img}+0x{off.lower()}"
            sym = rows[j][2]
            info = self.register.get(sym)
            return info[0] if info else sym
        return "unknown"


def crash_labels(feed):
    return Symbolicator(feed)
