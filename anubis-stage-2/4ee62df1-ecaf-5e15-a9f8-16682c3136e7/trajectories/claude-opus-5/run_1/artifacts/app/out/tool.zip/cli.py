#!/usr/bin/env python3
"""sealb-ctl - offline, stdlib-only security policy compiler."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

TOOL = "sealb-ctl"
DATA_DEFAULT = "/app/data"
OUT_DEFAULT = "/app/out"

INT_KEYS = ("handshake_timeout_ms", "max_sessions", "rekey_interval_s", "retry_budget")
SPINE_KEYS = INT_KEYS + ("mode",)
FLAG_TOKEN = "active"

R_MOD = 97
J_MOD = 31
Z_MOD = 53


# --------------------------------------------------------------------------- io


def dump_json(obj):
    return json.dumps(
        obj, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False
    ) + "\n"


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def write_json(path, obj):
    write_text(path, dump_json(obj))


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha256_bytes(blob):
    return hashlib.sha256(blob).hexdigest()


def sha256_file(path):
    return sha256_bytes(Path(path).read_bytes())


# ------------------------------------------------------------------- canonical


def canonical_int(value):
    """Return the integer of a canonical base-10 integer field, else None."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if not isinstance(value, str):
        return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if str(number) == value else None


# ---------------------------------------------------------------- spine replay


def journal_ops(data):
    ops = []
    text = (Path(data) / "change_journal.jsonl").read_text(encoding="utf-8")
    for line in text.splitlines():
        if not line.strip():
            continue
        ops.append(json.loads(line))
    ops.sort(key=lambda op: op["seq"])
    return ops


def _default_of(defaults, key):
    if key == "mode":
        return defaults["mode"]
    return defaults["base_config"][key]


def op_is_valid(op, state, rules):
    if op.get("env") not in rules["journal_envs"]:
        return False
    key = op.get("key")
    if key not in SPINE_KEYS:
        return False
    kind = op.get("op")
    if kind == "unset":
        return True
    if kind not in ("set", "touch"):
        return False
    if "value" not in op:
        return False
    value = op["value"]
    if key == "mode":
        if not isinstance(value, str):
            return False
        if kind == "touch":
            return value == state["mode"]
        return value in rules["allowed_modes"]
    if isinstance(value, bool) or not isinstance(value, int):
        return False
    if kind == "touch":
        return value == state[key]
    low, high = rules["bounds"][key]
    if not low <= value <= high:
        return False
    if key == "max_sessions":
        window = state["handshake_timeout_ms"]
        if window <= 0:
            return False
        if value > state["rekey_interval_s"] // window:
            return False
    return True


def apply_op(op, state, defaults):
    if op["op"] == "set":
        state[op["key"]] = op["value"]
    elif op["op"] == "unset":
        state[op["key"]] = _default_of(defaults, op["key"])


def replay(data, env=None, initial=None):
    """Replay the journal in ascending seq; env=None judges every recorded env."""
    data = Path(data)
    defaults = load_json(data / "defaults.json")
    rules = load_json(data / "validation_rules.json")
    if initial is None:
        state = {key: defaults["base_config"][key] for key in INT_KEYS}
        state["mode"] = defaults["mode"]
    else:
        state = dict(initial)
    rejected = []
    touch_rejected = 0
    for op in journal_ops(data):
        if env is not None and op.get("env") != env:
            continue
        if op_is_valid(op, state, rules):
            apply_op(op, state, defaults)
        else:
            rejected.append(op["seq"])
            if op.get("op") == "touch":
                touch_rejected += 1
    return {"state": state, "rejected": rejected, "touch_rejected": touch_rejected}


# --------------------------------------------------------------------- policies


def base_policy(data):
    data = Path(data)
    schema = load_json(data / "config_schema.json")
    defaults = load_json(data / "defaults.json")
    state = replay(data)["state"]
    policy = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": defaults["checksum"],
        "trailer": defaults["base_config"]["trailer"],
    }
    for key in SPINE_KEYS:
        policy[key] = state[key]
    return policy


def zone_policy(data, zone, config_digest):
    data = Path(data)
    overrides = load_json(data / "env_overrides.json")[zone]
    policy = base_policy(data)
    spine_trailer = policy["trailer"]
    policy["retry_budget"] += overrides["retry_budget_delta"]
    policy["handshake_timeout_ms"] += overrides["handshake_timeout_ms_delta"]
    policy["rekey_interval_s"] += overrides["rekey_interval_s_delta"]
    policy["mode"] = overrides["mode"]
    policy["profile"] = "{}-{}".format(policy["profile"], zone)
    policy["trailer"] = "{}:{}:{}".format(spine_trailer, zone, config_digest[:8])
    initial = {key: policy[key] for key in SPINE_KEYS}
    policy.update(replay(data, env=zone, initial=initial)["state"])
    return policy


def resolve_policy(data, env, out):
    if env == "base":
        return base_policy(data)
    digest = sha256_file(Path(out) / "config.json")
    return zone_policy(data, env, digest)


# ----------------------------------------------------------------- corpus table


CORPUS_ROW = re.compile(
    r"^\|\s*(c\d{2}_[a-z0-9_]+\.[a-z]+)\s*\|\s*([a-z]+)\s*\|"
    r"\s*([a-z]+)\s*\|\s*(-?\d+)\s*\|\s*(-?\d+)\s*\|$"
)


def corpus_table(data):
    data = Path(data)
    text = (data / "config_contract.md").read_text(encoding="utf-8")
    bounds = load_json(data / "validation_rules.json")["corpus_bounds"]
    table = []
    seen = set()
    for line in text.splitlines():
        match = CORPUS_ROW.match(line.strip())
        if not match:
            continue
        name, fmt, op, low, high = match.groups()
        if name in seen:
            continue
        seen.add(name)
        published = bounds[name.rsplit(".", 1)[0]]
        if [int(low), int(high)] != list(published):
            raise SystemExit("corpus bound mismatch for " + name)
        table.append(
            {
                "name": name,
                "format": fmt,
                "op": op,
                "lo": published[0],
                "hi": published[1],
            }
        )
    return table


# -------------------------------------------------------------- corpus parsing

CHAR_SEPS = {
    "csv": ",",
    "tsv": "\t",
    "psv": "|",
    "scsv": ";",
    "colon": ":",
    "caret": "^",
    "at": "@",
    "bang": "!",
    "tilde": "~",
    "dcolon": "::",
}


def _skip(line):
    stripped = line.strip()
    return not stripped or stripped[0] == "#"


def _sep_records(text, sep):
    records = []
    for line in text.splitlines():
        if _skip(line):
            continue
        fields = line.split(sep)
        if len(fields) != 3:
            continue
        records.append(tuple(fields))
    return records


def _ssv_records(text):
    records = []
    for line in text.splitlines():
        if _skip(line):
            continue
        fields = re.split(r" +", line)
        if len(fields) != 3:
            continue
        records.append(tuple(fields))
    return records


def _kv_records(text):
    records = []
    for line in text.splitlines():
        if _skip(line):
            continue
        fields = line.split(" ")
        if len(fields) != 3:
            continue
        slots = {}
        for field in fields:
            key, sep, value = field.partition("=")
            if sep:
                slots[key] = value
        if set(slots) != {"zone", "value", "flag"}:
            continue
        records.append((slots["zone"], slots["value"], slots["flag"]))
    return records


def _fixed_records(text):
    records = []
    for line in text.splitlines():
        if _skip(line):
            continue
        records.append((line[0:10].rstrip(), line[10:30].rstrip(), line[30:]))
    return records


def _md_records(text):
    records = []
    for line in text.splitlines():
        if _skip(line):
            continue
        if not (line.startswith("| ") and line.endswith(" |")):
            continue
        fields = line[2:-2].split(" | ")
        if len(fields) != 3:
            continue
        records.append(tuple(fields))
    return records


def _ini_records(text):
    records = []
    current = None

    def flush(row):
        if row is not None and set(row) == {"zone", "value", "flag"}:
            records.append((row["zone"], row["value"], row["flag"]))

    for line in text.splitlines():
        if _skip(line):
            continue
        if line.startswith("[") and line.endswith("]"):
            flush(current)
            current = {}
            continue
        if current is None:
            continue
        key, sep, value = line.partition(" = ")
        if not sep:
            key, sep, value = line.partition("=")
            if not sep:
                continue
            key = key.rstrip()
        current[key] = value
    flush(current)
    return records


def _props_records(text):
    order = []
    rows = {}
    for line in text.splitlines():
        if _skip(line):
            continue
        key, sep, value = line.partition("=")
        if not sep or "." not in key:
            continue
        row_id, _, field = key.rpartition(".")
        if field not in ("zone", "value", "flag"):
            continue
        if row_id not in rows:
            rows[row_id] = {}
            order.append(row_id)
        rows[row_id][field] = value
    records = []
    for row_id in order:
        row = rows[row_id]
        if set(row) == {"zone", "value", "flag"}:
            records.append((row["zone"], row["value"], row["flag"]))
    return records


def _dict_records(items):
    records = []
    for item in items:
        if not isinstance(item, dict):
            continue
        if not {"zone", "value", "flag"} <= set(item):
            continue
        records.append((item["zone"], item["value"], item["flag"]))
    return records


def _jsonarr_records(text):
    return _dict_records(json.loads(text))


def _jsonl_records(text):
    items = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("//") or stripped.startswith("#"):
            continue
        items.append(json.loads(stripped))
    return _dict_records(items)


def _xmlflat_records(text):
    records = []
    for row in ET.fromstring(text).findall("row"):
        if not {"zone", "value", "flag"} <= set(row.attrib):
            continue
        records.append((row.get("zone"), row.get("value"), row.get("flag")))
    return records


def _xmlnest_records(text):
    records = []
    for row in ET.fromstring(text).findall("row"):
        fields = []
        for name in ("zone", "value", "flag"):
            node = row.find(name)
            if node is None:
                fields = None
                break
            fields.append(node.text if node.text is not None else "")
        if fields is None:
            continue
        records.append(tuple(fields))
    return records


PARSERS = {
    "ssv": _ssv_records,
    "kvline": _kv_records,
    "fixed": _fixed_records,
    "mdtable": _md_records,
    "ini": _ini_records,
    "props": _props_records,
    "jsonarr": _jsonarr_records,
    "jsonl": _jsonl_records,
    "xmlflat": _xmlflat_records,
    "xmlnest": _xmlnest_records,
}


def corpus_records(path, fmt):
    text = Path(path).read_text(encoding="utf-8")
    if fmt in CHAR_SEPS:
        return _sep_records(text, CHAR_SEPS[fmt])
    if fmt in PARSERS:
        return PARSERS[fmt](text)
    raise SystemExit("unknown corpus format: " + fmt)


# ------------------------------------------------------------------ aggregation


def active_zones(data):
    return tuple(load_json(Path(data) / "validation_rules.json")["zones"])


def shifts(data, out):
    data, out = Path(data), Path(out)
    rekey = load_json(out / "config.json")["rekey_interval_s"]
    rejected = len(replay(data)["rejected"])
    zed = int(sha256_file(out / "tool.zip")[:16], 16)
    return {
        "R": rekey,
        "J": rejected,
        "Z": zed,
        "r_shift": rekey % R_MOD,
        "j_shift": rejected % J_MOD,
        "z_shift": zed % Z_MOD,
        "total": rekey % R_MOD + rejected % J_MOD + zed % Z_MOD,
    }


def reduce_corpus(data, entry, shift, zones):
    values = []
    per_zone = {zone: 0 for zone in zones}
    low = entry["lo"]
    high = entry["hi"] + shift
    path = Path(data) / entry["name"]
    for zone, value, flag in corpus_records(path, entry["format"]):
        if not isinstance(zone, str) or zone not in zones:
            continue
        if not isinstance(flag, str) or flag != FLAG_TOKEN:
            continue
        number = canonical_int(value)
        if number is None or not low <= number <= high:
            continue
        values.append(number)
        per_zone[zone] += 1
    op = entry["op"]
    if op == "count":
        result = len(values)
    elif not values:
        result = 0
    elif op == "max":
        result = max(values)
    elif op == "min":
        result = min(values)
    elif op == "sum":
        result = sum(values)
    elif op == "first":
        result = values[0]
    elif op == "last":
        result = values[-1]
    else:
        raise SystemExit("unknown operator: " + op)
    return {"value": result, "rows": len(values), "zones": per_zone}


def reduce_all(data, out):
    data = Path(data)
    zones = active_zones(data)
    shift = shifts(data, out)["total"]
    table = corpus_table(data)
    results = {
        entry["name"]: reduce_corpus(data, entry, shift, zones) for entry in table
    }
    return {"table": table, "results": results, "zones": zones, "shift": shift}


# --------------------------------------------------------------------- mirrors


def aggregate_mirrors(out, aggregates):
    out = Path(out)
    names = sorted(aggregates)
    write_json(out / "aggregates.json", aggregates)

    rows = ["corpus,value"] + ["{},{}".format(n, aggregates[n]) for n in names]
    write_text(out / "aggregates.csv", "\n".join(rows) + "\n")

    rows = ["corpus\tvalue"] + ["{}\t{}".format(n, aggregates[n]) for n in names]
    write_text(out / "aggregates.tsv", "\n".join(rows) + "\n")

    rows = ["[aggregates]"] + ["{} = {}".format(n, aggregates[n]) for n in names]
    write_text(out / "aggregates.ini", "\n".join(rows) + "\n")

    rows = ["{}={}".format(n.upper(), aggregates[n]) for n in names]
    write_text(out / "aggregates.env", "\n".join(rows) + "\n")

    rows = ["| corpus | value |", "| --- | --- |"]
    rows += ["| {} | {} |".format(n, aggregates[n]) for n in names]
    write_text(out / "aggregates.md", "\n".join(rows) + "\n")

    rows = ["{} {}".format(n, aggregates[n]) for n in names]
    write_text(out / "aggregates.txt", "\n".join(rows) + "\n")

    root = ET.Element("aggregates")
    for name in names:
        ET.SubElement(root, "corpus", {"name": name, "value": str(aggregates[name])})
    write_text(out / "aggregates.xml", ET.tostring(root, encoding="unicode") + "\n")


# -------------------------------------------------------------------- commands


def cmd_init(args):
    schema = load_json(args.schema)
    write_json(
        args.out,
        {
            "profile": schema["profile"],
            "producer": schema["producer"],
            "container": schema["container"],
            "checksum": schema["checksum"],
        },
    )
    print("initialized")


def cmd_set(args):
    config = load_json(args.config)
    value = args.value
    try:
        number = int(value)
    except ValueError:
        number = None
    if number is not None and str(number) == value:
        value = number
    config[args.key] = value
    write_json(args.config, config)
    print("set " + args.key)


def cmd_validate(args):
    schema = load_json(args.schema)
    config = load_json(args.config)
    required = schema["required_keys"]
    if isinstance(required, str):
        required = required.split(",")
    missing = [key for key in required if key not in config]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if any(isinstance(value, (dict, list)) for value in config.values()):
        raise SystemExit("configuration must be flat")
    print("ok")


def cmd_plan(args):
    sys.stdout.write(dump_json(resolve_policy(args.data, args.env, args.out)))


def cmd_compile(args):
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    reduced = reduce_all(args.data, out)
    aggregates = {name: res["value"] for name, res in reduced["results"].items()}
    aggregate_mirrors(out, aggregates)

    totals = {zone: 0 for zone in reduced["zones"]}
    for result in reduced["results"].values():
        for zone, count in result["zones"].items():
            totals[zone] += count
    write_json(out / "zone_totals.json", totals)

    corpora = [
        {
            "name": entry["name"],
            "format": entry["format"],
            "op": entry["op"],
            "lo": entry["lo"],
            "hi": entry["hi"],
            "eligible_rows": reduced["results"][entry["name"]]["rows"],
            "value": reduced["results"][entry["name"]]["value"],
        }
        for entry in reduced["table"]
    ]
    write_json(out / "corpus_index.json", {"count": len(corpora), "corpora": corpora})
    print("compiled " + str(len(corpora)))


def cmd_aggregate(args):
    data = Path(args.data)
    table = {entry["name"]: entry for entry in corpus_table(data)}
    name = args.corpus
    if name not in table:
        matches = [key for key in table if key.rsplit(".", 1)[0] == name]
        if len(matches) != 1:
            raise SystemExit("unknown corpus: " + args.corpus)
        name = matches[0]
    shift = shifts(data, args.out)["total"]
    print(reduce_corpus(data, table[name], shift, active_zones(data))["value"])


def cmd_report(args):
    config = load_json(args.config)
    raw = args.commands
    if raw.startswith("@"):
        raw = Path(raw[1:]).read_text(encoding="utf-8")
    commands = list(json.loads(raw))
    commands.append({"argv": [TOOL] + sys.argv[1:], "returncode": 0, "stdout": "ok\n"})
    write_json(
        args.out,
        {
            "ok": True,
            "tool": TOOL,
            "config_path": str(args.config),
            "config_sha256": args.digest,
            "trailer": config["trailer"],
            "commands": commands,
        },
    )
    print("ok")


def main():
    parser = argparse.ArgumentParser(prog=TOOL)
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("plan")
    p.add_argument("--data", default=DATA_DEFAULT)
    p.add_argument("--out", default=OUT_DEFAULT)
    p.add_argument("--env", required=True)
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("compile")
    p.add_argument("--data", default=DATA_DEFAULT)
    p.add_argument("--out", default=OUT_DEFAULT)
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("aggregate")
    p.add_argument("--corpus", required=True)
    p.add_argument("--data", default=DATA_DEFAULT)
    p.add_argument("--out", default=OUT_DEFAULT)
    p.set_defaults(func=cmd_aggregate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    args = parser.parse_args()
    if getattr(args, "func", None) is None:
        parser.print_help()
        raise SystemExit(2)
    args.func(args)


if __name__ == "__main__":
    main()
