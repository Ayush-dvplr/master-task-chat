#!/usr/bin/env python3
"""sealb-ctl - offline, standard-library-only security policy compiler.

Every value this tool emits is derived from the files in the data
directory (``defaults.json``, ``config_schema.json``,
``env_overrides.json``, ``validation_rules.json``,
``change_journal.jsonl``, ``config_contract.md`` and the fifty evidence
corpora).  The tool is deterministic and offline: no network, no wall
clock, no random sources, no reliance on dict insertion order.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

TOOL = "sealb-ctl"
HERE = Path(__file__).resolve().parent
TOOL_SCHEMA = HERE / "schema.json"
DEFAULT_DATA = "/app/data"
DEFAULT_OUT = "/app/out"
MODE_KEY = "mode"
TRAILER_KEY = "trailer"
INT_KEYS = ("handshake_timeout_ms", "max_sessions", "rekey_interval_s", "retry_budget")
DELTA_KEYS = ("handshake_timeout_ms", "rekey_interval_s", "retry_budget")
MUTABLE_KEYS = INT_KEYS + (MODE_KEY,)
OPS = ("set", "touch", "unset")
FLAG_ACTIVE = "active"
CORPUS_ROW_RE = re.compile(
    r"^\|\s*(\S+)\s*\|\s*(\S+)\s*\|\s*(\S+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*$"
)
FIELD_TOKEN_RE = re.compile(r"^([A-Za-z0-9_]+)=(.*)$")
PROPS_LINE_RE = re.compile(r"^([A-Za-z0-9_]+)\.(zone|value|flag)=(.*)$")


# ---------------------------------------------------------------- serialising


def dumps(obj):
    return json.dumps(obj, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False)


def write_json(path, obj):
    Path(path).write_text(dumps(obj) + "\n", encoding="utf-8")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    return sha256_hex(Path(path).read_bytes())


def scalar_only(obj):
    return not any(isinstance(value, (dict, list)) for value in obj.values())


def is_plain_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def is_canonical_int(text):
    """True when the exact field bytes are a canonical base-10 integer.

    ``str(int(value)) == value`` alone is not enough because ``int()``
    silently accepts non-ASCII decimal digits, surrounding whitespace and
    a leading ``+``; those are rejected here before the round trip.
    """
    if not isinstance(text, str) or not text or not text.isascii():
        return False
    try:
        number = int(text)
    except ValueError:
        return False
    return str(number) == text


# ------------------------------------------------------------- policy engine


class Policy:
    """Journal replay, zone profiles and corpus aggregation."""

    def __init__(self, data_dir):
        self.data = Path(data_dir)
        self.defaults = read_json(self.data / "defaults.json")
        self.schema = read_json(self.data / "config_schema.json")
        self.rules = read_json(self.data / "validation_rules.json")
        self.overrides = read_json(self.data / "env_overrides.json")
        self.contract = (self.data / "config_contract.md").read_text(encoding="utf-8")
        self.journal_envs = set(self.rules["journal_envs"])
        self.allowed_modes = set(self.rules["allowed_modes"])
        self.bounds = {key: tuple(pair) for key, pair in self.rules["bounds"].items()}
        self.corpus_bounds = {
            name: tuple(pair) for name, pair in self.rules["corpus_bounds"].items()
        }
        self.zones = list(self.rules["zones"])
        self.journal = self._load_journal()
        self._corpora = None

    # -- journal ---------------------------------------------------------

    def _load_journal(self):
        ops = []
        text = (self.data / "change_journal.jsonl").read_text(encoding="utf-8")
        for line in text.split("\n"):
            if not line.strip():
                continue
            record = json.loads(line)
            if "seq" not in record:
                raise SystemExit("journal record without seq")
            ops.append(record)
        ops.sort(key=lambda record: record["seq"])
        return ops

    def default_for(self, key):
        if key == MODE_KEY:
            return self.defaults[MODE_KEY]
        return self.defaults["base_config"][key]

    def base_state(self):
        state = {key: self.defaults["base_config"][key] for key in INT_KEYS}
        state[MODE_KEY] = self.defaults[MODE_KEY]
        state[TRAILER_KEY] = self.defaults["base_config"][TRAILER_KEY]
        return state

    def op_valid(self, state, op):
        """One journal operation judged against ``state`` as of ``seq - 1``."""
        if op.get("env") not in self.journal_envs:
            return False
        key = op.get("key")
        if key not in MUTABLE_KEYS:
            return False
        kind = op.get("op")
        if kind not in OPS:
            return False
        value = op.get("value")
        if kind == "unset":
            return True
        if kind == "set":
            if key == MODE_KEY:
                return isinstance(value, str) and value in self.allowed_modes
            if not is_plain_int(value):
                return False
            low, high = self.bounds[key]
            if not low <= value <= high:
                return False
            if key == "max_sessions":
                cap = state["rekey_interval_s"] // state["handshake_timeout_ms"]
                if value > cap:
                    return False
            return True
        # touch: type grounds first, then byte equality with the current value
        if key == MODE_KEY:
            return isinstance(value, str) and value == state[MODE_KEY]
        if not is_plain_int(value):
            return False
        return value == state[key]

    def replay(self, start, ops):
        """Apply ``ops`` in ascending seq order; return state and rejects."""
        state = dict(start)
        rejected = []
        touch_rejected = 0
        for op in ops:
            if self.op_valid(state, op):
                kind = op["op"]
                if kind == "set":
                    state[op["key"]] = op["value"]
                elif kind == "unset":
                    state[op["key"]] = self.default_for(op["key"])
            else:
                rejected.append(op["seq"])
                if op.get("op") == "touch":
                    touch_rejected += 1
        return state, rejected, touch_rejected

    def spine_replay(self):
        return self.replay(self.base_state(), self.journal)

    def spine_document(self):
        state, _rejected, _touch = self.spine_replay()
        document = {
            "checksum": self.defaults["checksum"],
            "container": self.schema["container"],
            "profile": self.schema["profile"],
            "producer": self.schema["producer"],
        }
        for key in INT_KEYS:
            document[key] = state[key]
        document[MODE_KEY] = state[MODE_KEY]
        document[TRAILER_KEY] = state[TRAILER_KEY]
        return document

    def profile_document(self, zone, config_sha256):
        spine = self.spine_document()
        override = self.overrides[zone]
        start = {key: spine[key] for key in INT_KEYS}
        for key in DELTA_KEYS:
            start[key] += override[key + "_delta"]
        start[MODE_KEY] = override[MODE_KEY]
        start[TRAILER_KEY] = "%s:%s:%s" % (spine[TRAILER_KEY], zone, config_sha256[:8])
        zone_ops = [op for op in self.journal if op.get("env") == zone]
        state, _rejected, _touch = self.replay(start, zone_ops)
        document = dict(spine)
        for key in INT_KEYS:
            document[key] = state[key]
        document[MODE_KEY] = state[MODE_KEY]
        document[TRAILER_KEY] = state[TRAILER_KEY]
        document["profile"] = "%s-%s" % (spine["profile"], zone)
        return document

    def resolved(self, env, config_sha256):
        if env == "base":
            return self.spine_document()
        if env in self.overrides:
            return self.profile_document(env, config_sha256)
        raise SystemExit("unknown env: " + str(env))

    # -- corpora ---------------------------------------------------------

    def corpus_table(self):
        """Parse the corpus table out of the written contract."""
        if self._corpora is None:
            corpora = {}
            for line in self.contract.split("\n"):
                match = CORPUS_ROW_RE.match(line)
                if not match:
                    continue
                filename, fmt, op, low, high = match.groups()
                name = filename.rsplit(".", 1)[0]
                if name not in self.corpus_bounds:
                    raise SystemExit("contract corpus missing from corpus_bounds: " + name)
                if self.corpus_bounds[name] != (int(low), int(high)):
                    raise SystemExit("contract and rules bounds disagree: " + name)
                corpora[name] = {
                    "name": name,
                    "filename": filename,
                    "format": fmt,
                    "op": op,
                    "lo": int(low),
                    "hi": int(high),
                }
            if sorted(corpora) != sorted(self.corpus_bounds):
                raise SystemExit("contract corpus table does not cover corpus_bounds")
            self._corpora = corpora
        return self._corpora

    def resolve_corpus(self, corpus):
        table = self.corpus_table()
        if corpus in table:
            return table[corpus]
        for entry in table.values():
            if entry["filename"] == corpus:
                return entry
        raise SystemExit("unknown corpus: " + str(corpus))

    @staticmethod
    def _data_lines(text):
        for line in text.split("\n"):
            if not line.strip():
                continue
            if line.lstrip().startswith("#"):
                continue
            yield line

    @staticmethod
    def _split_fields(parts):
        if len(parts) != 3:
            return None
        return parts

    @staticmethod
    def _md_cells(line):
        parts = line.split("|")
        if len(parts) != 5 or parts[0].strip() or parts[-1].strip():
            return None
        cells = []
        for part in parts[1:4]:
            if len(part) < 2 or part[0] != " " or part[-1] != " ":
                return None
            cells.append(part[1:-1])
        return cells

    def parse_rows(self, path, fmt):
        """Return the corpus records as (zone, value, flag) triples."""
        text = Path(path).read_text(encoding="utf-8")
        rows = []
        if fmt in ("csv", "tsv"):
            sep = "," if fmt == "csv" else "\t"
            for line in self._data_lines(text):
                fields = self._split_fields(line.split(sep))
                if fields is None or fields[0] == "zone":
                    continue
                rows.append((fields[0], fields[1], fields[2]))
        elif fmt == "ssv":
            for line in self._data_lines(text):
                fields = self._split_fields(re.split(r" +", line))
                if fields is None or fields[0] == "zone":
                    continue
                rows.append((fields[0], fields[1], fields[2]))
        elif fmt == "dcolon":
            for line in self._data_lines(text):
                fields = self._split_fields(line.split("::"))
                if fields is None:
                    continue
                rows.append((fields[0], fields[1], fields[2]))
        elif fmt in ("psv", "scsv", "colon", "caret", "at", "bang", "tilde"):
            sep = {
                "psv": "|",
                "scsv": ";",
                "colon": ":",
                "caret": "^",
                "at": "@",
                "bang": "!",
                "tilde": "~",
            }[fmt]
            for line in self._data_lines(text):
                fields = self._split_fields(line.split(sep))
                if fields is None:
                    continue
                rows.append((fields[0], fields[1], fields[2]))
        elif fmt == "jsonarr":
            for record in json.loads(text):
                if not isinstance(record, dict):
                    continue
                if not all(field in record for field in ("zone", "value", "flag")):
                    continue
                rows.append((record["zone"], record["value"], record["flag"]))
        elif fmt == "jsonl":
            for line in text.split("\n"):
                stripped = line.strip()
                if not stripped or stripped.startswith("//"):
                    continue
                record = json.loads(stripped)
                if not all(field in record for field in ("zone", "value", "flag")):
                    continue
                rows.append((record["zone"], record["value"], record["flag"]))
        elif fmt == "xmlflat":
            for row in ET.fromstring(text):
                if row.tag != "row":
                    continue
                rows.append((row.get("zone"), row.get("value"), row.get("flag")))
        elif fmt == "xmlnest":
            for row in ET.fromstring(text):
                if row.tag != "row":
                    continue
                cells = {child.tag: child.text for child in row}
                if not all(field in cells for field in ("zone", "value", "flag")):
                    continue
                rows.append((cells["zone"], cells["value"], cells["flag"]))
        elif fmt == "ini":
            records = []
            record = None
            for line in self._data_lines(text):
                if line.startswith("[") and line.endswith("]"):
                    if record is not None:
                        records.append(record)
                    record = {}
                    continue
                if record is None or " = " not in line:
                    continue
                key, value = line.split(" = ", 1)
                record[key] = value
            if record is not None:
                records.append(record)
            for record in records:
                if not all(field in record for field in ("zone", "value", "flag")):
                    continue
                rows.append((record["zone"], record["value"], record["flag"]))
        elif fmt == "fixed":
            for line in self._data_lines(text):
                if len(line) < 30 or line[:4] == "zone":
                    continue
                rows.append((line[:10].rstrip(" "), line[10:30].rstrip(" "), line[30:]))
        elif fmt == "mdtable":
            for line in text.split("\n"):
                stripped = line.strip()
                if not stripped.startswith("|"):
                    continue
                cells = self._md_cells(stripped)
                if cells is None:
                    continue
                if cells[0] == "zone" or all(cell.strip("-") == "" for cell in cells):
                    continue
                rows.append((cells[0], cells[1], cells[2]))
        elif fmt == "kvline":
            for line in self._data_lines(text):
                tokens = line.split(" ")
                if len(tokens) != 3:
                    continue
                record = {}
                ok = True
                for token in tokens:
                    match = FIELD_TOKEN_RE.match(token)
                    if not match or match.group(1) not in ("zone", "value", "flag"):
                        ok = False
                        break
                    record[match.group(1)] = match.group(2)
                if not ok or not all(field in record for field in ("zone", "value", "flag")):
                    continue
                rows.append((record["zone"], record["value"], record["flag"]))
        elif fmt == "props":
            records = {}
            order = []
            for line in self._data_lines(text):
                match = PROPS_LINE_RE.match(line)
                if not match:
                    continue
                record_id, field, value = match.groups()
                if record_id not in records:
                    records[record_id] = {}
                    order.append(record_id)
                records[record_id][field] = value
            for record_id in order:
                record = records[record_id]
                if not all(field in record for field in ("zone", "value", "flag")):
                    continue
                rows.append((record["zone"], record["value"], record["flag"]))
        else:
            raise SystemExit("unknown corpus format: " + str(fmt))
        return rows

    @staticmethod
    def raw_value_text(value):
        """The field bytes a JSON value stands for, or None for a real int."""
        if isinstance(value, str):
            return value
        if is_plain_int(value):
            return None
        return json.dumps(value, ensure_ascii=False)

    @staticmethod
    def shift(config_document, rejected_count, zip_sha256):
        """Effective upper-bound shift: (R mod 97) + (J mod 31) + (Z mod 53)."""
        rekey = int(config_document["rekey_interval_s"])
        zeta = int(zip_sha256[:16], 16)
        return (rekey % 97) + (rejected_count % 31) + (zeta % 53)

    def aggregate(self, corpus, out_dir):
        entry = self.resolve_corpus(corpus)
        config_path = Path(out_dir) / "config.json"
        zip_path = Path(out_dir) / "tool.zip"
        if not config_path.is_file():
            raise SystemExit("missing frozen spine: " + str(config_path))
        if not zip_path.is_file():
            raise SystemExit("missing rebuilt archive: " + str(zip_path))
        config_document = read_json(config_path)
        _state, rejected, _touch = self.spine_replay()
        zip_sha256 = sha256_file(zip_path)
        shift = self.shift(config_document, len(rejected), zip_sha256)
        low = entry["lo"]
        high = entry["hi"] + shift
        counted = []
        for zone, raw, flag in self.parse_rows(self.data / entry["filename"], entry["format"]):
            if not isinstance(zone, str) or not isinstance(flag, str):
                continue
            if zone not in self.zones:
                continue
            if flag != FLAG_ACTIVE:
                continue
            if is_plain_int(raw):
                value = raw
            else:
                text = self.raw_value_text(raw)
                if text is None or not is_canonical_int(text):
                    continue
                value = int(text)
            if not low <= value <= high:
                continue
            counted.append((zone, value))
        return entry, counted, shift

    def derived_value(self, counted, op):
        values = [value for _zone, value in counted]
        if op == "count":
            return len(values)
        if not values:
            return 0
        if op == "max":
            return max(values)
        if op == "min":
            return min(values)
        if op == "sum":
            return sum(values)
        if op == "first":
            return values[0]
        if op == "last":
            return values[-1]
        raise SystemExit("unknown operator: " + str(op))

    def compile_all(self, out_dir):
        table = self.corpus_table()
        aggregates = {}
        index = []
        zone_totals = {zone: 0 for zone in self.zones}
        for name in sorted(table):
            entry, counted, _shift = self.aggregate(name, out_dir)
            value = self.derived_value(counted, entry["op"])
            aggregates[name] = value
            for zone, _value in counted:
                zone_totals[zone] += 1
            index.append(
                {
                    "name": entry["name"],
                    "format": entry["format"],
                    "op": entry["op"],
                    "lo": entry["lo"],
                    "hi": entry["hi"],
                    "eligible_rows": len(counted),
                    "value": value,
                }
            )
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        write_json(out / "aggregates.json", aggregates)
        self.write_mirrors(out, aggregates)
        write_json(out / "zone_totals.json", zone_totals)
        write_json(out / "corpus_index.json", {"count": len(index), "corpora": index})
        return aggregates, zone_totals, index

    @staticmethod
    def write_mirrors(out_dir, aggregates):
        out = Path(out_dir)
        names = sorted(aggregates)
        lines = ["corpus,value\n"]
        lines += ["%s,%d\n" % (name, aggregates[name]) for name in names]
        (out / "aggregates.csv").write_text("".join(lines), encoding="utf-8")
        lines = ["corpus\tvalue\n"]
        lines += ["%s\t%d\n" % (name, aggregates[name]) for name in names]
        (out / "aggregates.tsv").write_text("".join(lines), encoding="utf-8")
        lines = ["[aggregates]\n"]
        lines += ["%s = %d\n" % (name, aggregates[name]) for name in names]
        (out / "aggregates.ini").write_text("".join(lines), encoding="utf-8")
        lines = ["%s=%d\n" % (name.upper(), aggregates[name]) for name in names]
        (out / "aggregates.env").write_text("".join(lines), encoding="utf-8")
        lines = ["| corpus | value |\n", "| --- | --- |\n"]
        lines += ["| %s | %d |\n" % (name, aggregates[name]) for name in names]
        (out / "aggregates.md").write_text("".join(lines), encoding="utf-8")
        lines = ["%s %d\n" % (name, aggregates[name]) for name in names]
        (out / "aggregates.txt").write_text("".join(lines), encoding="utf-8")
        root = ET.Element("aggregates")
        for name in names:
            ET.SubElement(root, "corpus", {"name": name, "value": str(aggregates[name])})
        (out / "aggregates.xml").write_text(
            ET.tostring(root, encoding="unicode") + "\n", encoding="utf-8"
        )


# ------------------------------------------------------------------ commands


def load_tool_schema(path):
    schema = read_json(path)
    if isinstance(schema.get("required_keys"), str):
        schema["required_keys"] = [key for key in schema["required_keys"].split(",") if key]
    return schema


def cmd_init(args):
    schema = load_tool_schema(args.schema)
    data = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    if not scalar_only(data):
        raise SystemExit("seed configuration must be flat")
    write_json(args.out, data)
    print("wrote " + args.out)


def cmd_set(args):
    config_path = Path(args.config)
    data = read_json(config_path)
    try:
        value = json.loads(args.value)
    except ValueError:
        value = args.value
    if isinstance(value, (dict, list)):
        raise SystemExit("value must be a scalar")
    data[args.key] = value
    if not scalar_only(data):
        raise SystemExit("configuration must be flat")
    write_json(config_path, data)
    print("%s=%s" % (args.key, json.dumps(value, sort_keys=True)))


def cmd_validate(args):
    schema = load_tool_schema(args.schema)
    data = read_json(args.config)
    missing = [key for key in schema["required_keys"] if key not in data]
    if missing:
        sys.stderr.write("missing: %s\n" % ",".join(missing))
        return 1
    if schema.get("scalar_only") and not scalar_only(data):
        sys.stderr.write("configuration must be flat\n")
        return 1
    print("ok")
    return 0


def cmd_plan(args):
    policy = Policy(args.data)
    config_path = Path(args.out) / "config.json"
    digest = sha256_file(config_path) if config_path.is_file() else ""
    document = policy.resolved(args.env, digest)
    if not scalar_only(document):
        raise SystemExit("resolved policy must be flat")
    sys.stdout.write(dumps(document) + "\n")
    return 0


def cmd_compile(args):
    policy = Policy(args.data)
    aggregates, _zone_totals, _index = policy.compile_all(args.out)
    print("compiled %d corpora" % len(aggregates))
    return 0


def cmd_aggregate(args):
    policy = Policy(args.data)
    entry, counted, _shift = policy.aggregate(args.corpus, args.out)
    print(policy.derived_value(counted, entry["op"]))
    return 0


def cmd_export_report(args):
    commands = read_json(args.commands) if args.commands else []
    config_path = Path(args.config)
    digest = args.digest or sha256_file(config_path)
    policy = Policy(args.data)
    report = {
        "ok": True,
        "tool": TOOL,
        "config_path": str(config_path),
        "config_sha256": digest,
        "trailer": policy.spine_document()[TRAILER_KEY],
        "commands": commands,
    }
    write_json(args.out, report)
    print("wrote " + args.out)
    return 0


def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL, description="offline security policy compiler")
    sub = parser.add_subparsers(dest="command")
    sub.required = True

    p = sub.add_parser("init", help="seed the flat configuration from the schema")
    p.add_argument("--schema", default=str(TOOL_SCHEMA))
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="assign one key a scalar value")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="check required keys and flatness")
    p.add_argument("--schema", default=str(TOOL_SCHEMA))
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("plan", help="print the resolved policy for one env")
    p.add_argument("--data", default=DEFAULT_DATA)
    p.add_argument("--out", default=DEFAULT_OUT)
    p.add_argument("--env", required=True)
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("compile", help="write every corpus-derived artifact")
    p.add_argument("--data", default=DEFAULT_DATA)
    p.add_argument("--out", default=DEFAULT_OUT)
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("aggregate", help="print one corpus's derived integer")
    p.add_argument("--corpus", required=True)
    p.add_argument("--data", default=DEFAULT_DATA)
    p.add_argument("--out", default=DEFAULT_OUT)
    p.set_defaults(func=cmd_aggregate)

    p = sub.add_parser("export-report", help="record the command transcript")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", default="")
    p.add_argument("--commands", default="")
    p.add_argument("--data", default=DEFAULT_DATA)
    p.set_defaults(func=cmd_export_report)

    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    return args.func(args) or 0


if __name__ == "__main__":
    sys.exit(main())
