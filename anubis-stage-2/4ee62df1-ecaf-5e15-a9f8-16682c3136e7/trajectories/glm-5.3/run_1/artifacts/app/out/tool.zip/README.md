# sealb-ctl

Offline, standard-library-only security policy compiler for the Ironvault
sealing service. It creates, updates, validates, reports, and compiles a flat
JSON security posture. It is broken in several places and must be repaired
before use, and two of its subcommands (`plan` and `compile`) are not
implemented at all and must be built from the written contract in
`/app/data/config_contract.md`.

Subcommands the repaired tool must support:

```bash
python3 cli.py init --schema schema.json --out config.json
python3 cli.py set --config config.json --key max_sessions --value 100
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py plan --data /app/data --env base
python3 cli.py compile --data /app/data --out /app/out
python3 cli.py export-report --config config.json --out report.json --digest <sha256> --commands <json>
```

- `init` seeds the flat configuration from the schema.
- `set` assigns one key to a scalar value, keeping the configuration flat.
- `validate` checks the required keys and flatness against the tool schema.
- `plan` prints the fully resolved policy document for one environment.
- `compile` reads the evidence corpora and writes every derived artifact.
- `export-report` records the command transcript and the config digest.

The tool schema stores `required_keys` as one comma-separated string; the
sidecar schema in `/app/data` stores the same list as a JSON array. The tool
consumes its own schema.
