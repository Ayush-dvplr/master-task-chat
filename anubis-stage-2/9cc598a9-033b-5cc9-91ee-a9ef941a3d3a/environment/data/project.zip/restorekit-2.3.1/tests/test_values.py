import datetime as dt
import unittest

from restorekit import values

UTC = dt.timezone.utc


class Identifiers(unittest.TestCase):
    def test_set_ids(self):
        for raw in ("BS-04211", "bs-04211", "BS-4211", "  BS-04211 ", "BS_04211", "BS04211"):
            self.assertEqual(values.norm_id(raw), "BS-04211")

    def test_hash(self):
        self.assertEqual(values.norm_hash("sha256:ABCD"), "abcd")


class Numbers(unittest.TestCase):
    def test_locales(self):
        self.assertEqual(values.parse_int("1.234.567", "de_DE"), 1234567)
        self.assertEqual(values.parse_int("1\u202f234", "fr_FR"), 1234)
        self.assertEqual(values.parse_int("1,234", "en_US"), 1234)
        self.assertEqual(values.size_of({"size_kib": "12,345703125"}, "de_DE"), 12642)


class Times(unittest.TestCase):
    def test_kinds(self):
        t = dt.datetime(2026, 10, 5, 21, 14, 3, tzinfo=UTC)
        self.assertEqual(values.parse_ts("2026-10-05T21:14:03Z", "utc"), t)
        self.assertEqual(values.parse_ts(1791234843, "epoch"), t)
        self.assertEqual(values.parse_ts("2026-10-05 23:14:03", "local", "Europe/Berlin"), t)
        self.assertEqual(values.parse_ts(0, "ft"), "SENTINEL")

    def test_repeated_hour_is_first(self):
        t = values.parse_ts("2026-10-25 02:30:00", "local", "Europe/Berlin")
        self.assertEqual(t, dt.datetime(2026, 10, 25, 0, 30, tzinfo=UTC))

    def test_excel_1904(self):
        self.assertEqual(values.parse_ts(45000.5, "xl", date1904=True),
                         dt.datetime(2027, 3, 16, 12, 0, tzinfo=UTC))


class Modes(unittest.TestCase):
    def test_parse_and_out(self):
        self.assertEqual(values.parse_mode({"mode_sym": "-rwsr-x--T"}), 0o5750)
        self.assertEqual(values.mode_out(0o6755, None), "0755")
        self.assertEqual(values.mode_out(0o1777, None), "1777")
        self.assertEqual(values.mode_out(None, "RA"), "0444")
        self.assertTrue(values.truthy("true"))


if __name__ == "__main__":
    unittest.main()
