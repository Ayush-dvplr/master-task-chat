import csv
import unittest
from pathlib import Path

from restorekit import globs

FIXTURE = Path(__file__).parent / "fixtures" / "glob_conformance.tsv"


class GlobConformance(unittest.TestCase):
    def test_fixture_cases(self):
        with FIXTURE.open(encoding="utf-8", newline="") as fh:
            rows = list(csv.DictReader(fh, delimiter="\t"))
        self.assertGreater(len(rows), 5000)
        bad = [r for r in rows if globs.match(r["pattern"], r["path"]) != (r["expected"] == "match")]
        self.assertEqual(bad[:5], [])

    def test_star_stays_in_component(self):
        self.assertTrue(globs.match("/Design/*.png", "/Design/a.png"))
        self.assertFalse(globs.match("/Design/*.png", "/Design/sub/a.png"))

    def test_directory_pattern(self):
        self.assertTrue(globs.match("Build/", "/x/Build/y.bin"))
        self.assertFalse(globs.match("Build/", "/x/Build"))


if __name__ == "__main__":
    unittest.main()
