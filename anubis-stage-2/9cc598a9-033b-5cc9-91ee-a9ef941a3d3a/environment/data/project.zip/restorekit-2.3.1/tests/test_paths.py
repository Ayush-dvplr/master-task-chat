import unittest

from restorekit import paths

WIN = ["D:\\Shares\\Projects", "\\\\corp-fs\\projects"]
NIX = ["/srv/samba/projects"]


class Canonical(unittest.TestCase):
    def test_windows_root_case_and_separators(self):
        self.assertEqual(paths.canonical("d:\\SHARES\\projects\\Eng\\a.txt", WIN, True), "/Eng/a.txt")
        self.assertEqual(paths.canonical("\\\\corp-fs\\projects/Eng\\b.txt", WIN, True), "/Eng/b.txt")

    def test_windows_trailing_dots(self):
        self.assertEqual(paths.canonical("D:\\Shares\\Projects\\Eng. \\c.txt", WIN, True), "/Eng/c.txt")

    def test_dot_dot(self):
        self.assertEqual(paths.canonical("D:\\Shares\\Projects\\Eng\\x\\..\\d.txt", WIN, True), "/Eng/d.txt")
        with self.assertRaises(paths.Unsafe):
            paths.canonical("D:\\Shares\\Projects\\..\\..\\Windows\\e.dll", WIN, True)

    def test_outside(self):
        with self.assertRaises(paths.Outside):
            paths.canonical("D:\\Shares\\Finance\\f.xlsx", WIN, True)
        with self.assertRaises(paths.Outside):
            paths.canonical("/srv/samba/projects2/g", NIX, False)

    def test_posix_exact_and_nfc(self):
        self.assertEqual(paths.canonical("/srv/samba/projects/Cafe\u0301.txt", NIX, False), "/Caf\u00e9.txt")
        with self.assertRaises(paths.Outside):
            paths.canonical("/SRV/samba/projects/h", NIX, False)

    def test_identity_key(self):
        self.assertEqual(paths.key("/A/Gr\u00f6\u00dfe"), paths.key("/a/GR\u00d6SSE"))

    def test_links(self):
        self.assertEqual(paths.resolve_link("../Specs/x.pdf", "/Eng/Build/l", NIX, False), "/Eng/Specs/x.pdf")
        self.assertIsNone(paths.resolve_link("../../../etc/passwd", "/Eng/l", NIX, False))
        self.assertEqual(paths.resolve_link("D:\\Shares\\Projects\\Eng\\y", "/a/l", WIN, True), "/Eng/y")


if __name__ == "__main__":
    unittest.main()
