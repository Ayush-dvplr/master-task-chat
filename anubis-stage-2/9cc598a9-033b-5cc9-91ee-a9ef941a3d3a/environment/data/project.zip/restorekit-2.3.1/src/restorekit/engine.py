"""Point-in-time restore of one share from a restore feed (restore specification revision 4.2)."""

from __future__ import annotations

import datetime as dt
import email.utils
import re
from dataclasses import dataclass, field
from pathlib import Path
from zoneinfo import ZoneInfo

from restorekit import feed, globs, paths, values
from restorekit.values import UTC, norm_hash, norm_id

REASONS = ["OUT_OF_SCOPE", "DISPOSED", "EXCLUDED_PATTERN", "SYMLINK_ESCAPE", "QUARANTINED", "UNRECOVERABLE"]
CAT_CANON = {
    "set": ["set_id", "backup_set", "bset", "set"], "seq": ["seq", "sequence"], "entry": ["entry_id", "eid", "entry"],
    "type": ["etype", "entry_type", "op", "type"], "path": ["path", "src_path", "object"],
    "new_path": ["new_path", "rename_to"], "target": ["target", "link_target"], "kind": ["kind", "obj_kind"],
    "owner": ["owner", "principal"], "sha256": ["sha256", "content_hash", "digest"], "container": ["container", "ct_id"],
    "file_id": ["file_id", "inode"], "client": ["client", "agent_client"], "committed": ["committed", "commit_flag"],
    "voids": ["voids", "void_target"], "attrs": ["attrs", "win_attrs"],
}
TS_KINDS = ("utc", "iso", "epoch", "ms", "ft", "local", "xl")


class FeedError(Exception):
    pass


@dataclass
class Entry:
    eid: str
    sid: str
    seq: int
    etype: str
    path: str = ""
    new_path: str = ""
    target: str = ""
    kind: str = ""
    size: int | None = None
    mtime: object = None
    mode: int | None = None
    attrs: str | None = None
    owner: str = ""
    sha256: str = ""
    container: str = ""
    file_id: str = ""
    client: str = ""
    committed: bool = True
    voids: str = ""
    canon: str = ""
    canon_new: str = ""
    canon_target: str = ""
    rejected: str = ""


@dataclass
class SetInfo:
    sid: str
    job: str
    type: str
    status: str
    server: str
    queued: dt.datetime
    consolidates: str
    snapshot: dt.datetime | None = None
    crash: bool = False


@dataclass
class Obj:
    path: str
    kind: str
    entry: Entry
    target: str = ""


@dataclass
class Context:
    files: list
    by_stream: dict = field(default_factory=dict)


def _first(row: dict, names: list[str]):
    for n in names:
        if n in row and row[n] not in ("", None):
            return row[n]
    return None


def _iso(s: str) -> dt.datetime:
    return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(UTC)


class Restore:
    def __init__(self, feed_dir: Path) -> None:
        pre = feed.load_feed(feed_dir, {})
        self.files = pre
        guide = self.one("FMTGUIDE")
        layouts: dict[str, list] = {}
        for row in guide.doc.table("Fixed-width layouts"):
            layouts.setdefault(row["layout"], []).append((row["column"], int(row["width"])))
        self.files = [feed.load(f.path, layouts) if f.fmt == "fixed" else f for f in pre]
        values.Folds.table = {chr(int(r["codepoint"][2:], 16)): r["fold"]
                              for r in self.one("PATHCONV").doc.table("Confusable fold table") if r["scope"] == "identifier"}

    # ------------------------------------------------------------------ feed access
    def all(self, stream: str, status: str | None = None) -> list:
        return [f for f in self.files if f.stream == stream and (status is None or f.status == status)]

    def one(self, stream: str, status: str | None = None):
        found = self.all(stream, status)
        if not found:
            raise FeedError(f"no {stream} file in feed")
        return found[0]

    # ------------------------------------------------------------------ request and documents
    def load_request(self) -> None:
        params = {r["key"]: r["value"] for r in self.one("RRQ").doc.table("Request parameters")}
        self.feed_id = params["feed"]
        self.files = [f for f in self.files if f.control.get("feed") == self.feed_id]
        self.share = params["share"]
        self.shares = {s["share"]: s for s in self.one("SHARE").tables["shares"]}
        me = self.shares[self.share]
        self.site_tz = me["site_tz"]
        self.array = me["array"]
        wall = dt.datetime.strptime(params["restore_point_local"], "%Y-%m-%d %H:%M:%S")
        self.rp = wall.replace(tzinfo=ZoneInfo(self.site_tz), fold=0).astimezone(UTC)
        self.rp_date = wall.date().isoformat()
        self.request_date = params["request_date"]
        rd = dt.date.fromisoformat(self.request_date)
        self.req_end = dt.datetime.combine(rd, dt.time(23, 59, 59)).replace(tzinfo=ZoneInfo(self.site_tz)).astimezone(UTC)
        self.target_volume = params["target_volume"]
        self.dispositions = self.one("RRQ").doc.table("Records disposition holds")
        reg = self.one("DOCREG").doc.table("Document control register")
        self.in_force: dict[tuple, str] = {}
        for row in reg:
            ok = row["status"] in ("APPROVED", "IN FORCE") and row["effective"] and row["effective"] <= self.rp_date
            self.in_force[(row["stream"], row["revision"], row["section"])] = "yes" if ok else "no"

    def doc_in_force(self, stream: str, revision: str, section: str = "ALL") -> bool:
        v = self.in_force.get((stream, revision, section))
        if v is None and section != "ALL":
            v = self.in_force.get((stream, revision, "ALL"))
        return v == "yes"

    def doc_rev(self, stream: str, revision: str):
        for f in self.all(stream):
            if f.control.get("revision") == revision:
                return f
        return None

    # ------------------------------------------------------------------ hosts, clients and roots
    def load_hosts(self) -> None:
        self.host_tz, self.host_os = {}, {}
        for h in self.one("HOST", "ORIGINAL").tables["hosts"]:
            self.host_tz[h["host"].upper()] = h["tz"]
            self.host_os[h["host"].upper()] = h["os"]
        self.host_fs = {h["hostname"].upper(): h["filesystem"] for h in self.one("HOST", "CMDB-EXPORT").tables["hosts"]}
        self.clientx = self.one("FMTGUIDE").doc.table("Client crosswalk")
        self.roots: dict[tuple, list[str]] = {}
        for s in self.one("ROOT").tables["sections"]:
            self.roots.setdefault((s["host"].upper(), s["share"].upper()), []).append(s["path"])
        self.servers = {}
        for s in self.one("SRV").tables["servers"]:
            self.servers[s["name"]] = {"tz": s["tz"], "builds": sorted(((_iso(b["installed"]), b["log_timestamps"]) for b in s["builds"]))}

    def client_host(self, code: str, when: dt.datetime) -> str | None:
        day = when.astimezone(ZoneInfo(self.site_tz)).date().isoformat()
        for row in self.clientx:
            if row["client"] == code and row["valid_from"] <= day and (not row["valid_to"] or day <= row["valid_to"]):
                return row["host"].upper()
        return None

    # ------------------------------------------------------------------ sets
    def load_sets(self) -> None:
        defs = {}
        for f in self.all("JOBDEF"):
            for j in f.tables["rows"]:
                defs[j["name"].strip().upper()] = j
        xwalk = []
        for f in self.all("SPEC"):
            rev = f.control.get("revision", "")
            if self.doc_in_force("SPEC", rev, "Appendix J"):
                xwalk += f.doc.table("Job rename crosswalk")

        def share_of(job: str, queued: dt.datetime) -> str:
            j = defs.get(job)
            if j and j["share"]:
                return j["share"]
            return ""
            day = queued.astimezone(ZoneInfo(self.site_tz)).date().isoformat()
            for x in xwalk:
                if x["old_name"].upper() == job and day < x["effective"]:
                    n = defs.get(x["new_name"].upper())
                    if n and n["share"]:
                        return n["share"]
            return ""

        self.entry_totals: dict[str, int] = {}
        for f in self.all("JOB", "REPORTING"):
            for row in f.tables.get("Sets", []):
                self.entry_totals[norm_id(row["set_id"])] = int(row["catalog_entries"])
        self.sets: dict[str, SetInfo] = {}
        for f in self.all("JOB", "ORIGINAL"):
            for row in f.tables["rows"]:
                kind = next(k for k in row if k.startswith("queued_")).split("_", 1)[1]
                server = row["server"].strip()
                tz = self.servers.get(server, {}).get("tz", "UTC")
                queued = values.parse_ts(row[f"queued_{kind}"], kind, tz)
                job = row["job_name"].strip().upper()
                if share_of(job, queued) != self.share:
                    continue
                sid = norm_id(row["set_id"])
                self.sets[sid] = SetInfo(sid, job, row["set_type"].strip().upper(), row["status"].strip().upper(), server, queued,
                                         norm_id(row.get("consolidates", "")))
        self._read_logs()
        for s in self.sets.values():
            s.snapshot = self.snap.get(s.sid, s.queued)
        self._crash()

    def _log_time(self, text: str, server: str) -> dt.datetime:
        info = self.servers[server]
        if re.match(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d[+-]\d\d:\d\d$", text):
            return _iso(text)
        return dt.datetime.strptime(text, "%Y-%m-%d %H:%M:%S").replace(tzinfo=UTC)

    def _read_logs(self) -> None:
        self.snap: dict[str, dt.datetime] = {}
        self.status_change: dict[str, tuple] = {}
        gaps: dict[str, list] = {}
        line_re = re.compile(r"^(\S+(?: \d\d:\d\d:\d\d)?) (\S+) (\w+) \[([\w-]+)\] (.*)$")

        def take(t: dt.datetime, comp: str, msg: str) -> None:
            m = re.match(r"snapshot \{[^}]*\} created set=(\S+)", msg)
            if m and comp == "vss":
                self.snap[norm_id(m.group(1))] = t
            m = re.match(r"set=(\S+) status changed \S+ -> (\S+)", msg)
            if m and comp == "catalog-check":
                sid = norm_id(m.group(1))
                if sid not in self.status_change or self.status_change[sid][0] <= t:
                    self.status_change[sid] = (t, m.group(2))

        for f in self.all("LOG", "ORIGINAL"):
            for ln in f.lines:
                m = line_re.match(ln)
                if not m or m.group(2) not in self.servers:
                    continue
                t = self._log_time(m.group(1), m.group(2))
                take(t, m.group(4), m.group(5))
                g = re.match(r"lines from (\S+) to (\S+) were not retained", m.group(5))
                if g and m.group(4) == "logrotate":
                    gaps.setdefault(m.group(2), []).append((_iso(g.group(1)), _iso(g.group(2))))
        for f in self.all("LOG", "MIRROR")[:0]:
            for ln in f.lines:
                m = re.match(r"^(\d{4}-\d\d-\d\dT\d\d:\d\dZ) (\S+) (\w+) \[([\w-]+)\] (.*)$", ln)
                if not m:
                    continue
                t = dt.datetime.strptime(m.group(1), "%Y-%m-%dT%H:%MZ").replace(tzinfo=UTC)
                if any(a <= t < b for a, b in gaps.get(m.group(2), [])):
                    take(t, m.group(4), m.group(5))

    def _crash(self) -> None:
        actual: dict[str, list] = {}
        for f in self.all("LOG", "ORIGINAL"):
            for ln in f.lines:
                m = re.match(r"^(\S+Z) (\S+) maintenance uid=(\S+) actual-(start|end)$", ln)
                if m:
                    actual.setdefault(m.group(3), [None, None])[0 if m.group(4) == "start" else 1] = _iso(m.group(1))
        windows = []
        for ev in self.one("CAL").tables["events"]:
            if ev.get("X-ARRAY", ("",))[0] != self.array or ev.get("STATUS", ("",))[0] != "CONFIRMED":
                continue
            if ev.get("X-IMPACT", ("",))[0] != "SNAPSHOT-CONSISTENCY":
                continue
            uid = ev["UID"][0]
            windows.append((self._ics_time(*ev["DTSTART"]), self._ics_time(*ev["DTEND"])))
        for s in self.sets.values():
            s.crash = s.snapshot is not None and any(a <= s.snapshot <= b for a, b in windows)

    @staticmethod
    def _ics_time(value: str, params: str) -> dt.datetime:
        if value.endswith("Z"):
            return dt.datetime.strptime(value, "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
        tz = re.search(r"TZID=([^;:]+)", params).group(1)
        return dt.datetime.strptime(value, "%Y%m%dT%H%M%S").replace(tzinfo=ZoneInfo(tz), fold=0).astimezone(UTC)

    # ------------------------------------------------------------------ chain
    def select_chain(self) -> None:
        order = sorted(self.sets.values(), key=lambda s: (s.snapshot, s.sid))
        eligible = [s for s in order if s.snapshot <= self.rp and s.status in ("COMPLETED", "PARTIAL") and not s.crash]
        base = max((s for s in eligible if s.type == "FULL"), key=lambda s: (s.snapshot, s.sid))
        diffs = [s for s in eligible if s.type == "DIFF" and s.snapshot > base.snapshot]
        diff = max(diffs, key=lambda s: (s.snapshot, s.sid)) if diffs else None
        anchor = diff or base
        chain = [base] + ([diff] if diff else [])
        skipped, broken = [], False
        for s in order:
            if s is base or s is diff:
                continue
            if s.snapshot > self.rp:
                reason = "AFTER_RP"
            elif s.status in ("FAILED", "CANCELLED"):
                reason = s.status
                if s.snapshot > anchor.snapshot:
                    broken = True
            elif s.crash:
                reason = "CRASH_INCONSISTENT"
                if s.snapshot > anchor.snapshot:
                    broken = True
            elif s.snapshot <= base.snapshot:
                reason = "BEFORE_BASE"
            elif s.snapshot <= anchor.snapshot:
                reason = "SUPERSEDED_BY_DIFF"
            elif broken:
                reason = "CHAIN_BROKEN"
            elif s.type == "INCR":
                chain.append(s)
                continue
            else:
                reason = "SUPERSEDED_BY_DIFF"
            skipped.append((s, reason))
        self.chain, self.skipped = chain, skipped

    # ------------------------------------------------------------------ catalog
    def load_catalog(self) -> None:
        wanted = set(self.sets)
        entries: dict[str, Entry] = {}
        original_ids: dict[str, set] = {}
        for f in self.all("CAT"):
            ids = set()
            for raw in self._cat_rows(f):
                e = self._entry(raw, f)
                if e is None:
                    continue
                ids.add(e.eid)
                if e.sid in wanted:
                    entries[e.eid] = e
            original_ids[f.part] = ids
        for f in self.all("CAT", "RESEND")[:0]:
            for raw in self._cat_rows(f):
                e = self._entry(raw, f)
                if e is None or e.eid in original_ids.get(f.part, set()):
                    continue
                if e.sid in wanted:
                    entries[e.eid] = e
        self._errata(entries)
        self.entries_by_set: dict[str, list[Entry]] = {}
        for e in entries.values():
            self.entries_by_set.setdefault(e.sid, []).append(e)
        for lst in self.entries_by_set.values():
            lst.sort(key=lambda e: e.seq)

    @staticmethod
    def _cat_rows(f) -> list[dict]:
        rows = []
        for name, lst in f.tables.items():
            rows.extend(lst)
        return rows

    def _entry(self, row: dict, f) -> Entry | None:
        sid = norm_id(_first(row, CAT_CANON["set"]))
        eid = norm_id(_first(row, CAT_CANON["entry"]))
        if not sid or not eid:
            return None
        if sid not in self.sets:
            return Entry(eid, sid, 0, "")
        locale = f.control.get("locale", "plain")
        e = Entry(eid, sid, int(_first(row, CAT_CANON["seq"])), str(_first(row, CAT_CANON["type"])).strip().upper())
        for fld in ("path", "new_path", "target", "kind", "owner", "client", "attrs"):
            v = _first(row, CAT_CANON[fld])
            setattr(e, fld, "" if v is None else str(v))
        e.client = e.client.strip()
        e.kind = e.kind.strip().lower()
        e.sha256 = norm_hash(_first(row, CAT_CANON["sha256"]))
        e.container = norm_id(_first(row, CAT_CANON["container"]))
        e.voids = norm_id(_first(row, CAT_CANON["voids"]))
        fid = _first(row, CAT_CANON["file_id"])
        e.file_id = "" if fid is None else str(int(float(fid)) if isinstance(fid, float) else fid).strip()
        c = _first(row, CAT_CANON["committed"])
        e.committed = True if c is None else values.truthy(c)
        e.size = values.size_of(row, locale)
        e.mode = values.parse_mode(row)
        snap = self.sets[sid].snapshot
        host = self.client_host(e.client, snap) if e.client else None
        tkey = next((k for k in row if re.match(r"^(mtime|modified)_(\w+)$", k)), None)
        if tkey is None and f.fmt == "fixed":
            tkey = next((k for k in row if k.startswith("mtime")), None)
        if tkey is not None and e.etype in ("F", "L"):
            kind = tkey.split("_", 1)[1]
            fat = host is not None and self.host_fs.get(host, "") in ("FAT32", "exFAT")
            tz = "UTC" if fat else self.host_tz.get(host or "", "UTC")
            v = row[tkey]
            t = values.parse_ts(v, kind, tz, f.extra.get("date1904", False)) if v not in ("", None) else None
            if t is None and f.fmt == "parquet":
                t = "SENTINEL"

            e.mtime = t
        e.host = host
        return e

    def _errata(self, entries: dict[str, Entry]) -> None:
        best: dict[tuple, tuple] = {}
        for f in self.all("ERR"):
            rev = f.control.get("revision", "")
            for row in f.doc.table("Catalog errata"):
                k = (norm_id(row["entry"]), row["field"])
                if k not in best or int(rev) > best[k][0]:
                    best[k] = (int(rev), row["value"])
        for (eid, fld), (_, value) in best.items():
            e = entries.get(eid)
            if e is None:
                continue
            if fld == "sha256":
                e.sha256 = norm_hash(value)
            elif fld == "size":
                e.size = int(value)
            elif fld == "mtime":
                e.mtime = _iso(value)
            elif fld == "container":
                e.container = norm_id(value)

    # ------------------------------------------------------------------ replay
    def canonicalize(self, e: Entry) -> None:
        host = e.host
        if host is None:
            e.rejected = "outside"
            return
        windows = self.host_os.get(host) == "windows"
        roots = self.roots.get((host, self.share.upper()), [])
        try:
            if e.etype != "X":
                e.canon = paths.canonical(e.path, roots, windows)
            if e.etype == "R":
                e.canon_new = paths.canonical(e.new_path, roots, windows)
            if e.etype == "H":
                e.canon_target = paths.canonical(e.target, roots, windows)
        except paths.Unsafe:
            e.rejected = "unsafe"
        except paths.Outside:
            e.rejected = "outside"

    def replay(self) -> None:
        self.dirs: dict[str, str] = {"": ""}
        self.objs: dict[str, Obj] = {}
        self.recon_sets = []
        self.applied_ids: set[str] = set()
        for s in self.chain:
            es = self.entries_by_set.get(s.sid, [])
            voided = set()
            counts = {"set": s.sid, "expected": self.entry_totals.get(s.sid), "entries": len(es), "applied": 0, "voided": 0, "uncommitted": 0, "rejected": 0}
            for e in es:
                if e.eid in voided:
                    counts["voided"] += 1
                    continue
                if e.etype == "X":
                    continue
                self.canonicalize(e)
                if e.rejected:
                    counts["rejected"] += 1
                    continue
                self.apply(e)
                counts["applied"] += 1
                self.applied_ids.add(e.eid)
            self.recon_sets.append(counts)

    def _parent_display(self, path: str) -> str:
        parent = path.rpartition("/")[0]
        if parent == "":
            return ""
        pk = paths.key(parent)
        if pk not in self.dirs:
            self.dirs[pk] = self._parent_display(parent) + "/" + parent.rpartition("/")[2]
        return self.dirs[pk]

    def _display(self, path: str) -> str:
        return self._parent_display(path) + "/" + path.rpartition("/")[2]

    def apply(self, e: Entry) -> None:
        k = paths.key(e.canon)
        t = e.etype
        if t == "D":
            if k not in self.dirs:
                self.dirs[k] = self._display(e.canon)
        elif t == "F":
            o = self.objs.get(k)
            if o is not None and o.kind == "file":
                o.entry = e
                o.path = e.canon
            else:
                self.objs[k] = Obj(self._display(e.canon), "file", e)
        elif t == "H":
            src = self.objs.get(paths.key(e.canon_target))
            if src is not None and src.kind == "file":
                self.objs[k] = Obj(self._display(e.canon), "file", src.entry)
        elif t == "L":
            self.objs[k] = Obj(self._display(e.canon), "link", e, e.target)
        elif t == "W":
            if e.kind == "dir":
                self.dirs.pop(k, None)
                for d in [d for d in self.dirs if d.startswith(k + "/")]:
                    del self.dirs[d]
                for o in [o for o in self.objs if o.startswith(k + "/")]:
                    del self.objs[o]
            else:
                self.objs.pop(k, None)
        elif t == "R":
            nk = paths.key(e.canon_new)
            if e.kind == "dir":
                if k not in self.dirs:
                    return
                old = self.dirs.pop(k)
                new = self._display(e.canon_new)
                self.dirs[nk] = new
                for d in [d for d in self.dirs if d.startswith(k + "/")]:
                    disp = new + self.dirs.pop(d)[len(old):]
                    self.dirs[paths.key(disp)] = disp
                for ok in [o for o in self.objs if o.startswith(k + "/")]:
                    o = self.objs.pop(ok)
                    o.path = new + o.path[len(old):]
                    self.objs[paths.key(o.path)] = o
            else:
                o = self.objs.pop(k, None)
                if o is not None:
                    o.path = self._display(e.canon_new)
                    self.objs[nk] = o

    # ------------------------------------------------------------------ registers used after replay
    def load_media(self) -> None:
        self.inventory = {}
        for f in self.all("MEDIA", "ORIGINAL"):
            for sheet, rows in f.tables.items():
                for row in rows:
                    m = norm_id(row["media_id"])
                    self.inventory[m] = {"status": str(row["status"]).strip().upper(), "gen": str(row.get("generation") or "")}
        self.barcode = {}
        for f in self.all("MEDIA", "PREVIEW"):
            for row in f.tables.get("Media", []):
                if row.get("barcode"):
                    self.barcode[str(row["barcode"]).strip().upper()] = norm_id(row["media_id"])
        self.copies: dict[str, list[dict]] = {}
        self.created: dict[str, dt.datetime] = {}
        for f in self.all("CMAP"):
            of_record_rc = f.status == "FINAL"
            if f.status not in ("ORIGINAL", "FINAL"):
                continue
            locale = f.control.get("locale", "plain")
            for row in f.tables["rows"]:
                c = norm_id(row["container"])
                if c.startswith("RC-") != of_record_rc:
                    continue
                size = values.parse_int(row["size_bytes"], locale) if "size_bytes" in row else values.parse_int(row["size_text"], locale)
                created = row["created"] if "created" in row else values.EPOCH + dt.timedelta(milliseconds=row["created_ms"])
                if created.tzinfo is None:
                    created = created.replace(tzinfo=UTC)
                ref = str(row["media_ref"]).strip().upper()
                media = self.barcode.get(ref, norm_id(ref)) if int(row["copy"]) == 2 else norm_id(ref)
                self.copies.setdefault(c, []).append({"copy": int(row["copy"]), "media": media, "size": size})
                self.created[c] = created
        self.repack = {}
        for row in self.one("REPACK").tables["repack"]:
            if _iso(row["repacked_at"]) <= self.req_end:
                self.repack[norm_id(row["old_container"])] = norm_id(row["new_container"])
        self.damaged = set()
        for f in self.all("MERR"):
            rev = f.control.get("revision", "")
            corrections = {}
            for g in self.all("MERR"):
                if self.doc_in_force("MERR", g.control.get("revision", ""), "Section 2"):
                    for c in g.doc.table("Corrections to revision A"):
                        if c["field"] == "media":
                            corrections[c["errata"]] = norm_id(c["now"])
            if not self.doc_in_force("MERR", rev):
                continue
            for row in f.doc.table("Media errata"):
                if row["status"] == "APPROVED" and row["defect"] in ("DAMAGED", "UNREADABLE"):
                    self.damaged.add(corrections.get(row["errata"], norm_id(row["media"])))
        self.destroyed = set()
        self.recalls = []
        rerun_named = set()
        for m in self.one("MAIL").tables["messages"]:
            when = email.utils.parsedate_to_datetime(m["date"]).astimezone(UTC)
            subj = m["subject"]
            if subj.startswith("Destruction notice:") and when <= self.req_end:
                self.destroyed.add(norm_id(subj.split(":", 1)[1]))
            elif subj.startswith("Recall completed:") and when <= self.req_end:
                mm = re.search(r"checked in at (\S+?)\.", m["body"])
                if mm:
                    self.recalls.append((when, norm_id(subj.split(":", 1)[1]), mm.group(1)))
            elif subj.startswith("Checksum rerun request"):
                for c, cp in re.findall(r"^(\S+) copy (\d+)$", m["body"], re.M):
                    rerun_named.add((norm_id(c), int(cp)))
        self.mismatch = set()
        for row in self.one("CHK", "ORIGINAL").tables["rows"]:
            if row["result"].strip().upper() == "MISMATCH":
                self.mismatch.add((norm_id(row["container"]), int(row["copy"])))
        for f in self.all("CHK", "RERUN"):
            for row in f.tables["rows"]:
                k = (norm_id(row["container"]), int(row["copy"]))
                if True:
                    if row["result"].strip().upper() == "MATCH":
                        self.mismatch.discard(k)
                    else:
                        self.mismatch.add(k)
        self.copy_done = set()
        for row in self.one("COPY").doc.table("Copy jobs"):
            if row["status"] == "COMPLETED" and _iso(row["completed_utc"]) <= self.req_end:
                self.copy_done.add((norm_id(row["container"]), int(row["copy"])))
        vault = {}
        for s in self.one("SLOT").tables["sections"]:
            vault[norm_id(s["media"])] = s["vault"]
        for row in self.one("DASH").doc.table("Media"):
            m = norm_id(row["media_id"])
            vault[m] = row["vault"]
        moves = list(self.recalls)
        for row in self.one("XFER").doc.table("Transfers"):
            t = _iso(row["received_utc"])
            if t <= self.req_end:
                moves.append((t, norm_id(row["media"]), row["to_vault"]))
        for _, m, v in sorted(moves):
            vault[m] = v
        self.vault = vault
        self.vault_prio = {}
        for row in self.one("MEDIAPROC").doc.table("Vault service calendar"):
            if row["date"] == self.request_date:
                self.vault_prio[row["vault"]] = int(row["priority"])

    def usable(self, container: str, cp: dict) -> bool:
        inv = self.inventory.get(cp["media"])
        if inv is None or inv["status"] == "EXPIRED":
            return False
        if cp["media"] in self.damaged or cp["media"] in self.destroyed:
            return False
        if (container, cp["copy"]) in self.mismatch:
            return False
        return True

    def pick_copy(self, container: str) -> tuple[str, dict | None]:
        c = container
        for cp in sorted(self.copies.get(c, []), key=lambda x: x["copy"]):
            if self.usable(c, cp):
                return c, cp
        return c, None

    def load_av(self) -> None:
        cut = re.search(r"The engine cutover is (\S+?)\.?$", self.one("QPROC").doc.text, re.M)
        self.cutover = _iso(cut.group(1).rstrip("."))
        vendor = {r["engine"]: r["vendor"] for r in self.one("QPROC").doc.table("Engine registry")}
        withdrawals = []
        for row in self.one("ADV").doc.table("Withdrawn signatures"):
            a, b = row["revisions"].split("-")
            withdrawals.append((row["vendor"], row["signature"], int(a), int(b), _iso(row["withdrawn_utc"])))
        self.infected: set[tuple] = set()

        def rows_of(f):
            for lst in f.tables.values():
                yield from lst

        for f in self.all("AV"):
            if f.status not in ("ORIGINAL", "PRELIMINARY"):
                continue
            for row in rows_of(f):
                if str(row["verdict"]).upper() != "INFECTED":
                    continue
                c = norm_id(row["container"])
                created = self.created.get(c)
                if created is None:
                    continue

                v = vendor.get(row["engine"])
                rev = int(row["sig_rev"])
                if any(v == wv and row["signature"] == ws and a <= rev <= b and t <= self.req_end for wv, ws, a, b, t in withdrawals):
                    continue
                self.infected.add((norm_hash(row["sha256"]), c))

    def load_identity(self) -> None:
        self.idmap = {}
        for row in self.one("IDMAP", "ORIGINAL").tables["accounts"]:
            self.idmap.setdefault(row["principal"], []).append(row)
        self.domains = {p.rsplit("-", 1)[0] for p in self.idmap}
        self.ad = {}
        for f in self.all("IDMAP", "EXPORT"):
            for row in f.tables.get("ad_users", []):
                self.ad[row["sid"]] = row["account"]
        self.changes = {}
        for row in self.one("IDCHG").doc.table("Identity changes"):
            if row["status"] == "APPROVED":
                t = _iso(row["effective_utc"])
                if t <= self.rp and (row["principal"] not in self.changes or self.changes[row["principal"]][0] < t):
                    self.changes[row["principal"]] = (t, row["account"])
        self.local = {}
        for s in self.one("LACCT").tables["sections"]:
            host = s["_section"].split(":", 1)[1].upper()
            for k, v in s.items():
                if k != "_section":
                    self.local[(host, k)] = v

    def owner(self, e: Entry) -> str:
        p = (e.owner or "").strip()
        if p in ("N/A", "-", "null", ""):
            return "UNMAPPED"
        if p in self.ad:
            return self.ad[p].split("\\")[-1]
        if p.startswith("uid:"):
            return self.local.get(((e.host or ""), p[4:]), "UNMAPPED")
        if p in self.changes:
            return self.changes[p][1]
        for row in self.idmap.get(p, []):
            if _iso(row["valid_from"]) <= self.rp and (row["valid_to"] is None or self.rp < _iso(row["valid_to"])):
                return row["account"]
        if p.rsplit("-", 1)[0] not in self.domains and p in self.ad:
            return self.ad[p]
        return "UNMAPPED"

    def load_scope(self) -> None:
        spec = None
        for f in self.all("SPEC"):
            if self.doc_in_force("SPEC", f.control.get("revision", "")):
                spec = f
        prof = next(r for r in spec.doc.table("Share restore profiles") if r["share"] == self.share)
        self.includes = [x.strip() for x in prof["include_prefixes"].split(";") if x.strip()]
        self.holds = sorted((h for h in self.dispositions if h["share"] == self.share and h["action"] == "DESTROY"
                             and h["effective"] <= self.rp_date), key=lambda h: h["hold"])
        cats = [f for f in self.all("EXCL")]
        in_force = max(cats, key=lambda f: int(f.control.get("revision", "0")))
        withdrawn = set()
        for f in cats:
            for w in f.tables.get("withdrawal", []):
                if w["effective"] <= self.rp_date:
                    withdrawn.add(w["id"])
        self.patterns = sorted((p for p in in_force.tables.get("pattern", [])
                                if p["scope"] in ("ALL", self.share) and p["from"] <= self.rp_date
                                and (not p["to"] or p["to"] > self.rp_date) and p["id"] not in withdrawn),
                               key=lambda p: int(p["id"].split("-")[1]))
        vol = next(v for v in self.one("VOL").tables["volume"] if v["id"] == self.target_volume)
        self.volume = vol

    # ------------------------------------------------------------------ restore decisions
    def custody(self) -> str:
        import hashlib
        src = {f.part: f.control.get("source_custody") for f in self.all("CAT", "CORRECTED")}
        lines = []
        for f in self.files:
            if f.status not in ("ORIGINAL", "ISSUED"):
                continue
            c = f.control["custody"]
            lines.append(f"{f.stream}|{f.part}|{f.status}|{f.control['records']}|{c}")
        return hashlib.sha256("".join(x + "\n" for x in sorted(lines)).encode("utf-8")).hexdigest()

    def allocation(self, size: int) -> int:
        v = self.volume
        c = v["large_cluster"] if size >= v["large_threshold"] else v["small_cluster"]
        return -(-size // c) * c

    def decide(self) -> None:
        order_sets = {s.sid: s for s in self.sets.values()}
        ok = {s.sid for s in self.chain} | {s.sid for s, r in self.skipped if r in ("BEFORE_BASE", "SUPERSEDED_BY_DIFF")}
        hist: dict[str, list] = {}
        for sid in ok:
            es = self.entries_by_set.get(sid, [])
            voided = {e.voids for e in es if e.etype == "X"}
            for e in es:
                if e.etype != "F" or e.eid in voided or not e.committed:
                    continue
                self.canonicalize(e)
                if e.rejected:
                    continue
                st = order_sets[sid]
                hist.setdefault(paths.key(e.canon), []).append(((st.snapshot, st.sid, e.seq), e))
        rows, excl, rolled = [], [], 0
        for o in sorted(self.objs.values(), key=lambda o: (paths.key(o.path), o.path)):
            kind = "file" if o.kind == "file" else "symlink"
            reason, detail, link_target = None, "", ""
            if not any(paths.under(o.path, inc) for inc in self.includes):
                reason = "OUT_OF_SCOPE"
            if reason is None:
                hs = [h for h in self.holds if paths.under(o.path, h["prefix"])]
                if hs:
                    reason, detail = "DISPOSED", hs[0]["hold"]
            if reason is None:
                for p in self.patterns:
                    if globs.match(p["pattern"], o.path):
                        reason, detail = "EXCLUDED_PATTERN", p["id"]
                        break
            if reason is None and kind == "symlink":
                host = o.entry.host
                lt = paths.resolve_link(o.target, o.path, self.roots.get((host, self.share.upper()), []), self.host_os.get(host) == "windows")
                if lt is None:
                    reason = "SYMLINK_ESCAPE"
                else:
                    link_target = lt
            chosen = o.entry
            if reason is None and kind == "file" and (chosen.sha256, chosen.container) in self.infected:
                st = order_sets[chosen.sid]
                mine = (st.snapshot, st.sid, chosen.seq)
                cands = sorted((c for c in hist.get(paths.key(o.path), []) if c[0] < mine), key=lambda c: c[0], reverse=True)
                chosen = next((c[1] for c in cands if (c[1].sha256, c[1].container) not in self.infected), None)
                if chosen is None:
                    reason, detail = "QUARANTINED", o.entry.sha256
                else:
                    rolled += 1
            cont, cp = "", None
            if reason is None and kind == "file":
                cont, cp = self.pick_copy(chosen.container)
                if cp is None:
                    reason, detail = "UNRECOVERABLE", cont
            if reason:
                excl.append({"path": o.path, "kind": kind, "reason": reason, "detail": detail})
                continue
            e = chosen
            mt = e.mtime
            if mt == "SENTINEL" or mt is None:
                mt = order_sets[e.sid].snapshot
            row = {"path": o.path, "kind": kind, "size": e.size if kind == "file" else 0, "allocated": 0,
                   "sha256": e.sha256 if kind == "file" else "", "mode": values.mode_out(e.mode, e.attrs),
                   "mtime_utc": values.iso_z(mt), "owner": self.owner(e), "source_set": e.sid,
                   "container": cont, "media": cp["media"] if cp else "", "copy": cp["copy"] if cp else 0,
                   "hardlink_group": "", "link_target": link_target, "_gk": (e.client, e.file_id) if kind == "file" else None,
                   "_size": cp["size"] if cp else 0}
            if kind == "file":
                row["allocated"] = self.allocation(e.size)
            rows.append(row)
        groups: dict = {}
        for row in rows:
            if row["_gk"] is not None:
                groups.setdefault(row["_gk"], []).append(row)
        n = 0
        for row in rows:
            g = groups.get(row["_gk"]) if row["_gk"] is not None else None
            if g and len(g) > 1 and g[0] is row:
                n += 1
                for i, m in enumerate(g):
                    m["hardlink_group"] = f"HL-{n:04d}"

        self.rows, self.excl, self.rolled, self.groups = rows, excl, rolled, n

    # ------------------------------------------------------------------ deliverables
    def pull_list(self) -> list[dict]:
        by: dict[str, dict] = {}
        for row in self.rows:
            if row["kind"] != "file":
                continue
            m = by.setdefault(row["media"], {"copy": row["copy"], "containers": {}})
            m["containers"][row["container"]] = row["_size"]
        out = []
        from decimal import ROUND_HALF_EVEN, Decimal
        for media, m in by.items():
            rb = sum(m["containers"].values())
            gib = round(rb / 1073741824, 3)
            out.append({"media_id": media, "vault": self.vault.get(media, ""), "copy": m["copy"],
                        "containers": len(m["containers"]), "read_bytes": rb, "read_gib": f"{gib:.3f}"})
        out.sort(key=lambda x: (self.vault_prio.get(x["vault"], 99), x["media_id"]))
        return out

    def run(self) -> dict:
        self.load_request()
        self.load_hosts()
        self.load_sets()
        self.select_chain()
        self.load_catalog()
        self.replay()
        self.load_media()
        self.load_av()
        self.load_identity()
        self.load_scope()
        self.decide()
        pull = self.pull_list()
        digest = self.custody()
        counts = {r: 0 for r in REASONS}
        for x in self.excl:
            counts[x["reason"]] += 1
        chain = {"share": self.share, "restore_point_utc": values.iso_z(self.rp),
                 "effective_point_utc": values.iso_z(self.chain[-1].snapshot),
                 "chain": [{"set": s.sid, "type": s.type, "snapshot_utc": values.iso_z(s.snapshot),
                            "role": "base" if i == 0 else ("diff" if s.type == "DIFF" else "incremental")}
                           for i, s in enumerate(self.chain)],
                 "skipped": [{"set": s.sid, "type": s.type, "snapshot_utc": values.iso_z(s.snapshot), "reason": r}
                             for s, r in sorted(self.skipped, key=lambda x: (x[0].snapshot, x[0].sid))],
                 "custody_digest": digest}
        recon = {"sets": self.recon_sets, "objects_at_effective_point": len(self.objs), "restored": len(self.rows),
                 "excluded": counts, "rolled_back": self.rolled, "bytes_restored": sum(r["size"] for r in self.rows),
                 "bytes_allocated": sum(r["allocated"] for r in self.rows), "hardlink_groups": self.groups,
                 "media": len(pull), "containers": sum(p["containers"] for p in pull),
                 "read_bytes": sum(p["read_bytes"] for p in pull), "custody_digest": digest}
        return {"manifest": self.rows, "exclusions": self.excl, "pull": pull, "chain": chain, "recon": recon, "digest": digest}
