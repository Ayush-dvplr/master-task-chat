"""Command line: python -m restorekit restore --feed DIR --out DIR"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from restorekit import engine, report


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="restorekit")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("plan", help="restore a share to the point a restore feed requests")
    r.add_argument("--catalog", required=True, type=Path)
    r.add_argument("--output", required=True, type=Path)
    args = ap.parse_args(argv)
    result = engine.Restore(args.catalog).run()
    report.write_all(args.output, result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
