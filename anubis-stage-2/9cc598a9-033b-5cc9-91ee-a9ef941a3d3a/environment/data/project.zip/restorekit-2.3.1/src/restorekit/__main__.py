import sys

from restorekit.cli import main

sys.exit(main())
