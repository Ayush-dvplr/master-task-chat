"""Reading a restore feed: format detection by content, control blocks and raw tables."""

from __future__ import annotations

import configparser
import csv
import io
import json
import mailbox
import sqlite3
import tomllib
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from xml.etree import ElementTree as ET

import magic
import yaml

from restorekit import docs


@dataclass
class FeedFile:
    path: Path
    fmt: str
    control: dict[str, str]
    tables: dict[str, list] = field(default_factory=dict)   # name -> list of row dicts, in file order
    lines: list[str] = field(default_factory=list)
    doc: docs.Document | None = None
    extra: dict = field(default_factory=dict)

    @property
    def stream(self) -> str:
        return self.control.get("stream", "")

    @property
    def part(self) -> str:
        return self.control.get("part", "")

    @property
    def status(self) -> str:
        return self.control.get("status", "")


def parse_control(text: str) -> dict[str, str]:
    out = {}
    for item in text.strip().split():
        if "=" in item:
            k, v = item.split("=", 1)
            out[k] = v
    return out


def sniff(data: bytes) -> str:
    if data.startswith(b"PK"):
        try:
            names = set(zipfile.ZipFile(io.BytesIO(data)).namelist())
        except zipfile.BadZipFile:
            return "unknown"
        if "xl/workbook.xml" in names:
            return "xlsx"
        if "word/document.xml" in names:
            return "docx"
        return "zip"
    if data.startswith(b"PAR1"):
        return "parquet"
    if data.startswith(b"SQLite format 3\x00"):
        return "sqlite"
    if data.startswith(b"%PDF"):
        return "pdf"
    head = data[:4096].lstrip(b"\xef\xbb\xbf").decode("utf-8", "replace")
    first = head.split("\n", 1)[0].strip()
    if first.startswith("#control"):
        lines = head.splitlines()
        second = lines[1] if len(lines) > 1 else ""
        if second.startswith("#layout"):
            return "fixed"
        ctl = parse_control(first[len("#control"):])
        if ctl.get("stream") == "LOG":
            return "log"
        return "tsv" if "\t" in second else "csv"
    if first.startswith("BEGIN:VCALENDAR"):
        return "ics"
    if first.startswith("From "):
        return "mbox"
    if first.startswith("<?xml"):
        return "xml"
    if first.lower().startswith("<!doctype html") or first.lower().startswith("<html"):
        return "html"
    if first.startswith("<!-- restore-control:"):
        return "md"
    if first.startswith("{"):
        try:
            json.loads(data.decode("utf-8"))
            return "json"
        except ValueError:
            return "jsonl"
    if first.startswith("[control]"):
        try:
            tomllib.loads(data.decode("utf-8"))
            return "toml"
        except tomllib.TOMLDecodeError:
            return "ini"
    if first.startswith("control:"):
        return "yaml"
    return "unknown"


def _text_lines(data: bytes) -> list[str]:
    """Decode a line-oriented file: BOM, CRLF and '#encoding' sections."""
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    out = []
    enc = "utf-8"
    for raw in data.split(b"\n"):
        if raw.endswith(b"\r"):
            raw = raw[:-1]
        line = raw.decode(enc)
        out.append(line)
    while out and out[-1] == "":
        out.pop()
    return out


def _unescape_tsv(s: str) -> str:
    out, i = [], 0
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            n = s[i + 1]
            out.append({"t": "\t", "n": "\n", "r": "\r", "\\": "\\"}.get(n, n))
            i += 2
            continue
        out.append(c)
        i += 1
    return "".join(out)


def read_delimited(data: bytes, delim: str) -> tuple[dict, list[dict]]:
    lines = _text_lines(data)
    control = parse_control(lines[0][len("#control"):])
    rows: list[dict] = []
    header: list[str] | None = None
    body: list[str] = []

    def flush() -> None:
        if header is None or not body:
            return
        if delim == ",":
            reader = csv.reader(io.StringIO("\n".join(body)))
            parsed = list(reader)
        else:
            parsed = [ln.split("\t") for ln in body]
        for cells in parsed:
            rows.append(dict(zip(header, cells)))

    for ln in lines[1:]:
        if ln.startswith("#schema "):
            flush()
            body = []
            spec = ln[len("#schema "):]
            header = next(csv.reader([spec])) if delim == "," else spec.split("\t")
            continue
        if ln.startswith("#"):
            continue
        if header is None:
            header = next(csv.reader([ln])) if delim == "," else ln.split("\t")
            continue
        body.append(ln)
    flush()
    return control, rows


def read_fixed(data: bytes, layouts: dict[str, list[tuple[str, int]]]) -> tuple[dict, list[dict]]:
    lines = _text_lines(data)
    control = parse_control(lines[0][len("#control"):])
    rows = []
    layout = None
    for ln in lines[1:]:
        if ln.startswith("#layout"):
            layout = layouts.get(ln.split()[1])
            continue
        if ln.startswith("#") or layout is None:
            continue
        pos, row = 0, {}
        for name, width in layout:
            row[name] = ln[pos:pos + width].strip()
            pos += width
        rows.append(row)
    return control, rows


def _xml_rows(root: ET.Element) -> tuple[dict, list[dict]]:
    control = {}
    rows = []
    for el in root:
        if el.tag == "control":
            control = dict(el.attrib)
        elif len(el.attrib) and not len(el):
            rows.append(dict(el.attrib))
        else:
            rows.append({c.tag: (c.text or "") for c in el})
    return control, rows


EXT = {".csv": "csv", ".tsv": "tsv", ".txt": "fixed", ".log": "log", ".jsonl": "jsonl", ".json": "json",
       ".xml": "xml", ".parquet": "parquet", ".xlsx": "xlsx", ".db": "sqlite", ".yaml": "yaml", ".toml": "toml",
       ".ini": "ini", ".ics": "ics", ".mbox": "mbox", ".md": "md", ".html": "html", ".docx": "docx", ".pdf": "pdf"}


def load(path: Path, layouts: dict | None = None) -> FeedFile | None:
    data = path.read_bytes()
    fmt = EXT.get(path.suffix.lower()) or magic.from_buffer(data[:2048], mime=True)
    if fmt in ("csv", "tsv"):
        control, rows = read_delimited(data, "," if fmt == "csv" else "\t")
        return FeedFile(path, fmt, control, {"rows": rows})
    if fmt == "fixed":
        control, rows = read_fixed(data, layouts or {})
        return FeedFile(path, fmt, control, {"rows": rows})
    if fmt == "log":
        lines = _text_lines(data)
        return FeedFile(path, fmt, parse_control(lines[0][len("#control"):]), lines=lines[1:])
    if fmt == "jsonl":
        lines = [ln for ln in data.decode("utf-8").splitlines() if ln.strip()]
        head = json.loads(lines[0])
        return FeedFile(path, fmt, {k: str(v) for k, v in head["control"].items()}, {"rows": [json.loads(x) for x in lines[1:]]})
    if fmt == "json":
        doc = json.loads(data.decode("utf-8"))
        control = {k: str(v) for k, v in doc.pop("control").items()}
        return FeedFile(path, fmt, control, {k: v for k, v in doc.items() if isinstance(v, list)})
    if fmt == "xml":
        root = ET.fromstring(data)
        control, rows = _xml_rows(root)
        return FeedFile(path, fmt, control, {"rows": rows})
    if fmt == "parquet":
        import pyarrow.parquet as pq
        table = pq.read_table(io.BytesIO(data))
        meta = table.schema.metadata or {}
        control = parse_control(meta.get(b"restore-control", b"").decode())
        return FeedFile(path, fmt, control, {"rows": table.to_pylist()})
    if fmt == "xlsx":
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        tables, control = {}, {}
        for ws in wb.worksheets:
            vals = [list(r) for r in ws.iter_rows(values_only=True)]
            if not vals:
                continue
            header = [str(h) for h in vals[0]]
            rows = [dict(zip(header, r)) for r in vals[1:] if any(v is not None for v in r)]
            if ws.title == "_control":
                control = {str(r["key"]): str(r["value"]) for r in rows}
            else:
                tables[ws.title] = rows
        f = FeedFile(path, fmt, control, tables)
        f.extra["date1904"] = wb.epoch.year == 1904
        wb.close()
        return f
    if fmt == "sqlite":
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        con.row_factory = sqlite3.Row
        names = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        tables = {n: [dict(r) for r in con.execute(f'SELECT * FROM "{n}" ORDER BY rowid')] for n in names}
        con.close()
        control = {r["key"]: r["value"] for r in tables.pop("_control", [])}
        return FeedFile(path, fmt, control, tables)
    if fmt == "yaml":
        doc = yaml.safe_load(data.decode("utf-8"))
        control = {k: str(v) for k, v in doc.pop("control").items()}
        return FeedFile(path, fmt, control, {k: v for k, v in doc.items()})
    if fmt == "toml":
        doc = tomllib.loads(data.decode("utf-8"))
        control = {k: str(v) for k, v in doc.pop("control").items()}
        return FeedFile(path, fmt, control, {k: v for k, v in doc.items()})
    if fmt == "ini":
        cp = configparser.ConfigParser(interpolation=None, delimiters=("=",))
        cp.optionxform = str
        cp.read_string(data.decode("utf-8"))
        control = dict(cp["control"])
        sections = {s: dict(cp[s]) for s in cp.sections() if s != "control"}
        return FeedFile(path, fmt, control, {"sections": [dict(v, _section=k) for k, v in sections.items()]})
    if fmt == "ics":
        return _load_ics(path, data)
    if fmt == "mbox":
        return _load_mbox(path)
    if fmt in ("md", "html", "docx", "pdf"):
        d = docs.load(fmt, data)
        return FeedFile(path, fmt, d.control, doc=d)
    return None


def _load_ics(path: Path, data: bytes) -> FeedFile:
    text = data.decode("utf-8").replace("\r\n", "\n").replace("\n ", "").replace("\n\t", "")
    control, events, cur = {}, [], None
    for ln in text.splitlines():
        if ln.startswith("X-RESTORE-CONTROL:"):
            control = parse_control(ln.split(":", 1)[1])
        elif ln == "BEGIN:VEVENT":
            cur = {}
        elif ln == "END:VEVENT":
            events.append(cur)
            cur = None
        elif cur is not None and ":" in ln:
            name, value = ln.split(":", 1)
            prop, _, params = name.partition(";")
            cur[prop] = (value, params)
    return FeedFile(path, "ics", control, {"events": events})


def _load_mbox(path: Path) -> FeedFile:
    box = mailbox.mbox(str(path), create=False)
    msgs = []
    control = {}
    for m in box:
        ctl = m.get("X-Restore-Control")
        if ctl:
            control = parse_control(ctl)
            continue
        body = m.get_payload(decode=True)
        body = body.decode("utf-8", "replace") if isinstance(body, bytes) else str(m.get_payload())
        msgs.append({"date": m.get("Date", ""), "subject": m.get("Subject", ""), "body": body})
    box.close()
    return FeedFile(path, "mbox", control, {"messages": msgs})


def load_feed(feed_dir: Path, layouts: dict) -> list[FeedFile]:
    out = []
    for p in sorted(feed_dir.iterdir()):
        if not p.is_file():
            continue
        f = load(p, layouts)
        if f is not None and f.control:
            out.append(f)
    return out
