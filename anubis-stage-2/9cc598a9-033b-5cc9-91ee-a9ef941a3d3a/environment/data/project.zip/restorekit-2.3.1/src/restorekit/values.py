"""Value notations of the feed: identifiers, numbers, timestamps, modes and sentinels."""

from __future__ import annotations

import datetime as dt
import re
from decimal import Decimal
from distutils.util import strtobool
from zoneinfo import ZoneInfo

UTC = dt.timezone.utc
EPOCH = dt.datetime(1970, 1, 1, tzinfo=UTC)
FT_EPOCH = dt.datetime(1601, 1, 1, tzinfo=UTC)
XL_1900 = dt.datetime(1899, 12, 30, tzinfo=UTC)
XL_1904 = dt.datetime(1904, 1, 1, tzinfo=UTC)
ID_WIDTH = {"BS": 5, "E": 7, "CT": 7, "RC": 7, "MD": 5}


class Folds:
    """Identifier fold table (PATHCONV Appendix C, identifier scope)."""

    table: dict[str, str] = {}


def norm_id(value) -> str:
    if value is None:
        return ""
    s = str(value).strip()
    if not s:
        return ""
    s = s.upper()
    m = re.fullmatch(r"([A-Z]+)-?0*(\d+)", s)
    if not m or m.group(1) not in ID_WIDTH:
        return s
    return f"{m.group(1)}-{int(m.group(2)):0{ID_WIDTH[m.group(1)]}d}"


def norm_hash(value) -> str:
    s = str(value or "").strip().lower()
    return s[7:] if s.startswith("sha256:") else s


def parse_int(value, locale: str) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise ValueError(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    s = str(value).strip()
    sep = {"en_US": ",", "de_DE": ".", "fr_FR": " "}.get(locale)
    if sep:
        s = s.replace(sep, "")
    return int(s)


def parse_dec(value, locale: str) -> Decimal:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return Decimal(repr(value)) if isinstance(value, float) else Decimal(value)
    s = str(value).strip()
    if locale in ("de_DE", "fr_FR"):
        s = s.replace("\u202f", "").replace(".", "").replace(",", ".")
    elif locale == "en_US":
        s = s.replace(",", "")
    return Decimal(s)


def size_of(row: dict, locale: str) -> int | None:
    for key in ("size", "size_bytes", "bytes"):
        if key in row and row[key] not in ("", None):
            return parse_int(row[key], locale)
    if "size_kib" in row and row["size_kib"] not in ("", None):
        v = parse_dec(row["size_kib"], locale) * 1024
        return int(v)
    return None


SENTINEL_TEXT = ("0000-00-00",)


def parse_ts(value, kind: str, tz: str | None = None, date1904: bool = False):
    """Returns an aware UTC datetime, 'SENTINEL', or None for an empty cell."""
    if value is None or value == "":
        return None
    if isinstance(value, dt.datetime):
        return value if value.tzinfo else value.replace(tzinfo=UTC)
    if kind in ("utc", "iso", "local"):
        s = str(value).strip()
        if s.startswith("0000-00-00"):
            return "SENTINEL"
        if kind == "local":
            wall = dt.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            return wall.replace(tzinfo=ZoneInfo(tz or "UTC"), fold=0).astimezone(UTC)
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
        return t.astimezone(UTC)
    n = int(value) if not isinstance(value, float) else value
    if kind == "epoch":
        return "SENTINEL" if n == 0 else EPOCH + dt.timedelta(seconds=n)
    if kind == "ms":
        return EPOCH + dt.timedelta(milliseconds=n)
    if kind == "ft":
        return "SENTINEL" if n == 0 else FT_EPOCH + dt.timedelta(microseconds=n // 10)
    if kind == "xl":
        if float(n) == 0:
            return "SENTINEL"
        base = XL_1900
        return base + dt.timedelta(seconds=round(float(n) * 86400))
    raise ValueError(kind)


def as_wall_in(t: dt.datetime, tz: str) -> dt.datetime:
    """FAT rule: the digits of the value are the client's wall-clock time."""
    wall = t.astimezone(UTC).replace(tzinfo=None)
    return wall.replace(tzinfo=ZoneInfo(tz), fold=0).astimezone(UTC)


def iso_z(t: dt.datetime) -> str:
    return t.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_mode(row: dict) -> int | None:
    for key in ("mode_oct", "mode_sym", "mode_dec", "st_mode"):
        v = row.get(key)
        if v in (None, ""):
            continue
        s = str(v).strip()
        if key == "mode_dec":
            return int(s)
        if key == "mode_oct":
            return int(s, 8)
        if key == "st_mode":
            return int(s, 8) & 0o7777
        bits = 0
        trip = s[1:10]
        for i, (shift, special) in enumerate(((6, 0o4000), (3, 0o2000), (0, 0o1000))):
            r, w, x = trip[i * 3:i * 3 + 3]
            bits |= (4 if r == "r" else 0) << shift
            bits |= (2 if w == "w" else 0) << shift
            if x in ("x", "s", "t"):
                bits |= 1 << shift
            if x in ("s", "S", "t", "T"):
                bits |= special
        return bits
    return None


def mode_out(mode: int | None, attrs: str | None) -> str:
    if mode is None:
        return "0444" if "R" in (attrs or "") else "0644"
    return f"{mode & 0o777:04o}"


def truthy(v) -> bool:
    return bool(strtobool(str(v)))
