"""Documents of the feed (Markdown, HTML, Word, PDF): control line, prose and tables."""

from __future__ import annotations

import html.parser
import io
import re
import zipfile
from dataclasses import dataclass, field
from xml.etree import ElementTree as ET


@dataclass
class Document:
    control: dict[str, str]
    text: str
    tables: list[tuple[str, list[str], list[list[str]]]] = field(default_factory=list)

    def table(self, caption: str) -> list[dict[str, str]]:
        for cap, cols, rows in self.tables:
            if cap == caption:
                return [dict(zip(cols, r)) for r in rows]
        return []


def _control(text: str) -> dict[str, str]:
    out = {}
    for item in text.split():
        if "=" in item:
            k, v = item.split("=", 1)
            out[k] = v
    return out


def load(fmt: str, data: bytes) -> Document:
    return {"md": _md, "html": _html, "docx": _docx, "pdf": _pdf}[fmt](data)


def _split_md_row(line: str) -> list[str]:
    body = line.strip()[1:-1]
    cells, cur, i = [], "", 0
    while i < len(body):
        if body[i] == "\\" and i + 1 < len(body) and body[i + 1] == "|":
            cur += "|"
            i += 2
            continue
        if body[i] == "|":
            cells.append(cur.strip())
            cur = ""
        else:
            cur += body[i]
        i += 1
    cells.append(cur.strip())
    return cells


def _md(data: bytes) -> Document:
    lines = data.decode("utf-8").splitlines()
    m = re.match(r"<!-- restore-control: (.*) -->", lines[0])
    doc = Document(_control(m.group(1)) if m else {}, "")
    prose, i = [], 1
    while i < len(lines):
        ln = lines[i]
        t = re.match(r"\*\*Table: (.*)\*\*$", ln)
        if t and i + 3 < len(lines) and lines[i + 2].startswith("|"):
            cols = _split_md_row(lines[i + 2])
            rows = []
            j = i + 4
            while j < len(lines) and lines[j].startswith("|"):
                rows.append(_split_md_row(lines[j]))
                j += 1
            doc.tables.append((t.group(1), cols, rows))
            i = j
            continue
        prose.append(ln)
        i += 1
    doc.text = "\n".join(prose)
    return doc


class _HTML(html.parser.HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.control: dict[str, str] = {}
        self.tables: list = []
        self.text: list[str] = []
        self.cap = None
        self.cell: list[str] | None = None
        self.row: list[str] | None = None
        self.rows: list = []
        self.cols: list = []
        self.in_cap = False
        self.in_head = False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "meta" and a.get("name") == "restore-control":
            self.control = _control(a.get("content", ""))
        elif tag == "table":
            self.cap, self.rows, self.cols = "", [], []
        elif tag == "caption":
            self.in_cap = True
        elif tag == "thead":
            self.in_head = True
        elif tag == "tr":
            self.row = []
        elif tag in ("td", "th"):
            self.cell = []

    def handle_endtag(self, tag):
        if tag == "caption":
            self.in_cap = False
        elif tag == "thead":
            self.in_head = False
        elif tag in ("td", "th") and self.row is not None and self.cell is not None:
            self.row.append("".join(self.cell))
            self.cell = None
        elif tag == "tr" and self.row is not None:
            if self.in_head:
                self.cols = self.row
            else:
                self.rows.append(self.row)
            self.row = None
        elif tag == "table":
            self.tables.append((self.cap, self.cols, self.rows))

    def handle_data(self, d):
        if self.in_cap:
            self.cap += d
        elif self.cell is not None:
            self.cell.append(d)
        else:
            self.text.append(d)


def _html(data: bytes) -> Document:
    p = _HTML()
    p.feed(data.decode("utf-8"))
    return Document(p.control, "\n".join(t for t in p.text if t.strip()), p.tables)


W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _ptext(p: ET.Element) -> str:
    return "".join(t.text or "" for t in p.iter(W + "t"))


def _docx(data: bytes) -> Document:
    xml = zipfile.ZipFile(io.BytesIO(data)).read("word/document.xml")
    body = ET.fromstring(xml).find(W + "body")
    doc = Document({}, "")
    prose, caption = [], ""
    for el in body:
        if el.tag == W + "p":
            t = _ptext(el)
            if t.startswith("CONTROL ") and not doc.control:
                doc.control = _control(t[8:])
                continue
            if t.startswith("Table: "):
                caption = t[7:]
                continue
            prose.append(t)
        elif el.tag == W + "tbl":
            rows = [[_ptext(tc) for tc in tr.findall(W + "tc")] for tr in el.findall(W + "tr")]
            doc.tables.append((caption, rows[0], rows[1:]))
    doc.text = "\n".join(prose)
    return doc


def _pdf(data: bytes) -> Document:
    import pypdf
    reader = pypdf.PdfReader(io.BytesIO(data))
    lines: list[str] = []
    for page in reader.pages:
        page_lines = page.extract_text().split("\n")
        if page_lines and re.match(r"^Page \d+ of \d+$", page_lines[-1].strip()):
            page_lines = page_lines[:-1]
        lines.extend(page_lines)
    doc = Document({}, "")
    prose = []
    i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        if ln.startswith("CONTROL ") and not doc.control:
            doc.control = _control(ln[8:])
            i += 1
            continue
        if ln.startswith("TABLE "):
            cap = ln[6:]
            header = lines[i + 1].rstrip()
            cols = header.split(" | ")
            rows = []
            j = i + 2
            while j < len(lines) and lines[j].rstrip() != "END TABLE":
                cur = lines[j].rstrip()
                if cur != header + " (continued)":
                    rows.append(["" if c == "-" else c for c in cur.split(" | ")])
                j += 1
            doc.tables.append((cap, cols, rows))
            i = j + 1
            continue
        prose.append(ln)
        i += 1
    doc.text = "\n".join(prose)
    return doc
