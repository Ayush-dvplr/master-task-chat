"""Raw catalog paths to canonical share paths, identity keys and link targets."""

from __future__ import annotations

import re
import unicodedata


def key(path: str) -> str:
    return path.lower()


def under(path: str, prefix: str) -> bool:
    a, b = key(path), key(prefix.rstrip("/"))
    return a == b or a.startswith(b + "/")


class Unsafe(Exception):
    pass


class Outside(Exception):
    pass


def _strip_root(raw: str, roots: list[str], windows: bool) -> str | None:
    best = None
    for root in roots:
        r = root.replace("\\", "/") if windows else root
        s = raw.replace("\\", "/") if windows else raw
        a, b = s, r
        if a == b or a.startswith(b + "/"):
            if best is None or len(r) > len(best[0]):
                best = (r, s[len(r):])
    return None if best is None else best[1]


def _components(rest: str, windows: bool, base: list[str] | None = None) -> list[str]:
    comps = list(base or [])
    for c in rest.split("/"):
        if c in ("", "."):
            continue
        if c == "..":
            if not comps:
                raise Unsafe(rest)
            comps.pop()
            continue
        comps.append(c)
    return comps


def canonical(raw: str, roots: list[str], windows: bool) -> str:
    rest = _strip_root(raw, roots, windows)
    if rest is None:
        raise Outside(raw)
    return "/" + "/".join(_components(rest, windows))


def resolve_link(target: str, link_path: str, roots: list[str], windows: bool) -> str | None:
    rest = _strip_root(target, roots, windows)
    if rest is not None:
        try:
            return "/" + "/".join(_components(rest, windows))
        except Unsafe:
            return None
    t = target.replace("\\", "/") if windows else target
    if t.startswith("/") or (windows and re.match(r"^[A-Za-z]:", t)):
        return None
    base = [c for c in link_path.split("/")[:-1] if c]
    out = list(base)
    for c in t.split("/"):
        if c in ("", "."):
            continue
        if c == "..":
            if not out:
                return None
            out.pop()
        else:
            out.append(unicodedata.normalize("NFC", c))
    return "/" + "/".join(out)
