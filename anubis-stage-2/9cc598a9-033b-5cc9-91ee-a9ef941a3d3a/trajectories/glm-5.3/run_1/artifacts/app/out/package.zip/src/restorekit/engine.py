"""Point-in-time restore of one share from a restore feed (restore specification revision 4.2)."""

from __future__ import annotations

import datetime as dt
import email.utils
import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path
from zoneinfo import ZoneInfo

from restorekit import feed, globs, paths, report, values
from restorekit.values import UTC, norm_hash, norm_id

REASONS = ["OUT_OF_SCOPE", "DISPOSED", "EXCLUDED_PATTERN", "SYMLINK_ESCAPE", "QUARANTINED", "UNRECOVERABLE"]
CAT_CANON = {
    "set": ["set_id", "backup_set", "bset", "set"], "seq": ["seq", "sequence"], "entry": ["entry_id", "eid", "entry"],
    "type": ["etype", "entry_type", "op", "type"], "path": ["path", "src_path", "object"],
    "new_path": ["new_path", "rename_to"], "target": ["target", "link_target"], "kind": ["kind", "obj_kind"],
    "owner": ["owner", "principal"], "sha256": ["sha256", "content_hash", "digest"], "container": ["container", "ct_id"],
    "file_id": ["file_id", "inode"], "client": ["client", "agent_client"], "committed": ["committed", "commit_flag"],
    "voids": ["voids", "void_target"], "attrs": ["attrs", "win_attrs"],
}
ERRATA_FIELDS = ("sha256", "size", "mtime", "container")


class FeedError(Exception):
    pass


@dataclass
class Entry:
    eid: str
    sid: str
    seq: int
    etype: str
    path: str = ""
    new_path: str = ""
    target: str = ""
    kind: str = ""
    size: int | None = None
    mtime: object = None
    mode: int | None = None
    attrs: str | None = None
    owner: str = ""
    sha256: str = ""
    container: str = ""
    file_id: str = ""
    client: str = ""
    committed: bool = True
    voids: str = ""
    canon: str = ""
    canon_new: str = ""
    canon_target: str = ""
    rejected: str = ""
    host: str = ""


@dataclass
class SetInfo:
    sid: str
    job: str
    type: str
    status: str
    server: str
    queued: dt.datetime
    consolidates: str
    snapshot: dt.datetime | None = None
    crash: bool = False


@dataclass
class Obj:
    path: str
    kind: str
    entry: Entry
    target: str = ""


def _first(row: dict, names: list[str]):
    for n in names:
        if n in row and row[n] not in ("", None):
            return row[n]
    return None


def _iso(s: str) -> dt.datetime:
    return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(UTC)


def _time_key(s: str) -> str:
    return re.sub(r"(\.\d+)?(Z|\+00:00)?$", "", s)


class Restore:
    """Plans the restore of one share from the files of one restore feed."""

    def __init__(self, feed_dir: Path) -> None:
        feed_dir = Path(feed_dir)
        files = feed.load_feed(feed_dir, {})
        request = next((f for f in files if f.stream == "RRQ"), None)
        if request is None:
            raise FeedError("no restore request in the feed directory")
        self.feed_id = request.control.get("feed", "")
        self.files = [f for f in files if f.control.get("feed") == self.feed_id]
        guide = self.one("FMTGUIDE")
        layouts: dict[str, list] = {}
        for row in guide.doc.table("Fixed-width layouts"):
            layouts.setdefault(row["layout"], []).append((row["column"], int(row["width"])))
        self.layouts = layouts
        self.files = [feed.load(f.path, layouts) if f.fmt == "fixed" else f for f in self.files]
        values.Folds.table = {chr(int(r["codepoint"][2:], 16)): r["fold"]
                              for r in self.one("PATHCONV").doc.table("Confusable fold table")
                              if r["scope"] == "identifier"}

    # ------------------------------------------------------------------ feed access
    def all(self, stream: str, status: str | None = None) -> list:
        return [f for f in self.files if f.stream == stream and (status is None or f.status == status)]

    def one(self, stream: str, status: str | None = None):
        found = self.all(stream, status)
        if not found:
            raise FeedError(f"no {stream} file in feed")
        return found[0]

    # ------------------------------------------------------------------ request and documents
    def load_request(self) -> None:
        params = {r["key"]: r["value"] for r in self.one("RRQ").doc.table("Request parameters")}
        self.share = params["share"]
        share_row = next((s for s in self.one("SHARE").tables["shares"] if s["share"] == self.share), None)
        if share_row is None:
            raise FeedError(f"share {self.share} is not in the share registry")
        self.site_tz = share_row["site_tz"]
        self.array = share_row["array"]
        self.fold = share_row.get("case_policy") != "sensitive"
        wall = dt.datetime.strptime(params["restore_point_local"], "%Y-%m-%d %H:%M:%S")
        self.rp = wall.replace(tzinfo=ZoneInfo(self.site_tz), fold=0).astimezone(UTC)
        self.rp_date = wall.date().isoformat()
        self.request_date = params["request_date"]
        rd = dt.date.fromisoformat(self.request_date)
        self.req_end = dt.datetime.combine(rd, dt.time(23, 59, 59)).replace(tzinfo=ZoneInfo(self.site_tz)).astimezone(UTC)
        self.target_volume = params["target_volume"]
        self.dispositions = self.one("RRQ").doc.table("Records disposition holds")
        self.in_force: dict[tuple, bool] = {}
        for row in self.one("DOCREG").doc.table("Document control register"):
            ok = row["status"] in ("APPROVED", "IN FORCE") and row["effective"] and row["effective"] <= self.rp_date
            self.in_force[(row["stream"], row["revision"], row["section"])] = ok

    def doc_in_force(self, stream: str, revision: str, section: str = "ALL") -> bool:
        v = self.in_force.get((stream, revision, section))
        if v is None and section != "ALL":
            v = self.in_force.get((stream, revision, "ALL"))
        return bool(v)

    # ------------------------------------------------------------------ hosts, clients and roots
    def load_hosts(self) -> None:
        self.host_tz, self.host_os, self.host_fs = {}, {}, {}
        for h in self.one("HOST", "ORIGINAL").tables["hosts"]:
            self.host_tz[h["host"].upper()] = h["tz"]
            self.host_os[h["host"].upper()] = h["os"]
        for h in self.one("HOST", "CMDB-EXPORT").tables["hosts"]:
            self.host_fs[h["hostname"].upper()] = h["filesystem"]
        self.clientx = self.one("FMTGUIDE").doc.table("Client crosswalk")
        self.roots: dict[tuple, list[str]] = {}
        for s in self.one("ROOT").tables["sections"]:
            self.roots.setdefault((s["host"].upper(), s["share"].upper()), []).append(s["path"])
        self.servers = {}
        for s in self.one("SRV").tables["servers"]:
            builds = sorted((_iso(b["installed"]), b["log_timestamps"]) for b in s.get("builds", []))
            self.servers[s["name"]] = {"tz": s["tz"], "builds": builds}

    def client_host(self, code: str, when: dt.datetime) -> str | None:
        day = when.astimezone(ZoneInfo(self.site_tz)).date().isoformat()
        for row in self.clientx:
            if row["client"] == code and row["valid_from"] <= day and (not row["valid_to"] or day <= row["valid_to"]):
                return row["host"].upper()
        return None

    # ------------------------------------------------------------------ sets
    def load_sets(self) -> None:
        defs: dict[str, list] = {}
        for f in self.all("JOBDEF"):
            for j in f.tables["rows"]:
                defs.setdefault(j["name"].strip().upper(), []).append(j)
        xwalk = []
        for f in self.all("SPEC"):
            if self.doc_in_force("SPEC", f.control.get("revision", ""), "Appendix J"):
                xwalk += f.doc.table("Job rename crosswalk")

        def assigns(job: str) -> set[str]:
            """Shares that the job definitions assign a job name to; retired jobs carry none."""
            return {j.get("share", "") for j in defs.get(job, []) if j.get("status") != "RETIRED" and j.get("share", "")}

        def share_of(job: str, queued: dt.datetime) -> str:
            shares = assigns(job)
            if self.share in shares:
                return self.share
            if shares:
                return ""
            day = queued.astimezone(ZoneInfo(self.site_tz)).date().isoformat()
            for x in xwalk:
                if x["old_name"].strip().upper() == job and day < x["effective"]:
                    if self.share in assigns(x["new_name"].strip().upper()):
                        return self.share
            return ""

        self.entry_totals: dict[str, int] = {}
        for f in self.all("JOB", "REPORTING"):
            for row in f.tables.get("Sets", []):
                self.entry_totals[norm_id(row["set_id"])] = int(row["catalog_entries"])
        self.sets: dict[str, SetInfo] = {}
        for f in self.all("JOB", "ORIGINAL"):
            for row in f.tables["rows"]:
                kind = next(k for k in row if k.startswith("queued_")).split("_", 1)[1]
                server = row["server"].strip()
                tz = self.servers.get(server, {}).get("tz", "UTC")
                queued = values.parse_ts(row[f"queued_{kind}"], kind, tz)
                job = row["job_name"].strip().upper()
                if share_of(job, queued) != self.share:
                    continue
                sid = norm_id(row["set_id"])
                self.sets[sid] = SetInfo(sid, job, row["set_type"].strip().upper(), row["status"].strip().upper(),
                                         server, queued, norm_id(row.get("consolidates", "")))
        self._read_logs()
        self._apply_snapshot_times()
        self._crash()

    def _log_time(self, text: str, server: str) -> dt.datetime | None:
        """A log line's instant: offset notation as written, local notation in the server's zone."""
        info = self.servers.get(server)
        if info is None:
            return None
        text = text.strip()
        if re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(Z|[+-]\d\d:\d\d)", text):
            return _iso(text)
        if re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\dZ", text):
            return dt.datetime.strptime(text, "%Y-%m-%dT%H:%MZ").replace(tzinfo=UTC)
        if re.fullmatch(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d", text):
            wall = dt.datetime.strptime(text, "%Y-%m-%d %H:%M:%S")
            return wall.replace(tzinfo=ZoneInfo(info["tz"]), fold=0).astimezone(UTC)
        return None

    def _log_instant(self, line: str) -> tuple[dt.datetime, str, str, str] | None:
        m = re.match(r"^(\S+(?: \d\d:\d\d:\d\d)?) (\S+) (\w+) \[([\w-]+)\] (.*)$", line)
        if m is None:
            return None
        stamp, server, _level, comp, msg = m.groups()
        if server not in self.servers:
            return None
        t = self._log_time(stamp, server)
        if t is None:
            return None
        return t, server, comp, msg

    def _read_logs(self) -> None:
        self.snap: dict[str, dt.datetime] = {}
        self.status_change: dict[str, tuple] = {}
        gaps: dict[str, list] = {}
        original_lines: list[tuple[dt.datetime, str, str, str]] = []

        def take(t: dt.datetime, comp: str, msg: str) -> None:
            m = re.match(r"snapshot \{[^}]*\} created set=(\S+)", msg)
            if m and comp == "vss":
                sid = norm_id(m.group(1))
                if sid not in self.snap or self.snap[sid] > t:
                    self.snap[sid] = t
            m = re.match(r"set=(\S+) status changed (\S+) -> (\S+)", msg)
            if m and comp == "catalog-check":
                sid = norm_id(m.group(1))
                if sid not in self.status_change or self.status_change[sid][0] <= t:
                    self.status_change[sid] = (t, m.group(3))

        for f in self.all("LOG", "ORIGINAL"):
            for ln in f.lines:
                if ln.startswith("#"):
                    continue
                parsed = self._log_instant(ln)
                if parsed is None:
                    m = re.match(r"^(\S+Z) (\S+) (\w+) \[([\w-]+)\] (.*)$", ln)
                    if m is None:
                        continue
                    stamp, server, _lvl, comp, msg = m.groups()
                    try:
                        t = _iso(stamp)
                    except ValueError:
                        continue
                    parsed = (t, server, comp, msg)
                t, server, comp, msg = parsed
                if server in self.servers:
                    take(t, comp, msg)
                g = re.match(r"lines from (\S+) to (\S+) were not retained", msg)
                if g and comp == "logrotate":
                    gaps.setdefault(server, []).append((_iso(g.group(1)), _iso(g.group(2))))
        for f in self.all("LOG", "MIRROR"):
            for ln in f.lines:
                m = re.match(r"^(\d{4}-\d\d-\d\dT\d\d:\d\dZ) (\S+) (\w+) \[([\w-]+)\] (.*)$", ln)
                if m is None:
                    continue
                t = dt.datetime.strptime(m.group(1), "%Y-%m-%dT%H:%MZ").replace(tzinfo=UTC)
                if not any(a <= t <= b for a, b in gaps.get(m.group(2), [])):
                    continue
                take(t, m.group(4), m.group(5))
        for sid, (t, status) in self.status_change.items():
            if sid in self.sets:
                self.sets[sid].status = status

    def _apply_snapshot_times(self) -> None:
        for s in self.sets.values():
            s.snapshot = self.snap.get(s.sid)
            if s.type == "SYNTH":
                s.snapshot = self.snap.get(s.consolidates) if s.consolidates else None

    def _crash(self) -> None:
        actual: dict[str, list] = {}
        for f in self.all("LOG", "ORIGINAL"):
            for ln in f.lines:
                m = re.match(r"^(\S+Z) (\S+) maintenance uid=(\S+) actual-(start|end)$", ln.strip())
                if m:
                    slot = 0 if m.group(4) == "start" else 1
                    actual.setdefault(m.group(3), [None, None])[slot] = _iso(m.group(1))
        windows = []
        for ev in self.one("CAL").tables["events"]:
            if ev.get("X-ARRAY", ("",))[0] != self.array:
                continue
            if ev.get("STATUS", ("",))[0] != "CONFIRMED" or ev.get("X-IMPACT", ("",))[0] != "SNAPSHOT-CONSISTENCY":
                continue
            uid = ev["UID"][0]
            if uid in actual and all(actual[uid]):
                windows.append((actual[uid][0], actual[uid][1]))
            else:
                windows.append((self._ics_time(*ev["DTSTART"]), self._ics_time(*ev["DTEND"])))
        for s in self.sets.values():
            s.crash = s.snapshot is not None and any(a <= s.snapshot < b for a, b in windows)

    @staticmethod
    def _ics_time(value: str, params: str) -> dt.datetime:
        if value.endswith("Z"):
            return dt.datetime.strptime(value, "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
        tz = re.search(r"TZID=([^;:]+)", params).group(1)
        return dt.datetime.strptime(value, "%Y%m%dT%H%M%S").replace(tzinfo=ZoneInfo(tz), fold=0).astimezone(UTC)

    # ------------------------------------------------------------------ chain
    def select_chain(self) -> None:
        far = dt.datetime.max.replace(tzinfo=UTC)
        order = sorted(self.sets.values(), key=lambda s: (s.snapshot or far, s.sid))
        eligible = [s for s in order if s.snapshot is not None and s.snapshot <= self.rp
                    and s.status in ("COMPLETED", "PARTIAL") and not s.crash]
        bases = [s for s in eligible if s.type in ("FULL", "SYNTH")]
        if not bases:
            raise FeedError("no eligible base set")
        base = max(bases, key=lambda s: (s.snapshot, s.sid))
        diffs = [s for s in eligible if s.type == "DIFF" and s.snapshot > base.snapshot]
        diff = max(diffs, key=lambda s: (s.snapshot, s.sid)) if diffs else None
        anchor = diff if diff is not None else base
        chain = [base] + ([diff] if diff is not None else [])
        skipped, broken = [], False
        for s in order:
            if s is base or s is diff:
                continue
            if s.snapshot is None or s.snapshot > self.rp:
                reason = "AFTER_RP"
            elif s.status in ("FAILED", "CANCELLED"):
                reason = s.status
            elif s.crash:
                reason = "CRASH_INCONSISTENT"
                if s.snapshot > anchor.snapshot:
                    broken = True
            elif s.snapshot <= base.snapshot:
                reason = "BEFORE_BASE"
            elif s.snapshot <= anchor.snapshot:
                reason = "SUPERSEDED_BY_DIFF"
            elif broken:
                reason = "CHAIN_BROKEN"
            elif s.type == "INCR":
                chain.append(s)
                continue
            else:
                reason = "SUPERSEDED_BY_DIFF"
            skipped.append((s, reason))
        self.chain, self.skipped = chain, skipped

    # ------------------------------------------------------------------ catalog
    def load_catalog(self) -> None:
        wanted = set(self.sets)
        entries: dict[str, Entry] = {}
        original_ids: dict[str, set] = {}
        parts: list = []
        for f in self.all("CAT"):
            if f.status == "CORRECTED":
                continue
            parts.append(f)
        for f in parts:
            ids: set[str] = set()
            for raw in self._cat_rows(f):
                e = self._entry(raw, f)
                if e is None:
                    continue
                ids.add(e.eid)
                if f.status == "ORIGINAL" and e.sid in wanted:
                    entries[e.eid] = e
            if f.status == "ORIGINAL":
                original_ids[f.part] = ids
        for f in parts:
            if f.status != "RESEND":
                continue
            known = original_ids.get(f.part, set())
            for raw in self._cat_rows(f):
                e = self._entry(raw, f)
                if e is None or e.eid in known:
                    continue
                if e.sid in wanted:
                    entries[e.eid] = e
        self._errata(entries)
        self.entries_by_set: dict[str, list[Entry]] = {}
        for e in entries.values():
            self.entries_by_set.setdefault(e.sid, []).append(e)
        for lst in self.entries_by_set.values():
            lst.sort(key=lambda e: (e.seq, e.eid))

    @staticmethod
    def _cat_rows(f) -> list[dict]:
        rows = []
        for name, lst in f.tables.items():
            rows.extend(lst)
        return rows

    def _entry(self, row: dict, f) -> Entry | None:
        sid = norm_id(_first(row, CAT_CANON["set"]))
        eid = norm_id(_first(row, CAT_CANON["entry"]))
        if not sid or not eid:
            return None
        seq = _first(row, CAT_CANON["seq"])
        seq = 0 if seq in (None, "") else int(float(seq))
        if sid not in self.sets:
            return Entry(eid, sid, seq, "")
        locale = f.control.get("locale", "plain")
        e = Entry(eid, sid, seq, str(_first(row, CAT_CANON["type"]) or "").strip().upper())
        for fld in ("path", "new_path", "target", "kind", "owner", "client", "attrs"):
            v = _first(row, CAT_CANON[fld])
            setattr(e, fld, "" if v is None else str(v))
        e.client = e.client.strip()
        e.kind = e.kind.strip().lower()
        e.sha256 = norm_hash(_first(row, CAT_CANON["sha256"]))
        e.container = norm_id(_first(row, CAT_CANON["container"]))
        e.voids = norm_id(_first(row, CAT_CANON["voids"]))
        fid = _first(row, CAT_CANON["file_id"])
        e.file_id = "" if fid is None else str(int(fid)) if isinstance(fid, float) and fid.is_integer() else str(fid).strip()
        c = _first(row, CAT_CANON["committed"])
        e.committed = True if c is None else values.truthy(c)
        e.size = values.size_of(row, locale)
        e.mode = values.parse_mode(row)
        e.etype = e.etype or ""
        snap = self.sets[sid].snapshot
        host = self.client_host(e.client, snap) if e.client else None
        tkey = next((k for k in row if re.match(r"^(mtime|modified)_(\w+)$", k)), None)
        if tkey is not None and e.etype in ("F", "L"):
            kind = tkey.split("_", 1)[1]
            fat = host is not None and self.host_fs.get(host, "") in ("FAT32", "exFAT")
            tz = self.host_tz.get(host or "", "UTC")
            v = row[tkey]
            if v in ("", None):
                e.mtime = "SENTINEL" if f.fmt == "parquet" else None
            else:
                e.mtime = values.parse_ts(v, kind, tz, f.extra.get("date1904", False), wall=fat)
        e.host = host or ""
        return e

    @staticmethod
    def _errata_value(field: str, value: str):
        """A correction only applies when its value is written in the canonical form."""
        v = str(value).strip()
        if field == "sha256":
            return v if re.fullmatch(r"[0-9a-f]{64}", v) else None
        if field == "size":
            return int(v) if re.fullmatch(r"[0-9]+", v) else None
        if field == "mtime":
            return _iso(v) if re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ", v) else None
        if field == "container":
            return v if re.fullmatch(r"(?:CT|RC)-\d{7}", v) else None
        return None

    def _errata(self, entries: dict[str, Entry]) -> None:
        best: dict[tuple, tuple] = {}
        for f in self.all("ERR"):
            rev = f.control.get("revision", "")
            if not self.doc_in_force("ERR", rev):
                continue
            for row in f.doc.table("Catalog errata"):
                if row["status"] != "APPROVED" or row["field"] not in ERRATA_FIELDS:
                    continue
                value = self._errata_value(row["field"], row["value"])
                if value is None:
                    continue
                k = (norm_id(row["entry"]), row["field"])
                if k not in best or int(rev) > best[k][0]:
                    best[k] = (int(rev), value)
        for (eid, fld), (_, value) in best.items():
            e = entries.get(eid)
            if e is None:
                continue
            if fld == "sha256":
                e.sha256 = value
            elif fld == "size":
                e.size = value
            elif fld == "mtime":
                e.mtime = value
            elif fld == "container":
                e.container = norm_id(value)

    # ------------------------------------------------------------------ replay
    def canonicalize(self, e: Entry) -> None:
        host = e.host
        if not host:
            e.rejected = "outside"
            return
        windows = self.host_os.get(host) == "windows"
        roots = self.roots.get((host, self.share.upper()), [])
        try:
            e.canon = paths.canonical(e.path, roots, windows, self.fold)
            if e.etype == "R":
                e.canon_new = paths.canonical(e.new_path, roots, windows, self.fold)
            if e.etype == "H":
                e.canon_target = paths.canonical(e.target, roots, windows, self.fold)
        except paths.Unsafe:
            e.rejected = "unsafe"
        except paths.Outside:
            e.rejected = "outside"

    def _ensure_dir(self, canon: str) -> str:
        """Display spelling of a directory, created with the entry's spelling when absent."""
        k = paths.key(canon, self.fold)
        if k in self.dirs:
            return self.dirs[k]
        parent, last = canon.rsplit("/", 1)
        head = self._ensure_dir(parent) if parent else ""
        disp = (head + "/" if head else "/") + last
        self.dirs[k] = disp
        return disp

    def _display(self, canon: str) -> str:
        parent, last = canon.rsplit("/", 1)
        head = self._ensure_dir(parent) if parent else ""
        return (head + "/" if head else "/") + last

    def replay(self) -> None:
        self.dirs: dict[str, str] = {"": ""}
        self.objs: dict[str, Obj] = {}
        self.recon_sets = []
        for s in self.chain:
            es = self.entries_by_set.get(s.sid, [])
            voided = {e.voids for e in es if e.etype == "X" and e.voids}
            counts = {"set": s.sid, "expected": self.entry_totals.get(s.sid), "entries": len(es),
                      "applied": 0, "voided": 0, "uncommitted": 0, "rejected": 0}
            for e in es:
                if e.etype == "X":
                    continue
                if e.eid in voided:
                    counts["voided"] += 1
                    continue
                if not e.committed:
                    counts["uncommitted"] += 1
                    continue
                self.canonicalize(e)
                if e.rejected:
                    counts["rejected"] += 1
                    continue
                self.apply(e)
                counts["applied"] += 1
            self.recon_sets.append(counts)

    def _remove_under(self, k: str) -> None:
        for d in [d for d in self.dirs if d == k or d.startswith(k + "/")]:
            del self.dirs[d]
        for o in [o for o in self.objs if o == k or o.startswith(k + "/")]:
            del self.objs[o]

    def apply(self, e: Entry) -> None:
        k = paths.key(e.canon, self.fold)
        t = e.etype
        if t == "D":
            if k not in self.dirs:
                self.dirs[k] = self._display(e.canon)
        elif t in ("F", "H"):
            version = e
            if t == "H":
                src = self.objs.get(paths.key(e.canon_target, self.fold))
                if src is None or src.kind != "file":
                    return
                version = src.entry
            o = self.objs.get(k)
            if o is not None and o.kind == "file":
                o.entry = version
            else:
                self.objs[k] = Obj(self._display(e.canon), "file", version)
        elif t == "L":
            o = self.objs.get(k)
            if o is not None and o.kind == "link":
                o.entry = e
                o.target = e.target
            else:
                self.objs[k] = Obj(self._display(e.canon), "link", e, e.target)
        elif t == "W":
            if e.kind == "dir":
                self._remove_under(k)
            else:
                self.objs.pop(k, None)
        elif t == "R":
            nk = paths.key(e.canon_new, self.fold)
            if e.kind == "dir":
                if k not in self.dirs:
                    return
                old = self.dirs[k]
                new = self._display(e.canon_new)
                for key in [key for key in self.dirs if key == k or key.startswith(k + "/")]:
                    if key == k:
                        disp = new
                    else:
                        disp = new + self.dirs[key][len(old):]
                    del self.dirs[key]
                    self.dirs[paths.key(disp, self.fold)] = disp
                for key in [key for key in self.objs if key == k or key.startswith(k + "/")]:
                    o = self.objs.pop(key)
                    o.path = new + o.path[len(old):]
                    self.objs[paths.key(o.path, self.fold)] = o
            else:
                o = self.objs.pop(k, None)
                if o is not None:
                    o.path = self._display(e.canon_new)
                    self.objs[nk] = o

    # ------------------------------------------------------------------ registers used after replay
    def load_media(self) -> None:
        self.inventory: dict[str, dict] = {}
        for f in self.all("MEDIA", "ORIGINAL"):
            for sheet, rows in f.tables.items():
                for row in rows:
                    self.inventory[norm_id(row["media_id"])] = {
                        "status": str(row["status"]).strip().upper(),
                        "generation": str(row.get("generation") or row.get("kind") or "").strip().upper(),
                    }
        self.barcode: dict[str, str] = {}
        for row in self.one("MEDIA", "PREVIEW").tables.get("Media", []):
            if row.get("barcode"):
                self.barcode[str(row["barcode"]).strip().upper()] = norm_id(row["media_id"])
        self.copies: dict[str, list[dict]] = {}
        self.created: dict[str, dt.datetime] = {}
        for f in self.all("CMAP"):
            rc = f.status == "FINAL"
            locale = f.control.get("locale", "plain")
            for row in f.tables["rows"]:
                c = norm_id(row["container"])
                if c.startswith("RC-") != rc:
                    continue
                size = values.parse_int(row["size_bytes"], locale) if "size_bytes" in row else values.parse_int(row["size_text"], locale)
                if "created" in row:
                    created = row["created"]
                    if created.tzinfo is None:
                        created = created.replace(tzinfo=UTC)
                else:
                    created = values.EPOCH + dt.timedelta(milliseconds=row["created_ms"])
                copy = int(row["copy"])
                ref = str(row["media_ref"]).strip().upper()
                media = self.barcode.get(ref, norm_id(ref)) if copy == 2 else norm_id(ref)
                self.copies.setdefault(c, []).append({"copy": copy, "media": media, "size": size or 0})
                if c not in self.created or created < self.created[c]:
                    self.created[c] = created
        self.repack: dict[str, str] = {}
        for row in self.one("REPACK").tables["repack"]:
            if _iso(row["repacked_at"]) <= self.req_end:
                self.repack[norm_id(row["old_container"])] = norm_id(row["new_container"])
        corrections = {}
        for g in self.all("MERR"):
            if self.doc_in_force("MERR", g.control.get("revision", ""), "Section 2"):
                for c in g.doc.table("Corrections to revision A"):
                    if c["field"] == "media":
                        corrections[c["errata"]] = norm_id(c["now"])
        self.damaged: set[str] = set()
        for f in self.all("MERR"):
            rev = f.control.get("revision", "")
            if not self.doc_in_force("MERR", rev):
                continue
            for row in f.doc.table("Media errata"):
                if row["status"] == "APPROVED" and row["defect"] in ("DAMAGED", "UNREADABLE"):
                    self.damaged.add(corrections.get(row["errata"], norm_id(row["media"])))
        self.destroyed: set[str] = set()
        self.recalls: list = []
        rerun_named: set[tuple] = set()
        for m in self.one("MAIL").tables["messages"]:
            when = email.utils.parsedate_to_datetime(m["date"]).astimezone(UTC)
            subj = m["subject"]
            body = m["body"]
            if subj.startswith("Destruction notice:") and when <= self.req_end:
                self.destroyed.add(norm_id(subj.split(":", 1)[1]))
            elif subj.startswith("Recall completed:") and when <= self.req_end:
                mm = re.search(r"checked in at (\S+?)\.", body)
                if mm:
                    self.recalls.append((when, norm_id(subj.split(":", 1)[1]), mm.group(1)))
            elif subj.startswith("Checksum rerun request"):
                for line in body.splitlines():
                    mm = re.match(r"^(\S+) copy (\d+)$", line.strip())
                    if mm:
                        rerun_named.add((norm_id(mm.group(1)), int(mm.group(2))))
        self.rerun_named = rerun_named
        self.mismatch: set[tuple] = set()
        for row in self.one("CHK", "ORIGINAL").tables["rows"]:
            if row["result"].strip().upper() == "MISMATCH":
                self.mismatch.add((norm_id(row["container"]), int(row["copy"])))
        for f in self.all("CHK", "RERUN"):
            for row in f.tables["rows"]:
                key = (norm_id(row["container"]), int(row["copy"]))
                if key not in rerun_named:
                    continue
                if row["result"].strip().upper() == "MATCH":
                    self.mismatch.discard(key)
                else:
                    self.mismatch.add(key)
        self.copy_done: set[tuple] = set()
        for row in self.one("COPY").doc.table("Copy jobs"):
            if row["status"] == "COMPLETED" and _iso(row["completed_utc"]) <= self.req_end:
                self.copy_done.add((norm_id(row["container"]), int(row["copy"])))
        vault: dict[str, str] = {}
        for s in self.one("SLOT").tables["sections"]:
            vault[norm_id(s["media"])] = s["vault"]
        for row in self.one("DASH").doc.table("Media"):
            m = norm_id(row["media_id"])
            if m not in vault and row["vault"] == "VLT-OFF3":
                vault[m] = row["vault"]
        moves = list(self.recalls)
        for row in self.one("XFER").doc.table("Transfers"):
            t = _iso(row["received_utc"])
            if t <= self.req_end:
                moves.append((t, norm_id(row["media"]), row["to_vault"]))
        for _, m, v in sorted(moves, key=lambda x: x[0]):
            vault[m] = v
        self.vault = vault
        self.vault_prio: dict[str, int] = {}
        for row in self.one("MEDIAPROC").doc.table("Vault service calendar"):
            if row["date"] == self.request_date:
                self.vault_prio[row["vault"]] = int(row["priority"])

    def usable(self, container: str, cp: dict) -> bool:
        """MEDIAPROC section 2: is this copy of this container readable."""
        inv = self.inventory.get(cp["media"])
        if inv is None or inv["status"] == "EXPIRED":
            return False
        if inv["generation"] == "LTO-6":
            return False
        if cp["media"] in self.damaged or cp["media"] in self.destroyed:
            return False
        if (container, cp["copy"]) in self.mismatch:
            return False
        if cp["copy"] in (2, 3) and (container, cp["copy"]) not in self.copy_done:
            return False
        return True

    def pick_copy(self, container: str) -> tuple[str, dict | None]:
        c = self.repack.get(container, container)
        for cp in sorted(self.copies.get(c, []), key=lambda x: x["copy"]):
            if self.usable(c, cp):
                return c, cp
        return c, None

    def load_av(self) -> None:
        """QPROC sections 2 and 3: which versions are infected."""
        cut = re.search(r"The engine cutover is (\S+?)\.?$", self.one("QPROC").doc.text, re.M)
        self.cutover = _iso(cut.group(1).rstrip("."))
        vendor = {r["engine"]: r["vendor"] for r in self.one("QPROC").doc.table("Engine registry")}
        withdrawals = []
        for row in self.one("ADV").doc.table("Withdrawn signatures"):
            a, b = row["revisions"].split("-")
            withdrawals.append((row["vendor"], row["signature"], int(a), int(b), _iso(row["withdrawn_utc"])))
        self.infected: set[tuple] = set()
        for f in self.all("AV"):
            if f.status not in ("ORIGINAL", "PRELIMINARY"):
                continue
            for row in self._rows(f):
                if str(row.get("verdict", "")).upper() != "INFECTED":
                    continue
                c = norm_id(row["container"])
                created = self.created.get(c)
                if created is None:
                    continue
                of_record = "ORIGINAL" if created >= self.cutover else "PRELIMINARY"
                if f.status != of_record:
                    continue
                v = vendor.get(row["engine"])
                rev = int(row["sig_rev"])
                if any(v == wv and row["signature"] == ws and a <= rev <= b and t <= self.req_end
                       for wv, ws, a, b, t in withdrawals):
                    continue
                self.infected.add((norm_hash(row["sha256"]), c))

    @staticmethod
    def _rows(f) -> list[dict]:
        rows = []
        for lst in f.tables.values():
            rows.extend(lst)
        return rows

    def load_identity(self) -> None:
        self.idmap: dict[str, list] = {}
        for row in self.one("IDMAP", "ORIGINAL").tables["accounts"]:
            self.idmap.setdefault(row["principal"], []).append(row)
        self.domains = {p.rsplit("-", 1)[0] for p in self.idmap}
        self.ad: dict[str, str] = {}
        for f in self.all("IDMAP", "EXPORT"):
            for row in f.tables.get("ad_users", []):
                self.ad[row["sid"]] = row["account"]
        self.changes: dict[str, tuple] = {}
        for row in self.one("IDCHG").doc.table("Identity changes"):
            if row["status"] == "APPROVED":
                t = _iso(row["effective_utc"])
                if t <= self.rp and (row["principal"] not in self.changes or self.changes[row["principal"]][0] < t):
                    self.changes[row["principal"]] = (t, row["account"])
        self.local: dict[tuple, str] = {}
        for s in self.one("LACCT").tables["sections"]:
            head = s["_section"]
            if ":" not in head:
                continue
            host = head.split(":", 1)[1].upper()
            for k, v in s.items():
                if k != "_section":
                    self.local[(host, k)] = v

    def owner(self, e: Entry) -> str:
        p = (e.owner or "").strip()
        if p in ("N/A", "-", "null", ""):
            return "UNMAPPED"
        if p.startswith("uid:"):
            return self.local.get((e.host, p[4:]), "UNMAPPED")
        if p in self.changes:
            return self.changes[p][1]
        for row in self.idmap.get(p, []):
            if _iso(row["valid_from"]) <= self.rp and (row["valid_to"] is None or self.rp < _iso(row["valid_to"])):
                return row["account"]
        if p.rsplit("-", 1)[0] not in self.domains and p in self.ad:
            return self.ad[p]
        return "UNMAPPED"

    def load_scope(self) -> None:
        spec = None
        for f in self.all("SPEC"):
            if self.doc_in_force("SPEC", f.control.get("revision", "")):
                spec = f
        if spec is None:
            raise FeedError("no restore specification in force")
        prof = next((r for r in spec.doc.table("Share restore profiles") if r["share"] == self.share), None)
        if prof is None:
            raise FeedError(f"no restore profile for {self.share}")
        self.includes = [x.strip() for x in prof["include_prefixes"].split(";") if x.strip()]
        self.holds = sorted((h for h in self.dispositions if h["share"] == self.share and h["action"] == "DESTROY"
                             and h["effective"] <= self.rp_date), key=lambda h: h["hold"])
        cats = []
        for f in self.all("EXCL"):
            eff = f.control.get("effective_from", "")
            if eff and eff <= self.rp_date:
                cats.append(f)
        if not cats:
            cats = self.all("EXCL")
        in_force = max(cats, key=lambda f: int(f.control.get("revision", "0")))
        withdrawn: set[str] = set()
        for f in self.all("EXCL"):
            for w in f.tables.get("withdrawal", []):
                if w["effective"] <= self.rp_date:
                    withdrawn.add(w["id"])
        self.patterns = sorted((p for p in in_force.tables.get("pattern", [])
                                if p["scope"] in ("ALL", self.share) and p["from"] <= self.rp_date
                                and (not p["to"] or p["to"] > self.rp_date) and p["id"] not in withdrawn),
                               key=lambda p: int(p["id"].split("-")[1]))
        self.volume = next(v for v in self.one("VOL").tables["volume"] if v["id"] == self.target_volume)

    # ------------------------------------------------------------------ restore decisions
    def custody(self) -> str:
        """README section 6: the custody digest of every file of the feed."""
        source = {}
        for f in self.all("CAT", "CORRECTED"):
            source[(f.part, f.stream)] = f.control.get("source_custody")
        lines = []
        for f in self.files:
            custody = f.control.get("custody", "")
            if custody == "N/A" and f.status == "ORIGINAL":
                custody = source.get((f.part, f.stream), custody)
            lines.append(f"{f.stream}|{f.part}|{f.status}|{f.control.get('records', '')}|{custody}")
        lines.sort()
        return hashlib.sha256("".join(x + "\n" for x in lines).encode("utf-8")).hexdigest()

    def allocation(self, size: int, first: bool) -> int:
        v = self.volume
        if not first or size <= v["resident_max"]:
            return 0
        cluster = v["large_cluster"] if size >= v["large_threshold"] else v["small_cluster"]
        return -(-size // cluster) * cluster

    def decide(self) -> None:
        sets_by_id = {s.sid: s for s in self.sets.values()}
        ok = {s.sid for s in self.chain} | {sid for sid, reason in ((x[0].sid, x[1]) for x in self.skipped)
                                           if reason in ("BEFORE_BASE", "SUPERSEDED_BY_DIFF")}
        hist: dict[str, list] = {}
        for sid in ok:
            es = self.entries_by_set.get(sid, [])
            voided = {e.voids for e in es if e.etype == "X" and e.voids}
            for e in es:
                if e.etype != "F" or e.eid in voided or not e.committed:
                    continue
                self.canonicalize(e)
                if e.rejected:
                    continue
                st = sets_by_id[sid]
                hist.setdefault(paths.key(e.canon, self.fold), []).append(((st.snapshot, st.sid, e.seq), e))
        for lst in hist.values():
            lst.sort(key=lambda x: x[0])
        rows, excl, rolled = [], [], 0
        for o in sorted(self.objs.values(), key=lambda x: (paths.key(x.path, self.fold), x.path)):
            kind = "file" if o.kind == "file" else "symlink"
            reason, detail, link_target = None, "", ""
            if not any(paths.under(o.path, inc, True) for inc in self.includes):
                reason = "OUT_OF_SCOPE"
            if reason is None:
                holds = [h for h in self.holds if paths.under(o.path, h["prefix"], self.fold)]
                if holds:
                    reason, detail = "DISPOSED", holds[0]["hold"]
            if reason is None:
                for p in self.patterns:
                    if globs.match(p["pattern"], o.path):
                        reason, detail = "EXCLUDED_PATTERN", p["id"]
                        break
            if reason is None and kind == "symlink":
                host = o.entry.host
                lt = paths.resolve_link(o.target, o.path, self.roots.get((host, self.share.upper()), []),
                                        self.host_os.get(host) == "windows", self.fold)
                if lt is None:
                    reason = "SYMLINK_ESCAPE"
                else:
                    link_target = lt
            chosen = o.entry
            if reason is None and kind == "file" and (chosen.sha256, chosen.container) in self.infected:
                st = sets_by_id[chosen.sid]
                mine = (st.snapshot, st.sid, chosen.seq)
                cands = [c for c in hist.get(paths.key(o.path, self.fold), []) if c[0] < mine]
                alt = next((c[1] for c in reversed(cands) if (c[1].sha256, c[1].container) not in self.infected), None)
                if alt is None:
                    reason, detail = "QUARANTINED", chosen.sha256
                else:
                    chosen = alt
                    rolled += 1
            cont, cp = "", None
            if reason is None and kind == "file":
                cont, cp = self.pick_copy(chosen.container)
                if cp is None:
                    reason, detail = "UNRECOVERABLE", cont
            if reason:
                excl.append({"path": o.path, "kind": kind, "reason": reason, "detail": detail})
                continue
            e = chosen
            mt = e.mtime
            if mt in ("SENTINEL", None):
                mt = sets_by_id[e.sid].snapshot
            row = {"path": o.path, "kind": kind, "size": e.size if kind == "file" else 0, "allocated": 0,
                   "sha256": e.sha256 if kind == "file" else "", "mode": values.mode_out(e.mode, e.attrs),
                   "mtime_utc": values.iso_z(mt) if mt is not None else "", "owner": self.owner(e), "source_set": e.sid,
                   "container": cont if kind == "file" else "", "media": cp["media"] if cp else "",
                   "copy": cp["copy"] if cp else 0, "hardlink_group": "", "link_target": link_target,
                   "_gk": (e.client, e.file_id) if kind == "file" else None,
                   "_size": cp["size"] if cp else 0}
            rows.append(row)
        groups: dict = {}
        for row in rows:
            if row["_gk"] is not None and all(row["_gk"]):
                groups.setdefault(row["_gk"], []).append(row)
        n = 0
        for row in rows:
            g = groups.get(row["_gk"]) if row["_gk"] is not None else None
            member = bool(g) and len(g) > 1
            if member and g[0] is row:
                n += 1
                for m in g:
                    m["hardlink_group"] = f"HL-{n:04d}"
            row["allocated"] = self.allocation(row["size"], not (member and g[0] is not row))
        self.rows, self.excl, self.rolled, self.groups = rows, excl, rolled, n

    # ------------------------------------------------------------------ deliverables
    def pull_list(self) -> list[dict]:
        by: dict[str, dict] = {}
        for row in self.rows:
            if row["kind"] != "file":
                continue
            m = by.setdefault(row["media"], {"copy": row["copy"], "containers": {}})
            m["containers"][row["container"]] = row["_size"]
        out = []
        for media, m in by.items():
            rb = sum(m["containers"].values())
            out.append({"media_id": media, "vault": self.vault.get(media, ""), "copy": m["copy"],
                        "containers": len(m["containers"]), "read_bytes": rb, "read_gib": report.gib(rb)})
        out.sort(key=lambda x: (self.vault_prio.get(x["vault"], 99), x["media_id"]))
        return out

    def run(self) -> dict:
        self.load_request()
        self.load_hosts()
        self.load_sets()
        self.select_chain()
        self.load_catalog()
        self.replay()
        self.load_media()
        self.load_av()
        self.load_identity()
        self.load_scope()
        self.decide()
        pull = self.pull_list()
        digest = self.custody()
        counts = {r: 0 for r in REASONS}
        for x in self.excl:
            counts[x["reason"]] += 1
        chain = {"share": self.share, "restore_point_utc": values.iso_z(self.rp),
                 "effective_point_utc": values.iso_z(self.chain[-1].snapshot),
                 "chain": [{"set": s.sid, "type": s.type, "snapshot_utc": values.iso_z(s.snapshot),
                            "role": "base" if i == 0 else ("diff" if s.type == "DIFF" else "incremental")}
                           for i, s in enumerate(self.chain)],
                 "skipped": [{"set": s.sid, "type": s.type, "snapshot_utc": values.iso_z(s.snapshot), "reason": r}
                             for s, r in sorted(self.skipped, key=lambda x: (x[0].snapshot, x[0].sid))],
                 "custody_digest": digest}
        recon = {"sets": self.recon_sets, "objects_at_effective_point": len(self.objs), "restored": len(self.rows),
                 "excluded": counts, "rolled_back": self.rolled, "bytes_restored": sum(r["size"] for r in self.rows),
                 "bytes_allocated": sum(r["allocated"] for r in self.rows), "hardlink_groups": self.groups,
                 "media": len(pull), "containers": sum(p["containers"] for p in pull),
                 "read_bytes": sum(p["read_bytes"] for p in pull), "custody_digest": digest}
        return {"manifest": self.rows, "exclusions": self.excl, "pull": pull, "chain": chain, "recon": recon, "digest": digest}

