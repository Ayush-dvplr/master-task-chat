"""Value notations of the feed: identifiers, numbers, timestamps, modes and sentinels."""

from __future__ import annotations

import datetime as dt
import re
from decimal import Decimal
from zoneinfo import ZoneInfo

UTC = dt.timezone.utc
EPOCH = dt.datetime(1970, 1, 1, tzinfo=UTC)
FT_EPOCH = dt.datetime(1601, 1, 1, tzinfo=UTC)
XL_1900 = dt.datetime(1899, 12, 30, tzinfo=UTC)
XL_1904 = dt.datetime(1904, 1, 1, tzinfo=UTC)
ID_WIDTH = {"BS": 5, "E": 7, "CT": 7, "RC": 7, "MD": 5}
GROUP = {"en_US": ",", "de_DE": ".", "fr_FR": " "}


class Folds:
    """Identifier fold table (PATHCONV Appendix C, identifier scope)."""

    table: dict[str, str] = {}


def _fold(value: str) -> str:
    if Folds.table:
        return "".join(Folds.table.get(ch, ch) for ch in value)
    return value


def norm_id(value) -> str:
    """Set, entry, container and media identifiers (catalog format guide section 4)."""
    if value is None:
        return ""
    s = _fold(str(value).strip())
    if not s:
        return ""
    s = s.upper().replace("_", "-")
    m = re.fullmatch(r"([A-Z]+)-?0*(\d+)", s)
    if not m or m.group(1) not in ID_WIDTH:
        return s
    return f"{m.group(1)}-{int(m.group(2)):0{ID_WIDTH[m.group(1)]}d}"


def norm_hash(value) -> str:
    s = str(value or "").strip().lower()
    return s[7:] if s.startswith("sha256:") else s


def parse_int(value, locale: str) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise ValueError(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    s = str(value).strip()
    sep = GROUP.get(locale)
    if sep:
        s = s.replace(sep, "").replace("\u202f", "").replace("\u00a0", "")
    return int(s)


def parse_dec(value, locale: str) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        return Decimal(value)
    if isinstance(value, float):
        return Decimal(repr(value))
    s = str(value).strip()
    if locale in ("de_DE", "fr_FR"):
        s = s.replace("\u202f", "").replace("\u00a0", "").replace(".", "").replace(",", ".")
    else:
        s = s.replace(",", "")
    return Decimal(s)


def size_of(row: dict, locale: str) -> int | None:
    for key in ("size", "size_bytes", "bytes"):
        if key in row and row[key] not in ("", None):
            return parse_int(row[key], locale)
    if "size_kib" in row and row["size_kib"] not in ("", None):
        return int(parse_dec(row["size_kib"], locale) * 1024)
    return None


def is_sentinel_text(s: str) -> bool:
    return bool(re.match(r"^0000-00-00", s))


def parse_ts(value, kind: str, tz: str | None = None, date1904: bool = False, wall: bool = False):
    """Returns an aware UTC datetime, 'SENTINEL', or None for an empty cell.

    Fractions of a second are dropped (restore specification 4.1 section 9.2).  When
    wall is true the calendar digits of the value are read as a wall-clock time of
    the client host and any offset is ignored (FAT32 and exFAT clients).
    """
    if value is None or value == "":
        return None
    if isinstance(value, dt.datetime):
        return _aware(value, tz)
    if isinstance(value, dt.date):
        return _aware(dt.datetime(value.year, value.month, value.day), tz)
    if kind in ("utc", "iso", "local"):
        s = str(value).strip()
        if is_sentinel_text(s):
            return "SENTINEL"
        m = re.match(r"^(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d):(\d\d)", s)
        if m is None:
            return None
        digits = dt.datetime(*(int(x) for x in m.groups()))
        if wall or kind == "local":
            return digits.replace(tzinfo=ZoneInfo(tz or "UTC"), fold=0).astimezone(UTC)
        return _drop(dt.datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(UTC))
    n = int(value) if not isinstance(value, float) else value
    if kind == "epoch":
        if n == 0:
            return "SENTINEL"
        t = _drop(EPOCH + dt.timedelta(seconds=n))
    elif kind == "ms":
        if int(n) == -1:
            return "SENTINEL"
        t = _drop(EPOCH + dt.timedelta(milliseconds=n))
    elif kind == "ft":
        if n == 0:
            return "SENTINEL"
        t = _drop(FT_EPOCH + dt.timedelta(microseconds=int(n) // 10))
    elif kind == "xl":
        if float(n) == 0:
            return "SENTINEL"
        base = XL_1904 if date1904 else XL_1900
        t = _drop(base + dt.timedelta(seconds=_round_half_even(float(n) * 86400)))
    else:
        raise ValueError(kind)
    return as_wall_in(t, tz) if wall else t


def _aware(t: dt.datetime, tz: str | None) -> dt.datetime:
    if t.tzinfo is None:
        return t.replace(tzinfo=ZoneInfo(tz or "UTC"))
    return t.astimezone(UTC)


def _drop(t: dt.datetime) -> dt.datetime:
    return t.replace(microsecond=0)


def _round_half_even(value: float) -> int:
    whole = int(value)
    frac = value - whole
    if abs(frac - 0.5) > 1e-9:
        return whole if frac < 0.5 else whole + 1
    return whole if whole % 2 == 0 else whole + 1


def as_wall_in(t: dt.datetime, tz: str) -> dt.datetime:
    """FAT rule: the digits of the value are the client's wall-clock time."""
    wall = t.astimezone(UTC).replace(tzinfo=None)
    return wall.replace(tzinfo=ZoneInfo(tz), fold=0).astimezone(UTC)


def iso_z(t: dt.datetime) -> str:
    return t.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_mode(row: dict) -> int | None:
    for key in ("mode_oct", "mode_sym", "mode_dec", "st_mode"):
        v = row.get(key)
        if v in (None, ""):
            continue
        s = str(v).strip()
        if key == "mode_dec":
            return int(s)
        if key == "mode_oct":
            return int(s, 8)
        if key == "st_mode":
            return int(s, 8) & 0o7777
        bits = 0
        trip = s[1:10]
        for i, (shift, special) in enumerate(((6, 0o4000), (3, 0o2000), (0, 0o1000))):
            r, w, x = trip[i * 3:i * 3 + 3]
            bits |= (4 if r == "r" else 0) << shift
            bits |= (2 if w == "w" else 0) << shift
            if x in ("x", "s", "t"):
                bits |= 1 << shift
            if x in ("s", "S", "t", "T"):
                bits |= special
        return bits
    return None


def mode_out(mode: int | None, attrs: str | None) -> str:
    """Permission bits with set-user-ID and set-group-ID cleared, sticky kept."""
    if mode is None:
        return "0444" if "R" in (attrs or "").upper() else "0644"
    return f"{mode & 0o1777:04o}"


_TRUTHY = {"y", "yes", "true", "t", "1", "on"}


def truthy(v) -> bool:
    return str(v).strip().lower() in _TRUTHY
