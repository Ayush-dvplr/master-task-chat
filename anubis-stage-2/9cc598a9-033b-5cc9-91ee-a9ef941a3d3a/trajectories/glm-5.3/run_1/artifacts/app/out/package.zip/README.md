# restorekit

`restorekit` plans a point-in-time restore of one file share from a restore feed: the
backup catalog parts, job history, server logs, registers and documents that the
backup estate exports for a restore request. It writes the restore manifest, the
exclusions, the media pull list, the backup set chain and the reconciliation report.

The behaviour is defined by the restore specification revision in force and the
documents it incorporates; those documents travel inside every feed.

Layout:

- `src/restorekit/` - the package (`python -m restorekit restore --feed DIR --out DIR`)
- `tests/` - unit tests, run with `PYTHONPATH=src python -m unittest discover -s tests -t .`
- `tests/fixtures/glob_conformance.tsv` - conformance cases for the exclusion pattern dialect

Runtime dependencies are the ones `pyproject.toml` declares. A normal restore run writes the five
deliverables of specification section 11 into the `--out` directory and nothing to the console.
