"""Raw catalog paths to canonical share paths, identity keys and link targets."""

from __future__ import annotations

import re
import unicodedata


def nfc(text: str) -> str:
    return unicodedata.normalize("NFC", text)


def key(path: str, fold: bool = True) -> str:
    """Identity key of a path: full Unicode case folding for insensitive shares."""
    p = nfc(path)
    return p.casefold() if fold else p


def under(path: str, prefix: str, fold: bool = True) -> bool:
    """True when path is at or under prefix, matching whole components."""
    a = key(path, fold)
    b = key(prefix.rstrip("/"), fold)
    return a == b or a.startswith(b + "/")


class Unsafe(Exception):
    pass


class Outside(Exception):
    pass


def _split(raw: str, windows: bool) -> list[str]:
    text = raw.replace("\\", "/") if windows else raw
    return [c for c in text.split("/") if c]


def _prefix(comps: list[str], rcomps: list[str], windows: bool) -> bool:
    for c, r in zip(comps, rcomps):
        if windows:
            if key(c) != key(r):
                return False
        elif c != r:
            return False
    return True


def _strip_root(raw: str, roots: list[str], windows: bool) -> list[str] | None:
    """Components after the longest root that the raw path sits under."""
    comps = _split(raw, windows)
    best: list[str] | None = None
    width = -1
    for root in roots:
        rcomps = _split(root, windows)
        if len(rcomps) > len(comps) or len(rcomps) <= width:
            continue
        if not _prefix(comps, rcomps, windows):
            continue
        width = len(rcomps)
        best = comps[len(rcomps):]
    return best


def _components(rest: list[str], windows: bool, base: list[str] | None = None) -> list[str]:
    comps = list(base or [])
    for c in rest:
        if c == "..":
            if not comps:
                raise Unsafe(c)
            comps.pop()
            continue
        if windows:
            c = c.rstrip(" .")
        if c in ("", "."):
            continue
        comps.append(nfc(c))
    return comps


def canonical(raw: str, roots: list[str], windows: bool, fold: bool = True) -> str:
    rest = _strip_root(raw, roots, windows)
    if rest is None:
        raise Outside(raw)
    return "/" + "/".join(_components(rest, windows))


def resolve_link(target: str, link_path: str, roots: list[str], windows: bool, fold: bool = True) -> str | None:
    """Canonical target of a link, or None when the target leaves the share."""
    rest = _strip_root(target, roots, windows)
    if rest is not None:
        try:
            return "/" + "/".join(_components(rest, windows))
        except Unsafe:
            return None
    t = target.replace("\\", "/") if windows else target
    if t.startswith("/") or (windows and re.match(r"^[A-Za-z]:", t)):
        return None
    base = [c for c in link_path.split("/")[:-1] if c]
    try:
        comps = _components(t.split("/"), windows, base)
    except Unsafe:
        return None
    return "/" + "/".join(comps)
