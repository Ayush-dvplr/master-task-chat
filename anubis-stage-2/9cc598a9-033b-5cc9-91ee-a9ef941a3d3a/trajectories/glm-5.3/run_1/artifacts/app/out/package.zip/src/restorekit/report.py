"""Writing the restore deliverables (restore specification section 11)."""

from __future__ import annotations

import csv
import io
import json
from decimal import ROUND_HALF_EVEN, Decimal
from pathlib import Path

MANIFEST = ["path", "kind", "size", "allocated", "sha256", "mode", "mtime_utc", "owner", "source_set", "container",
            "media", "copy", "hardlink_group", "link_target"]
EXCLUSIONS = ["path", "kind", "reason", "detail"]
PULL = ["media_id", "vault", "copy", "containers", "read_bytes", "read_gib"]


def _quote(value) -> str:
    """RFC 4180 quoting: a field is quoted only when it needs it (section 11.1)."""
    text = "" if value is None else str(value)
    if any(c in text for c in (',', '"', '\r', '\n')):
        return '"' + text.replace('"', '""') + '"'
    return text


def _csv_bytes(columns: list[str], rows: list[dict], digest: str) -> bytes:
    buf = io.StringIO(newline="")
    buf.write(",".join(columns) + "\n")
    for row in rows:
        buf.write(",".join(_quote(row[c]) for c in columns) + "\n")
    buf.write(f"#custody={digest} rows={len(rows)}\n")
    return buf.getvalue().encode("utf-8")


def write_all(out: Path, result: dict) -> None:
    out.mkdir(parents=True, exist_ok=True)
    d = result["digest"]
    (out / "restore_manifest.csv").write_bytes(_csv_bytes(MANIFEST, result["manifest"], d))
    (out / "exclusions.csv").write_bytes(_csv_bytes(EXCLUSIONS, result["exclusions"], d))
    (out / "media_pull_list.csv").write_bytes(_csv_bytes(PULL, result["pull"], d))
    (out / "restore_chain.json").write_text(_json(result["chain"]) + "\n", encoding="utf-8")
    (out / "reconciliation.json").write_text(_json(result["recon"]) + "\n", encoding="utf-8")


def _json(obj) -> str:
    return json.dumps(obj, indent=2, ensure_ascii=False)


def gib(bytes_total: int) -> str:
    """read_gib: the byte total over 1 GiB, rounded half to even to three decimals."""
    value = Decimal(bytes_total) / Decimal(1073741824)
    return f"{value.quantize(Decimal('0.001'), rounding=ROUND_HALF_EVEN):.3f}"
