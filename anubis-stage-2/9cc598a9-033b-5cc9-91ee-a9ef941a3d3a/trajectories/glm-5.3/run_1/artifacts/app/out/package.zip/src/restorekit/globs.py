"""Exclusion pattern dialect (restore specification revision 4.1, sections 7.1 to 7.3)."""

from __future__ import annotations

import functools
import re
import unicodedata


@functools.lru_cache(maxsize=4096)
def _segment(seg: str) -> re.Pattern:
    out, i = "", 0
    while i < len(seg):
        c = seg[i]
        if c == "*":
            out += "[^/]*"
        elif c == "?":
            out += "[^/]"
        elif c == "[":
            j = seg.find("]", i + 1)
            if j == -1:
                out += re.escape(c)
            else:
                body = seg[i + 1:j]
                neg = body.startswith("!")
                if neg:
                    body = body[1:]
                out += "[" + ("^" if neg else "") + "".join("\\" + ch if ch in "\\^]" else ch for ch in body) + "]"
                i = j
        else:
            out += re.escape(c)
        i += 1
    return re.compile(out)


@functools.lru_cache(maxsize=None)
def _match_segs(segs: tuple[str, ...], comps: tuple[str, ...]) -> bool:
    n = len(segs)

    def m(i: int, j: int) -> bool:
        if i == n:
            return j == len(comps)
        if segs[i] == "**":
            return any(m(i + 1, k) for k in range(j, len(comps) + 1))
        if j >= len(comps) or _segment(segs[i]).fullmatch(comps[j]) is None:
            return False
        return m(i + 1, j + 1)

    return m(0, 0)


def match(pattern: str, path: str) -> bool:
    """Match an exclusion pattern against the display path of an object."""
    pat = unicodedata.normalize("NFC", pattern).casefold()
    comps = tuple(c for c in unicodedata.normalize("NFC", path).casefold().split("/") if c)
    directory = pat.endswith("/")
    body = pat.rstrip("/")
    if not body:
        return False
    if "/" not in body:
        seg = _segment(body.strip("/"))
        if directory:
            return any(seg.fullmatch(comps[d]) is not None for d in range(len(comps) - 1))
        return bool(comps) and seg.fullmatch(comps[-1]) is not None
    segs = tuple(s for s in body.strip("/").split("/") if s)
    if not segs:
        return False
    if not directory:
        return _match_segs(segs, comps)
    return any(_match_segs(segs, comps[:depth]) for depth in range(1, len(comps)))
