"""Writing the restore deliverables (restore specification section 11)."""

from __future__ import annotations

import io
import json
from pathlib import Path

MANIFEST = ["path", "kind", "size", "allocated", "sha256", "mode", "mtime_utc", "owner", "source_set", "container",
            "media", "copy", "hardlink_group", "link_target"]
EXCLUSIONS = ["path", "kind", "reason", "detail"]
PULL = ["media_id", "vault", "copy", "containers", "read_bytes", "read_gib"]


def _field(value) -> str:
    s = str(value)
    if any(c in s for c in ',"\r\n'):
        return '"' + s.replace('"', '""') + '"'
    return s


def _csv(path: Path, columns: list[str], rows: list[dict], digest: str) -> None:
    buf = io.StringIO()
    buf.write(",".join(_field(c) for c in columns) + "\n")
    for row in rows:
        buf.write(",".join(_field(row[c]) for c in columns) + "\n")
    buf.write(f"#custody={digest} rows={len(rows)}\n")
    path.write_bytes(buf.getvalue().encode("utf-8"))


def write_all(out: Path, result: dict) -> None:
    out.mkdir(parents=True, exist_ok=True)
    d = result["digest"]
    _csv(out / "restore_manifest.csv", MANIFEST, result["manifest"], d)
    _csv(out / "exclusions.csv", EXCLUSIONS, result["exclusions"], d)
    _csv(out / "media_pull_list.csv", PULL, result["pull"], d)
    (out / "restore_chain.json").write_text(
        json.dumps(result["chain"], indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (out / "reconciliation.json").write_text(
        json.dumps(result["recon"], indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
