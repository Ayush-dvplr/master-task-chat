"""Point-in-time restore of one share from a restore feed (restore specification revision 4.2)."""

from __future__ import annotations

import datetime as dt
import email.utils
import hashlib
import re
from dataclasses import dataclass, field
from decimal import ROUND_HALF_EVEN, Decimal
from pathlib import Path
from zoneinfo import ZoneInfo

from restorekit import feed, globs, paths, values
from restorekit.values import UTC, norm_hash, norm_id

REASONS = ["OUT_OF_SCOPE", "DISPOSED", "EXCLUDED_PATTERN", "SYMLINK_ESCAPE", "QUARANTINED", "UNRECOVERABLE"]
TS_KINDS = ("utc", "iso", "epoch", "ms", "ft", "local", "xl")
OWNER_SENTINELS = ("", "N/A", "-", "null", "NULL", "None")


class FeedError(Exception):
    pass


@dataclass
class Entry:
    eid: str
    sid: str
    seq: int
    etype: str
    path: str = ""
    new_path: str = ""
    target: str = ""
    kind: str = ""
    size: int | None = None
    mtime: object = None
    mode: int | None = None
    attrs: str | None = None
    owner: str = ""
    sha256: str = ""
    container: str = ""
    file_id: str = ""
    client: str = ""
    committed: bool = True
    voids: str = ""
    canon: str = ""
    canon_new: str = ""
    canon_target: str = ""
    rejected: str = ""
    host: str | None = None
    windows: bool = False


@dataclass
class SetInfo:
    sid: str
    job: str
    type: str
    status: str
    server: str
    queued: dt.datetime
    consolidates: str
    snapshot: dt.datetime | None = None
    crash: bool = False


@dataclass
class Obj:
    path: str
    kind: str
    entry: Entry
    target: str = ""


def _is_media(value: str) -> bool:
    return re.fullmatch(r"MD-\d{5}", value) is not None


def _iso(s) -> dt.datetime:
    if isinstance(s, dt.datetime):
        return (s if s.tzinfo else s.replace(tzinfo=UTC)).astimezone(UTC)
    t = dt.datetime.fromisoformat(str(s).strip().replace("Z", "+00:00"))
    if t.tzinfo is None:
        t = t.replace(tzinfo=UTC)
    return t.astimezone(UTC).replace(microsecond=0)


class Restore:
    def __init__(self, feed_dir: Path) -> None:
        pre = feed.load_feed(Path(feed_dir), {})
        rrq = [f for f in pre if f.stream == "RRQ"]
        if not rrq:
            raise FeedError("no restore request in feed")
        self.feed_id = {r["key"]: r["value"] for r in rrq[0].doc.table("Request parameters")}["feed"]
        pre = [f for f in pre if f.control.get("feed") == self.feed_id]
        self.files = pre
        guide = self.one("FMTGUIDE")
        layouts: dict[str, list] = {}
        for row in guide.doc.table("Fixed-width layouts"):
            layouts.setdefault(row["layout"], []).append((row["column"], int(row["width"])))
        self.files = [feed.load(f.path, layouts) if f.fmt == "fixed" else f for f in pre]
        values.Folds.table = {chr(int(r["codepoint"][2:], 16)): r["fold"]
                              for r in self.one("PATHCONV").doc.table("Confusable fold table")
                              if r["scope"] == "identifier"}
        self.aliases: dict[str, list[str]] = {}
        for row in guide.doc.table("Catalog column aliases"):
            names = [row["column"]] + [a.strip() for a in row["aliases"].split(",") if a.strip()]
            seen: list[str] = []
            for n in names:
                if n not in seen:
                    seen.append(n)
            self.aliases[row["column"]] = seen

    # ------------------------------------------------------------------ feed access
    def all(self, stream: str, status: str | None = None) -> list:
        return [f for f in self.files if f.stream == stream and (status is None or f.status == status)]

    def one(self, stream: str, status: str | None = None):
        found = self.all(stream, status)
        if not found:
            raise FeedError(f"no {stream} file in feed")
        return found[0]

    def _col(self, row: dict, column: str):
        for name in self.aliases.get(column, [column]):
            if name in row and row[name] not in ("", None):
                return row[name]
        return None

    # ------------------------------------------------------------------ request and documents
    def load_request(self) -> None:
        rrq = self.one("RRQ")
        params = {r["key"]: r["value"] for r in rrq.doc.table("Request parameters")}
        self.share = params["share"]
        self.shares = {s["share"]: s for s in self.one("SHARE").tables["shares"]}
        me = self.shares[self.share]
        self.site_tz = me["site_tz"]
        self.array = me["array"]
        wall = dt.datetime.strptime(params["restore_point_local"], "%Y-%m-%d %H:%M:%S")
        self.rp = wall.replace(tzinfo=ZoneInfo(self.site_tz), fold=0).astimezone(UTC)
        self.rp_date = wall.date().isoformat()
        self.request_date = params["request_date"]
        rd = dt.date.fromisoformat(self.request_date)
        self.req_end = dt.datetime.combine(rd, dt.time(23, 59, 59)).replace(
            tzinfo=ZoneInfo(self.site_tz), fold=0).astimezone(UTC)
        self.target_volume = params["target_volume"]
        self.dispositions = rrq.doc.table("Records disposition holds")
        self.in_force: dict[tuple, bool] = {}
        for row in self.one("DOCREG").doc.table("Document control register"):
            ok = (row["status"] in ("APPROVED", "IN FORCE") and row["effective"]
                  and row["effective"] <= self.rp_date)
            self.in_force[(row["stream"], row["revision"], row["section"])] = bool(ok)

    def doc_in_force(self, stream: str, revision: str, section: str = "ALL") -> bool:
        v = self.in_force.get((stream, revision, section))
        if v is None and section != "ALL":
            v = self.in_force.get((stream, revision, "ALL"))
        return bool(v)

    def spec_table(self, caption: str, section: str = "ALL") -> list[dict]:
        for f in self.all("SPEC"):
            if self.doc_in_force("SPEC", f.control.get("revision", ""), section):
                rows = f.doc.table(caption)
                if rows:
                    return rows
        return []

    # ------------------------------------------------------------------ hosts, clients and roots
    def load_hosts(self) -> None:
        self.host_tz, self.host_os = {}, {}
        for h in self.one("HOST", "ORIGINAL").tables["hosts"]:
            self.host_tz[h["host"].upper()] = h["tz"]
            self.host_os[h["host"].upper()] = h["os"]
        self.host_fs = {h["hostname"].upper(): h["filesystem"] for h in self.one("HOST", "CMDB-EXPORT").tables["hosts"]}
        self.clientx = self.one("FMTGUIDE").doc.table("Client crosswalk")
        self.roots: dict[tuple, list[str]] = {}
        for s in self.one("ROOT").tables["sections"]:
            self.roots.setdefault((s["host"].upper(), s["share"].upper()), []).append(s["path"])
        self.servers = {}
        for s in self.one("SRV").tables["servers"]:
            self.servers[s["name"]] = {
                "tz": s["tz"],
                "builds": sorted((_iso(b["installed"]), b["log_timestamps"]) for b in s["builds"]),
            }

    def client_host(self, code: str, when: dt.datetime) -> str | None:
        day = when.astimezone(ZoneInfo(self.site_tz)).date().isoformat()
        for row in self.clientx:
            if row["client"] == code and row["valid_from"] <= day and (not row["valid_to"] or day <= row["valid_to"]):
                return row["host"].upper()
        return None

    # ------------------------------------------------------------------ sets
    def load_sets(self) -> None:
        defs = {}
        for f in self.all("JOBDEF"):
            for j in f.tables["rows"]:
                defs[j["name"].strip().upper()] = j
        xwalk = self.spec_table("Job rename crosswalk", "Appendix J")

        def share_of_job(job: str) -> str:
            j = defs.get(job)
            if j and j.get("status", "").strip().upper() != "RETIRED":
                return j.get("share", "")
            return ""

        def share_of(job: str, queued: dt.datetime) -> str:
            direct = share_of_job(job)
            if direct:
                return direct
            day = queued.astimezone(ZoneInfo(self.site_tz)).date().isoformat()
            for x in xwalk:
                if x["old_name"].strip().upper() == job and day < x["effective"]:
                    s = share_of_job(x["new_name"].strip().upper())
                    if s:
                        return s
            return ""

        self.entry_totals: dict[str, int] = {}
        for f in self.all("JOB", "REPORTING"):
            for row in f.rows():
                if "set_id" in row and "catalog_entries" in row:
                    self.entry_totals[norm_id(row["set_id"])] = int(row["catalog_entries"])
        self.sets: dict[str, SetInfo] = {}
        for f in self.all("JOB", "ORIGINAL"):
            for row in f.tables["rows"]:
                kind = next(k for k in row if k.startswith("queued_")).split("_", 1)[1]
                server = row["server"].strip()
                tz = self.servers.get(server, {}).get("tz", "UTC")
                queued = values.parse_ts(row[f"queued_{kind}"], kind, tz)
                job = row["job_name"].strip().upper()
                if share_of(job, queued) != self.share:
                    continue
                sid = norm_id(row["set_id"])
                self.sets[sid] = SetInfo(sid, job, row["set_type"].strip().upper(), row["status"].strip().upper(),
                                         server, queued, norm_id(row.get("consolidates", "")))
        self._read_logs()
        for s in self.sets.values():
            if s.type == "SYNTH":
                continue
            s.snapshot = self.snap.get(s.sid)
        for s in self.sets.values():
            if s.type == "SYNTH":
                base = self.snap.get(s.consolidates)
                s.snapshot = base if base is not None else self.snap.get(s.sid)
        for s in self.sets.values():
            change = self.status_change.get(s.sid)
            if change:
                s.status = change[1].strip().upper()
        self.sets = {sid: s for sid, s in self.sets.items() if s.snapshot is not None}
        self._crash()

    def _log_time(self, text: str, server: str) -> dt.datetime:
        if re.search(r"(Z|[+-]\d\d:?\d\d)$", text):
            return _iso(text)
        tz = self.servers.get(server, {}).get("tz", "UTC")
        wall = dt.datetime.strptime(text, "%Y-%m-%d %H:%M:%S")
        return wall.replace(tzinfo=ZoneInfo(tz), fold=0).astimezone(UTC)

    def _read_logs(self) -> None:
        self.snap: dict[str, dt.datetime] = {}
        self.status_change: dict[str, tuple] = {}
        gaps: dict[str, list] = {}
        line_re = re.compile(r"^(\S+(?: \d\d:\d\d:\d\d)?) (\S+) (\w+) \[([\w-]+)\] (.*)$")

        def take(store: dict, t: dt.datetime, comp: str, msg: str) -> None:
            m = re.match(r"snapshot \{[^}]*\} created set=(\S+)$", msg)
            if m:
                store[norm_id(m.group(1))] = t
                return
            m = re.match(r"set=(\S+) status changed \S+ -> (\S+)", msg)
            if m and comp == "catalog-check":
                sid = norm_id(m.group(1))
                if sid not in self.status_change or self.status_change[sid][0] <= t:
                    self.status_change[sid] = (t, m.group(2))

        for f in self.all("LOG", "ORIGINAL"):
            for ln in f.lines:
                m = line_re.match(ln)
                if not m or m.group(2) not in self.servers:
                    continue
                t = self._log_time(m.group(1), m.group(2))
                take(self.snap, t, m.group(4), m.group(5))
                g = re.match(r"lines from (\S+) to (\S+) were not retained", m.group(5))
                if g:
                    gaps.setdefault(m.group(2), []).append((_iso(g.group(1)), _iso(g.group(2))))
        for f in self.all("LOG", "MIRROR"):
            for ln in f.lines:
                m = re.match(r"^(\d{4}-\d\d-\d\dT\d\d:\d\dZ) (\S+) (\w+) \[([\w-]+)\] (.*)$", ln)
                if not m:
                    continue
                t = dt.datetime.strptime(m.group(1), "%Y-%m-%dT%H:%MZ").replace(tzinfo=UTC)
                if not any(a <= t < b for a, b in gaps.get(m.group(2), [])):
                    continue
                mirror: dict = {}
                take(mirror, t, m.group(4), m.group(5))
                for sid, when in mirror.items():
                    self.snap.setdefault(sid, when)

    def _crash(self) -> None:
        actual: dict[str, list] = {}
        for f in self.all("LOG", "ORIGINAL"):
            for ln in f.lines:
                m = re.match(r"^(\S+) (\S+) maintenance uid=(\S+) actual-(start|end)$", ln)
                if m:
                    slot = actual.setdefault(m.group(3), [None, None])
                    slot[0 if m.group(4) == "start" else 1] = _iso(m.group(1))
        windows = []
        for ev in self.one("CAL").tables["events"]:
            if ev.get("X-ARRAY", ("",))[0] != self.array or ev.get("STATUS", ("",))[0] != "CONFIRMED":
                continue
            if ev.get("X-IMPACT", ("",))[0] != "SNAPSHOT-CONSISTENCY":
                continue
            uid = ev["UID"][0]
            start, end = self._ics_time(*ev["DTSTART"]), self._ics_time(*ev["DTEND"])
            a = actual.get(uid)
            if a and a[0] is not None and a[1] is not None:
                start, end = a
            windows.append((start, end))
        self.windows = windows
        for s in self.sets.values():
            s.crash = s.snapshot is not None and any(a <= s.snapshot < b for a, b in windows)

    @staticmethod
    def _ics_time(value: str, params: str) -> dt.datetime:
        if value.endswith("Z"):
            return dt.datetime.strptime(value, "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
        tz = re.search(r"TZID=([^;:]+)", params).group(1)
        return dt.datetime.strptime(value, "%Y%m%dT%H%M%S").replace(tzinfo=ZoneInfo(tz), fold=0).astimezone(UTC)

    # ------------------------------------------------------------------ chain
    def select_chain(self) -> None:
        order = sorted(self.sets.values(), key=lambda s: (s.snapshot, s.sid))
        eligible = [s for s in order if s.snapshot <= self.rp and s.status in ("COMPLETED", "PARTIAL") and not s.crash]
        bases = [s for s in eligible if s.type in ("FULL", "SYNTH")]
        if not bases:
            raise FeedError("no eligible base set")
        base = max(bases, key=lambda s: (s.snapshot, s.sid))
        diffs = [s for s in eligible if s.type == "DIFF" and s.snapshot > base.snapshot]
        diff = max(diffs, key=lambda s: (s.snapshot, s.sid)) if diffs else None
        anchor = diff or base
        chain = [base] + ([diff] if diff else [])
        applied = {base.sid} | ({diff.sid} if diff else set())
        broken = False
        for s in order:
            if s.sid in applied or s.snapshot > self.rp:
                continue
            if (s.snapshot, s.sid) <= (anchor.snapshot, anchor.sid):
                continue
            if s.status in ("FAILED", "CANCELLED"):
                continue
            if s.crash:
                broken = True
                continue
            if broken or s.type != "INCR" or s not in eligible:
                continue
            chain.append(s)
            applied.add(s.sid)
        skipped = []
        for s in order:
            if s.sid in applied:
                continue
            if s.snapshot > self.rp:
                reason = "AFTER_RP"
            elif s.status == "FAILED":
                reason = "FAILED"
            elif s.status == "CANCELLED":
                reason = "CANCELLED"
            elif s.crash:
                reason = "CRASH_INCONSISTENT"
            elif s.snapshot <= base.snapshot:
                reason = "BEFORE_BASE"
            elif s.snapshot <= anchor.snapshot:
                reason = "SUPERSEDED_BY_DIFF"
            else:
                reason = "CHAIN_BROKEN"
            skipped.append((s, reason))
        self.chain, self.skipped, self.base, self.anchor = chain, skipped, base, anchor

    # ------------------------------------------------------------------ catalog
    def load_catalog(self) -> None:
        wanted = set(self.sets)
        entries: dict[str, Entry] = {}
        seen_by_part: dict[str, set] = {}
        for f in self.all("CAT", "ORIGINAL"):
            ids = seen_by_part.setdefault(f.part, set())
            for raw in f.rows():
                e = self._entry(raw, f)
                if e is None:
                    continue
                ids.add(e.eid)
                if e.sid in wanted:
                    entries[e.eid] = e
        for f in self.all("CAT", "RESEND"):
            known = seen_by_part.get(f.part, set())
            for raw in f.rows():
                e = self._entry(raw, f)
                if e is None or e.eid in known:
                    continue
                if e.sid in wanted:
                    entries[e.eid] = e
        self._errata(entries)
        self.entries_by_set: dict[str, list[Entry]] = {}
        for e in entries.values():
            self.entries_by_set.setdefault(e.sid, []).append(e)
        for lst in self.entries_by_set.values():
            lst.sort(key=lambda e: (e.seq, e.eid))

    def _mtime_of(self, row: dict, f) -> tuple[object, str]:
        names = self.aliases.get("mtime", ["mtime", "modified"])
        stamps = tuple(f.extra.get("timestamp_columns", ()))
        for k in row:
            m = re.fullmatch(r"(" + "|".join(re.escape(n) for n in names) + r")_(\w+)", k)
            if m and m.group(2) in TS_KINDS:
                return row[k], m.group(2)
        for k in row:
            if k in names:
                return row[k], ("ts" if k in stamps else "utc")
        return None, ""

    def _entry(self, row: dict, f) -> Entry | None:
        sid = norm_id(self._col(row, "set"))
        eid = norm_id(self._col(row, "entry"))
        if not sid or not eid:
            return None
        if sid not in self.sets:
            return Entry(eid, sid, 0, "")
        locale = f.control.get("locale", "plain")
        seq = self._col(row, "seq")
        e = Entry(eid, sid, int(seq), str(self._col(row, "type") or "").strip().upper())
        for fld in ("path", "new_path", "target", "kind", "owner", "client", "attrs"):
            v = self._col(row, fld)
            setattr(e, fld, "" if v is None else str(v))
        e.client = e.client.strip()
        e.kind = e.kind.strip().lower()
        e.sha256 = norm_hash(self._col(row, "sha256"))
        e.container = norm_id(self._col(row, "container"))
        e.voids = norm_id(self._col(row, "voids"))
        fid = self._col(row, "file_id")
        if fid is None:
            e.file_id = ""
        elif isinstance(fid, float):
            e.file_id = str(int(fid))
        else:
            e.file_id = str(fid).strip()
        c = self._col(row, "committed")
        e.committed = True if c is None else values.truthy(c)
        e.size = self._size(row, locale)
        e.mode = values.parse_mode(row)
        snap = self.sets[sid].snapshot
        host = self.client_host(e.client, snap) if e.client else None
        e.host = host
        e.windows = self.host_os.get(host or "", "") == "windows"
        raw, kind = self._mtime_of(row, f)
        if kind:
            fat = self.host_fs.get(host or "", "") in ("FAT32", "exFAT")
            tz = self.host_tz.get(host or "", "UTC")
            if raw is None:
                e.mtime = "SENTINEL" if kind == "ts" else None
            elif fat:
                e.mtime = self._fat_time(raw, kind, tz, f)
            else:
                e.mtime = values.parse_ts(raw, "utc" if kind == "ts" else kind, tz, f.extra.get("date1904", False))
        return e

    @staticmethod
    def _fat_time(raw, kind: str, tz: str, f):
        if kind in ("utc", "iso", "local"):
            s = str(raw).strip()
            if s.startswith("0000-00-00"):
                return "SENTINEL"
            m = re.match(r"(\d{4}-\d\d-\d\d)[T ](\d\d:\d\d:\d\d)", s)
            if not m:
                return values.parse_ts(raw, kind, tz)
            wall = dt.datetime.fromisoformat(m.group(1) + "T" + m.group(2))
            return wall.replace(tzinfo=ZoneInfo(tz), fold=0).astimezone(UTC)
        t = values.parse_ts(raw, "utc" if kind == "ts" else kind, "UTC", f.extra.get("date1904", False))
        if t == "SENTINEL" or t is None:
            return t
        return values.as_wall_in(t, tz)

    def _size(self, row: dict, locale: str) -> int | None:
        for name in self.aliases.get("size", ["size"]):
            if name in row and row[name] not in ("", None):
                if name.endswith("_kib"):
                    return int(values.parse_dec(row[name], locale) * 1024)
                return values.parse_int(row[name], locale)
        return None

    @staticmethod
    def _well_formed(field: str, value: str) -> bool:
        if field == "sha256":
            return re.fullmatch(r"[0-9a-f]{64}", value) is not None
        if field == "size":
            return re.fullmatch(r"\d+", value) is not None
        if field == "mtime":
            return re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ", value) is not None
        if field == "container":
            return re.fullmatch(r"(CT|RC)-\d{7}", value) is not None
        return False

    def _errata(self, entries: dict[str, Entry]) -> None:
        best: dict[tuple, tuple] = {}
        for f in self.all("ERR"):
            rev = f.control.get("revision", "")
            if not self.doc_in_force("ERR", rev):
                continue
            for row in f.doc.table("Catalog errata"):
                if row["status"].strip().upper() != "APPROVED":
                    continue
                value = row["value"].strip()
                if not self._well_formed(row["field"], value):
                    continue
                k = (norm_id(row["entry"]), row["field"])
                if k not in best or int(rev) > best[k][0]:
                    best[k] = (int(rev), value)
        for (eid, fld), (_, value) in best.items():
            e = entries.get(eid)
            if e is None:
                continue
            if fld == "sha256":
                e.sha256 = value
            elif fld == "size":
                e.size = int(value)
            elif fld == "mtime":
                e.mtime = _iso(value)
            elif fld == "container":
                e.container = value

    # ------------------------------------------------------------------ replay
    def canonicalize(self, e: Entry) -> None:
        if e.canon or e.rejected:
            return
        host = e.host
        if host is None:
            e.rejected = "outside"
            return
        roots = self.roots.get((host, self.share.upper()), [])
        try:
            if e.etype != "X":
                e.canon = paths.canonical(e.path, roots, e.windows)
            if e.etype == "R":
                e.canon_new = paths.canonical(e.new_path, roots, e.windows)
            if e.etype == "H":
                e.canon_target = paths.canonical(e.target, roots, e.windows)
        except paths.Unsafe:
            e.rejected = "unsafe"
        except paths.Outside:
            e.rejected = "outside"

    def replay(self) -> None:
        self.dirs: dict[str, str] = {"": ""}
        self.objs: dict[str, Obj] = {}
        self.recon_sets = []
        for s in self.chain:
            es = self.entries_by_set.get(s.sid, [])
            voided = {e.voids for e in es if e.etype == "X" and e.voids}
            counts = {"set": s.sid, "expected": self.entry_totals.get(s.sid), "entries": len(es),
                      "applied": 0, "voided": 0, "uncommitted": 0, "rejected": 0}
            for e in es:
                if e.etype == "X":
                    continue
                if e.eid in voided:
                    counts["voided"] += 1
                    continue
                if not e.committed:
                    counts["uncommitted"] += 1
                    continue
                self.canonicalize(e)
                if e.rejected:
                    counts["rejected"] += 1
                    continue
                self.apply(e)
                counts["applied"] += 1
            self.recon_sets.append(counts)

    def _parent_display(self, path: str) -> str:
        parent = path.rpartition("/")[0]
        if parent == "":
            return ""
        pk = paths.key(parent)
        if pk not in self.dirs:
            self.dirs[pk] = self._parent_display(parent) + "/" + parent.rpartition("/")[2]
        return self.dirs[pk]

    def _display(self, path: str) -> str:
        return self._parent_display(path) + "/" + path.rpartition("/")[2]

    def apply(self, e: Entry) -> None:
        k = paths.key(e.canon)
        t = e.etype
        if t == "D":
            if k not in self.dirs:
                self.dirs[k] = self._display(e.canon)
        elif t == "F":
            o = self.objs.get(k)
            if o is not None:
                o.entry = e
                o.kind = "file"
                o.target = ""
            else:
                self.objs[k] = Obj(self._display(e.canon), "file", e)
        elif t == "H":
            src = self.objs.get(paths.key(e.canon_target))
            if src is not None and src.kind == "file":
                o = self.objs.get(k)
                if o is not None:
                    o.entry = src.entry
                    o.kind = "file"
                    o.target = ""
                else:
                    self.objs[k] = Obj(self._display(e.canon), "file", src.entry)
        elif t == "L":
            o = self.objs.get(k)
            if o is not None:
                o.entry, o.kind, o.target = e, "link", e.target
            else:
                self.objs[k] = Obj(self._display(e.canon), "link", e, e.target)
        elif t == "W":
            if e.kind == "dir":
                self.dirs.pop(k, None)
                for d in [d for d in self.dirs if d.startswith(k + "/")]:
                    del self.dirs[d]
                for o in [o for o in self.objs if o.startswith(k + "/")]:
                    del self.objs[o]
            else:
                self.objs.pop(k, None)
        elif t == "R":
            nk = paths.key(e.canon_new)
            if e.kind == "dir":
                if k not in self.dirs:
                    return
                old = self.dirs.pop(k)
                new = self._display(e.canon_new)
                self.dirs[nk] = new
                for d in [d for d in self.dirs if d.startswith(k + "/")]:
                    disp = new + self.dirs.pop(d)[len(old):]
                    self.dirs[paths.key(disp)] = disp
                for ok in [o for o in self.objs if o.startswith(k + "/")]:
                    o = self.objs.pop(ok)
                    o.path = new + o.path[len(old):]
                    self.objs[paths.key(o.path)] = o
            else:
                o = self.objs.pop(k, None)
                if o is not None:
                    o.path = self._display(e.canon_new)
                    self.objs[nk] = o

    # ------------------------------------------------------------------ registers used after replay
    def load_media(self) -> None:
        self.inventory = {}
        for f in self.all("MEDIA", "ORIGINAL"):
            for row in f.rows():
                if "media_id" not in row:
                    continue
                m = norm_id(row["media_id"])
                self.inventory[m] = {"status": str(row.get("status") or "").strip().upper(),
                                     "gen": str(row.get("generation") or "").strip().upper()}
        self.barcode = {}
        for f in self.all("MEDIA", "PREVIEW"):
            for row in f.rows():
                if row.get("barcode") and row.get("media_id"):
                    self.barcode[str(row["barcode"]).strip().upper()] = norm_id(row["media_id"])
        by_copy: dict[str, dict[int, dict]] = {}
        self.created: dict[str, dt.datetime] = {}
        for f in self.all("CMAP"):
            if f.status not in ("ORIGINAL", "FINAL"):
                continue
            rc_source = f.status == "FINAL"
            locale = f.control.get("locale", "plain")
            for row in f.tables["rows"]:
                c = norm_id(row["container"])
                if c.startswith("RC-") != rc_source:
                    continue
                if "size_bytes" in row:
                    size = values.parse_int(row["size_bytes"], locale)
                else:
                    size = values.parse_int(row["size_text"], locale)
                if "created" in row:
                    created = _iso(row["created"])
                else:
                    created = values.EPOCH + dt.timedelta(milliseconds=int(row["created_ms"]))
                copy = int(row["copy"])
                ref = str(row["media_ref"]).strip().upper()
                media = self.barcode.get(ref, norm_id(ref)) if copy == 2 else norm_id(ref)
                cur = by_copy.setdefault(c, {}).get(copy)
                if cur is not None and (cur["named"] or not _is_media(media)):
                    continue
                by_copy[c][copy] = {"copy": copy, "media": media, "size": size, "named": _is_media(media)}
                self.created.setdefault(c, created)
        self.copies = {c: sorted(d.values(), key=lambda x: x["copy"]) for c, d in by_copy.items()}
        self.repack = {}
        for row in self.one("REPACK").tables["repack"]:
            if _iso(row["repacked_at"]) <= self.req_end:
                self.repack[norm_id(row["old_container"])] = norm_id(row["new_container"])
        corrections: dict[str, dict] = {}
        for f in self.all("MERR"):
            rev = f.control.get("revision", "")
            if not self.doc_in_force("MERR", rev, "Section 2"):
                continue
            for c in f.doc.table("Corrections to revision A"):
                corrections.setdefault(c["errata"], {})[c["field"]] = c["now"]
        self.damaged = set()
        for f in self.all("MERR"):
            rev = f.control.get("revision", "")
            if not self.doc_in_force("MERR", rev):
                continue
            for row in f.doc.table("Media errata"):
                fix = corrections.get(row["errata"], {})
                status = fix.get("status", row["status"]).strip().upper()
                defect = fix.get("defect", row["defect"]).strip().upper()
                media = norm_id(fix.get("media", row["media"]))
                if status == "APPROVED" and defect in ("DAMAGED", "UNREADABLE"):
                    self.damaged.add(media)
        self.destroyed = set()
        self.recalls = []
        rerun_named = set()
        for m in self.one("MAIL").tables["messages"]:
            when = email.utils.parsedate_to_datetime(m["date"]).astimezone(UTC)
            subj = m["subject"]
            if subj.startswith("Destruction notice:") and when <= self.req_end:
                self.destroyed.add(norm_id(subj.split(":", 1)[1]))
            elif subj.startswith("Recall completed:") and when <= self.req_end:
                mm = re.search(r"checked in at (\S+?)\.", m["body"])
                if mm:
                    self.recalls.append((when, norm_id(subj.split(":", 1)[1]), mm.group(1)))
            elif subj.startswith("Checksum rerun request"):
                for c, cp in re.findall(r"^(\S+) copy (\d+)$", m["body"], re.M):
                    rerun_named.add((norm_id(c), int(cp)))
        self.mismatch = set()
        for f in self.all("CHK", "ORIGINAL"):
            for row in f.rows():
                if str(row["result"]).strip().upper() == "MISMATCH":
                    self.mismatch.add((norm_id(row["container"]), int(row["copy"])))
        for f in self.all("CHK", "RERUN"):
            for row in f.rows():
                k = (norm_id(row["container"]), int(row["copy"]))
                if k not in rerun_named:
                    continue
                if str(row["result"]).strip().upper() == "MISMATCH":
                    self.mismatch.add(k)
                else:
                    self.mismatch.discard(k)
        self.copy_done = set()
        for row in self.one("COPY").doc.table("Copy jobs"):
            if row["status"].strip().upper() == "COMPLETED" and _iso(row["completed_utc"]) <= self.req_end:
                self.copy_done.add((norm_id(row["container"]), int(row["copy"])))
        vault = {}
        for s in self.one("SLOT").tables["sections"]:
            vault[norm_id(s["media"])] = s["vault"]
        for row in self.one("DASH").doc.table("Media"):
            m = norm_id(row["media_id"])
            if m not in vault and row["vault"] == "VLT-OFF3":
                vault[m] = row["vault"]
        moves = list(self.recalls)
        for row in self.one("XFER").doc.table("Transfers"):
            t = _iso(row["received_utc"])
            if t <= self.req_end:
                moves.append((t, norm_id(row["media"]), row["to_vault"]))
        for _, m, v in sorted(moves, key=lambda x: (x[0], x[1], x[2])):
            vault[m] = v
        self.vault = vault
        self.vault_prio = {}
        for row in self.one("MEDIAPROC").doc.table("Vault service calendar"):
            if row["date"] == self.request_date:
                self.vault_prio[row["vault"]] = int(row["priority"])

    def usable(self, container: str, cp: dict) -> bool:
        media = cp["media"]
        inv = self.inventory.get(media)
        if inv is not None and inv["status"] == "EXPIRED":
            return False
        if inv is not None and inv["gen"] == "LTO-6":
            return False
        if media in self.damaged or media in self.destroyed:
            return False
        if (container, cp["copy"]) in self.mismatch:
            return False
        if cp["copy"] in (2, 3) and (container, cp["copy"]) not in self.copy_done:
            return False
        return True

    def pick_copy(self, container: str) -> tuple[str, dict | None]:
        c = self.repack.get(container, container)
        for cp in sorted(self.copies.get(c, []), key=lambda x: x["copy"]):
            if self.usable(c, cp):
                return c, cp
        return c, None

    def load_av(self) -> None:
        qproc = self.one("QPROC")
        cut = re.search(r"The engine cutover is (\S+?)\.", qproc.doc.text)
        self.cutover = _iso(cut.group(1))
        vendor = {r["engine"]: r["vendor"] for r in qproc.doc.table("Engine registry")}
        withdrawals = []
        for row in self.one("ADV").doc.table("Withdrawn signatures"):
            a, b = row["revisions"].split("-")
            withdrawals.append((row["vendor"], row["signature"], int(a), int(b), _iso(row["withdrawn_utc"])))
        self.infected: set[tuple] = set()
        for f in self.all("AV"):
            if f.status not in ("ORIGINAL", "PRELIMINARY"):
                continue
            final = f.status == "ORIGINAL"
            for row in f.rows():
                if str(row.get("verdict") or "").strip().upper() != "INFECTED":
                    continue
                c = norm_id(row["container"])
                created = self.created.get(c)
                if created is None:
                    continue
                if (created >= self.cutover) != final:
                    continue
                v = vendor.get(row["engine"])
                rev = int(row["sig_rev"])
                if any(v == wv and row["signature"] == ws and a <= rev <= b and t <= self.req_end
                       for wv, ws, a, b, t in withdrawals):
                    continue
                self.infected.add((norm_hash(row["sha256"]), c))

    def load_identity(self) -> None:
        self.idmap: dict[str, list] = {}
        for f in self.all("IDMAP", "ORIGINAL"):
            for row in f.rows():
                if "principal" in row and "account" in row:
                    self.idmap.setdefault(row["principal"], []).append(row)
        self.domains = {p.rsplit("-", 1)[0] for p in self.idmap}
        self.ad = {}
        for f in self.all("IDMAP", "EXPORT"):
            for row in f.rows():
                if "sid" in row and "account" in row:
                    self.ad[row["sid"]] = row["account"]
        self.changes = {}
        for row in self.one("IDCHG").doc.table("Identity changes"):
            if row["status"].strip().upper() != "APPROVED":
                continue
            t = _iso(row["effective_utc"])
            if t <= self.rp and (row["principal"] not in self.changes or self.changes[row["principal"]][0] <= t):
                self.changes[row["principal"]] = (t, row["account"])
        self.local = {}
        for s in self.one("LACCT").tables["sections"]:
            host = s["_section"].split(":", 1)[1].upper()
            for k, v in s.items():
                if k != "_section":
                    self.local[(host, k)] = v

    def owner(self, e: Entry) -> str:
        p = (e.owner or "").strip()
        if p in OWNER_SENTINELS:
            return "UNMAPPED"
        if p.startswith("uid:"):
            return self.local.get(((e.host or ""), p[4:]), "UNMAPPED")
        if p in self.changes:
            return self.changes[p][1]
        for row in self.idmap.get(p, []):
            if _iso(row["valid_from"]) <= self.rp and (not row["valid_to"] or self.rp < _iso(row["valid_to"])):
                return row["account"]
        if p.rsplit("-", 1)[0] not in self.domains and p in self.ad:
            return self.ad[p]
        return "UNMAPPED"

    def load_scope(self) -> None:
        prof = next((r for r in self.spec_table("Share restore profiles") if r["share"] == self.share), None)
        if prof is None:
            raise FeedError("no restore profile for the share")
        self.includes = [x.strip() for x in prof["include_prefixes"].split(";") if x.strip()]
        self.holds = sorted((h for h in self.dispositions
                             if h["share"] == self.share and h["action"].strip().upper() == "DESTROY"
                             and h["effective"] <= self.rp_date), key=lambda h: h["hold"])
        cats = [f for f in self.all("EXCL")
                if self.doc_in_force("EXCL", f.control.get("revision", ""))
                and f.control.get("effective_from", "") <= self.rp_date]
        in_force = max(cats, key=lambda f: int(f.control.get("revision", "0")))
        withdrawn = set()
        for f in self.all("EXCL"):
            for w in f.tables.get("withdrawal", []):
                if w["effective"] <= self.rp_date:
                    withdrawn.add(w["id"])
        self.patterns = sorted((p for p in in_force.tables.get("pattern", [])
                                if p["scope"] in ("ALL", self.share) and p["from"] <= self.rp_date
                                and (not p["to"] or p["to"] > self.rp_date) and p["id"] not in withdrawn),
                               key=lambda p: int(p["id"].split("-")[1]))
        self.volume = next(v for v in self.one("VOL").tables["volume"] if v["id"] == self.target_volume)

    # ------------------------------------------------------------------ restore decisions
    def custody(self) -> str:
        src = {f.part: f.control.get("source_custody", "") for f in self.all("CAT", "CORRECTED")}
        lines = []
        for f in self.files:
            c = f.control["custody"]
            if c == "N/A" and f.status == "ORIGINAL":
                c = src.get(f.part, c)
            lines.append(f"{f.stream}|{f.part}|{f.status}|{f.control['records']}|{c}")
        return hashlib.sha256("".join(x + "\n" for x in sorted(lines)).encode("utf-8")).hexdigest()

    def allocation(self, size: int) -> int:
        v = self.volume
        if size <= int(v["resident_max"]):
            return 0
        c = int(v["large_cluster"]) if size >= int(v["large_threshold"]) else int(v["small_cluster"])
        return -(-size // c) * c

    def decide(self) -> None:
        order_sets = {s.sid: s for s in self.sets.values()}
        rollback_sets = {s.sid for s in self.chain} | {s.sid for s, r in self.skipped
                                                       if r in ("BEFORE_BASE", "SUPERSEDED_BY_DIFF")}
        hist: dict[str, list] = {}
        for sid in rollback_sets:
            es = self.entries_by_set.get(sid, [])
            voided = {e.voids for e in es if e.etype == "X" and e.voids}
            st = order_sets[sid]
            for e in es:
                if e.etype != "F" or e.eid in voided or not e.committed:
                    continue
                self.canonicalize(e)
                if e.rejected:
                    continue
                hist.setdefault(paths.key(e.canon), []).append(((st.snapshot, st.sid, e.seq), e))
        for lst in hist.values():
            lst.sort(key=lambda c: c[0])
        rows, excl, rolled = [], [], 0
        for o in sorted(self.objs.values(), key=lambda o: (paths.key(o.path), o.path)):
            kind = "file" if o.kind == "file" else "symlink"
            reason, detail, link_target = None, "", ""
            if not any(paths.under(o.path, inc) for inc in self.includes):
                reason = "OUT_OF_SCOPE"
            if reason is None:
                hs = [h for h in self.holds if paths.under(o.path, h["prefix"])]
                if hs:
                    reason, detail = "DISPOSED", hs[0]["hold"]
            if reason is None:
                for p in self.patterns:
                    if globs.match(p["pattern"], o.path):
                        reason, detail = "EXCLUDED_PATTERN", p["pattern"]
                        break
            if reason is None and kind == "symlink":
                host = o.entry.host
                lt = paths.resolve_link(o.target, o.path, self.roots.get((host, self.share.upper()), []),
                                        o.entry.windows)
                if lt is None:
                    reason = "SYMLINK_ESCAPE"
                else:
                    link_target = lt
            chosen = o.entry
            if reason is None and kind == "file" and (chosen.sha256, chosen.container) in self.infected:
                st = order_sets[chosen.sid]
                mine = (st.snapshot, st.sid, chosen.seq)
                cands = [c for c in hist.get(paths.key(o.path), []) if c[0] < mine]
                clean = [c[1] for c in cands if (c[1].sha256, c[1].container) not in self.infected]
                if clean:
                    chosen = clean[-1]
                    rolled += 1
                else:
                    reason, detail = "QUARANTINED", o.entry.sha256
            cont, cp = "", None
            if reason is None and kind == "file":
                cont, cp = self.pick_copy(chosen.container)
                if cp is None:
                    reason, detail = "UNRECOVERABLE", cont
            if reason:
                excl.append({"path": o.path, "kind": kind, "reason": reason, "detail": detail})
                continue
            e = chosen
            mt = e.mtime
            if mt == "SENTINEL" or mt is None:
                mt = order_sets[e.sid].snapshot
            size = e.size if kind == "file" else 0
            row = {"path": o.path, "kind": kind, "size": size if size is not None else 0, "allocated": 0,
                   "sha256": e.sha256 if kind == "file" else "",
                   "mode": values.mode_out(None if e.windows else e.mode, e.attrs),
                   "mtime_utc": values.iso_z(mt), "owner": self.owner(e), "source_set": e.sid,
                   "container": cont, "media": cp["media"] if cp else "", "copy": cp["copy"] if cp else 0,
                   "hardlink_group": "", "link_target": link_target,
                   "_gk": (e.client, e.file_id) if kind == "file" and e.file_id else None,
                   "_csize": cp["size"] if cp else 0}
            rows.append(row)
        groups: dict = {}
        for row in rows:
            if row["_gk"] is not None:
                groups.setdefault(row["_gk"], []).append(row)
        n = 0
        for row in rows:
            g = groups.get(row["_gk"]) if row["_gk"] is not None else None
            if g and len(g) > 1 and g[0] is row:
                n += 1
                for m in g:
                    m["hardlink_group"] = f"HL-{n:04d}"
        for row in rows:
            if row["kind"] != "file":
                continue
            g = groups.get(row["_gk"]) if row["_gk"] is not None else None
            if g and len(g) > 1 and g[0] is not row:
                continue
            row["allocated"] = self.allocation(row["size"])
        self.rows, self.excl, self.rolled, self.groups = rows, excl, rolled, n

    # ------------------------------------------------------------------ deliverables
    def pull_list(self) -> list[dict]:
        by: dict[str, dict] = {}
        for row in self.rows:
            if row["kind"] != "file" or not row["media"]:
                continue
            m = by.setdefault(row["media"], {"copy": row["copy"], "containers": {}})
            m["containers"][row["container"]] = row["_csize"]
        out = []
        for media, m in by.items():
            rb = sum(m["containers"].values())
            gib = (Decimal(rb) / Decimal(1073741824)).quantize(Decimal("0.001"), rounding=ROUND_HALF_EVEN)
            out.append({"media_id": media, "vault": self.vault.get(media, ""), "copy": m["copy"],
                        "containers": len(m["containers"]), "read_bytes": rb, "read_gib": f"{gib:.3f}"})
        out.sort(key=lambda x: (self.vault_prio.get(x["vault"], 10 ** 9), x["media_id"]))
        return out

    def run(self) -> dict:
        self.load_request()
        self.load_hosts()
        self.load_sets()
        self.select_chain()
        self.load_catalog()
        self.replay()
        self.load_media()
        self.load_av()
        self.load_identity()
        self.load_scope()
        self.decide()
        pull = self.pull_list()
        digest = self.custody()
        counts = {r: 0 for r in REASONS}
        for x in self.excl:
            counts[x["reason"]] += 1
        chain = {"share": self.share, "restore_point_utc": values.iso_z(self.rp),
                 "effective_point_utc": values.iso_z(self.chain[-1].snapshot),
                 "chain": [{"set": s.sid, "type": s.type, "snapshot_utc": values.iso_z(s.snapshot),
                            "role": "base" if i == 0 else ("diff" if s.type == "DIFF" else "incremental")}
                           for i, s in enumerate(self.chain)],
                 "skipped": [{"set": s.sid, "type": s.type, "snapshot_utc": values.iso_z(s.snapshot), "reason": r}
                             for s, r in sorted(self.skipped, key=lambda x: (x[0].snapshot, x[0].sid))],
                 "custody_digest": digest}
        recon = {"sets": self.recon_sets, "objects_at_effective_point": len(self.objs), "restored": len(self.rows),
                 "excluded": counts, "rolled_back": self.rolled,
                 "bytes_restored": sum(r["size"] for r in self.rows),
                 "bytes_allocated": sum(r["allocated"] for r in self.rows), "hardlink_groups": self.groups,
                 "media": len(pull), "containers": sum(p["containers"] for p in pull),
                 "read_bytes": sum(p["read_bytes"] for p in pull), "custody_digest": digest}
        return {"manifest": self.rows, "exclusions": self.excl, "pull": pull, "chain": chain, "recon": recon,
                "digest": digest}
