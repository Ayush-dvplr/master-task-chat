"""Exclusion pattern dialect (restore specification revision 4.1, section 7)."""

from __future__ import annotations

import functools
import re
import unicodedata


@functools.lru_cache(maxsize=4096)
def _segment(seg: str) -> re.Pattern:
    out, i = "", 0
    while i < len(seg):
        c = seg[i]
        if c == "*":
            out += "[^/]*"
        elif c == "?":
            out += "[^/]"
        elif c == "[":
            j = seg.find("]", i + 1)
            if j == -1:
                out += re.escape(c)
            else:
                body = seg[i + 1:j]
                neg = body.startswith("!")
                if neg:
                    body = body[1:]
                out += "[" + ("^" if neg else "") + "".join("\\" + ch if ch in "\\^]-" else ch for ch in body) + "]"
                i = j
        else:
            out += re.escape(c)
        i += 1
    return re.compile(out)


def _match_comps(pat: str, comps: list[str]) -> bool:
    if "/" not in pat:
        return bool(comps) and _segment(pat).fullmatch(comps[-1]) is not None
    segs = [s for s in pat.strip("/").split("/") if s]

    @functools.lru_cache(maxsize=None)
    def m(i: int, j: int) -> bool:
        if i == len(segs):
            return j == len(comps)
        if segs[i] == "**":
            return any(m(i + 1, k) for k in range(j, len(comps) + 1))
        return j < len(comps) and _segment(segs[i]).fullmatch(comps[j]) is not None and m(i + 1, j + 1)

    return m(0, 0)


def match(pattern: str, path: str) -> bool:
    pat = unicodedata.normalize("NFC", pattern).casefold()
    comps = [c for c in unicodedata.normalize("NFC", path).casefold().split("/") if c]
    if pat.endswith("/"):
        pat = pat.rstrip("/")
        return any(_match_comps(pat, comps[:i]) for i in range(1, len(comps)))
    return _match_comps(pat, comps)
