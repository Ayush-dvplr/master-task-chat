"""Value notations of the feed: identifiers, numbers, timestamps, modes and sentinels."""

from __future__ import annotations

import datetime as dt
import re
import unicodedata
from decimal import Decimal
from zoneinfo import ZoneInfo

UTC = dt.timezone.utc
EPOCH = dt.datetime(1970, 1, 1, tzinfo=UTC)
FT_EPOCH = dt.datetime(1601, 1, 1, tzinfo=UTC)
XL_1900 = dt.datetime(1899, 12, 30, tzinfo=UTC)
XL_1904 = dt.datetime(1904, 1, 1, tzinfo=UTC)
ID_WIDTH = {"BS": 5, "E": 7, "CT": 7, "RC": 7, "MD": 5}
GROUPING = {"plain": "", "en_US": ",", "de_DE": ".", "fr_FR": "\u202f"}
DECIMAL_POINT = {"plain": ".", "en_US": ".", "de_DE": ",", "fr_FR": ","}


class Folds:
    """Identifier fold table (PATHCONV Appendix C, identifier scope)."""

    table: dict[str, str] = {}


def norm_id(value) -> str:
    if value is None:
        return ""
    s = str(value).strip()
    if not s:
        return ""
    s = "".join(Folds.table.get(c, c) for c in s)
    s = s.upper().replace("_", "-")
    m = re.fullmatch(r"([A-Z]+)-?0*(\d+)", s)
    if not m or m.group(1) not in ID_WIDTH:
        return s
    return f"{m.group(1)}-{int(m.group(2)):0{ID_WIDTH[m.group(1)]}d}"


def norm_hash(value) -> str:
    s = str(value or "").strip().lower()
    return s[7:] if s.startswith("sha256:") else s


def _clean_number(s: str, locale: str) -> str:
    sep = GROUPING.get(locale, "")
    if sep:
        s = s.replace(sep, "")
    return s.replace("\u00a0", "").replace(" ", "")


def parse_int(value, locale: str) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise ValueError(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return int(_clean_number(str(value).strip(), locale))


def parse_dec(value, locale: str) -> Decimal:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return Decimal(repr(value)) if isinstance(value, float) else Decimal(value)
    s = _clean_number(str(value).strip(), locale)
    if DECIMAL_POINT.get(locale, ".") == ",":
        s = s.replace(",", ".")
    return Decimal(s)


def size_of(row: dict, locale: str) -> int | None:
    for key in ("size", "size_bytes", "bytes"):
        if key in row and row[key] not in ("", None):
            return parse_int(row[key], locale)
    if "size_kib" in row and row["size_kib"] not in ("", None):
        return int(parse_dec(row["size_kib"], locale) * 1024)
    return None


def _wall_to_utc(wall: dt.datetime, tz: str) -> dt.datetime:
    return wall.replace(tzinfo=ZoneInfo(tz), fold=0).astimezone(UTC)


def _trunc(t: dt.datetime) -> dt.datetime:
    return t.replace(microsecond=0)


def parse_ts(value, kind: str, tz: str | None = None, date1904: bool = False):
    """Returns an aware UTC datetime, 'SENTINEL', or None for an empty cell."""
    if value is None or value == "":
        return None
    if isinstance(value, dt.datetime):
        t = value if value.tzinfo else value.replace(tzinfo=UTC)
        return _trunc(t.astimezone(UTC))
    if kind in ("utc", "iso", "local"):
        s = str(value).strip()
        if s.startswith("0000-00-00"):
            return "SENTINEL"
        if kind == "local":
            wall = dt.datetime.fromisoformat(s.split("+")[0].strip())
            return _trunc(_wall_to_utc(wall.replace(tzinfo=None), tz or "UTC"))
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00").replace("z", "+00:00"))
        if t.tzinfo is None:
            t = t.replace(tzinfo=UTC)
        return _trunc(t.astimezone(UTC))
    n = value if isinstance(value, (int, float)) else Decimal(str(value).strip())
    if kind == "epoch":
        if int(n) == 0:
            return "SENTINEL"
        return EPOCH + dt.timedelta(seconds=int(n // 1))
    if kind == "ms":
        if int(n) == -1:
            return "SENTINEL"
        return EPOCH + dt.timedelta(milliseconds=int(n // 1000 * 1000))
    if kind == "ft":
        if int(n) == 0:
            return "SENTINEL"
        return FT_EPOCH + dt.timedelta(seconds=int(n) // 10000000)
    if kind == "xl":
        if float(n) == 0:
            return "SENTINEL"
        base = XL_1904 if date1904 else XL_1900
        days = Decimal(str(n))
        secs = (days * 86400).quantize(Decimal(1), rounding="ROUND_HALF_EVEN")
        return base + dt.timedelta(seconds=int(secs))
    raise ValueError(kind)


def as_wall_in(t: dt.datetime, tz: str) -> dt.datetime:
    """FAT rule: the digits of the value are the client's wall-clock time."""
    wall = t.astimezone(UTC).replace(tzinfo=None)
    return _wall_to_utc(wall, tz)


def iso_z(t: dt.datetime) -> str:
    return t.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_mode(row: dict) -> int | None:
    for key in ("mode_oct", "mode_sym", "mode_dec", "st_mode"):
        v = row.get(key)
        if v in (None, ""):
            continue
        s = str(v).strip()
        if key == "mode_dec":
            return int(s) & 0o7777
        if key == "mode_oct":
            return int(s, 8)
        if key == "st_mode":
            return int(s, 8) & 0o7777
        bits = 0
        trip = s[1:10]
        for i, (shift, special) in enumerate(((6, 0o4000), (3, 0o2000), (0, 0o1000))):
            r, w, x = trip[i * 3:i * 3 + 3]
            bits |= (4 if r == "r" else 0) << shift
            bits |= (2 if w == "w" else 0) << shift
            if x in ("x", "s", "t"):
                bits |= 1 << shift
            if x in ("s", "S", "t", "T"):
                bits |= special
        return bits
    return None


def mode_out(mode: int | None, attrs: str | None) -> str:
    if mode is None:
        return "0444" if "R" in (attrs or "") else "0644"
    return f"{mode & 0o1777:04o}"


def truthy(v) -> bool:
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    s = str(v).strip().lower()
    if s in ("y", "yes", "t", "true", "1", "on"):
        return True
    if s in ("n", "no", "f", "false", "0", "off"):
        return False
    raise ValueError(v)


def nfc(s: str) -> str:
    return unicodedata.normalize("NFC", s)
