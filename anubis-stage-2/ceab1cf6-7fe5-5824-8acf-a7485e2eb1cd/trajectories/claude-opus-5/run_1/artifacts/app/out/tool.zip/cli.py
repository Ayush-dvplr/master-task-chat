#!/usr/bin/env python3
"""task-ctl: offline budget-envelope allocation ledger CLI."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

CANON = "CANONICAL"


def data_dir():
    return Path(os.environ.get("TASK_CTL_DATA") or "/app/data")


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------
# arithmetic policy
# --------------------------------------------------------------------------
def round_half_even(num, den):
    """Exact integer banker's rounding of num/den."""
    if den == 0:
        raise ValueError("zero denominator")
    if den < 0:
        num, den = -num, -den
    quo, rem = divmod(num, den)
    twice = 2 * rem
    if twice > den or (twice == den and quo % 2 == 1):
        quo += 1
    return quo


def quantize_nearest(value, step):
    return round_half_even(value, step) * step


def clamp(value, low, high):
    return max(low, min(high, value))


# --------------------------------------------------------------------------
# rule-corpus readers
# --------------------------------------------------------------------------
def _text(name):
    return (data_dir() / name).read_text(encoding="utf-8", errors="replace")


def _lines(name):
    out = []
    for line in _text(name).split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def _delimited_rows(name, sep):
    lines = _lines(name)
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) == len(header):
            rows.append(dict(zip(header, parts)))
    return rows


def _band_row(name, sep, band_field, band):
    """The single CANONICAL row of a per-band table; row order is irrelevant."""
    hits = [
        r for r in _delimited_rows(name, sep)
        if r.get("status") == CANON and r.get(band_field, "").isdigit()
        and int(r[band_field]) == band
    ]
    if len(hits) != 1:
        raise SystemExit(
            "%s: expected one %s row for band %d, found %d" % (name, CANON, band, len(hits))
        )
    return hits[0]


def _one(name, pattern, text=None):
    """The single capture of a CANONICAL pattern inside a rule file."""
    hits = re.findall(pattern, _text(name) if text is None else text, re.M)
    if len(hits) != 1:
        raise SystemExit("%s: expected one %s match, found %d" % (name, CANON, len(hits)))
    return hits[0]


def rounding_policy():
    return _one("rounding_policy.rst3", r"^:rule-\d+:\s+(\S+)\s+status=CANONICAL\s*$")


def granularity_kbps():
    return int(_one("granularity.kv", r"^granularity_kbps=(\d+)\|status=CANONICAL\s*$"))


def maxrate_ratio_permille():
    body = _text("maxrate_ratio.toml")
    block = re.search(r"^\[active\]\s*$(.*?)(?=^\[|\Z)", body, re.M | re.S)
    if not block:
        raise SystemExit("maxrate_ratio.toml: no [active] section")
    section = block.group(1)
    if re.search(r'status\s*=\s*"?CANONICAL"?', section) is None:
        raise SystemExit("maxrate_ratio.toml: [active] is not CANONICAL")
    return int(re.search(r"ratio_permille\s*=\s*(\d+)", section).group(1))


def selected_codec():
    root = ET.fromstring(_text("kernel_selector.xml"))
    hits = [c.get("id") for c in root.iter("codec") if c.get("selected") == "true"]
    if len(hits) != 1:
        raise SystemExit("kernel_selector.xml: expected one selected codec")
    return hits[0]


def eff_permille(codec):
    pattern = r"^codec\s+%s\s+efficiency_permille\s+(\d+)\s+status\s+CANONICAL\s*$" % re.escape(codec)
    return int(_one("eff_permille.conf", pattern))


def avg_formula_scale():
    return int(_one("avg_formula.edn2", r"\(\*\s*(\d+)\s+fps_den\)"))


def band_height(band):
    return int(_band_row("precision_ladder.tsv", "\t", "tier_id", band)["height"])


def band_aspect(band):
    row = _band_row("aspect_table.csv", ",", "tier_id", band)
    return int(row["dar_num"]), int(row["dar_den"])


def band_width_even(band):
    root = ET.fromstring(_text("width_even.html2"))
    hits = [w.get("even") for w in root.iter("w")
            if w.get("status") == CANON and int(w.get("band")) == band]
    if len(hits) != 1:
        raise SystemExit("width_even.html2: expected one CANONICAL row for band %d" % band)
    return hits[0] == "true"


def band_bpp_milli(band):
    body = _text("bpp.env")
    if _one("bpp.env", r"^BPP_TIER_%d_STATUS=(\w+)$" % band, body) != CANON:
        raise SystemExit("bpp.env: band %d is not CANONICAL" % band)
    return int(_one("bpp.env", r"^BPP_TIER_%d=(\d+)$" % band, body))


def band_fps(band):
    num = den = None
    for line in _lines("fps_num.ndjson"):
        row = json.loads(line)
        if row.get("status") == CANON and row.get("tier") == band:
            num = int(row["fps_num"])
    for line in _lines("fps_den.jsonl"):
        row = json.loads(line)
        if row.get("status") == CANON and row.get("tier") == band:
            den = int(row["fps_den"])
    if num is None or den is None:
        raise SystemExit("fps tables: no CANONICAL row for band %d" % band)
    return num, den


def band_min_kbps(band):
    section = value = status = None
    for line in _lines("min_kbps.ini"):
        s = line.strip()
        if s.startswith("["):
            section = s[1:-1].strip()
            continue
        if section != "tier.%d" % band or "=" not in s:
            continue
        key, val = (p.strip() for p in s.split("=", 1))
        if key == "min_kbps":
            value = int(val)
        elif key == "status":
            status = val
    if value is None or status != CANON:
        raise SystemExit("min_kbps.ini: no CANONICAL [tier.%d] floor" % band)
    return value


def band_max_kbps(band):
    props = {}
    for line in _lines("max_kbps.properties"):
        if "=" in line:
            key, val = (p.strip() for p in line.split("=", 1))
            props[key] = val
    if props.get("tier.%d.status" % band) != CANON:
        raise SystemExit("max_kbps.properties: tier.%d is not CANONICAL" % band)
    return int(props["tier.%d.max_kbps" % band])


def qp_base():
    return int(_one("qp_base.txt", r"^qp_base\s+(\d+)\s+CANONICAL\s*$"))


def qp_floor_ceil():
    floor = int(_one("qp_floor_ceil.edn", r"\(qp_floor\s+(\d+)\s+CANONICAL\)"))
    ceiling = int(_one("qp_floor_ceil.edn", r"\(qp_ceil\s+(\d+)\s+CANONICAL\)"))
    return floor, ceiling


def qp_stair():
    return sorted(
        (int(r["threshold_kbps"]), int(r["band_offset"]))
        for r in _delimited_rows("qp_stair.psv", "|") if r.get("status") == CANON
    )


def qp_band_offset(avg_kbps):
    eligible = [off for thr, off in qp_stair() if thr <= avg_kbps]
    if not eligible:
        raise SystemExit("qp_stair.psv: no threshold at or below %d" % avg_kbps)
    return eligible[-1]


def lookahead_seconds():
    return int(_one("lookahead_seconds.conf2", r"^lookahead_seconds::(\d+)::CANONICAL\s*$"))


def pass_count():
    return int(_one("pass_count.env2", r"^PASS_COUNT::(\d+)::CANONICAL\s*$"))


def trailer_suffix():
    return _one("trailer_suffix.txt3", r"^trailer_suffix::(\S+?)::CANONICAL\s*$")


def mode_id():
    return _one("mode.hex", r"^mode=(\S+?)\|status=CANONICAL\s*$")


def container_id():
    return _one("container.pipe", r"^container\|(\S+?)\|CANONICAL\s*$")


def pixel_format_id():
    hits = []
    for line in _lines("pixel_format.b64"):
        try:
            decoded = base64.b64decode(line.strip(), validate=True).decode("utf-8")
        except Exception:
            continue
        name, _, status = decoded.rpartition("|")
        if status == CANON:
            hits.append(name)
    if len(hits) != 1:
        raise SystemExit("pixel_format.b64: expected one CANONICAL entry")
    return hits[0]


def band_bucket_class(band):
    return _one("color_primaries.rst", r"^:band-%d:\s+(\S+)\s+status=CANONICAL\s*$" % band)


def band_review_class(band):
    return _one(
        "color_transfer.sexp",
        r"\(review\s+\(band\s+%d\)\s+\(class\s+(\S+)\)\s+\(status\s+CANONICAL\)\)" % band,
    )


def band_ledger_class(band):
    return _one(
        "color_matrix.html",
        r'<tr class="CANONICAL"><td>%d</td><td>(\S+?)</td></tr>' % band,
    )


def band_threads(band):
    hits = []
    for line in _lines("threads.fixed"):
        tier, workers, status = line[0:4].strip(), line[4:10].strip(), line[10:].strip()
        if status == CANON and tier.isdigit() and int(tier) == band:
            hits.append(int(workers))
    if len(hits) != 1:
        raise SystemExit("threads.fixed: expected one CANONICAL row for band %d" % band)
    return hits[0]


def profile_ids():
    body = _text("profile_id_map.kv3")
    return dict(re.findall(r"^profile\.(\w+)=(\S+?)\|CANONICAL\s*$", body, re.M))


def canonical_keys():
    keys = []
    for line in _lines("field_registry.ndjson3"):
        row = json.loads(line)
        if row.get("in_config") is True and row.get("status") == CANON:
            keys.append(row["key"])
    return sorted(set(keys))


def schema_keys(schema):
    required = schema["required_keys"]
    if isinstance(required, str):
        required = [k.strip() for k in required.split(",") if k.strip()]
    return list(required)


# --------------------------------------------------------------------------
# derivation
# --------------------------------------------------------------------------
FIELD_SOURCES = {
    "avg_bitrate_kbps": "avg_formula.edn2",
    "bframes": "batch_frames.scsv",
    "checksum": "defaults.json",
    "codec": "kernel_selector.xml",
    "color_matrix": "color_matrix.html",
    "color_primaries": "color_primaries.rst",
    "color_transfer": "color_transfer.sexp",
    "container": "container.pipe",
    "film_grain": "dither_scale.caret",
    "fps_den": "fps_den.jsonl",
    "fps_num": "fps_num.ndjson",
    "gop_size_frames": "gop_formula.scsv2",
    "height": "precision_ladder.tsv",
    "lookahead_frames": "lookahead_seconds.conf2",
    "luma_pixels": "luma_formula.rst2",
    "max_bitrate_kbps": "max_formula.pipe2",
    "min_keyint_frames": "gop_formula.scsv2",
    "mode": "mode.hex",
    "pass_count": "pass_count.env2",
    "pixel_format": "pixel_format.b64",
    "profile": "config_schema.json",
    "qp": "qp_stair.psv",
    "temporal_layers": "temporal_layers.tsv3",
    "threads": "threads.fixed",
    "tile_columns": "shard_cols.tsv2",
    "tile_rows": "shard_rows.csv2",
    "tiles": "shard_cols.tsv2",
    "trailer": "defaults.json",
    "vbv_buffer_kbits": "vbv_formula.psv2",
    "vmaf_target": "fidelity_target.tilde",
    "width": "aspect_table.csv",
}


def solve(schema):
    policy = rounding_policy()
    if policy != "round_half_even":
        raise SystemExit("unsupported rounding policy: " + policy)

    defaults = load_json(data_dir() / "defaults.json")
    base = defaults["base_config"]
    records = int(base["max_records"])
    retry = int(base["retry_limit"])
    timeout = int(base["timeout_ms"])
    band = (records // 13) % 7

    height = band_height(band)
    dar_num, dar_den = band_aspect(band)
    width_pre = round_half_even(height * dar_num, dar_den)
    width = quantize_nearest(width_pre, 2) if band_width_even(band) else width_pre
    luma = width * height

    fps_num, fps_den = band_fps(band)
    bpp_milli = band_bpp_milli(band)
    codec = selected_codec()
    eff = eff_permille(codec)
    scale = avg_formula_scale()
    gran = granularity_kbps()
    floor_kbps = band_min_kbps(band)
    ceil_kbps = band_max_kbps(band)

    avg_pre = round_half_even(luma * bpp_milli * eff * fps_num, scale * fps_den)
    avg_clamped = clamp(avg_pre, floor_kbps, ceil_kbps)
    avg = quantize_nearest(avg_clamped, gran)

    ratio = maxrate_ratio_permille()
    maxb = round_half_even(avg * ratio, 1000)

    vbv_seconds_milli = 1000 + (timeout % 4000)
    vbv = round_half_even(maxb * vbv_seconds_milli, 1000)

    keyint_seconds = retry
    min_keyint_seconds = max(1, retry - 1)
    gop = round_half_even(fps_num * keyint_seconds, fps_den)
    min_keyint = round_half_even(fps_num * min_keyint_seconds, fps_den)

    base_qp = qp_base()
    qp_lo, qp_hi = qp_floor_ceil()
    offset = qp_band_offset(avg)
    qp = clamp(base_qp - offset, qp_lo, qp_hi)

    la_seconds = lookahead_seconds()
    lookahead = round_half_even(fps_num * la_seconds, fps_den)

    cols = int(_band_row("shard_cols.tsv2", "\t\t", "tier_id", band)["tile_columns"])
    rows = int(_band_row("shard_rows.csv2", ";;", "tier_id", band)["tile_rows"])

    suffix = trailer_suffix()
    trailer = base["trailer"] if suffix == "none" else base["trailer"] + ":" + suffix

    config = {
        "avg_bitrate_kbps": avg,
        "bframes": int(_band_row("batch_frames.scsv", ";", "tier_id", band)["bframes"]),
        "checksum": defaults["checksum"],
        "codec": codec,
        "color_matrix": band_ledger_class(band),
        "color_primaries": band_bucket_class(band),
        "color_transfer": band_review_class(band),
        "container": container_id(),
        "film_grain": int(_band_row("dither_scale.caret", "^", "tier_id", band)["film_grain"]),
        "fps_den": fps_den,
        "fps_num": fps_num,
        "gop_size_frames": gop,
        "height": height,
        "lookahead_frames": lookahead,
        "luma_pixels": luma,
        "max_bitrate_kbps": maxb,
        "min_keyint_frames": min_keyint,
        "mode": mode_id(),
        "pass_count": pass_count(),
        "pixel_format": pixel_format_id(),
        "profile": load_json(data_dir() / "config_schema.json")["profile"],
        "qp": qp,
        "temporal_layers": int(
            _band_row("temporal_layers.tsv3", "\t", "tier_id", band)["temporal_layers"]
        ),
        "threads": band_threads(band),
        "tile_columns": cols,
        "tile_rows": rows,
        "tiles": cols * rows,
        "trailer": trailer,
        "vbv_buffer_kbits": vbv,
        "vmaf_target": int(_band_row("fidelity_target.tilde", "~", "tier_id", band)["vmaf_target"]),
        "width": width,
    }

    expected = canonical_keys()
    if sorted(config) != expected:
        raise SystemExit("derived key set does not match the field registry")
    if sorted(schema_keys(schema)) != expected:
        raise SystemExit("schema key set does not match the field registry")

    derivation = {
        "active_band": band,
        "avg_clamped_kbps": avg_clamped,
        "avg_formula_scale": scale,
        "avg_pre_kbps": avg_pre,
        "band_offset": offset,
        "bpp_milli": bpp_milli,
        "dar_den": dar_den,
        "dar_num": dar_num,
        "eff_permille": eff,
        "granularity_kbps": gran,
        "keyint_seconds": keyint_seconds,
        "lookahead_seconds": la_seconds,
        "max_kbps": ceil_kbps,
        "maxrate_ratio_permille": ratio,
        "min_kbps": floor_kbps,
        "min_keyint_seconds": min_keyint_seconds,
        "qp_base": base_qp,
        "qp_ceil": qp_hi,
        "qp_floor": qp_lo,
        "rounding_policy": policy,
        "selection_rule": "active_band = (max_records // 13) % 7",
        "trailer_suffix": suffix,
        "vbv_seconds_milli": vbv_seconds_milli,
        "width_pre": width_pre,
    }
    return {
        "base": {"max_records": records, "retry_limit": retry, "timeout_ms": timeout},
        "config": config,
        "derivation": derivation,
        "field_sources": dict(FIELD_SOURCES),
        "registry_keys": expected,
        "tier": band,
    }


def solve_profile(schema, name):
    solved = solve(schema)
    config = solved["config"]
    deriv = solved["derivation"]
    overrides = load_json(data_dir() / "env_overrides.json")
    if name not in overrides:
        raise SystemExit("unknown profile: " + name)
    delta = overrides[name]
    ids = profile_ids()
    if name not in ids:
        raise SystemExit("profile %s is not CANONICAL in profile_id_map.kv3" % name)

    scaled = round_half_even(config["avg_bitrate_kbps"] * int(delta["avg_scale_permille"]), 1000)
    avg = quantize_nearest(clamp(scaled, deriv["min_kbps"], deriv["max_kbps"]),
                           deriv["granularity_kbps"])
    maxb = round_half_even(avg * deriv["maxrate_ratio_permille"], 1000)
    window = deriv["vbv_seconds_milli"] + 1000 * int(delta["vbv_delta_seconds"])
    vbv = round_half_even(maxb * window, 1000)
    gop = round_half_even(
        config["fps_num"] * (deriv["keyint_seconds"] + int(delta["gop_delta_seconds"])),
        config["fps_den"],
    )
    qp = clamp(
        deriv["qp_base"] - qp_band_offset(avg) + int(delta["qp_delta"]),
        deriv["qp_floor"],
        deriv["qp_ceil"],
    )
    return {
        "avg_bitrate_kbps": avg,
        "gop_size_frames": gop,
        "max_bitrate_kbps": maxb,
        "profile": config["profile"] + "-" + ids[name],
        "qp": qp,
        "trailer": config["trailer"] + ":" + ids[name],
        "vbv_buffer_kbits": vbv,
    }


# --------------------------------------------------------------------------
# subcommands
# --------------------------------------------------------------------------
def cmd_derive(args):
    solved = solve(load_json(args.schema))
    write_json(args.out, solved)
    if args.config_out:
        write_json(args.config_out, solved["config"])
    print("derived")
    return 0


def cmd_profile(args):
    write_json(args.out, solve_profile(load_json(args.schema), args.name))
    print("profiled")
    return 0


def cmd_init(args):
    schema = load_json(args.schema)
    seed = {}
    for key in schema_keys(schema):
        value = schema.get(key, 0)
        seed[key] = value if not isinstance(value, (dict, list)) else 0
    write_json(args.out, seed)
    print("initialized")
    return 0


def cmd_set(args):
    data = load_json(args.config)
    value = int(args.value) if re.fullmatch(r"-?\d+", args.value) else args.value
    data[args.key] = value
    write_json(args.config, data)
    print("set")
    return 0


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    nested = sorted(k for k, v in data.items() if isinstance(v, (dict, list)))
    if nested:
        sys.stderr.write("configuration must be flat; nested values: " + ",".join(nested) + "\n")
        return 1
    missing = [k for k in schema_keys(schema) if k not in data]
    if missing:
        sys.stderr.write("missing: " + ",".join(missing) + "\n")
        return 1
    print("ok")
    return 0


def cmd_report(args):
    config_bytes = Path(args.config).read_bytes()
    digest = hashlib.sha256(config_bytes).hexdigest()
    if args.digest != digest:
        sys.stderr.write("digest mismatch: %s != %s\n" % (args.digest, digest))
        return 1
    commands = list(load_json(args.commands)) if args.commands else []
    commands.append({"argv": ["task-ctl"] + sys.argv[1:], "returncode": 0, "stdout": "reported\n"})
    if [c for c in commands if c.get("returncode") != 0]:
        sys.stderr.write("transcript contains failed commands\n")
        return 1
    report = {
        "ok": True,
        "tool": "task-ctl",
        "config_path": str(args.config),
        "config_sha256": digest,
        "commands": commands,
        "trailer": json.loads(config_bytes.decode("utf-8"))["trailer"],
    }
    write_json(args.out, report)
    print("reported")
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--config-out", dest="config_out", default=None)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile")
    p.add_argument("--schema", required=True)
    p.add_argument("--name", required=True, choices=["dev", "prod"])
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", default=None)
    p.set_defaults(func=cmd_report)

    args = parser.parse_args(argv)
    if getattr(args, "func", None) is None:
        parser.print_usage(sys.stderr)
        sys.stderr.write("task-ctl: error: a subcommand is required\n")
        return 2
    try:
        return args.func(args)
    except SystemExit:
        raise
    except Exception as exc:  # never surface a traceback to the caller
        sys.stderr.write("task-ctl: error: %s\n" % exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())
