#!/usr/bin/env python3
"""task-ctl - offline household budget-envelope allocation ledger CLI.

Reads the rule corpus in /app/data, or the directory named by the
TASK_CTL_DATA environment variable, and derives the flat allocation-ladder
configuration for the active commitment band of that corpus.

Every derived value comes from the corpus that is read.  Only rows whose
status is CANONICAL are authoritative; DEPRECATED, PHANTOM, ARCHIVE and any
other status is ignored.  All arithmetic uses exact integer round-half-even
(banker's rounding).
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

TOOL = "task-ctl"
CANONICAL = "CANONICAL"
DEFAULT_DATA_DIR = "/app/data"
PROFILE_KEYS = (
    "profile",
    "avg_bitrate_kbps",
    "max_bitrate_kbps",
    "vbv_buffer_kbits",
    "gop_size_frames",
    "qp",
    "trailer",
)
DELTA_KEYS = ("avg_scale_permille", "qp_delta", "gop_delta_seconds", "vbv_delta_seconds")


class ToolError(Exception):
    """Raised for any corpus or usage problem; never escapes as a traceback."""


DATA = Path(os.environ.get("TASK_CTL_DATA") or DEFAULT_DATA_DIR)


# --------------------------------------------------------------------------
# generic helpers
# --------------------------------------------------------------------------

def load_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise ToolError("missing file: %s" % path)
    except json.JSONDecodeError as exc:
        raise ToolError("invalid JSON in %s: %s" % (path, exc))


def write_json(path, data):
    text = json.dumps(data, indent=2, sort_keys=True) + "\n"
    Path(path).write_text(text, encoding="utf-8")


def _read_text(name):
    path = DATA / name
    if not path.is_file():
        raise ToolError("missing rule file: %s" % name)
    return path.read_text(encoding="utf-8", errors="replace")


def _data_lines(name):
    """Corpus lines with blank and comment lines removed."""
    out = []
    for raw in _read_text(name).split("\n"):
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith(";"):
            continue
        out.append(line)
    return out


def _to_int(value, what="value"):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        raise ToolError("non-integer %s: %r" % (what, value))


def _maybe_int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def round_half_even(num, den):
    """Exact integer round-half-even of num/den."""
    num, den = int(num), int(den)
    if den == 0:
        raise ToolError("division by zero")
    negative = (num < 0) != (den < 0)
    a, b = abs(num), abs(den)
    q, r = divmod(a, b)
    if 2 * r > b or (2 * r == b and q % 2 == 1):
        q += 1
    return -q if negative else q


def quantize_nearest(value, step):
    """Nearest multiple of step, ties resolved by round-half-even."""
    if not step:
        raise ToolError("granularity must not be zero")
    return round_half_even(value, step) * step


def _is_canonical(row):
    return isinstance(row, dict) and str(row.get("status", "")).strip().upper() == CANONICAL


def _strip_comment(text):
    for marker in (" ;", " #", "\t;", "\t#"):
        idx = text.find(marker)
        if idx >= 0:
            text = text[:idx]
    return text.strip()


def _table(name, sep):
    """Header-keyed rows of a delimited corpus file; malformed rows are skipped."""
    lines = _data_lines(name)
    if not lines:
        raise ToolError("no rows in %s" % name)
    header = [cell.strip() for cell in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        cells = [cell.strip() for cell in line.split(sep)]
        if len(cells) != len(header):
            continue
        rows.append(dict(zip(header, cells)))
    return rows


def _band_row(rows, band, band_field):
    for row in rows:
        if not _is_canonical(row):
            continue
        if _maybe_int(row.get(band_field)) == band:
            return row
    return None


def _band_table_value(name, sep, field, band, band_field="tier_id"):
    row = _band_row(_table(name, sep), band, band_field)
    if row is None or row.get(field) is None:
        raise ToolError("no canonical %s row for band %s in %s" % (band_field, band, name))
    return _to_int(row.get(field), "%s.%s" % (name, field))


def _json_lines(name):
    out = []
    for line in _data_lines(name):
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def _band_json_value(name, field, band, band_field="tier"):
    for row in _json_lines(name):
        if not isinstance(row, dict) or not _is_canonical(row):
            continue
        if _maybe_int(row.get(band_field)) == band and row.get(field) is not None:
            return _to_int(row.get(field), "%s.%s" % (name, field))
    raise ToolError("no canonical %s row for band %s in %s" % (band_field, band, name))


def _ini_sections(name):
    sections = {}
    current = None
    for line in _data_lines(name):
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if current is None or "=" not in line:
            continue
        key, _, value = line.partition("=")
        sections[current][key.strip()] = _strip_comment(value)
    return sections


def _toml_sections(name):
    sections = {}
    current = None
    for line in _data_lines(name):
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].strip()
            sections.setdefault(current, {})
            continue
        if current is None or "=" not in line:
            continue
        key, _, value = line.partition("=")
        value = _strip_comment(value)
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        sections[current][key.strip()] = value
    return sections


def _env_pairs(name):
    pairs = {}
    for line in _data_lines(name):
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        pairs[key.strip()] = _strip_comment(value)
    return pairs


def _pipe_status_value(raw):
    """'value|status=STATUS|slot=N' -> (value, STATUS)."""
    parts = [p.strip() for p in raw.split("|")]
    status = None
    for part in parts[1:]:
        if part.lower().startswith("status="):
            status = part.split("=", 1)[1].strip().upper()
    return parts[0], status


def _colon_status_value(raw):
    """'value::STATUS' -> (value, STATUS)."""
    parts = [p.strip() for p in raw.split("::")]
    return parts[0], (parts[1].strip().upper() if len(parts) > 1 else None)


def _canonical_status_value(name, key, splitter):
    """Value of `key` whose inline status marker is CANONICAL."""
    for line in _data_lines(name):
        if "=" not in line:
            continue
        found, _, raw = line.partition("=")
        if found.strip() != key:
            continue
        value, status = splitter(_strip_comment(raw))
        if status == CANONICAL:
            return value
    raise ToolError("no canonical %s row in %s" % (key, name))


def _canonical_colon_value(name, key):
    """Value of a 'KEY::value::STATUS' row whose status is CANONICAL."""
    for line in _data_lines(name):
        cells = [c.strip() for c in line.split("::")]
        if len(cells) < 3 or cells[0] != key:
            continue
        if cells[-1].upper() == CANONICAL:
            return cells[1]
    raise ToolError("no canonical %s row in %s" % (key, name))


def _canonical_pipe_row(name, first_cell):
    """'first_cell|value|STATUS' rows -> value of the CANONICAL row."""
    for line in _data_lines(name):
        cells = [c.strip() for c in line.split("|")]
        if len(cells) < 3 or cells[0] != first_cell:
            continue
        if cells[-1].upper() == CANONICAL:
            return cells[1]
    raise ToolError("no canonical %s row in %s" % (first_cell, name))


def _canonical_b64_row(name):
    """Base64 rows decoding to 'value|STATUS' -> value of the CANONICAL row."""
    for line in _data_lines(name):
        try:
            decoded = base64.b64decode(line, validate=True).decode("utf-8")
        except Exception:
            continue
        cells = [c.strip() for c in decoded.split("|")]
        if len(cells) >= 2 and cells[-1].upper() == CANONICAL:
            return cells[0]
    raise ToolError("no canonical row in %s" % name)


def _canonical_tagged(name, tag):
    """'tag value STATUS' rows -> value of the CANONICAL row."""
    for line in _data_lines(name):
        parts = line.split()
        if len(parts) >= 3 and parts[0] == tag and parts[-1].upper() == CANONICAL:
            return parts[1]
    raise ToolError("no canonical %s row in %s" % (tag, name))


# --------------------------------------------------------------------------
# corpus readers
# --------------------------------------------------------------------------

def _base_config():
    data = load_json(DATA / "defaults.json")
    base = data.get("base_config")
    if not isinstance(base, dict):
        raise ToolError("defaults.json has no base_config object")
    return data, base


def _selection_rule():
    """(divisor, modulus) of the active band rule documented in the corpus."""
    divisor, modulus = 13, 7
    for line in _data_lines("selection_rule.txt2"):
        if not line.startswith("rule:"):
            continue
        if "DEPRECATED" in line.upper():
            continue
        m = re.search(r"max_records\s*//\s*(\d+)\s*\)?\s*%\s*(\d+)", line)
        if m:
            divisor, modulus = int(m.group(1)), int(m.group(2))
    return divisor, modulus


def _active_band(max_records):
    divisor, modulus = _selection_rule()
    return (max_records // divisor) % modulus


def _schema_keys(schema):
    raw = schema.get("required_keys", [])
    if isinstance(raw, str):
        return [k.strip() for k in raw.split(",") if k.strip()]
    if isinstance(raw, list):
        return [str(k).strip() for k in raw if str(k).strip()]
    raise ToolError("schema has no usable required_keys")


def _registry_keys(schema):
    """Canonical in_config keys of the corpus registry, else the schema keys."""
    keys = []
    for row in _json_lines("field_registry.ndjson3"):
        if not isinstance(row, dict):
            continue
        if str(row.get("in_config", "")).lower() != "true":
            continue
        if str(row.get("status", "")).strip().upper() != CANONICAL:
            continue
        key = row.get("key")
        if isinstance(key, str) and key not in keys:
            keys.append(key)
    if keys:
        return sorted(keys)
    return sorted(_schema_keys(schema))


def _selected_codec():
    try:
        root = ET.fromstring(_read_text("kernel_selector.xml"))
    except ET.ParseError as exc:
        raise ToolError("invalid kernel_selector.xml: %s" % exc)
    for element in root.iter("codec"):
        if str(element.get("selected", "")).strip().lower() == "true":
            codec = (element.get("id") or element.text or "").strip()
            if codec:
                return codec
    raise ToolError("kernel_selector.xml has no selected codec")


def _eff_permille(codec):
    for line in _data_lines("eff_permille.conf"):
        parts = line.split()
        if len(parts) < 6 or parts[0] != "codec" or parts[2] != "efficiency_permille":
            continue
        if parts[1] != codec or parts[-1].upper() != CANONICAL:
            continue
        return _to_int(parts[3], "eff_permille.conf")
    raise ToolError("no canonical efficiency row for codec %s" % codec)


def _band_color_matrix(band):
    try:
        root = ET.fromstring(_read_text("color_matrix.html"))
    except ET.ParseError as exc:
        raise ToolError("invalid color_matrix.html: %s" % exc)
    for tr in root.iter("tr"):
        if str(tr.get("class", "")).strip().upper() != CANONICAL:
            continue
        cells = [(td.text or "").strip() for td in tr.iter("td")]
        if len(cells) >= 2 and _maybe_int(cells[0]) == band:
            return cells[1]
    raise ToolError("no canonical color_matrix row for band %s" % band)


def _band_color_primaries(band):
    for line in _data_lines("color_primaries.rst"):
        m = re.match(r"^:band-(\d+):\s*(\S+)\s+status=(\S+)", line)
        if not m or _maybe_int(m.group(1)) != band:
            continue
        if m.group(3).strip().upper() == CANONICAL:
            return m.group(2)
    raise ToolError("no canonical color_primaries row for band %s" % band)


def _band_color_transfer(band):
    for line in _data_lines("color_transfer.sexp"):
        m = re.match(r"^\(review\s+\(band\s+(\d+)\)\s+\(class\s+(\S+)\)\s+\(status\s+(\S+)\)\)", line)
        if not m or _maybe_int(m.group(1)) != band:
            continue
        if m.group(3).strip().upper() == CANONICAL:
            return m.group(2)
    raise ToolError("no canonical color_transfer row for band %s" % band)


def _band_width_even(band):
    text = _read_text("width_even.html2")
    for m in re.finditer(r"<w\s+band=\"(\d+)\"\s+even=\"(\w+)\"\s+status=\"(\w+)\"\s*/>", text):
        if _maybe_int(m.group(1)) != band:
            continue
        if m.group(3).strip().upper() != CANONICAL:
            continue
        return m.group(2).strip().lower() == "true"
    return False


def _min_kbps(band):
    sections = _ini_sections("min_kbps.ini")
    section = sections.get("tier.%d" % band)
    if not section or section.get("status", "").upper() != CANONICAL:
        raise ToolError("no canonical min_kbps row for band %s" % band)
    return _to_int(section.get("min_kbps"), "min_kbps.ini")


def _max_kbps(band):
    pairs = _env_pairs("max_kbps.properties")
    if pairs.get("tier.%d.status" % band, "").upper() != CANONICAL:
        raise ToolError("no canonical max_kbps row for band %s" % band)
    return _to_int(pairs.get("tier.%d.max_kbps" % band), "max_kbps.properties")


def _ratio_permille():
    sections = _toml_sections("maxrate_ratio.toml")
    active = sections.get("active")
    if not active or active.get("status", "").upper() != CANONICAL:
        raise ToolError("no canonical maxrate_ratio.toml [active] section")
    return _to_int(active.get("ratio_permille"), "maxrate_ratio.toml")


def _granularity_kbps():
    value = _canonical_status_value("granularity.kv", "granularity_kbps", _pipe_status_value)
    return _to_int(value, "granularity.kv")


def _bpp_milli(band):
    pairs = _env_pairs("bpp.env")
    if pairs.get("BPP_TIER_%d_STATUS" % band, "").upper() != CANONICAL:
        raise ToolError("no canonical bpp_milli row for band %s" % band)
    return _to_int(pairs.get("BPP_TIER_%d" % band), "bpp.env")


def _lookahead_seconds():
    value = _canonical_colon_value("lookahead_seconds.conf2", "lookahead_seconds")
    return _to_int(value, "lookahead_seconds.conf2")


def _pass_count():
    value = _canonical_colon_value("pass_count.env2", "PASS_COUNT")
    return _to_int(value, "pass_count.env2")


def _qp_bounds():
    text = _read_text("qp_floor_ceil.edn")
    floor = ceil = None
    for m in re.finditer(r"\(\s*(qp_floor|qp_ceil)\s+(\d+)\s+(\S+)\s*\)", text):
        if m.group(3).strip().upper() != CANONICAL:
            continue
        if m.group(1) == "qp_floor":
            floor = _to_int(m.group(2))
        else:
            ceil = _to_int(m.group(2))
    if floor is None or ceil is None:
        raise ToolError("qp_floor_ceil.edn has no canonical bounds")
    return floor, ceil


def _staircase():
    """Canonical (threshold, band_offset) pairs of the priority staircase."""
    steps = []
    for row in _table("qp_stair.psv", "|"):
        if not _is_canonical(row):
            continue
        threshold = _maybe_int(row.get("threshold_kbps"))
        offset = _maybe_int(row.get("band_offset"))
        if threshold is None or offset is None:
            continue
        steps.append((threshold, offset))
    if not steps:
        raise ToolError("qp_stair.psv has no canonical rows")
    return steps


def _band_offset(avg_kbps, steps):
    """band_offset of the largest canonical threshold not exceeding avg_kbps."""
    offset = 0
    for threshold, value in sorted(steps):
        if threshold <= avg_kbps:
            offset = value
    return offset


def _trailer_suffix():
    value = _canonical_colon_value("trailer_suffix.txt3", "trailer_suffix")
    if value.lower() in ("", "none"):
        return ""
    return value


def _threads(band):
    for line in _data_lines("threads.fixed"):
        if len(line) < 11:
            continue
        if _maybe_int(line[0:4]) != band:
            continue
        if line[10:].strip().upper() != CANONICAL:
            continue
        return _to_int(line[4:10], "threads.fixed")
    raise ToolError("no canonical threads row for band %s" % band)


def _identity_values(schema):
    """Identity strings read from the corpus, with the passed schema as fallback."""
    corpus_schema = {}
    schema_path = DATA / "config_schema.json"
    if schema_path.is_file():
        corpus_schema = load_json(schema_path)
    defaults, _base = _base_config()
    return {
        "profile": corpus_schema.get("profile") or schema.get("profile") or "",
        "codec": _selected_codec(),
        "container": _canonical_pipe_row("container.pipe", "container"),
        "mode": _canonical_status_value("mode.hex", "mode", _pipe_status_value),
        "pixel_format": _canonical_b64_row("pixel_format.b64"),
        "checksum": corpus_schema.get("checksum") or defaults.get("checksum") or schema.get("checksum") or "",
    }


# --------------------------------------------------------------------------
# derivation
# --------------------------------------------------------------------------

def derive_context(schema):
    """Every documented value of the corpus, plus the flat config fields."""
    defaults, base = _base_config()
    max_records = _to_int(base.get("max_records"), "max_records")
    retry_limit = _to_int(base.get("retry_limit"), "retry_limit")
    timeout_ms = _to_int(base.get("timeout_ms"), "timeout_ms")
    trailer = str(base.get("trailer", "")) + _trailer_suffix()
    band = _active_band(max_records)

    fps_num = _band_json_value("fps_num.ndjson", "fps_num", band)
    fps_den = _band_json_value("fps_den.jsonl", "fps_den", band)
    height = _band_table_value("precision_ladder.tsv", "\t", "height", band)
    dar_row = _band_row(_table("aspect_table.csv", ","), band, "tier_id")
    if dar_row is None:
        raise ToolError("no canonical aspect_table row for band %s" % band)
    dar_num = _to_int(dar_row.get("dar_num"), "aspect_table.csv")
    dar_den = _to_int(dar_row.get("dar_den"), "aspect_table.csv")
    width = round_half_even(height * dar_num, dar_den)
    if _band_width_even(band) and width % 2:
        width -= 1
    luma = width * height

    codec = _selected_codec()
    bpp_milli = _bpp_milli(band)
    eff_permille = _eff_permille(codec)
    granularity = _granularity_kbps()
    min_kbps = _min_kbps(band)
    max_kbps = _max_kbps(band)
    avg_pre = round_half_even(luma * bpp_milli * eff_permille * fps_num, 1000000000 * fps_den)
    avg = quantize_nearest(max(min_kbps, min(max_kbps, avg_pre)), granularity)

    ratio = _ratio_permille()
    max_bitrate = round_half_even(avg * ratio, 1000)
    vbv_seconds_milli = _band_json_value("vbv_window_map.ndjson2", "vbv_seconds_milli", band, "band")
    vbv = round_half_even(max_bitrate * vbv_seconds_milli, 1000)

    gop = round_half_even(fps_num * retry_limit, fps_den)
    min_keyint = _band_json_value("gop_keyint_map.jsonl2", "keyint", band, "band")
    lookahead = round_half_even(fps_num * _lookahead_seconds(), fps_den)

    qp_base = _to_int(_canonical_tagged("qp_base.txt", "qp_base"), "qp_base.txt")
    qp_floor, qp_ceil = _qp_bounds()
    staircase = _staircase()
    band_offset = _band_offset(avg, staircase)
    qp = max(qp_floor, min(qp_ceil, qp_base - band_offset))

    identity = _identity_values(schema)
    tile_columns = _band_table_value("shard_cols.tsv2", "\t\t", "tile_columns", band)
    tile_rows = _band_table_value("shard_rows.csv2", ";;", "tile_rows", band)

    config = {
        "avg_bitrate_kbps": avg,
        "bframes": _band_table_value("batch_frames.scsv", ";", "bframes", band),
        "checksum": identity["checksum"],
        "codec": identity["codec"],
        "color_matrix": _band_color_matrix(band),
        "color_primaries": _band_color_primaries(band),
        "color_transfer": _band_color_transfer(band),
        "container": identity["container"],
        "film_grain": _band_table_value("dither_scale.caret", "^", "film_grain", band),
        "fps_den": fps_den,
        "fps_num": fps_num,
        "gop_size_frames": gop,
        "height": height,
        "lookahead_frames": lookahead,
        "luma_pixels": luma,
        "max_bitrate_kbps": max_bitrate,
        "min_keyint_frames": min_keyint,
        "mode": identity["mode"],
        "pass_count": _pass_count(),
        "pixel_format": identity["pixel_format"],
        "profile": identity["profile"],
        "qp": qp,
        "temporal_layers": _band_table_value("temporal_layers.tsv3", "\t", "temporal_layers", band),
        "threads": _threads(band),
        "tile_columns": tile_columns,
        "tile_rows": tile_rows,
        "tiles": tile_columns * tile_rows,
        "trailer": trailer,
        "vbv_buffer_kbits": vbv,
        "vmaf_target": _band_table_value("fidelity_target.tilde", "~", "vmaf_target", band),
        "width": width,
    }
    context = {
        "band": band,
        "max_records": max_records,
        "retry_limit": retry_limit,
        "timeout_ms": timeout_ms,
        "granularity_kbps": granularity,
        "min_kbps": min_kbps,
        "max_kbps": max_kbps,
        "ratio_permille": ratio,
        "eff_permille": eff_permille,
        "bpp_milli": bpp_milli,
        "vbv_seconds_milli": vbv_seconds_milli,
        "qp_base": qp_base,
        "qp_floor": qp_floor,
        "qp_ceil": qp_ceil,
        "band_offset": band_offset,
        "avg_pre": avg_pre,
        "fps_num": fps_num,
        "fps_den": fps_den,
        "width": width,
        "height": height,
        "luma_pixels": luma,
        "staircase": staircase,
        "trailer_suffix": _trailer_suffix(),
        "required_keys": _registry_keys(schema),
    }
    return config, context


def derive_config(schema):
    """The flat configuration restricted to the corpus registry's canonical keys."""
    config, context = derive_context(schema)
    keys = context["required_keys"]
    missing = [key for key in keys if key not in config]
    if missing:
        raise ToolError("registry keys without a derived value: %s" % ",".join(missing))
    return {key: config[key] for key in keys}


def profile_config(schema, name):
    config = derive_config(schema)
    overrides = load_json(DATA / "env_overrides.json")
    if not isinstance(overrides, dict) or name not in overrides:
        raise ToolError("unknown profile: %s" % name)
    deltas = overrides[name]
    if not isinstance(deltas, dict):
        raise ToolError("env_overrides.json has no object for %s" % name)
    for key in DELTA_KEYS:
        if key not in deltas:
            raise ToolError("env_overrides.json is missing %s.%s" % (name, key))
    _, context = derive_context(schema)

    # documented order: average scale (before granularity), priority, cycle span, reserve
    scaled = round_half_even(config["avg_bitrate_kbps"] * _to_int(deltas["avg_scale_permille"]), 1000)
    avg = quantize_nearest(scaled, context["granularity_kbps"])
    max_bitrate = round_half_even(avg * context["ratio_permille"], 1000)
    vbv_seconds = context["vbv_seconds_milli"] + 1000 * _to_int(deltas["vbv_delta_seconds"])
    vbv = round_half_even(max_bitrate * vbv_seconds, 1000)
    gop = config["gop_size_frames"] + round_half_even(
        context["fps_num"] * _to_int(deltas["gop_delta_seconds"]), context["fps_den"])
    qp = max(context["qp_floor"], min(context["qp_ceil"], config["qp"] + _to_int(deltas["qp_delta"])))
    profile = {
        "profile": "%s-%s" % (config["profile"], name),
        "avg_bitrate_kbps": avg,
        "max_bitrate_kbps": max_bitrate,
        "vbv_buffer_kbits": vbv,
        "gop_size_frames": gop,
        "qp": qp,
        "trailer": "%s:%s" % (config["trailer"], name),
    }
    return {key: profile[key] for key in PROFILE_KEYS}


# --------------------------------------------------------------------------
# subcommands
# --------------------------------------------------------------------------

def _coerce(value):
    text = str(value).strip()
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    return text


def cmd_derive(args):
    schema = load_json(args.schema)
    write_json(args.out, {"config": derive_config(schema)})
    print("derived")


def cmd_profile(args):
    schema = load_json(args.schema)
    write_json(args.out, profile_config(schema, args.name))
    print("profiled")


def cmd_init(args):
    schema = load_json(args.schema)
    seeded = {}
    for key in _schema_keys(schema):
        if isinstance(schema.get(key), (str, int)) and not isinstance(schema.get(key), bool):
            seeded[key] = schema[key]
    if not seeded:
        raise ToolError("schema.json carries no seedable config keys")
    write_json(args.out, seeded)
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    if not isinstance(data, dict):
        raise ToolError("config is not a JSON object: %s" % args.config)
    data[args.key.strip().lower()] = _coerce(args.value)
    write_json(args.config, data)
    print("set")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    if not isinstance(data, dict):
        raise SystemExit("configuration must be flat: not a JSON object")
    nested = [key for key, value in data.items() if isinstance(value, (dict, list))]
    if nested:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(nested)))
    missing = [key for key in _schema_keys(schema) if key not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    if not isinstance(data, dict):
        raise ToolError("config is not a JSON object: %s" % args.config)
    algorithm = (args.digest or "sha256").strip().lower()
    if algorithm != "sha256":
        raise ToolError("unsupported digest algorithm: %s" % algorithm)
    commands = load_json(args.commands)
    if not isinstance(commands, list):
        raise ToolError("commands file must hold a JSON list: %s" % args.commands)
    transcript = []
    for record in commands:
        if not isinstance(record, dict):
            raise ToolError("command record must be an object")
        argv = record.get("argv")
        if not isinstance(argv, list) or not all(isinstance(a, str) for a in argv):
            raise ToolError("command record argv must be a list of strings")
        transcript.append({
            "argv": [str(a) for a in argv],
            "returncode": _to_int(record.get("returncode", 0), "returncode"),
            "stdout": str(record.get("stdout", "")),
        })
    if len(transcript) < 6:
        raise ToolError("command transcript needs at least six records")
    payload = Path(args.config).read_bytes()
    report = {
        "ok": all(record["returncode"] == 0 for record in transcript)
        and not any(isinstance(value, (dict, list)) for value in data.values()),
        "tool": TOOL,
        "config_path": str(args.config),
        "config_sha256": hashlib.sha256(payload).hexdigest(),
        "commands": transcript,
        "trailer": str(data.get("trailer", "")),
    }
    write_json(args.out, report)
    print("reported")


# --------------------------------------------------------------------------
# entry point
# --------------------------------------------------------------------------

def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL, description="offline budget-envelope allocation ledger")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("derive", help="derive the flat allocation config")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_derive)

    p = sub.add_parser("profile", help="derive a deployment profile")
    p.add_argument("--schema", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("init", help="seed a flat config from a schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="set one scalar config key")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="check a flat config against a schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("export-report", help="emit the command transcript and config digest")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", default="sha256")
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    func = getattr(args, "func", None)
    if func is None:
        sys.stderr.write("%s: a subcommand is required\n" % TOOL)
        parser.print_usage(sys.stderr)
        return 2
    try:
        func(args)
    except ToolError as exc:
        sys.stderr.write("%s: %s\n" % (TOOL, exc))
        return 1
    except SystemExit as exc:
        code = exc.code
        if isinstance(code, str):
            sys.stderr.write("%s: %s\n" % (TOOL, code))
            return 1
        return int(code or 0)
    except (OSError, ValueError) as exc:
        sys.stderr.write("%s: %s\n" % (TOOL, exc))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
