#!/usr/bin/env python3
"""Faulty task-ctl budget-envelope allocation CLI (must be repaired)."""
from __future__ import annotations

import argparse
import base64
import json
import math
import xml.etree.ElementTree as ET
from pathlib import Path

DATA = Path("/app/data")


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).write_text(json.dumps(data), encoding="utf-8")


def _read_lines(name):
    out = []
    for line in (DATA / name).read_text(encoding="utf-8", errors="replace").split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";"):
            continue
        out.append(line)
    return out


def _delimited_rows(name, sep):
    lines = _read_lines(name)
    header = [c.strip() for c in lines[0].split(sep)]
    rows = []
    for line in lines[1:]:
        parts = [c.strip() for c in line.split(sep)]
        if len(parts) == len(header):
            rows.append(dict(zip(header, parts)))
    return rows


def round_half_up(num, den):
    return int(math.floor(num / den + 0.5))


def quantize_floor(value, step):
    return (value // step) * step


def base_inputs():
    cfg = load_json(DATA / "defaults.json")["base_config"]
    return cfg["max_records"], cfg["retry_limit"], cfg["timeout_ms"], cfg["trailer"]


def first_row_value(rows, field):
    return rows[0][field]


def cmd_derive(args):
    B, R, T, trailer = base_inputs()
    prow = _delimited_rows("precision_ladder.tsv", "\t")
    height = int(first_row_value(prow, "height"))
    arow = _delimited_rows("aspect_table.csv", ",")
    dar_num = int(first_row_value(arow, "dar_num"))
    dar_den = int(first_row_value(arow, "dar_den"))
    width = round_half_up(height * dar_num, dar_den)
    luma = width * height
    fps_num = 7000
    fps_den = 1001
    bpp_milli = 244
    eff_permille = 6000
    avg_pre = round_half_up(luma * bpp_milli * eff_permille * fps_num, 1000000000 * fps_den)
    min_kbps = 300
    max_kbps = 5200
    avg = quantize_floor(max(min_kbps, min(max_kbps, avg_pre)), 50)
    maxb = round_half_up(avg * 1450, 1000)
    vbv_seconds_milli = 1000 + (T % 4000)
    vbv = round_half_up(avg * vbv_seconds_milli, 1000)
    gop = int(math.ceil(fps_num * R / fps_den))
    min_keyint = int(math.ceil(fps_num * max(1, R - 1) / fps_den))
    qp = int(max(10, min(63, round(63 - 4 * math.log2(max(1, avg) / 1000 + 1)))))
    ladder = {
        "avg_bitrate_kbps": avg, "max_bitrate_kbps": maxb, "vbv_buffer_kbits": vbv,
        "gop_size_frames": gop, "min_keyint_frames": min_keyint, "qp": qp,
        "width": width, "height": height, "luma_pixels": luma,
    }
    config = {"ladder": ladder, "profile": "TASK", "trailer": trailer}
    write_json(args.out, config)
    print("derived")


def cmd_profile(args):
    B, R, T, trailer = base_inputs()
    data = load_json(args.config)
    avg = data.get("ladder", {}).get("avg_bitrate_kbps", 0)
    scale = 600 if args.name == "dev" else 1150
    avg_scaled = quantize_floor(round_half_up(avg * scale, 1000), 50)
    out = {"profile": "TASK-" + args.name, "avg_bitrate_kbps": avg_scaled}
    write_json(args.out, out)
    print("profiled")


def cmd_init(args):
    schema = load_json(args.schema)
    data = {"profile": schema["profile"], "checksum": schema["checksum"], "mode": "strict-envelope"}
    write_json(args.out, data)
    print("initialized")


def cmd_set(args):
    data = load_json(args.config)
    data[args.key.upper()] = args.value
    write_json(args.config, data)
    print("set")


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    bad = [k for k, v in data.items() if isinstance(v, (dict, list))]
    if bad:
        raise SystemExit("configuration must be flat: " + ",".join(sorted(bad)))
    required = [k for k in schema["required_keys"].split(",") if k]
    missing = [k for k in required if k not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    print("ok")


def cmd_report(args):
    data = load_json(args.config)
    report = {"ok": True, "config": data, "commands": "unknown"}
    write_json(args.out, report)
    print("reported")


def main():
    parser = argparse.ArgumentParser(prog="task-ctl")
    sub = parser.add_subparsers(dest="command")
    p = sub.add_parser("derive"); p.add_argument("--out", required=True); p.set_defaults(func=cmd_derive)
    p = sub.add_parser("profile"); p.add_argument("--config", required=True); p.add_argument("--name", required=True); p.add_argument("--out", required=True); p.set_defaults(func=cmd_profile)
    p = sub.add_parser("init"); p.add_argument("--schema", required=True); p.add_argument("--out", required=True); p.set_defaults(func=cmd_init)
    p = sub.add_parser("set"); p.add_argument("--config", required=True); p.add_argument("--key", required=True); p.add_argument("--value", required=True); p.set_defaults(func=cmd_set)
    p = sub.add_parser("validate"); p.add_argument("--schema", required=True); p.add_argument("--config", required=True); p.set_defaults(func=cmd_validate)
    p = sub.add_parser("export-report"); p.add_argument("--config", required=True); p.add_argument("--out", required=True); p.set_defaults(func=cmd_report)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
