# task-ctl

A small offline CLI for deriving a single household budget-envelope allocation
config from the local data files. The shipped copy is faulty and must be
repaired in place before use.

## Rule files

The tool reads its rule files from `/app/data`. When the environment variable
`TASK_CTL_DATA` is set, it reads them from that directory instead; the files
there follow exactly the same names and layouts.

## Expected repaired commands

- `derive --schema <schema.json> --out <path>`: computes the allocation config
  for the active commitment band and writes a JSON object whose `config` member
  is the flat 31-key configuration.
- `profile --schema <schema.json> --name dev|prod --out <path>`: writes the flat
  deployment profile object for the named profile.
- `init --schema --out`: seed a flat config from `schema.json`.
- `set --config --key --value`: set one scalar key (values coerced).
- `validate --schema --config`: check every required key is present and the
  config is flat. On success it prints `ok` and exits 0; a nested config makes
  it exit non-zero with a message that says the configuration must be flat.
- `export-report --config --out --digest --commands`: emit a truthful command
  transcript with the config digest.

Invoked with no subcommand at all, the tool prints a usage error and exits
non-zero; it never ends in a Python traceback.

## Contract notes

- Every derived number uses exact integer round-half-even (banker's rounding).
- The config must be a flat scalar-only JSON object (no nested containers).
- The authoritative required keys live in `schema.json` and are mirrored by the
  field registry data file.
