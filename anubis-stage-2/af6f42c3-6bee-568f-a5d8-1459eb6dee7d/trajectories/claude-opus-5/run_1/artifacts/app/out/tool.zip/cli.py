#!/usr/bin/env python3
"""sealb-ctl: offline, standard-library-only security policy compiler."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

TOOL_NAME = "sealb-ctl"

INT_KEYS = (
    "handshake_timeout_ms",
    "max_sessions",
    "rekey_interval_s",
    "retry_budget",
)
SPINE_KEYS = INT_KEYS + ("mode",)

JSON_ARTIFACTS = (
    "aggregates.json",
    "config.json",
    "corpus_index.json",
    "posture.json",
    "profile_core.json",
    "profile_dmz.json",
    "profile_edge.json",
    "profile_mgmt.json",
    "rejected_ops.json",
    "summary.json",
    "validation_report.json",
    "zone_totals.json",
)
VIEW_ARTIFACTS = (
    "aggregates.csv",
    "aggregates.env",
    "aggregates.ini",
    "aggregates.md",
    "aggregates.tsv",
    "aggregates.txt",
    "aggregates.xml",
)
EXTRA_ARTIFACTS = ("manifest.sha256", "report.json", "tool.zip")
MANIFEST_ARTIFACTS = tuple(sorted(JSON_ARTIFACTS + VIEW_ARTIFACTS))
ALL_ARTIFACTS = tuple(sorted(MANIFEST_ARTIFACTS + EXTRA_ARTIFACTS))

ACTIVE_FLAG = "active"
CORPUS_ROW_RE = re.compile(
    r"^\|\s*(c\d+_[A-Za-z0-9_]+\.[A-Za-z0-9]+)\s*\|\s*([a-z]+)\s*\|"
    r"\s*([a-z]+)\s*\|\s*(-?\d+)\s*\|\s*(-?\d+)\s*\|\s*$"
)


# --------------------------------------------------------------------------
# serialization helpers
# --------------------------------------------------------------------------
def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dump_json(data):
    return (
        json.dumps(
            data,
            sort_keys=True,
            indent=2,
            separators=(",", ": "),
            ensure_ascii=False,
        )
        + "\n"
    )


def write_json(path, data):
    Path(path).write_text(dump_json(data), encoding="utf-8")


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def coerce_scalar(text):
    """Turn a canonical base-10 integer literal into an int, keep anything else."""
    try:
        number = int(text)
    except ValueError:
        return text
    return number if str(number) == text else text


def is_flat(config):
    return all(not isinstance(value, (dict, list)) for value in config.values())


# --------------------------------------------------------------------------
# spine / profile derivation
# --------------------------------------------------------------------------
def data_inputs(data_dir):
    data_dir = Path(data_dir)
    return {
        "schema": load_json(data_dir / "config_schema.json"),
        "defaults": load_json(data_dir / "defaults.json"),
        "rules": load_json(data_dir / "validation_rules.json"),
        "overrides": load_json(data_dir / "env_overrides.json"),
    }


def journal_ops(data_dir):
    path = Path(data_dir) / "change_journal.jsonl"
    ops = []
    for line in path.read_text(encoding="utf-8").split("\n"):
        if not line.strip():
            continue
        ops.append(json.loads(line))
    ops.sort(key=lambda op: op["seq"])
    return ops


def op_is_valid(op, rules):
    if op.get("env") not in rules["journal_envs"]:
        return False
    key = op.get("key")
    if key not in SPINE_KEYS:
        return False
    kind = op.get("op")
    if kind == "unset":
        return True
    if kind != "set":
        return False
    value = op.get("value")
    if key == "mode":
        return isinstance(value, str) and value in rules["allowed_modes"]
    if isinstance(value, bool) or not isinstance(value, int):
        return False
    low, high = rules["bounds"][key]
    return low <= value <= high


def classify_journal(data_dir, rules):
    valid, rejected = [], []
    for op in journal_ops(data_dir):
        (valid if op_is_valid(op, rules) else rejected).append(op)
    return valid, [op["seq"] for op in rejected]


def default_value(key, defaults):
    if key == "mode":
        return defaults["mode"]
    return defaults["base_config"][key]


def apply_op(config, op, defaults):
    key = op["key"]
    if op["op"] == "set":
        config[key] = op["value"]
    else:
        config[key] = default_value(key, defaults)


def base_spine(inputs):
    schema, defaults = inputs["schema"], inputs["defaults"]
    config = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": defaults["checksum"],
        "mode": defaults["mode"],
    }
    config.update(defaults["base_config"])
    return config


def build_spine(inputs, valid_ops):
    config = base_spine(inputs)
    for op in valid_ops:
        apply_op(config, op, inputs["defaults"])
    return config


def build_profile(spine, zone, inputs, valid_ops):
    config = dict(spine)
    override = inputs["overrides"][zone]
    for key in ("retry_budget", "handshake_timeout_ms", "rekey_interval_s"):
        config[key] = config[key] + override[key + "_delta"]
    config["mode"] = override["mode"]
    config["profile"] = "{}-{}".format(spine["profile"], zone)
    config["trailer"] = "{}:{}".format(spine["trailer"], zone)
    for op in valid_ops:
        if op["env"] == zone:
            apply_op(config, op, inputs["defaults"])
    return config


def resolve_policy(data_dir, env):
    inputs = data_inputs(data_dir)
    valid_ops, _ = classify_journal(data_dir, inputs["rules"])
    spine = build_spine(inputs, valid_ops)
    if env == "base":
        return spine
    if env not in inputs["rules"]["zones"]:
        raise SystemExit("unknown env: " + env)
    return build_profile(spine, env, inputs, valid_ops)


# --------------------------------------------------------------------------
# corpora
# --------------------------------------------------------------------------
def canonical_int(raw):
    """Return the integer of a canonical base-10 value, else None."""
    if isinstance(raw, bool):
        return None
    if isinstance(raw, int):
        return raw
    if not isinstance(raw, str):
        return None
    try:
        number = int(raw)
    except (ValueError, TypeError):
        return None
    return number if str(number) == raw else None


def content_lines(text):
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        yield line


def _split_rows(text, sep):
    rows = []
    for line in content_lines(text):
        fields = line.split(sep)
        if len(fields) != 3:
            continue
        rows.append(tuple(fields))
    return rows


def _rows_ssv(text):
    rows = []
    for line in content_lines(text):
        fields = re.split(r" +", line)
        if len(fields) != 3:
            continue
        rows.append(tuple(fields))
    return rows


def _json_row(item):
    if not isinstance(item, dict):
        return None
    if not all(key in item for key in ("zone", "value", "flag")):
        return None
    return (item["zone"], item["value"], item["flag"])


def _rows_jsonarr(text):
    rows = []
    for item in json.loads(text):
        row = _json_row(item)
        if row is not None:
            rows.append(row)
    return rows


def _rows_jsonl(text):
    rows = []
    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped or stripped.startswith("//"):
            continue
        row = _json_row(json.loads(stripped))
        if row is not None:
            rows.append(row)
    return rows


def _rows_xmlflat(text):
    rows = []
    for row in ET.fromstring(text).findall("row"):
        attrib = row.attrib
        if not all(key in attrib for key in ("zone", "value", "flag")):
            continue
        rows.append((attrib["zone"], attrib["value"], attrib["flag"]))
    return rows


def _rows_xmlnest(text):
    rows = []
    for row in ET.fromstring(text).findall("row"):
        children = list(row)
        if [child.tag for child in children] != ["zone", "value", "flag"]:
            continue
        rows.append(tuple(child.text or "" for child in children))
    return rows


def _collect_records(order, records):
    rows = []
    for row_id in order:
        record = records.get(row_id, {})
        if len(record) != 3:
            continue
        rows.append((record["zone"], record["value"], record["flag"]))
    return rows


def _rows_ini(text):
    sections, order = {}, []
    current = None
    for line in content_lines(text):
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            current = stripped[1:-1]
            sections.setdefault(current, {})
            order.append(current)
            continue
        if current is None or "=" not in line:
            continue
        key, _, value = line.partition("=")
        if value.startswith(" "):
            value = value[1:]
        key = key.strip()
        if key in ("zone", "value", "flag"):
            sections[current][key] = value
    return _collect_records(order, sections)


def _rows_props(text):
    records, order = {}, []
    for line in content_lines(text):
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        row_id, _, field = key.partition(".")
        if field not in ("zone", "value", "flag"):
            continue
        if row_id not in records:
            records[row_id] = {}
            order.append(row_id)
        records[row_id][field] = value
    return _collect_records(order, records)


def _rows_fixed(text):
    return [
        (line[0:10].rstrip(" "), line[10:30].rstrip(" "), line[30:])
        for line in content_lines(text)
    ]


def _md_cell(cell):
    if cell.startswith(" "):
        cell = cell[1:]
    if cell.endswith(" "):
        cell = cell[:-1]
    return cell


def _rows_mdtable(text):
    rows = []
    for line in content_lines(text):
        if not line.startswith("|"):
            continue
        cells = line.split("|")
        if len(cells) < 3 or cells[0].strip() or cells[-1].strip():
            continue
        fields = [_md_cell(cell) for cell in cells[1:-1]]
        if len(fields) != 3:
            continue
        rows.append(tuple(fields))
    return rows


def _rows_kvline(text):
    rows = []
    for line in content_lines(text):
        tokens = line.split(" ")
        if len(tokens) != 3:
            continue
        record = {}
        for token in tokens:
            key, sep, value = token.partition("=")
            if sep and key in ("zone", "value", "flag"):
                record[key] = value
        if len(record) != 3:
            continue
        rows.append((record["zone"], record["value"], record["flag"]))
    return rows


READERS = {
    "csv": lambda text: _split_rows(text, ","),
    "tsv": lambda text: _split_rows(text, "\t"),
    "psv": lambda text: _split_rows(text, "|"),
    "scsv": lambda text: _split_rows(text, ";"),
    "colon": lambda text: _split_rows(text, ":"),
    "caret": lambda text: _split_rows(text, "^"),
    "at": lambda text: _split_rows(text, "@"),
    "bang": lambda text: _split_rows(text, "!"),
    "tilde": lambda text: _split_rows(text, "~"),
    "dcolon": lambda text: _split_rows(text, "::"),
    "ssv": _rows_ssv,
    "jsonarr": _rows_jsonarr,
    "jsonl": _rows_jsonl,
    "xmlflat": _rows_xmlflat,
    "xmlnest": _rows_xmlnest,
    "ini": _rows_ini,
    "fixed": _rows_fixed,
    "mdtable": _rows_mdtable,
    "kvline": _rows_kvline,
    "props": _rows_props,
}


def corpus_catalog(data_dir, rules):
    """Read the corpus table of the written contract; bounds come from the rules."""
    text = (Path(data_dir) / "config_contract.md").read_text(encoding="utf-8")
    bounds = rules["corpus_bounds"]
    catalog = []
    for line in text.split("\n"):
        match = CORPUS_ROW_RE.match(line)
        if not match:
            continue
        name, fmt, op, low, high = match.groups()
        stem = name.rsplit(".", 1)[0]
        if stem not in bounds:
            continue
        published = bounds[stem]
        if [int(low), int(high)] != list(published):
            raise SystemExit("contract and rules disagree on bounds for " + name)
        catalog.append(
            {
                "name": name,
                "format": fmt,
                "op": op,
                "lo": published[0],
                "hi": published[1],
            }
        )
    if len(catalog) != len(bounds):
        raise SystemExit("corpus catalog incomplete")
    catalog.sort(key=lambda entry: entry["name"])
    return catalog


def reduce_counted(op, counted):
    if not counted:
        return 0
    if op == "max":
        return max(counted)
    if op == "min":
        return min(counted)
    if op == "sum":
        return sum(counted)
    if op == "count":
        return len(counted)
    if op == "first":
        return counted[0]
    if op == "last":
        return counted[-1]
    raise SystemExit("unknown operator: " + op)


def reduce_corpus(path, entry, zones, shift, zone_totals):
    rows = READERS[entry["format"]](Path(path).read_text(encoding="utf-8"))
    high = entry["hi"] + shift
    counted = []
    for zone, raw, flag in rows:
        if zone not in zones or flag != ACTIVE_FLAG:
            continue
        number = canonical_int(raw)
        if number is None or number < entry["lo"] or number > high:
            continue
        counted.append(number)
        zone_totals[zone] = zone_totals.get(zone, 0) + 1
    return counted


# --------------------------------------------------------------------------
# aggregate views
# --------------------------------------------------------------------------
def view_sv(aggregates, names, sep):
    header = sep.join(("corpus", "value")) + "\n"
    return header + "".join(
        "{}{}{}\n".format(name, sep, aggregates[name]) for name in names
    )


def view_xml(aggregates, names):
    root = ET.Element("aggregates")
    for name in names:
        ET.SubElement(root, "corpus", {"name": name, "value": str(aggregates[name])})
    return ET.tostring(root, encoding="unicode") + "\n"


def view_ini(aggregates, names):
    return "[aggregates]\n" + "".join(
        "{} = {}\n".format(name, aggregates[name]) for name in names
    )


def view_env(aggregates, names):
    return "".join("{}={}\n".format(name.upper(), aggregates[name]) for name in names)


def view_md(aggregates, names):
    return "| corpus | value |\n| --- | --- |\n" + "".join(
        "| {} | {} |\n".format(name, aggregates[name]) for name in names
    )


def view_txt(aggregates, names):
    return "".join("{} {}\n".format(name, aggregates[name]) for name in names)


# --------------------------------------------------------------------------
# subcommands
# --------------------------------------------------------------------------
def cmd_init(args):
    schema = load_json(args.schema)
    config = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    write_json(args.out, config)
    print("init " + str(args.out))


def cmd_set(args):
    config = load_json(args.config)
    config[args.key] = coerce_scalar(args.value)
    if not is_flat(config):
        raise SystemExit("configuration must be flat")
    write_json(args.config, config)
    print("set {}={}".format(args.key, config[args.key]))


def cmd_validate(args):
    schema = load_json(args.schema)
    config = load_json(args.config)
    required = [key for key in schema["required_keys"].split(",") if key]
    missing = [key for key in required if key not in config]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if schema.get("scalar_only") and not is_flat(config):
        raise SystemExit("configuration must be flat")
    print("ok")


def cmd_plan(args):
    print(dump_json(resolve_policy(args.data, args.env)), end="")


def cmd_compile(args):
    data_dir, out_dir = Path(args.data), Path(args.out)
    inputs = data_inputs(data_dir)
    rules = inputs["rules"]
    zones = list(rules["zones"])
    valid_ops, rejected = classify_journal(data_dir, rules)

    spine = load_json(out_dir / "config.json")
    profiles = {zone: build_profile(spine, zone, inputs, valid_ops) for zone in zones}
    for zone in zones:
        write_json(out_dir / "profile_{}.json".format(zone), profiles[zone])

    shift = spine["rekey_interval_s"] % 97 + len(rejected) % 31
    catalog = corpus_catalog(data_dir, rules)
    zone_totals = {zone: 0 for zone in zones}
    aggregates, index = {}, []
    for entry in catalog:
        counted = reduce_corpus(
            data_dir / entry["name"], entry, set(zones), shift, zone_totals
        )
        value = reduce_counted(entry["op"], counted)
        aggregates[entry["name"]] = value
        record = dict(entry)
        record["eligible_rows"] = len(counted)
        record["value"] = value
        index.append(record)

    names = sorted(aggregates)
    total = sum(aggregates.values())
    best = min(names, key=lambda name: (-aggregates[name], name))

    write_json(out_dir / "aggregates.json", aggregates)
    write_text(out_dir / "aggregates.csv", view_sv(aggregates, names, ","))
    write_text(out_dir / "aggregates.tsv", view_sv(aggregates, names, "\t"))
    write_text(out_dir / "aggregates.xml", view_xml(aggregates, names))
    write_text(out_dir / "aggregates.ini", view_ini(aggregates, names))
    write_text(out_dir / "aggregates.env", view_env(aggregates, names))
    write_text(out_dir / "aggregates.md", view_md(aggregates, names))
    write_text(out_dir / "aggregates.txt", view_txt(aggregates, names))
    write_json(out_dir / "zone_totals.json", zone_totals)
    write_json(out_dir / "corpus_index.json", {"count": len(index), "corpora": index})
    write_json(
        out_dir / "posture.json",
        {
            "aggregate_total": total,
            "corpus_count": len(catalog),
            "max_corpus": best,
            "max_value": aggregates[best],
            "nonzero_corpora": sum(1 for name in names if aggregates[name] != 0),
        },
    )
    write_json(
        out_dir / "rejected_ops.json",
        {"rejected": rejected, "count": len(rejected)},
    )
    data_files = sorted(path.name for path in data_dir.iterdir() if path.is_file())
    write_json(
        out_dir / "summary.json",
        {
            "tool": TOOL_NAME,
            "profile_tag": spine["profile"],
            "trailer": spine["trailer"],
            "profiles": sorted(zones),
            "artifacts": list(ALL_ARTIFACTS),
            "artifact_count": len(ALL_ARTIFACTS),
            "inputs": data_files,
            "input_count": len(data_files),
            "corpus_count": len(catalog),
            "aggregate_total": total,
        },
    )

    commands = json.loads(args.commands) if args.commands else []
    failures = sum(1 for command in commands if command.get("returncode") != 0)
    required = set(inputs["schema"]["required_keys"])
    # validation_report.json is the artifact this very call is about to write.
    present = all(
        name == "validation_report.json" or (out_dir / name).is_file()
        for name in MANIFEST_ARTIFACTS
    )
    scalar_flat = is_flat(spine) and set(spine) == required
    matches = spine == build_spine(inputs, valid_ops)
    profile_flat = {
        zone: is_flat(profiles[zone]) and set(profiles[zone]) == required
        for zone in zones
    }
    checks = {
        "all_artifacts_present": present,
        "config_matches_policy": matches,
        "config_scalar_flat": scalar_flat,
        "command_failures": failures,
        "rejected_ops": len(rejected),
        "profiles": {
            zone: {
                "scalar_flat": profile_flat[zone],
                "trailer": profiles[zone]["trailer"],
            }
            for zone in zones
        },
        "corpus_count": len(catalog),
        "aggregate_total": total,
    }
    ok = bool(
        present
        and matches
        and scalar_flat
        and failures == 0
        and all(profile_flat.values())
        and len(catalog) == len(rules["corpus_bounds"])
    )
    write_json(out_dir / "validation_report.json", {"ok": ok, "checks": checks})
    print("compiled {} corpora, aggregate_total {}".format(len(catalog), total))


def cmd_report(args):
    config = load_json(args.config)
    digest = hashlib.sha256(Path(args.config).read_bytes()).hexdigest()
    if args.digest and args.digest != digest:
        raise SystemExit("digest mismatch for " + str(args.config))
    commands = json.loads(args.commands) if args.commands else []
    report = {
        "ok": all(command.get("returncode") == 0 for command in commands),
        "tool": TOOL_NAME,
        "config_path": str(args.config),
        "config_sha256": digest,
        "trailer": config["trailer"],
        "commands": commands,
    }
    write_json(args.out, report)
    print("report " + str(args.out))


def main():
    parser = argparse.ArgumentParser(prog=TOOL_NAME)
    sub = parser.add_subparsers(dest="command")
    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)
    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)
    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)
    p = sub.add_parser("plan")
    p.add_argument("--data", required=True)
    p.add_argument("--env", required=True)
    p.set_defaults(func=cmd_plan)
    p = sub.add_parser("compile")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--commands", default="")
    p.set_defaults(func=cmd_compile)
    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", default="")
    p.add_argument("--commands", default="")
    p.set_defaults(func=cmd_report)
    args = parser.parse_args()
    if not getattr(args, "func", None):
        parser.error("a subcommand is required")
    args.func(args)


if __name__ == "__main__":
    main()
