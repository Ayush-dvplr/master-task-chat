#!/usr/bin/env python3
"""sealb-ctl - offline, standard-library-only security policy compiler.

The shipped tool was broken in several places.  The repairs:

* every JSON document is written with the canonical serialisation required by
  ``/app/data/config_contract.md`` (``sort_keys=True``, ``indent=2``,
  ``separators=(",", ": ")``, ``ensure_ascii=False`` and one trailing newline);
* ``init`` seeds a flat scalar configuration from the tool schema and, when the
  sidecar data directory is available, from ``defaults.json``;
* ``set`` assigns the exact key (no case folding) and keeps canonical base-10
  integers as integers so the configuration stays flat;
* ``validate`` accepts ``required_keys`` as either a comma-separated string or
  a JSON array and checks the required keys, flatness and scalar-only policy;
* ``plan`` resolves one environment's policy from the journal replay;
* ``compile`` reduces the evidence corpora into the derived artifacts;
* ``export-report`` records the command transcript and the config digest.

Everything is derived from the files under ``/app/data``; nothing is networked,
timestamped or randomised.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

TOOL = "sealb-ctl"
DEFAULT_DATA = Path("/app/data")
INT_KEYS = ("max_sessions", "retry_budget", "handshake_timeout_ms", "rekey_interval_s")
MODE_KEY = "mode"
OP_KINDS = ("max", "min", "sum", "count", "first", "last")
AGG_VIEWS = ("csv", "tsv", "xml", "ini", "env", "md", "txt")
BASE_ENV = "base"
CORPUS_NAME_RE = re.compile(r"^c\d\d_[a-z0-9_]+\.[a-z]+$")
COMMENT_RE = re.compile(r"^\s*#")


# ---------------------------------------------------------------- serialisation


def dumps_canonical(obj) -> str:
    """Serialise exactly as the contract demands."""
    return json.dumps(
        obj, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False
    )


def json_document(obj) -> str:
    return dumps_canonical(obj) + "\n"


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, obj) -> str:
    text = json_document(obj)
    Path(path).write_text(text, encoding="utf-8")
    return text


def write_text(path, text) -> None:
    Path(path).write_text(text, encoding="utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ------------------------------------------------------------------ policy spine


class Policy:
    """Journal replay and policy resolution, all derived from ``/app/data``."""

    def __init__(self, data_dir):
        self.dir = Path(data_dir)
        self.schema = read_json(self.dir / "config_schema.json")
        self.defaults = read_json(self.dir / "defaults.json")
        self.rules = read_json(self.dir / "validation_rules.json")
        self.overrides = read_json(self.dir / "env_overrides.json")
        self.contract = (self.dir / "config_contract.md").read_text(encoding="utf-8")
        self.ops = self._load_journal()
        self.zones = tuple(self.rules["zones"])
        self.base_config = self.defaults["base_config"]

    # ---- inputs

    def _load_journal(self):
        ops = []
        for line in (self.dir / "change_journal.jsonl").read_text(
            encoding="utf-8"
        ).splitlines():
            if not line.strip():
                continue
            ops.append(json.loads(line))
        ops.sort(key=lambda rec: rec["seq"])
        return tuple(ops)

    def corpus_table(self):
        """Parse the corpus table out of the written contract."""
        table = {}
        for line in self.contract.splitlines():
            stripped = line.strip()
            if not stripped.startswith("|"):
                continue
            cells = [cell.strip() for cell in stripped.strip("|").split("|")]
            if len(cells) != 5:
                continue
            name, fmt, op, lo, hi = cells
            if not CORPUS_NAME_RE.match(name):
                continue
            if op not in OP_KINDS:
                continue
            if not re.fullmatch(r"-?\d+", lo) or not re.fullmatch(r"-?\d+", hi):
                continue
            table[name] = {"format": fmt, "op": op, "lo": int(lo), "hi": int(hi)}
        bounds = self.rules["corpus_bounds"]
        files = sorted(
            p.name
            for p in self.dir.iterdir()
            if p.is_file() and CORPUS_NAME_RE.match(p.name)
        )
        if sorted(table) != files:
            raise SystemExit("contract corpus table does not match the corpora")
        for name, spec in table.items():
            stem = name.rsplit(".", 1)[0]
            if stem not in bounds:
                raise SystemExit("no bounds for corpus %s" % name)
            if list(bounds[stem]) != [spec["lo"], spec["hi"]]:
                raise SystemExit("bounds disagree for corpus %s" % name)
        return table

    # ---- journal classification

    def is_valid(self, rec) -> bool:
        """Classify one journal operation against validation_rules.json."""
        if rec.get("op") not in ("set", "unset"):
            return False
        if rec.get("env") not in self.rules["journal_envs"]:
            return False
        key = rec.get("key")
        if key in self.rules["bounds"]:
            if rec["op"] == "unset":
                return True
            value = rec.get("value")
            if isinstance(value, bool) or not isinstance(value, int):
                return False
            low, high = self.rules["bounds"][key]
            return low <= value <= high
        if key == MODE_KEY:
            if rec["op"] == "unset":
                return True
            value = rec.get("value")
            return isinstance(value, str) and value in self.rules["allowed_modes"]
        return False

    def rejected(self):
        """Ascending ``seq`` of every invalid journal operation."""
        return [rec["seq"] for rec in self.ops if not self.is_valid(rec)]

    # ---- resolution

    def _apply(self, doc, rec) -> None:
        key = rec["key"]
        if rec["op"] == "set":
            doc[key] = rec["value"]
        elif key in self.base_config:
            doc[key] = self.base_config[key]
        else:
            doc[key] = self.defaults[MODE_KEY]

    def _seed(self) -> dict:
        doc = {
            "profile": self.schema["profile"],
            "producer": self.schema["producer"],
            "container": self.schema["container"],
            "checksum": self.defaults["checksum"],
            MODE_KEY: self.defaults[MODE_KEY],
            "trailer": self.base_config["trailer"],
        }
        for key in INT_KEYS:
            doc[key] = self.base_config[key]
        return doc

    def seed(self) -> dict:
        """The defaults.json/config_schema.json starting configuration."""
        return self._seed()

    def resolve(self, env) -> dict:
        """The fully resolved policy document for one environment."""
        if env not in self.rules["journal_envs"]:
            raise SystemExit("unknown environment: %s" % env)
        doc = self._seed()
        for rec in self.ops:
            if rec["env"] != BASE_ENV or not self.is_valid(rec):
                continue
            self._apply(doc, rec)
        if env == BASE_ENV:
            return doc
        if env not in self.overrides:
            raise SystemExit("no overrides for environment: %s" % env)
        zone = dict(doc)
        delta = self.overrides[env]
        for name in sorted(delta):
            if name == MODE_KEY:
                continue
            if not name.endswith("_delta"):
                raise SystemExit("unsupported override key: %s" % name)
            key = name[: -len("_delta")]
            if key not in INT_KEYS:
                raise SystemExit("unsupported override key: %s" % name)
            zone[key] = zone[key] + delta[name]
        if MODE_KEY in delta:
            zone[MODE_KEY] = delta[MODE_KEY]
        zone["profile"] = doc["profile"] + "-" + env
        zone["trailer"] = doc["trailer"] + ":" + env
        for rec in self.ops:
            if rec["env"] != env or not self.is_valid(rec):
                continue
            self._apply(zone, rec)
        return zone


def scalar_flat(doc) -> bool:
    if not isinstance(doc, dict):
        return False
    for value in doc.values():
        if isinstance(value, (dict, list)):
            return False
    return True


def canonical_int(text):
    """Return the integer when ``str(int(value)) == value`` on the field bytes."""
    if not isinstance(text, str):
        return None
    try:
        number = int(text)
    except ValueError:
        return None
    if str(number) != text:
        return None
    return number


# ----------------------------------------------------------------- corpus rows


def _json_value_to_text(value):
    """A JSON integer is already canonical; other JSON types are judged as bytes."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value)
    if isinstance(value, str):
        return value
    return None


def _split_lines(text):
    for line in text.split("\n"):
        if not line.strip():
            continue
        if COMMENT_RE.match(line):
            continue
        yield line


def _delimited(text, sep):
    rows = []
    for line in _split_lines(text):
        fields = line.split(sep)
        if len(fields) != 3:
            continue
        rows.append((fields[0], fields[1], fields[2]))
    return rows


def _ssv_rows(text):
    rows = []
    for line in _split_lines(text):
        fields = line.split()
        if len(fields) != 3:
            continue
        rows.append((fields[0], fields[1], fields[2]))
    return rows


def _ini_rows(text):
    rows = []
    current = None
    for line in _split_lines(text):
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            if current is not None:
                rows.append(
                    (current.get("zone"), current.get("value"), current.get("flag"))
                )
            current = {}
            continue
        if current is None or "=" not in line:
            continue
        key, _, rest = line.partition("=")
        current[key.strip()] = rest[1:] if rest.startswith(" ") else rest
    if current is not None:
        rows.append((current.get("zone"), current.get("value"), current.get("flag")))
    return rows


def _props_rows(text):
    records = {}
    order = []
    for line in _split_lines(text):
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        match = re.fullmatch(r"([^\s=]+)\.(zone|value|flag)", key)
        if not match:
            continue
        rid, field = match.group(1), match.group(2)
        if rid not in records:
            records[rid] = {}
            order.append(rid)
        records[rid][field] = value
    return [
        (
            records[rid].get("zone"),
            records[rid].get("value"),
            records[rid].get("flag"),
        )
        for rid in order
    ]


def _kv_rows(text):
    rows = []
    for line in _split_lines(text):
        fields = {}
        for token in line.split():
            key, _, value = token.partition("=")
            fields[key] = value
        rows.append((fields.get("zone"), fields.get("value"), fields.get("flag")))
    return rows


def _fixed_rows(text):
    """``zone`` in 0-10, ``value`` in 10-30, ``flag`` from 30; fields are
    left-aligned and space padded, so only the trailing padding is removed."""
    rows = []
    for line in _split_lines(text):
        rows.append(
            (
                line[0:10].rstrip(" "),
                line[10:30].rstrip(" "),
                line[30:].rstrip(" "),
            )
        )
    return rows


def _md_rows(text):
    """Markdown table: ``| zone | value | flag |`` pads each cell with one
    space either side, so only that padding is removed."""
    rows = []
    for line in _split_lines(text):
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        body = stripped[1:]
        if body.endswith("|"):
            body = body[:-1]
        cells = []
        for cell in body.split("|"):
            if cell.startswith(" "):
                cell = cell[1:]
            if cell.endswith(" "):
                cell = cell[:-1]
            cells.append(cell)
        if len(cells) != 3:
            continue
        rows.append((cells[0], cells[1], cells[2]))
    return rows


def _xml_flat_rows(text):
    root = ET.fromstring(text)
    return [(row.get("zone"), row.get("value"), row.get("flag")) for row in root]


def _xml_nested_rows(text):
    root = ET.fromstring(text)
    rows = []
    for row in root:
        fields = {child.tag: child.text or "" for child in row}
        rows.append((fields.get("zone"), fields.get("value"), fields.get("flag")))
    return rows


def _json_array_rows(text):
    return [
        (item.get("zone"), item.get("value"), item.get("flag"))
        for item in json.loads(text)
    ]


def _jsonl_rows(text):
    rows = []
    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped or stripped.startswith("//"):
            continue
        item = json.loads(stripped)
        rows.append((item.get("zone"), item.get("value"), item.get("flag")))
    return rows


DELIMITERS = {
    "csv": ",",
    "tsv": "\t",
    "psv": "|",
    "scsv": ";",
    "colon": ":",
    "caret": "^",
    "at": "@",
    "bang": "!",
    "tilde": "~",
    "dcolon": "::",
}

ROW_PARSERS = {
    "ini": _ini_rows,
    "props": _props_rows,
    "kvline": _kv_rows,
    "fixed": _fixed_rows,
    "mdtable": _md_rows,
    "xmlflat": _xml_flat_rows,
    "xmlnest": _xml_nested_rows,
    "jsonarr": _json_array_rows,
    "jsonl": _jsonl_rows,
    "ssv": _ssv_rows,
}


def corpus_rows(path, fmt):
    text = Path(path).read_text(encoding="utf-8")
    if fmt in DELIMITERS:
        return _delimited(text, DELIMITERS[fmt])
    if fmt not in ROW_PARSERS:
        raise SystemExit("unsupported corpus format: %s" % fmt)
    return ROW_PARSERS[fmt](text)


def eligible_int(zone, value, flag, zones, lo, hi, shift):
    """The counted integer of one row, or ``None``."""
    if zone not in zones or flag != "active":
        return None
    if isinstance(value, str):
        text = value
    else:
        text = _json_value_to_text(value)
    number = canonical_int(text)
    if number is None:
        return None
    if number < lo or number > hi + shift:
        return None
    return number


def reduce_corpus(policy, name, spec, shift):
    """Count the eligible rows of one corpus and apply its aggregation operator."""
    zones = set(policy.zones)
    counted = []
    eligible = 0
    for zone, value, flag in corpus_rows(policy.dir / name, spec["format"]):
        number = eligible_int(zone, value, flag, zones, spec["lo"], spec["hi"], shift)
        if number is None:
            continue
        counted.append(number)
        eligible += 1
    op = spec["op"]
    if not counted:
        return eligible, 0
    if op == "max":
        result = max(counted)
    elif op == "min":
        result = min(counted)
    elif op == "sum":
        result = sum(counted)
    elif op == "count":
        result = len(counted)
    elif op == "first":
        result = counted[0]
    elif op == "last":
        result = counted[-1]
    else:
        raise SystemExit("unsupported operator: %s" % op)
    return eligible, result


# ------------------------------------------------------------- aggregates views


def aggregates_csv(mapping):
    lines = ["corpus,value"]
    lines.extend("%s,%s" % (name, mapping[name]) for name in sorted(mapping))
    return "\n".join(lines) + "\n"


def aggregates_tsv(mapping):
    lines = ["corpus\tvalue"]
    lines.extend("%s\t%s" % (name, mapping[name]) for name in sorted(mapping))
    return "\n".join(lines) + "\n"


def aggregates_xml(mapping):
    root = ET.Element("aggregates")
    for name in sorted(mapping):
        ET.SubElement(root, "corpus", {"name": name, "value": str(mapping[name])})
    return ET.tostring(root, encoding="unicode") + "\n"


def aggregates_ini(mapping):
    lines = ["[aggregates]"]
    lines.extend("%s = %s" % (name, mapping[name]) for name in sorted(mapping))
    return "\n".join(lines) + "\n"


def aggregates_env(mapping):
    return "".join(
        "%s=%s\n" % (name.upper(), mapping[name]) for name in sorted(mapping)
    )


def aggregates_md(mapping):
    lines = ["| corpus | value |", "| --- | --- |"]
    lines.extend("| %s | %s |" % (name, mapping[name]) for name in sorted(mapping))
    return "\n".join(lines) + "\n"


def aggregates_txt(mapping):
    return "".join("%s %s\n" % (name, mapping[name]) for name in sorted(mapping))


AGGREGATE_VIEWS = {
    "csv": aggregates_csv,
    "tsv": aggregates_tsv,
    "xml": aggregates_xml,
    "ini": aggregates_ini,
    "env": aggregates_env,
    "md": aggregates_md,
    "txt": aggregates_txt,
}


# ------------------------------------------------------------------- artifacts


def compile_artifacts(policy, out_dir, config_doc):
    """Reduce every corpus and write the aggregates views and JSON roll-ups."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rejected = policy.rejected()
    rejected_count = len(rejected)
    rekey = config_doc["rekey_interval_s"]
    shift = (rekey % 97) + (rejected_count % 31)
    table = policy.corpus_table()

    aggregates = {}
    index = []
    zone_totals = {zone: 0 for zone in policy.zones}
    for name in sorted(table):
        spec = table[name]
        eligible, value = reduce_corpus(policy, name, spec, shift)
        aggregates[name] = value
        index.append(
            {
                "name": name,
                "format": spec["format"],
                "op": spec["op"],
                "lo": spec["lo"],
                "hi": spec["hi"],
                "eligible_rows": eligible,
                "value": value,
            }
        )
        zones = set(policy.zones)
        for zone, row_value, flag in corpus_rows(policy.dir / name, spec["format"]):
            number = eligible_int(
                zone, row_value, flag, zones, spec["lo"], spec["hi"], shift
            )
            if number is not None and zone in zone_totals:
                zone_totals[zone] += 1

    written = []
    for view in AGG_VIEWS:
        path = out / ("aggregates." + view)
        write_text(path, AGGREGATE_VIEWS[view](aggregates))
        written.append(path.name)
    write_json(out / "aggregates.json", aggregates)
    written.append("aggregates.json")
    write_json(out / "zone_totals.json", zone_totals)
    written.append("zone_totals.json")
    write_json(out / "corpus_index.json", {"count": len(index), "corpora": index})
    written.append("corpus_index.json")

    aggregate_total = sum(aggregates.values())
    max_name = None
    max_value = None
    for name in sorted(aggregates):
        value = aggregates[name]
        if max_value is None or value > max_value:
            max_name, max_value = name, value
    posture = {
        "aggregate_total": aggregate_total,
        "corpus_count": len(aggregates),
        "max_corpus": max_name,
        "max_value": max_value,
        "nonzero_corpora": sum(1 for value in aggregates.values() if value != 0),
    }
    write_json(out / "posture.json", posture)
    written.append("posture.json")
    write_json(
        out / "rejected_ops.json", {"rejected": rejected, "count": rejected_count}
    )
    written.append("rejected_ops.json")
    rollups = {
        "aggregates": aggregates,
        "zone_totals": zone_totals,
        "posture": posture,
        "shift": shift,
        "rejected_count": rejected_count,
    }
    return sorted(written), rollups


# ------------------------------------------------------------------ subcommands


def required_keys_from(schema):
    keys = schema["required_keys"]
    if isinstance(keys, str):
        return [key.strip() for key in keys.split(",") if key.strip()]
    return list(keys)


def resolve_data_dir(value):
    if value:
        return Path(value)
    if DEFAULT_DATA.is_dir():
        return DEFAULT_DATA
    return None


def cmd_init(args):
    schema = read_json(args.schema)
    doc = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    data_dir = resolve_data_dir(args.data)
    if data_dir is not None:
        doc.update(Policy(data_dir).seed())
    write_json(args.out, doc)
    print(args.out)
    return 0


def cmd_set(args):
    path = Path(args.config)
    doc = read_json(path)
    number = canonical_int(args.value)
    doc[args.key] = number if number is not None else args.value
    write_json(path, doc)
    print("ok")
    return 0


def cmd_validate(args):
    schema = read_json(args.schema)
    doc = read_json(args.config)
    missing = [key for key in required_keys_from(schema) if key not in doc]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if not scalar_flat(doc):
        raise SystemExit("configuration must be flat")
    print("ok")
    return 0


def cmd_plan(args):
    data_dir = resolve_data_dir(args.data)
    if data_dir is None:
        raise SystemExit("no data directory")
    doc = Policy(data_dir).resolve(args.env)
    sys.stdout.write(json_document(doc))
    return 0


def cmd_compile(args):
    data_dir = resolve_data_dir(args.data)
    if data_dir is None:
        raise SystemExit("no data directory")
    config_path = Path(args.out) / "config.json"
    if not config_path.is_file():
        raise SystemExit("missing finished policy: %s" % config_path)
    config_doc = read_json(config_path)
    policy = Policy(data_dir)
    written, _ = compile_artifacts(policy, args.out, config_doc)
    for name in written:
        print(name)
    return 0


def cmd_export_report(args):
    config_path = Path(args.config)
    raw = config_path.read_bytes()
    digest = sha256_bytes(raw)
    if args.digest and args.digest != digest:
        raise SystemExit("digest mismatch for %s" % config_path)
    doc = json.loads(raw.decode("utf-8"))
    commands = []
    if args.commands:
        payload = read_json(args.commands)
        if isinstance(payload, dict):
            payload = payload.get("commands", [])
        commands = list(payload)
    report = {
        "ok": all(entry.get("returncode") == 0 for entry in commands),
        "tool": TOOL,
        "config_path": str(args.config),
        "config_sha256": digest,
        "trailer": doc["trailer"],
        "commands": commands,
    }
    write_json(args.out, report)
    print("ok")
    return 0


def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL)
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init", help="seed the flat configuration from the schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--data", default=None)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="assign one key to a scalar value")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="check the required keys and flatness")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("plan", help="print the resolved policy for one environment")
    p.add_argument("--data", required=True)
    p.add_argument("--env", required=True)
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("compile", help="reduce the corpora into the derived artifacts")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("export-report", help="record the command transcript")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", default=None)
    p.add_argument("--commands", default=None)
    p.set_defaults(func=cmd_export_report)
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 2
    try:
        return args.func(args) or 0
    except SystemExit as exc:
        if exc.code is None:
            return 0
        if isinstance(exc.code, int):
            return exc.code
        print("%s: %s" % (TOOL, exc.code), file=sys.stderr)
        return 1
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print("%s: %s: %s" % (TOOL, type(exc).__name__, exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
