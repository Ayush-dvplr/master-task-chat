#!/usr/bin/env python3
"""task-ctl: build, seal, check and report flat TASK configurations."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zlib
from pathlib import Path

PROG = "task-ctl"
TRAILER_PREFIX = "harbor:cli-config"
DEFAULT_MODE = "relaxed-local"


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def encode(doc):
    return (json.dumps(doc) + "\n").encode("utf-8")


def write_document(path, doc):
    Path(path).write_bytes(encode(doc))


def config_trailer(doc):
    digest = zlib.crc32(encode(doc))
    return f"{TRAILER_PREFIX}:{doc['profile']}:{digest:08x}"


def parse_number(text):
    value = float(text)
    return int(value) if value.is_integer() else value


def cmd_init(args):
    schema = load_json(args.schema)
    defaults = load_json(args.defaults) if args.defaults else {}
    doc = {"profile": schema["profile"], "mode": schema.get("mode", DEFAULT_MODE)}
    for key in ("producer", "container", "checksum"):
        doc[key] = schema.get(key, defaults.get(key, ""))
    write_document(args.out, doc)


def cmd_set(args):
    doc = load_json(args.config)
    doc.setdefault(args.key.strip().lower(), parse_number(args.value))
    write_document(args.config, doc)


def cmd_seal(args):
    doc = load_json(args.config)
    doc["trailer"] = config_trailer(doc)
    write_document(args.config, doc)
    print(doc["trailer"])


def required_keys(schema):
    keys = schema["required_keys"]
    return keys.split(",") if isinstance(keys, str) else list(keys)


def cmd_validate(args):
    schema = load_json(args.schema)
    doc = load_json(args.config)
    present = {key.lower() for key in doc}
    missing = [key for key in required_keys(schema) if key.lower() not in present]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if any(isinstance(value, dict) for value in doc.values()):
        raise SystemExit("configuration must be flat")
    if not str(doc.get("trailer", "")).startswith(TRAILER_PREFIX + ":"):
        raise SystemExit("configuration is not sealed")
    print("ok")


def cmd_profile(args):
    config = load_json(args.config)
    overrides = load_json(args.overrides)
    entry = overrides[args.name]
    sample = load_json(Path(args.samples) / f"sample_config_{args.name}.json")
    doc = dict(config)
    doc["profile"] = f"{config['profile']}-{args.name}"
    doc["max_records"] = config["max_records"] + sample.get("max_records_delta", 0)
    doc["retry_limit"] = config["retry_limit"] + entry.get("retry_limit_delta", 0)
    doc["timeout_ms"] = config["timeout_ms"] + entry.get("timeout_ms_delta", 0)
    doc.update({key: value for key, value in entry.items() if key in doc})
    doc["checksum"] = sample.get("checksum", config["checksum"])
    doc["trailer"] = f"{config['trailer']}:{args.name}"
    write_document(args.out, doc)


def cmd_report(args):
    doc = load_json(args.config)
    commands = load_json(args.commands) if args.commands else []
    commands.append({"argv": sys.argv, "returncode": 0, "stdout": ""})
    report = {
        "ok": True,
        "tool": PROG,
        "config_path": args.config,
        "config_sha256": hashlib.sha256(encode(doc)).hexdigest(),
        "trailer": doc.get("trailer"),
        "commands": commands,
        "repairs": load_json(args.repairs) if args.repairs else [],
    }
    write_document(args.out, report)


def build_parser():
    parser = argparse.ArgumentParser(prog=PROG)
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init", help="seed a configuration from a schema and defaults")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="store one numeric base value")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("seal", help="compute and store the trailer")
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_seal)

    p = sub.add_parser("validate", help="check a configuration against a schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("profile", help="derive an environment profile")
    p.add_argument("--config", required=True)
    p.add_argument("--overrides", required=True)
    p.add_argument("--samples", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("export-report", help="write the run report")
    p.add_argument("--config", required=True)
    p.add_argument("--commands")
    p.add_argument("--repairs")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_report)
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if args.command is None:
        parser.print_usage()
        return
    args.func(args)


if __name__ == "__main__":
    main()
