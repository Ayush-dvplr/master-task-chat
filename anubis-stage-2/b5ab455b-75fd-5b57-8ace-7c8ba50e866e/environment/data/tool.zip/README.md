# task-ctl

This local stdlib-only CLI builds, seals, checks and reports a flat JSON
configuration for TASK processing, and derives environment profiles from it.
It is broken in several places and must be repaired before use.

Expected commands after repair:

```bash
python3 cli.py init --schema schema.json --defaults defaults.json --out config.json
python3 cli.py set --config config.json --key max_records --value 100
python3 cli.py seal --config config.json
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py profile --config config.json --overrides env_overrides.json --samples . --name dev --out profile_dev.json
python3 cli.py export-report --config config.json --commands commands.json --repairs repairs.json --out report.json
```
