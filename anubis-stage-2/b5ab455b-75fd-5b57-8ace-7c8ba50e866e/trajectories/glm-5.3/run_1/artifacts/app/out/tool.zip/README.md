# task-ctl

This stdlib-only CLI builds, seals, checks and reports a flat JSON
configuration for TASK processing, and derives environment profiles from it.

```bash
python3 cli.py init --schema schema.json --defaults defaults.json --out config.json
python3 cli.py set --config config.json --key max_records --value 100
python3 cli.py seal --config config.json
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py profile --config config.json --overrides env_overrides.json --samples . --name dev --out profile_dev.json
python3 cli.py export-report --config config.json --commands commands.json --repairs repairs.json --out report.json
```

`init` writes the five identity keys: profile from the schema, and producer,
container, checksum and mode from the defaults file.

`set` stores one of max_records, retry_limit or timeout_ms as an exact
base-10 integer and replaces any value the key already holds.

`seal` removes any existing trailer, digests what remains and prints the
`harbor:cli-config:{profile}:{digest}` trailer it stores. The digest is the
CRC-32 of the document's canonical encoding, final newline included, as 16
lowercase hexadecimal digits.

`validate` prints ok only when the file's bytes are exactly its canonical
encoding, its keys are exactly the schema's required_keys, its profile
matches the schema, the three numeric keys hold integers, every other key
holds a string, and its trailer equals the trailer seal computes.

`profile` resolves the named override entry's extends chain from its root,
adds each entry's deltas and the matching sample file's max_records_delta,
applies the last mode it meets, and seals one name:digest pair per chain
entry onto the parent trailer.

Every subcommand writes its document as the canonical encoding: keys sorted
by code point at every depth, no whitespace between tokens, non-ASCII as raw
UTF-8, one trailing newline and no byte order mark. Input files may start
with a byte order mark, and the first occurrence of a duplicated key counts.
A failing subcommand prints one line on standard error and exits 1; a usage
error prints a usage line on standard error and exits 2.
