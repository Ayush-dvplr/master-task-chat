#!/usr/bin/env python3
"""task-ctl: build, seal, check and report flat TASK configurations."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
import zlib
from pathlib import Path

PROG = "task-ctl"
TRAILER_PREFIX = "harbor:cli-config"
SET_KEYS = ("max_records", "retry_limit", "timeout_ms")
IDENTITY_KEYS = ("profile", "producer", "container", "checksum", "mode")


class ToolError(Exception):
    """A failure reported as one stderr line, never as a traceback."""


def _first_wins(pairs):
    """object_pairs_hook: the first occurrence of a duplicated key counts."""
    doc = {}
    for key, value in pairs:
        if key not in doc:
            doc[key] = value
    return doc


def load_json(path):
    """Read a UTF-8 JSON document; a leading byte order mark is not content."""
    try:
        data = Path(path).read_bytes()
    except OSError as exc:
        raise ToolError(f"cannot read {path}: {exc.strerror or exc}")
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_first_wins)
    except UnicodeDecodeError:
        raise ToolError(f"{path} is not valid UTF-8")
    except ValueError as exc:
        raise ToolError(f"{path} is not valid JSON: {exc}")


def encode(doc):
    """The canonical encoding of a JSON object."""
    text = json.dumps(doc, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False)
    return (text + "\n").encode("utf-8")


def write_document(path, doc):
    """Write canonically and atomically; a failure leaves the old file as it was."""
    data = encode(doc)
    target = Path(path)
    parent = target.parent if str(target.parent) else Path(".")
    mask = os.umask(0)
    os.umask(mask)
    mode = 0o666 & ~mask
    try:
        fd, tmp = tempfile.mkstemp(dir=str(parent), prefix=target.name + ".", suffix=".tmp")
        try:
            os.fchmod(fd, mode)
            with os.fdopen(fd, "wb") as handle:
                handle.write(data)
            os.replace(tmp, str(target))
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
    except OSError as exc:
        raise ToolError(f"cannot write {path}: {exc.strerror or exc}")


def digest(doc):
    """CRC-32 of the canonical encoding of the document without its trailer key."""
    body = {key: value for key, value in doc.items() if key != "trailer"}
    return f"{zlib.crc32(encode(body)):016x}"


def config_trailer(doc):
    return f"{TRAILER_PREFIX}:{doc['profile']}:{digest(doc)}"


def is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def is_string(value):
    return isinstance(value, str)


def parse_number(text):
    """A base-10 integer: optional minus, digits 0-9, no leading zero but 0 itself."""
    if not isinstance(text, str):
        raise ToolError(f"invalid value: {text!r}")
    body = text[1:] if text.startswith("-") else text
    if not body or not body.isascii() or not body.isdigit():
        raise ToolError(f"invalid value: {text}")
    if len(body) > 1 and body[0] == "0":
        raise ToolError(f"invalid value: {text}")
    return int(text)


def _require(doc, key, where):
    if key not in doc:
        raise ToolError(f"{where} has no {key}")
    return doc[key]


def _base_document(config, name):
    for key in SET_KEYS:
        if not is_int(config.get(key)):
            raise ToolError(f"configuration {key} is not an integer")
    doc = {"profile": name}
    for key in ("producer", "container", "checksum", "mode"):
        value = _require(config, key, "configuration")
        if not is_string(value):
            raise ToolError(f"configuration {key} is not a string")
        doc[key] = value
    for key in SET_KEYS:
        doc[key] = config[key]
    return doc


def cmd_init(args):
    schema = load_json(args.schema)
    if not isinstance(schema, dict):
        raise ToolError("schema is not a JSON object")
    defaults = load_json(args.defaults) if args.defaults else {}
    if not isinstance(defaults, dict):
        raise ToolError("defaults is not a JSON object")
    doc = {"profile": _require(schema, "profile", "schema")}
    for key in IDENTITY_KEYS[1:]:
        doc[key] = _require(defaults, key, "defaults file")
    write_document(args.out, doc)


def cmd_set(args):
    if args.key not in SET_KEYS:
        raise ToolError(f"unknown key: {args.key}")
    doc = load_json(args.config)
    if not isinstance(doc, dict):
        raise ToolError(f"{args.config} is not a JSON object")
    doc[args.key] = parse_number(args.value)
    write_document(args.config, doc)


def cmd_seal(args):
    doc = load_json(args.config)
    if not isinstance(doc, dict):
        raise ToolError(f"{args.config} is not a JSON object")
    doc.pop("trailer", None)
    doc["trailer"] = config_trailer(doc)
    write_document(args.config, doc)
    print(doc["trailer"])


def required_keys(schema):
    keys = _require(schema, "required_keys", "schema")
    if isinstance(keys, str):
        keys = [part.strip() for part in keys.split(",")]
    if not isinstance(keys, list):
        raise ToolError("schema required_keys is neither a list nor a string")
    return keys


def cmd_validate(args):
    schema = load_json(args.schema)
    if not isinstance(schema, dict):
        raise ToolError("schema is not a JSON object")
    doc = load_json(args.config)
    if not isinstance(doc, dict):
        raise ToolError(f"{args.config} is not a JSON object")
    keys = required_keys(schema)
    missing = [key for key in keys if key not in doc]
    if missing:
        raise ToolError(f"missing: {','.join(missing)}")
    extra = sorted(set(doc) - set(keys))
    if extra:
        raise ToolError("extra keys: " + ",".join(extra))
    for key in SET_KEYS:
        if not is_int(doc.get(key)):
            raise ToolError(f"{key} is not an integer")
    for key, value in doc.items():
        if key in SET_KEYS:
            continue
        if not is_string(value):
            raise ToolError(f"{key} is not a string")
    if doc["profile"] != schema["profile"]:
        raise ToolError("profile does not match the schema")
    try:
        on_disk = Path(args.config).read_bytes()
    except OSError as exc:
        raise ToolError(f"cannot read {args.config}: {exc.strerror or exc}")
    if on_disk != encode(doc):
        raise ToolError(f"{args.config} is not in canonical form")
    if doc["trailer"] != config_trailer(doc):
        raise ToolError("configuration is not sealed")
    print("ok")


def profile_chain(overrides, name):
    """The override entries of a profile, root first."""
    if not isinstance(overrides, dict):
        raise ToolError("overrides is not a JSON object")
    if name not in overrides:
        raise ToolError(f"no override entry named {name}")
    chain = []
    seen = set()
    current = name
    while True:
        if current in seen:
            raise ToolError(f"extends cycle at {current}")
        seen.add(current)
        entry = overrides.get(current)
        if not isinstance(entry, dict):
            raise ToolError(f"override entry {current} is not a JSON object")
        chain.append((current, entry))
        parent = entry.get("extends")
        if parent is None:
            break
        if not isinstance(parent, str):
            raise ToolError(f"override entry {current} has a non-string extends")
        if parent not in overrides:
            raise ToolError(f"override entry {current} extends missing entry {parent}")
        current = parent
    chain.reverse()
    return chain


def sample_delta(samples, name):
    """The max_records_delta of sample_config_{name}.json, 0 when there is none."""
    path = Path(samples) / f"sample_config_{name}.json"
    if not path.is_file():
        return 0
    sample = load_json(path)
    if not isinstance(sample, dict):
        raise ToolError(f"sample {path} is not a JSON object")
    delta = sample.get("max_records_delta", 0)
    if not is_int(delta):
        raise ToolError(f"sample {path} has a non-integer max_records_delta")
    return delta


def cmd_profile(args):
    config = load_json(args.config)
    if not isinstance(config, dict):
        raise ToolError(f"{args.config} is not a JSON object")
    overrides = load_json(args.overrides)
    chain = profile_chain(overrides, args.name)
    if "profile" not in config:
        raise ToolError("configuration has no profile")
    parent_trailer = config.get("trailer")
    if not is_string(parent_trailer):
        raise ToolError("configuration has no trailer")
    doc = _base_document(config, "")
    for name, entry in chain:
        doc["max_records"] += sample_delta(args.samples, name)
        for key, target in (("retry_limit_delta", "retry_limit"),
                            ("timeout_ms_delta", "timeout_ms")):
            delta = entry.get(key, 0)
            if not is_int(delta):
                raise ToolError(f"override entry {name} has a non-integer {key}")
            doc[target] += delta
        if "mode" in entry:
            doc["mode"] = entry["mode"]
        # Each ancestor is sealed as its own profile document, whose trailer
        # becomes the parent trailer of the entry that extends it.
        doc["profile"] = f"{config['profile']}-{name}"
        doc["trailer"] = f"{parent_trailer}:{name}:{digest(doc)}"
        parent_trailer = doc["trailer"]
    write_document(args.out, doc)


def own_argv():
    """The tool's argument vector as the interpreter received it."""
    return [sys.executable, os.path.abspath(sys.argv[0])] + list(sys.argv[1:])


def cmd_report(args):
    doc = load_json(args.config)
    if not isinstance(doc, dict):
        raise ToolError(f"{args.config} is not a JSON object")
    commands = load_json(args.commands) if args.commands else []
    if not isinstance(commands, list):
        raise ToolError("commands is not a JSON list")
    repairs = load_json(args.repairs) if args.repairs else []
    if not isinstance(repairs, list):
        raise ToolError("repairs is not a JSON list")
    commands = list(commands)
    commands.append({"argv": own_argv(), "returncode": 0, "stdout": ""})
    ok = all(isinstance(entry, dict) and is_int(entry.get("returncode"))
             and entry["returncode"] == 0 for entry in commands)
    try:
        config_bytes = Path(args.config).read_bytes()
    except OSError as exc:
        raise ToolError(f"cannot read {args.config}: {exc.strerror or exc}")
    report = {
        "ok": ok,
        "tool": PROG,
        "config_path": os.path.abspath(args.config),
        "config_sha256": hashlib.sha256(config_bytes).hexdigest(),
        "trailer": doc.get("trailer"),
        "commands": commands,
        "repairs": repairs,
    }
    write_document(args.out, report)


def build_parser():
    parser = argparse.ArgumentParser(prog=PROG)
    sub = parser.add_subparsers(dest="command", metavar="SUBCOMMAND")

    p = sub.add_parser("init", help="seed a configuration from a schema and defaults")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="store one numeric base value")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("seal", help="compute and store the trailer")
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_seal)

    p = sub.add_parser("validate", help="check a configuration against a schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("profile", help="derive an environment profile")
    p.add_argument("--config", required=True)
    p.add_argument("--overrides", required=True)
    p.add_argument("--samples", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("export-report", help="write the run report")
    p.add_argument("--config", required=True)
    p.add_argument("--commands")
    p.add_argument("--repairs")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_report)
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if args.command is None:
        print(f"usage: {PROG} [-h] SUBCOMMAND ...", file=sys.stderr)
        return 2
    try:
        args.func(args)
    except ToolError as exc:
        print(f"{PROG}: {exc}", file=sys.stderr)
        return 1
    except KeyError as exc:
        print(f"{PROG}: missing key {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
