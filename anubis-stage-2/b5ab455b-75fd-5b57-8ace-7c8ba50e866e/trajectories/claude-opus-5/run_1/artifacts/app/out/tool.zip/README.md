# task-ctl

This local stdlib-only CLI builds, seals, checks and reports a flat JSON
configuration for TASK processing, and derives environment profiles from it.

Every document it writes is canonical JSON: keys sorted by code point at
every depth, no whitespace between tokens, raw UTF-8 for non-ASCII, and one
trailing newline. Input files may carry a UTF-8 byte order mark and may name
a key twice, in which case the first occurrence counts. Integers are exact at
any size. A document is sealed with a trailer whose digest is the CRC-32 of
the canonical encoding of the document without its trailer, in 16 lowercase
hexadecimal digits.

Commands:

```bash
python3 cli.py init --schema schema.json --defaults defaults.json --out config.json
python3 cli.py set --config config.json --key max_records --value 100
python3 cli.py seal --config config.json
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py profile --config config.json --overrides env_overrides.json --samples . --name dev --out profile_dev.json
python3 cli.py export-report --config config.json --commands commands.json --repairs repairs.json --out report.json
```
