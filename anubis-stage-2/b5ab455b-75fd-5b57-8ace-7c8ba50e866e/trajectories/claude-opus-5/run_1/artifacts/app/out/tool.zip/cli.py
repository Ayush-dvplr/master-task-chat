#!/usr/bin/env python3
"""task-ctl: build, seal, check and report flat TASK configurations."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zlib
from pathlib import Path

PROG = "task-ctl"
TRAILER_PREFIX = "harbor:cli-config"
NUMERIC_KEYS = ("max_records", "retry_limit", "timeout_ms")
IDENTITY_KEYS = ("producer", "container", "checksum", "mode")
INTEGER_TEXT = re.compile(r"\A-?(?:0|[1-9][0-9]*)\Z")


class ToolError(Exception):
    """A clean, reportable failure."""


def first_occurrence(pairs):
    doc = {}
    for key, value in pairs:
        if key not in doc:
            doc[key] = value
    return doc


def decode_json(data, path):
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        raise ToolError(f"{path}: not valid UTF-8")
    try:
        return json.loads(text, object_pairs_hook=first_occurrence)
    except ValueError as exc:
        raise ToolError(f"{path}: invalid JSON: {exc}")


def read_bytes(path):
    try:
        return Path(path).read_bytes()
    except OSError as exc:
        raise ToolError(f"cannot read {path}: {exc.strerror}")


def load_json(path):
    return decode_json(read_bytes(path), path)


def load_object(path):
    doc = load_json(path)
    if not isinstance(doc, dict):
        raise ToolError(f"{path}: expected a JSON object")
    return doc


def encode(doc):
    text = json.dumps(doc, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return (text + "\n").encode("utf-8")


def write_document(path, doc):
    try:
        Path(path).write_bytes(encode(doc))
    except OSError as exc:
        raise ToolError(f"cannot write {path}: {exc.strerror}")


def digest(doc):
    body = {key: value for key, value in doc.items() if key != "trailer"}
    return f"{zlib.crc32(encode(body)):016x}"


def config_trailer(doc):
    return f"{TRAILER_PREFIX}:{doc['profile']}:{digest(doc)}"


def parse_integer(text):
    if not isinstance(text, str) or not INTEGER_TEXT.match(text):
        raise ToolError(f"not a base-10 integer: {text!r}")
    return int(text)


def require_string(doc, key, path):
    value = doc.get(key)
    if not isinstance(value, str):
        raise ToolError(f"{path}: {key} must be a string")
    return value


def require_integer(doc, key, path):
    value = doc.get(key)
    if not isinstance(value, int) or isinstance(value, bool):
        raise ToolError(f"{path}: {key} must be an integer")
    return value


def cmd_init(args):
    schema = load_object(args.schema)
    defaults = load_object(args.defaults)
    doc = {"profile": require_string(schema, "profile", args.schema)}
    for key in IDENTITY_KEYS:
        doc[key] = require_string(defaults, key, args.defaults)
    write_document(args.out, doc)


def cmd_set(args):
    if args.key not in NUMERIC_KEYS:
        raise ToolError(f"key must be one of {', '.join(NUMERIC_KEYS)}, not {args.key!r}")
    value = parse_integer(args.value)
    doc = load_object(args.config)
    doc[args.key] = value
    write_document(args.config, doc)


def cmd_seal(args):
    doc = load_object(args.config)
    doc.pop("trailer", None)
    require_string(doc, "profile", args.config)
    doc["trailer"] = config_trailer(doc)
    write_document(args.config, doc)
    print(doc["trailer"])


def required_keys(schema):
    keys = schema.get("required_keys")
    if isinstance(keys, str):
        keys = [part.strip() for part in keys.split(",") if part.strip()]
    if not isinstance(keys, list) or not all(isinstance(key, str) for key in keys):
        raise ToolError("schema required_keys must be a list or a comma-separated string")
    return keys


def cmd_validate(args):
    schema = load_object(args.schema)
    raw = read_bytes(args.config)
    doc = decode_json(raw, args.config)
    if not isinstance(doc, dict):
        raise ToolError(f"{args.config}: expected a JSON object")
    if raw != encode(doc):
        raise ToolError(f"{args.config}: not the canonical encoding of its content")
    keys = required_keys(schema)
    missing = [key for key in keys if key not in doc]
    if missing:
        raise ToolError("missing: " + ",".join(missing))
    extra = sorted(key for key in doc if key not in keys)
    if extra:
        raise ToolError("unexpected: " + ",".join(extra))
    if doc["profile"] != schema.get("profile"):
        raise ToolError(f"profile is {doc['profile']!r}, schema requires {schema.get('profile')!r}")
    for key in keys:
        if key in NUMERIC_KEYS:
            require_integer(doc, key, args.config)
        else:
            require_string(doc, key, args.config)
    if doc["trailer"] != config_trailer(doc):
        raise ToolError(f"{args.config}: trailer does not match its contents")
    print("ok")


def override_entry(overrides, name, path):
    entry = overrides.get(name)
    if entry is None:
        raise ToolError(f"{path}: no override entry named {name!r}")
    if not isinstance(entry, dict):
        raise ToolError(f"{path}: override entry {name!r} is not an object")
    return entry


def resolve_chain(overrides, name, path):
    chain = []
    seen = set()
    current = name
    while True:
        if current in seen:
            raise ToolError(f"{path}: extends cycle at {current!r}")
        seen.add(current)
        chain.append(current)
        parent = override_entry(overrides, current, path).get("extends")
        if parent is None:
            break
        if not isinstance(parent, str):
            raise ToolError(f"{path}: extends of {current!r} is not a name")
        current = parent
    chain.reverse()
    return chain


def entry_delta(entry, key, name, path):
    if key not in entry:
        return 0
    value = entry[key]
    if not isinstance(value, int) or isinstance(value, bool):
        raise ToolError(f"{path}: {key} of {name!r} is not an integer")
    return value


def sample_delta(samples, name):
    path = Path(samples) / f"sample_config_{name}.json"
    if not path.is_file():
        return 0
    sample = load_object(path)
    if "max_records_delta" not in sample:
        return 0
    value = sample["max_records_delta"]
    if not isinstance(value, int) or isinstance(value, bool):
        raise ToolError(f"{path}: max_records_delta is not an integer")
    return value


def cmd_profile(args):
    config = load_object(args.config)
    overrides = load_object(args.overrides)
    chain = resolve_chain(overrides, args.name, args.overrides)

    values = {key: require_integer(config, key, args.config) for key in NUMERIC_KEYS}
    identity = {key: require_string(config, key, args.config) for key in IDENTITY_KEYS}
    base_profile = require_string(config, "profile", args.config)
    trailer = require_string(config, "trailer", args.config)

    doc = None
    for name in chain:
        entry = override_entry(overrides, name, args.overrides)
        values["retry_limit"] += entry_delta(entry, "retry_limit_delta", name, args.overrides)
        values["timeout_ms"] += entry_delta(entry, "timeout_ms_delta", name, args.overrides)
        values["max_records"] += sample_delta(args.samples, name)
        if "mode" in entry:
            mode = entry["mode"]
            if not isinstance(mode, str):
                raise ToolError(f"{args.overrides}: mode of {name!r} is not a string")
            identity["mode"] = mode
        doc = dict(identity)
        doc.update(values)
        doc["profile"] = f"{base_profile}-{name}"
        doc["trailer"] = f"{trailer}:{name}:{digest(doc)}"
        trailer = doc["trailer"]
    write_document(args.out, doc)


def own_argv():
    return [sys.executable, str(Path(sys.argv[0]).resolve())] + sys.argv[1:]


def cmd_report(args):
    config_path = Path(args.config).resolve()
    raw = read_bytes(config_path)
    doc = decode_json(raw, config_path)
    if not isinstance(doc, dict):
        raise ToolError(f"{config_path}: expected a JSON object")

    commands = load_json(args.commands) if args.commands else []
    if not isinstance(commands, list) or not all(isinstance(item, dict) for item in commands):
        raise ToolError(f"{args.commands}: expected a list of command entries")
    repairs = load_json(args.repairs) if args.repairs else []
    if not isinstance(repairs, list) or not all(isinstance(item, str) for item in repairs):
        raise ToolError(f"{args.repairs}: expected a list of strings")

    commands = [dict(item) for item in commands]
    commands.append({"argv": own_argv(), "returncode": 0, "stdout": ""})
    report = {
        "ok": all(item.get("returncode") == 0 for item in commands),
        "tool": PROG,
        "config_path": str(config_path),
        "config_sha256": hashlib.sha256(raw).hexdigest(),
        "trailer": require_string(doc, "trailer", config_path),
        "commands": commands,
        "repairs": repairs,
    }
    write_document(args.out, report)


def build_parser():
    parser = argparse.ArgumentParser(prog=PROG)
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init", help="seed a configuration from a schema and defaults")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="store one numeric base value")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("seal", help="compute and store the trailer")
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_seal)

    p = sub.add_parser("validate", help="check a configuration against a schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("profile", help="derive an environment profile")
    p.add_argument("--config", required=True)
    p.add_argument("--overrides", required=True)
    p.add_argument("--samples", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_profile)

    p = sub.add_parser("export-report", help="write the run report")
    p.add_argument("--config", required=True)
    p.add_argument("--commands")
    p.add_argument("--repairs")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_report)
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_usage(sys.stderr)
        return 2
    try:
        args.func(args)
    except (ToolError, OSError) as exc:
        message = " ".join(str(exc).split())
        sys.stderr.write(f"{PROG}: {message}\n")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
