# sealb-ctl

Offline, standard-library-only security policy compiler for the Ironvault
sealing service. It creates, updates, validates, reports, and compiles a flat
JSON security posture, exactly as written in `/app/data/config_contract.md`.

Subcommands:

```bash
python3 cli.py init --schema schema.json --out config.json
python3 cli.py set --config config.json --key max_sessions --value 100
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py plan --data /app/data --env base
python3 cli.py compile --data /app/data --out /app/out
python3 cli.py export-report --config config.json --out report.json --digest <sha256> --commands <json>
```

- `init` seeds the flat configuration from the schema.
- `set` assigns one key to a scalar value, keeping the configuration flat.
- `validate` checks the required keys and flatness against the tool schema.
- `plan` prints the fully resolved policy document for one environment,
  replaying the valid journal operations for that environment in `seq` order.
- `compile` reads the evidence corpora and writes every derived artifact.
- `export-report` records the command transcript and the config digest.

A row of evidence is counted only when its zone is exactly one of the active
zones, its flag is exactly the token `active`, its value is a canonical base-10
integer on the exact field bytes, and the integer lies inside the corpus bound
with the effective upper bound `hi + (rekey_interval_s mod 97) + (rejected mod
31)`. Each wire-format reader strips only the padding its own syntax imposes
(fixed columns, the spaces around `=` in `ini`, the spaces inside the pipes of a
Markdown table); every other field is judged byte-literally.

The tool schema stores `required_keys` as one comma-separated string; the
sidecar schema in `/app/data` stores the same list as a JSON array. The tool
consumes its own schema.

Every JSON artifact is written with `json.dumps(obj, sort_keys=True,
indent=2, separators=(",", ": "), ensure_ascii=False)` plus one trailing
newline, so repeated runs on the same inputs are byte-identical.
