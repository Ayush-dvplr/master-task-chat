#!/usr/bin/env python3
"""sealb-ctl: offline deterministic security policy compiler.

Implements the derivation contract in ``config_contract.md`` using only the
Python standard library. Every emitted byte is derived from the files under the
input data directory; nothing is fixed by the tool and no wall-clock time,
random state or dict ordering leaks into any artifact.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

TOOL = "sealb-ctl"

JOURNAL_NAME = "change_journal.jsonl"
DEFAULTS_NAME = "defaults.json"
SCHEMA_NAME = "config_schema.json"
RULES_NAME = "validation_rules.json"
OVERRIDES_NAME = "env_overrides.json"

INT_KEYS = ("max_sessions", "retry_budget", "handshake_timeout_ms", "rekey_interval_s")

CORPUS_SPECS = (
    ("c01_cve_severity.csv", "csv", "max", 1, 500),
    ("c02_cipher_grade.tsv", "tsv", "min", 2, 517),
    ("c03_port_exposure.psv", "psv", "sum", 3, 534),
    ("c04_tls_versions.scsv", "scsv", "count", 4, 551),
    ("c05_key_age_days.colon", "colon", "last", 5, 568),
    ("c06_iam_priv_level.ssv", "ssv", "first", 1, 585),
    ("c07_mfa_factor_count.caret", "caret", "max", 2, 602),
    ("c08_patch_lag_hours.at", "at", "min", 3, 619),
    ("c09_firewall_hits.dcolon", "dcolon", "sum", 4, 636),
    ("c10_cert_days_left.bang", "bang", "count", 5, 653),
    ("c11_session_ttl.tilde", "tilde", "last", 1, 670),
    ("c12_rate_budget.json", "jsonarr", "first", 2, 687),
    ("c13_scope_bits.jsonl", "jsonl", "max", 3, 704),
    ("c14_audit_gap_min.xml", "xmlflat", "min", 4, 721),
    ("c15_sudo_grants.nxml", "xmlnest", "sum", 5, 738),
    ("c16_ssh_keybits.ini", "ini", "count", 1, 755),
    ("c17_kms_rotations.fixed", "fixed", "last", 2, 772),
    ("c18_acl_depth.md", "mdtable", "first", 3, 789),
    ("c19_quota_caps.kv", "kvline", "max", 4, 806),
    ("c20_login_fails.properties", "props", "min", 5, 823),
    ("c21_privilege_escal.csv", "csv", "sum", 1, 840),
    ("c22_dns_ttl_sec.tsv", "tsv", "count", 2, 857),
    ("c23_backup_age_hrs.psv", "psv", "last", 3, 874),
    ("c24_vuln_count.scsv", "scsv", "first", 4, 891),
    ("c25_handshake_ms.colon", "colon", "max", 5, 908),
    ("c26_nonce_reuse.ssv", "ssv", "min", 1, 925),
    ("c27_hsts_max_age.caret", "caret", "sum", 2, 942),
    ("c28_cookie_ttl.at", "at", "count", 3, 959),
    ("c29_jwt_exp_min.dcolon", "dcolon", "last", 4, 976),
    ("c30_replay_window.bang", "bang", "first", 5, 993),
    ("c31_entropy_bits.tilde", "tilde", "max", 1, 1010),
    ("c32_salt_rounds.json", "jsonarr", "min", 2, 1027),
    ("c33_cidr_size.jsonl", "jsonl", "sum", 3, 1044),
    ("c34_egress_ports.xml", "xmlflat", "count", 4, 1061),
    ("c35_ingress_ports.nxml", "xmlnest", "last", 5, 1078),
    ("c36_trust_score.ini", "ini", "first", 1, 1095),
    ("c37_risk_weight.fixed", "fixed", "max", 2, 1112),
    ("c38_drift_count.md", "mdtable", "min", 3, 1129),
    ("c39_seal_depth.kv", "kvline", "sum", 4, 1146),
    ("c40_vault_leases.properties", "props", "count", 5, 1163),
    ("c41_rotation_days.csv", "csv", "last", 1, 1180),
    ("c42_throttle_rps.tsv", "tsv", "first", 2, 1197),
    ("c43_ban_minutes.psv", "psv", "max", 3, 1214),
    ("c44_cap_drops.scsv", "scsv", "min", 4, 1231),
    ("c45_syscall_allow.colon", "colon", "sum", 5, 1248),
    ("c46_namespace_ct.ssv", "ssv", "count", 1, 1265),
    ("c47_cgroup_limit.caret", "caret", "last", 2, 1282),
    ("c48_seccomp_rules.at", "at", "first", 3, 1299),
    ("c49_apparmor_hits.dcolon", "dcolon", "max", 4, 9007199254740993),
    ("c50_oauth_scopes.bang", "bang", "min", 5, 1333),
)


# ---------------------------------------------------------------------------
# canonical serialization
# ---------------------------------------------------------------------------

def dumps(obj):
    """The one serialization used for every JSON artifact."""
    return json.dumps(
        obj, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False
    ) + "\n"


def write_json(path, obj):
    Path(path).write_bytes(dumps(obj).encode("utf-8"))


def write_bytes(path, data):
    Path(path).write_bytes(data)


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_text(path):
    return Path(path).read_text(encoding="utf-8")


def is_scalar(value):
    return not isinstance(value, (dict, list))


def is_scalar_flat(mapping):
    return isinstance(mapping, dict) and all(is_scalar(v) for v in mapping.values())


def is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


# ---------------------------------------------------------------------------
# corpus reading
# ---------------------------------------------------------------------------

def canonical_int(field):
    """True when the exact field bytes are a canonical base-10 integer."""
    if not isinstance(field, str) or field == "":
        return False
    for ch in field:
        if ch not in "0123456789":
            return False
    if len(field) > 1 and field[0] == "0":
        return False
    return True


def _line_records(text, sep, header):
    """Slice line-oriented formats; blank and ``#`` lines are skipped."""
    rows = []
    for line in text.split("\n"):
        if line.strip() == "":
            continue
        if line.lstrip().startswith("#"):
            continue
        if header:
            header = False
            continue
        fields = line.split(sep)
        if len(fields) != 3:
            continue
        rows.append((fields[0], fields[1], fields[2]))
    return rows


def _ssv_records(text, header):
    """``ssv``: three fields separated by runs of spaces, with a header."""
    rows = []
    for line in text.split("\n"):
        if line.strip() == "":
            continue
        if line.lstrip().startswith("#"):
            continue
        if header:
            header = False
            continue
        fields = line.split(" ")
        if len(fields) != 3:
            continue
        rows.append((fields[0], fields[1], fields[2]))
    return rows


def _json_scalar(field):
    """A JSON integer is canonical; other JSON types are judged as strings."""
    if is_int(field):
        return str(field)
    if isinstance(field, str):
        return field
    return None


def _jsonarr_records(path):
    rows = []
    for item in json.loads(read_text(path)):
        if not isinstance(item, dict):
            continue
        if not {"zone", "value", "flag"} <= set(item):
            continue
        value = _json_scalar(item.get("value"))
        if value is None:
            continue
        rows.append((item.get("zone"), value, item.get("flag")))
    return rows


def _jsonl_records(path):
    rows = []
    for line in read_text(path).split("\n"):
        if line.strip() == "":
            continue
        if line.lstrip().startswith("//"):
            continue
        item = json.loads(line)
        if not isinstance(item, dict):
            continue
        if not {"zone", "value", "flag"} <= set(item):
            continue
        value = _json_scalar(item.get("value"))
        if value is None:
            continue
        rows.append((item.get("zone"), value, item.get("flag")))
    return rows


def _xmlflat_records(path):
    rows = []
    for node in ET.parse(str(path)).getroot():
        if node.tag != "row":
            continue
        rows.append((node.get("zone"), node.get("value"), node.get("flag")))
    return rows


def _xmlnest_records(path):
    rows = []
    for node in ET.parse(str(path)).getroot():
        if node.tag != "row":
            continue
        child = {}
        for sub in node:
            child[sub.tag] = sub.text
        if not {"zone", "value", "flag"} <= set(child):
            continue
        rows.append((child["zone"], child["value"], child["flag"]))
    return rows


def _ini_records(path):
    """One ``[rNNNN]`` section per row with ``zone``, ``value``, ``flag`` keys.

    The layout is ``key = value``: one space each side of the ``=`` is layout,
    anything beyond it is field data and is judged byte-literally.
    """
    rows = []
    current = None
    for line in read_text(path).split("\n"):
        if line.strip() == "" or line.lstrip().startswith("#"):
            continue
        if line.startswith("["):
            if current is not None and len(current) == 3:
                rows.append((current["zone"], current["value"], current["flag"]))
            current = {}
            continue
        if current is None or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.rstrip(" ")
        if value.startswith(" "):
            value = value[1:]
        current[key] = value
    if current is not None and len(current) == 3:
        rows.append((current["zone"], current["value"], current["flag"]))
    return rows


def _fixed_records(path):
    """Fixed columns: zone 0-10, value 10-30, flag from 30.

    The columns are left-justified, so trailing space padding is layout and
    leading bytes are field data.
    """
    rows = []
    for line in read_text(path).split("\n"):
        if line.strip() == "" or line.lstrip().startswith("#"):
            continue
        if len(line) < 30:
            continue
        rows.append((line[0:10].rstrip(" "), line[10:30].rstrip(" "), line[30:].rstrip(" ")))
    return rows


def _mdtable_records(path):
    """A Markdown table: ``| zone | value | flag |`` header plus a rule row.

    One space inside each pair of pipes is layout; anything beyond it is field
    data and is judged byte-literally.
    """
    rows = []
    seen_header = False
    seen_rule = False
    for line in read_text(path).split("\n"):
        if line.strip() == "" or line.lstrip().startswith("#"):
            continue
        if not line.startswith("|"):
            continue
        cells = line.rstrip("\r\n").strip("|").split("|")
        if not seen_header:
            seen_header = True
            continue
        if not seen_rule:
            seen_rule = True
            continue
        if len(cells) != 3:
            continue
        fields = []
        for cell in cells:
            if cell.startswith(" "):
                cell = cell[1:]
            if cell.endswith(" "):
                cell = cell[:-1]
            fields.append(cell)
        rows.append((fields[0], fields[1], fields[2]))
    return rows


def _kvline_records(path):
    rows = []
    for line in read_text(path).split("\n"):
        if line.strip() == "":
            continue
        if line.lstrip().startswith("#"):
            continue
        fields = line.split()
        if len(fields) != 3:
            continue
        row = {}
        for token in fields:
            if "=" not in token:
                row = None
                break
            key, value = token.split("=", 1)
            row[key] = value
        if row is None or not {"zone", "value", "flag"} <= set(row):
            continue
        rows.append((row["zone"], row["value"], row["flag"]))
    return rows


def _props_records(path):
    rows = {}
    order = []
    for line in read_text(path).split("\n"):
        if line.strip() == "":
            continue
        if line.lstrip().startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        if "." not in key:
            continue
        rid, field = key.split(".", 1)
        if rid not in rows:
            rows[rid] = {}
            order.append(rid)
        rows[rid][field] = value
    result = []
    for rid in order:
        item = rows[rid]
        if not {"zone", "value", "flag"} <= set(item):
            continue
        result.append((item["zone"], item["value"], item["flag"]))
    return result


def read_corpus_rows(path, fmt):
    text = read_text(path)
    if fmt == "csv":
        return _line_records(text, ",", True)
    if fmt == "tsv":
        return _line_records(text, "\t", True)
    if fmt in ("psv", "scsv", "colon", "caret", "at", "bang", "tilde", "dcolon"):
        sep = {
            "psv": "|",
            "scsv": ";",
            "colon": ":",
            "caret": "^",
            "at": "@",
            "bang": "!",
            "tilde": "~",
            "dcolon": "::",
        }[fmt]
        return _line_records(text, sep, False)
    if fmt == "ssv":
        return _ssv_records(text, True)
    if fmt == "jsonarr":
        return _jsonarr_records(path)
    if fmt == "jsonl":
        return _jsonl_records(path)
    if fmt == "xmlflat":
        return _xmlflat_records(path)
    if fmt == "xmlnest":
        return _xmlnest_records(path)
    if fmt == "ini":
        return _ini_records(path)
    if fmt == "fixed":
        return _fixed_records(path)
    if fmt == "mdtable":
        return _mdtable_records(path)
    if fmt == "kvline":
        return _kvline_records(path)
    if fmt == "props":
        return _props_records(path)
    raise SystemExit("unsupported corpus format: " + fmt)


# ---------------------------------------------------------------------------
# journal replay
# ---------------------------------------------------------------------------

def load_policy_inputs(data_dir):
    data = Path(data_dir)
    return (
        load_json(data / DEFAULTS_NAME),
        load_json(data / SCHEMA_NAME),
        load_json(data / RULES_NAME),
        load_json(data / OVERRIDES_NAME),
    )


def load_journal(data_dir):
    ops = []
    for line in read_text(Path(data_dir) / JOURNAL_NAME).split("\n"):
        if line.strip() == "":
            continue
        ops.append(json.loads(line))
    return ops


def op_is_valid(op, rules):
    if not isinstance(op, dict):
        return False
    if op.get("env") not in rules["journal_envs"]:
        return False
    if op.get("op") not in ("set", "unset"):
        return False
    key = op.get("key")
    if key in INT_KEYS:
        if op["op"] == "unset":
            return True
        value = op.get("value")
        if not is_int(value):
            return False
        low, high = rules["bounds"][key]
        return low <= value <= high
    if key == "mode":
        if op["op"] == "unset":
            return True
        value = op.get("value")
        if not isinstance(value, str):
            return False
        return value in rules["allowed_modes"]
    return False


def journal_validity(ops, rules):
    """Return the valid operations and the ascending seq of rejected ones."""
    valid = [op for op in ops if op_is_valid(op, rules)]
    rejected = sorted(op.get("seq") for op in ops if not op_is_valid(op, rules))
    return valid, rejected


def replay_environment(base, valid_ops, env, defaults):
    """Apply every valid operation of ``env`` in ascending seq order."""
    state = dict(base)
    for op in sorted(
        (op for op in valid_ops if op.get("env") == env), key=lambda o: o["seq"]
    ):
        key = op["key"]
        if op["op"] == "set":
            state[key] = op["value"]
        else:
            if key in INT_KEYS:
                state[key] = defaults["base_config"][key]
            else:
                state[key] = defaults["mode"]
    return state


def build_spine(defaults, schema, valid_ops):
    """The finished scalar-flat spine configuration."""
    cfg = {
        "max_sessions": defaults["base_config"]["max_sessions"],
        "retry_budget": defaults["base_config"]["retry_budget"],
        "handshake_timeout_ms": defaults["base_config"]["handshake_timeout_ms"],
        "rekey_interval_s": defaults["base_config"]["rekey_interval_s"],
        "trailer": defaults["base_config"]["trailer"],
        "checksum": defaults["checksum"],
        "mode": defaults["mode"],
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
    }
    return replay_environment(cfg, valid_ops, "base", defaults)


def build_profile(spine, valid_ops, zone, defaults, overrides):
    cfg = dict(spine)
    cfg["retry_budget"] = spine["retry_budget"] + overrides[zone]["retry_budget_delta"]
    cfg["handshake_timeout_ms"] = (
        spine["handshake_timeout_ms"] + overrides[zone]["handshake_timeout_ms_delta"]
    )
    cfg["rekey_interval_s"] = (
        spine["rekey_interval_s"] + overrides[zone]["rekey_interval_s_delta"]
    )
    cfg["mode"] = overrides[zone]["mode"]
    cfg["profile"] = spine["profile"] + "-" + zone
    cfg["trailer"] = spine["trailer"] + ":" + zone
    return replay_environment(cfg, valid_ops, zone, defaults)


# ---------------------------------------------------------------------------
# corpus aggregation
# ---------------------------------------------------------------------------

def effective_hi(published_hi, rekey_interval_s, rejected_count):
    """hi + (R mod 97) + (J mod 31) over the replayed spine."""
    return published_hi + (rekey_interval_s % 97) + (rejected_count % 31)


def apply_op(op, values):
    if op == "count":
        return len(values)
    if op == "max":
        return max(values) if values else 0
    if op == "min":
        return min(values) if values else 0
    if op == "sum":
        return sum(values) if values else 0
    if op == "first":
        return values[0] if values else 0
    if op == "last":
        return values[-1] if values else 0
    raise SystemExit("unsupported operator: " + op)


def compile_corpora(data_dir, spine, rejected_count, rules):
    """Read, filter and aggregate every corpus.

    The eligibility rule uses the effective upper bound, ``published hi +
    (rekey_interval_s mod 97) + (rejected_count mod 31)``; the corpus index
    records the published bounds that the contract pairs with the corpus.
    """
    zones = rules["zones"]
    rekey_interval_s = spine["rekey_interval_s"]
    results = []
    for spec in CORPUS_SPECS:
        name, fmt, op, published_lo, published_hi = spec
        published = rules["corpus_bounds"].get(name.rsplit(".", 1)[0])
        low = published[0] if published else published_lo
        high = published[1] if published else published_hi
        effective = effective_hi(high, rekey_interval_s, rejected_count)
        counted = []
        zone_rows = {zone: 0 for zone in zones}
        for zone, value, flag in read_corpus_rows(Path(data_dir) / name, fmt):
            if zone not in zones:
                continue
            if flag != "active":
                continue
            if not canonical_int(value):
                continue
            number = int(value)
            if number < low or number > effective:
                continue
            counted.append(number)
            zone_rows[zone] += 1
        results.append(
            {
                "name": name,
                "format": fmt,
                "op": op,
                "lo": low,
                "hi": high,
                "eligible_rows": len(counted),
                "value": apply_op(op, counted),
                "zone_rows": zone_rows,
            }
        )
    return results


# ---------------------------------------------------------------------------
# ancillary aggregate formats
# ---------------------------------------------------------------------------

def aggregate_table_bytes(aggregates, delimiter):
    buffer = io.StringIO()
    writer = csv.writer(buffer, delimiter=delimiter, lineterminator="\n")
    writer.writerow(["corpus", "value"])
    for name in sorted(aggregates):
        writer.writerow([name, str(aggregates[name])])
    return buffer.getvalue().encode("utf-8")


def aggregate_xml_bytes(aggregates):
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', "<aggregates>"]
    for name in sorted(aggregates):
        escaped = (
            name.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        )
        lines.append(
            '  <aggregate corpus="' + escaped + '">' + str(aggregates[name]) + "</aggregate>"
        )
    lines.append("</aggregates>")
    return ("\n".join(lines) + "\n").encode("utf-8")


def aggregate_ini_bytes(aggregates):
    buffer = io.StringIO()
    for name in sorted(aggregates):
        buffer.write("[" + name.replace("%", "%%") + "]\n")
        buffer.write("value = " + str(aggregates[name]) + "\n")
    return buffer.getvalue().encode("utf-8")


def aggregate_env_bytes(aggregates):
    return "".join(
        name.upper() + "=" + str(aggregates[name]) + "\n" for name in sorted(aggregates)
    ).encode("utf-8")


def aggregate_md_bytes(aggregates):
    lines = ["| corpus | value |", "| --- | --- |"]
    for name in sorted(aggregates):
        lines.append("| " + name + " | " + str(aggregates[name]) + " |")
    return ("\n".join(lines) + "\n").encode("utf-8")


def aggregate_txt_bytes(aggregates):
    return "".join(
        name + " " + str(aggregates[name]) + "\n" for name in sorted(aggregates)
    ).encode("utf-8")


# ---------------------------------------------------------------------------
# subcommands
# ---------------------------------------------------------------------------

def cmd_init(args):
    """Seed a flat configuration from the schema's required keys.

    Only the scalar identity keys come from the schema; the policy keys are
    seeded from the sidecar defaults, which is where the contract puts them.
    """
    schema = load_json(args.schema)
    defaults = {}
    if getattr(args, "data", None):
        sidecar = load_json(Path(args.data) / DEFAULTS_NAME)
        defaults.update(sidecar["base_config"])
        defaults["checksum"] = sidecar["checksum"]
        defaults["mode"] = sidecar["mode"]
        defaults["trailer"] = sidecar["base_config"]["trailer"]
    for key in ("profile", "producer", "container"):
        if key in schema:
            defaults[key] = schema[key]
    for key in ("max_sessions", "retry_budget", "handshake_timeout_ms",
                "rekey_interval_s", "checksum", "mode", "trailer"):
        defaults.setdefault(key, schema.get(key))
    required = schema["required_keys"]
    if isinstance(required, str):
        required = required.split(",")
    out = {}
    for key in required:
        if defaults.get(key) is not None:
            out[key] = defaults[key]
        else:
            raise SystemExit("schema has no value for required key: " + key)
    write_json(args.out, out)
    print("wrote " + args.out)


def cmd_set(args):
    data = load_json(args.config)
    value = args.value
    if isinstance(value, str) and re.fullmatch(r"-?\d+", value):
        value = int(value)
    data[args.key] = value
    if not is_scalar_flat(data):
        raise SystemExit("configuration must be flat")
    write_json(args.config, data)
    print("set " + args.key)


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    required = schema["required_keys"]
    if isinstance(required, str):
        required = required.split(",")
    missing = [key for key in required if key not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if not is_scalar_flat(data):
        raise SystemExit("configuration must be flat")
    print("ok")


def cmd_plan(args):
    defaults, schema, rules, overrides = load_policy_inputs(args.data)
    ops = load_journal(args.data)
    valid, _rejected = journal_validity(ops, rules)
    spine = build_spine(defaults, schema, valid)
    if args.env == "base":
        cfg = spine
    else:
        cfg = build_profile(spine, valid, args.env, defaults, overrides)
    sys.stdout.write(dumps(cfg))
    return 0


def cmd_compile(args):
    data_dir = Path(args.data)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    defaults, schema, rules, overrides = load_policy_inputs(data_dir)
    ops = load_journal(data_dir)
    valid, rejected = journal_validity(ops, rules)
    spine = build_spine(defaults, schema, valid)
    write_json(out_dir / "config.json", spine)

    for zone in rules["zones"]:
        write_json(out_dir / ("profile_" + zone + ".json"),
                   build_profile(spine, valid, zone, defaults, overrides))

    write_json(
        out_dir / "rejected_ops.json", {"rejected": rejected, "count": len(rejected)}
    )

    results = compile_corpora(data_dir, spine, len(rejected), rules)
    aggregates = {result["name"]: result["value"] for result in results}
    write_json(out_dir / "aggregates.json", aggregates)
    write_bytes(out_dir / "aggregates.csv", aggregate_table_bytes(aggregates, ","))
    write_bytes(out_dir / "aggregates.tsv", aggregate_table_bytes(aggregates, "\t"))
    write_bytes(out_dir / "aggregates.xml", aggregate_xml_bytes(aggregates))
    write_bytes(out_dir / "aggregates.ini", aggregate_ini_bytes(aggregates))
    write_bytes(out_dir / "aggregates.env", aggregate_env_bytes(aggregates))
    write_bytes(out_dir / "aggregates.md", aggregate_md_bytes(aggregates))
    write_bytes(out_dir / "aggregates.txt", aggregate_txt_bytes(aggregates))

    zone_totals = {zone: 0 for zone in rules["zones"]}
    for result in results:
        for zone in zone_totals:
            zone_totals[zone] += result["zone_rows"][zone]
    write_json(out_dir / "zone_totals.json", zone_totals)

    write_json(
        out_dir / "corpus_index.json",
        {
            "count": len(results),
            "corpora": [
                {
                    "name": result["name"],
                    "format": result["format"],
                    "op": result["op"],
                    "lo": result["lo"],
                    "hi": result["hi"],
                    "eligible_rows": result["eligible_rows"],
                    "value": result["value"],
                }
                for result in results
            ],
        },
    )

    aggregate_total = sum(result["value"] for result in results)
    max_corpus = None
    max_value = None
    for name in sorted(aggregates):
        if max_corpus is None or aggregates[name] > max_value:
            max_corpus = name
            max_value = aggregates[name]
    nonzero_corpora = sum(1 for name in aggregates if aggregates[name] != 0)
    write_json(
        out_dir / "posture.json",
        {
            "aggregate_total": aggregate_total,
            "corpus_count": len(aggregates),
            "max_corpus": max_corpus,
            "max_value": max_value,
            "nonzero_corpora": nonzero_corpora,
        },
    )

    print("compiled " + str(len(results)) + " corpora")
    return 0


def cmd_export_report(args):
    config_path = Path(args.config)
    commands = load_json(args.commands) if args.commands else []
    digest = args.digest if args.digest else sha256_file(config_path)
    write_json(
        args.out,
        {
            "ok": True,
            "tool": TOOL,
            "config_path": str(config_path),
            "config_sha256": digest,
            "trailer": load_json(config_path)["trailer"],
            "commands": commands,
        },
    )
    print("wrote " + args.out)
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(prog=TOOL)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--data")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("plan")
    p.add_argument("--data", required=True)
    p.add_argument("--env", default="base")
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("compile")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest")
    p.add_argument("--commands")
    p.set_defaults(func=cmd_export_report)

    args = parser.parse_args(argv)
    return args.func(args) or 0


if __name__ == "__main__":
    sys.exit(main())
