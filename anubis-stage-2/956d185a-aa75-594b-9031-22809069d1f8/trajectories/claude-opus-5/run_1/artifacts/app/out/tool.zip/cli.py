#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

TOOL_NAME = "sealb-ctl"
INT_KEYS = ("max_sessions", "retry_budget", "handshake_timeout_ms", "rekey_interval_s")
DELTA_KEYS = ("retry_budget", "handshake_timeout_ms", "rekey_interval_s")
ZIP_DATE = (1980, 1, 1, 0, 0, 0)
ZIP_ATTR = 0o100644 << 16


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dumps(data):
    return json.dumps(
        data, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False
    ) + "\n"


def write_json(path, data):
    Path(path).write_text(dumps(data), encoding="utf-8")


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def is_canonical_int(text):
    if not isinstance(text, str):
        return False
    try:
        return str(int(text)) == text
    except (TypeError, ValueError):
        return False


def scalarize(raw):
    return int(raw) if is_canonical_int(raw) else raw


def is_flat(data):
    return not any(isinstance(value, (dict, list)) for value in data.values())


# --------------------------------------------------------------------------
# spine / profile derivation
# --------------------------------------------------------------------------


class Policy:
    def __init__(self, data_dir):
        self.data = Path(data_dir)
        self.defaults = load_json(self.data / "defaults.json")
        self.schema = load_json(self.data / "config_schema.json")
        self.rules = load_json(self.data / "validation_rules.json")
        self.overrides = load_json(self.data / "env_overrides.json")
        self.journal = self._load_journal()
        self.rejected = [r["seq"] for r in self.journal if not self._valid(r)]

    def _load_journal(self):
        text = (self.data / "change_journal.jsonl").read_text(encoding="utf-8")
        records = [json.loads(line) for line in text.splitlines() if line.strip()]
        records.sort(key=lambda record: record["seq"])
        return records

    def _valid(self, record):
        if record.get("env") not in self.rules["journal_envs"]:
            return False
        key = record.get("key")
        bounds = self.rules["bounds"]
        if key != "mode" and key not in bounds:
            return False
        op = record.get("op")
        if op == "unset":
            return True
        if op != "set":
            return False
        value = record.get("value")
        if key == "mode":
            return isinstance(value, str) and value in self.rules["allowed_modes"]
        if isinstance(value, bool) or not isinstance(value, int):
            return False
        low, high = bounds[key]
        return low <= value <= high

    def _default_of(self, key):
        if key == "mode":
            return self.defaults["mode"]
        return self.defaults["base_config"][key]

    def _replay(self, config, env):
        for record in self.journal:
            if record.get("env") != env or not self._valid(record):
                continue
            key = record["key"]
            if record["op"] == "set":
                config[key] = record["value"]
            else:
                config[key] = self._default_of(key)
        return config

    def seed(self):
        base = self.defaults["base_config"]
        config = {
            "profile": self.schema["profile"],
            "producer": self.schema["producer"],
            "container": self.schema["container"],
            "checksum": self.defaults["checksum"],
            "mode": self.defaults["mode"],
            "trailer": base["trailer"],
        }
        for key in INT_KEYS:
            config[key] = base[key]
        return config

    def spine(self):
        return self._replay(self.seed(), "base")

    def profile(self, zone):
        spine = self.spine()
        override = self.overrides[zone]
        config = dict(spine)
        for key in DELTA_KEYS:
            config[key] = spine[key] + override[key + "_delta"]
        config["mode"] = override["mode"]
        config["profile"] = "%s-%s" % (spine["profile"], zone)
        config["trailer"] = "%s:%s" % (spine["trailer"], zone)
        return self._replay(config, zone)

    @property
    def zones(self):
        return list(self.rules["zones"])

    def shift(self):
        return self.spine()["rekey_interval_s"] % 97 + len(self.rejected) % 31


# --------------------------------------------------------------------------
# evidence corpora
# --------------------------------------------------------------------------

CHAR_SEPARATORS = {
    "csv": ",",
    "tsv": "\t",
    "psv": "|",
    "scsv": ";",
    "colon": ":",
    "caret": "^",
    "at": "@",
    "bang": "!",
    "tilde": "~",
    "dcolon": "::",
}
HEADER_FORMATS = {"csv", "tsv", "ssv", "fixed"}


def _data_lines(text, skip_header):
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    if skip_header and lines:
        lines = lines[1:]
    for line in lines:
        if not line.strip() or line.lstrip(" ").startswith("#"):
            continue
        yield line


def parse_corpus(path, fmt):
    """Return each logical row of a corpus as a byte-exact field list."""
    raw = Path(path).read_text(encoding="utf-8")
    rows = []

    if fmt in CHAR_SEPARATORS:
        separator = CHAR_SEPARATORS[fmt]
        for line in _data_lines(raw, fmt in HEADER_FORMATS):
            rows.append(line.split(separator))
    elif fmt == "ssv":
        for line in _data_lines(raw, True):
            rows.append(re.split(r" +", line))
    elif fmt == "jsonarr":
        for item in json.loads(raw):
            rows.append([item.get("zone"), item.get("value"), item.get("flag")])
    elif fmt == "jsonl":
        for line in raw.split("\n"):
            if not line.strip() or line.lstrip(" ").startswith("//"):
                continue
            item = json.loads(line)
            rows.append([item.get("zone"), item.get("value"), item.get("flag")])
    elif fmt == "xmlflat":
        for row in ET.fromstring(raw):
            rows.append([row.get("zone"), row.get("value"), row.get("flag")])
    elif fmt == "xmlnest":
        for row in ET.fromstring(raw):
            fields = []
            for name in ("zone", "value", "flag"):
                node = row.find(name)
                fields.append("" if node is None or node.text is None else node.text)
            rows.append(fields)
    elif fmt == "ini":
        sections = []
        current = None
        for line in _data_lines(raw, False):
            if line.startswith("["):
                current = {}
                sections.append(current)
                continue
            if current is None or " = " not in line:
                continue
            key, value = line.split(" = ", 1)
            current[key] = value
        rows = [[s.get("zone"), s.get("value"), s.get("flag")] for s in sections]
    elif fmt == "fixed":
        for line in _data_lines(raw, True):
            rows.append([line[0:10].rstrip(" "), line[10:30].rstrip(" "), line[30:]])
    elif fmt == "mdtable":
        for line in _data_lines(raw, False):
            if not (line.startswith("| ") and line.endswith(" |")):
                continue
            rows.append(line[2:-2].split(" | "))
    elif fmt == "kvline":
        prefixes = ("zone=", "value=", "flag=")
        for line in _data_lines(raw, False):
            tokens = line.split(" ")
            if len(tokens) != 3 or not all(
                token.startswith(prefix) for token, prefix in zip(tokens, prefixes)
            ):
                continue
            rows.append([t[len(p):] for t, p in zip(tokens, prefixes)])
    elif fmt == "props":
        order = []
        groups = {}
        for line in _data_lines(raw, False):
            if "=" not in line:
                continue
            name, value = line.split("=", 1)
            if "." not in name:
                continue
            record, field = name.rsplit(".", 1)
            if record not in groups:
                groups[record] = {}
                order.append(record)
            groups[record][field] = value
        for record in order:
            group = groups[record]
            rows.append([group.get("zone"), group.get("value"), group.get("flag")])
    else:
        raise SystemExit("unknown corpus format: " + fmt)

    return rows


def counted_values(rows, zones, low, high):
    """Yield (zone, integer) for every row satisfying the eligibility rule."""
    for row in rows:
        if len(row) != 3:
            continue
        zone, value, flag = row
        if zone not in zones or flag != "active":
            continue
        if isinstance(value, bool):
            continue
        if isinstance(value, int):
            number = value
        elif is_canonical_int(value):
            number = int(value)
        else:
            continue
        if low <= number <= high:
            yield zone, number


def aggregate(op, values):
    if op == "count":
        return len(values)
    if not values:
        return 0
    if op == "max":
        return max(values)
    if op == "min":
        return min(values)
    if op == "sum":
        return sum(values)
    if op == "first":
        return values[0]
    if op == "last":
        return values[-1]
    raise SystemExit("unknown aggregation operator: " + op)


CORPUS_ROW = re.compile(
    r"^\|\s*(c\d{2}_[a-z_]+\.[a-z]+)\s*\|\s*(\S+)\s*\|\s*(\S+)\s*\|"
    r"\s*(-?\d+)\s*\|\s*(-?\d+)\s*\|$"
)


def corpus_table(data_dir):
    """Read the fifty corpus declarations straight out of the written contract."""
    text = (Path(data_dir) / "config_contract.md").read_text(encoding="utf-8")
    table = []
    for line in text.split("\n"):
        match = CORPUS_ROW.match(line.strip())
        if match:
            name, fmt, op, low, high = match.groups()
            table.append(
                {"name": name, "format": fmt, "op": op, "lo": int(low), "hi": int(high)}
            )
    if len(table) != 50:
        raise SystemExit("contract corpus table incomplete: %d rows" % len(table))
    return table


# --------------------------------------------------------------------------
# ancillary aggregate views
# --------------------------------------------------------------------------


def render_views(names, values):
    rows = [(name, values[name]) for name in names]
    return {
        "aggregates.csv": "".join(
            ["corpus,value\n"] + ["%s,%d\n" % row for row in rows]
        ),
        "aggregates.tsv": "".join(
            ["corpus\tvalue\n"] + ["%s\t%d\n" % row for row in rows]
        ),
        "aggregates.xml": "".join(
            ["<aggregates>\n"]
            + ['  <corpus name="%s" value="%d" />\n' % row for row in rows]
            + ["</aggregates>\n"]
        ),
        "aggregates.ini": "".join(
            ["[aggregates]\n"] + ["%s = %d\n" % row for row in rows]
        ),
        "aggregates.env": "".join("%s=%d\n" % (n.upper(), v) for n, v in rows),
        "aggregates.md": "".join(
            ["| corpus | value |\n", "| --- | --- |\n"]
            + ["| %s | %d |\n" % row for row in rows]
        ),
        "aggregates.txt": "".join("%s %d\n" % row for row in rows),
    }


def build_zip(source_dir, target):
    members = sorted(p for p in Path(source_dir).iterdir() if p.is_file())
    with zipfile.ZipFile(target, "w", zipfile.ZIP_STORED) as archive:
        for member in members:
            info = zipfile.ZipInfo(member.name, date_time=ZIP_DATE)
            info.external_attr = ZIP_ATTR
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, member.read_bytes())


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# --------------------------------------------------------------------------
# subcommands
# --------------------------------------------------------------------------


def cmd_init(args):
    schema = load_json(args.schema)
    data = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    write_json(args.out, data)
    print("init " + str(args.out))


def cmd_set(args):
    data = load_json(args.config)
    data[args.key] = scalarize(args.value)
    if not is_flat(data):
        raise SystemExit("configuration must be flat")
    write_json(args.config, data)
    print("set %s" % args.key)


def cmd_validate(args):
    schema = load_json(args.schema)
    data = load_json(args.config)
    required = schema["required_keys"]
    if isinstance(required, str):
        required = required.split(",")
    missing = [key for key in required if key not in data]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if not is_flat(data):
        raise SystemExit("configuration must be flat")
    print("ok")


def cmd_plan(args):
    policy = Policy(args.data)
    if args.env == "base":
        document = policy.spine()
    elif args.env in policy.zones:
        document = policy.profile(args.env)
    else:
        raise SystemExit("unknown environment: " + args.env)
    print(dumps(document), end="")


def cmd_compile(args):
    policy = Policy(args.data)
    data_dir = Path(args.data)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    commands = json.loads(args.commands)

    spine = policy.spine()
    zones = policy.zones
    zone_set = set(zones)
    shift = policy.shift()
    config = load_json(out / "config.json")

    values = {}
    index = []
    zone_totals = {zone: 0 for zone in zones}
    for entry in corpus_table(data_dir):
        rows = parse_corpus(data_dir / entry["name"], entry["format"])
        counted = list(
            counted_values(rows, zone_set, entry["lo"], entry["hi"] + shift)
        )
        for zone, _ in counted:
            zone_totals[zone] += 1
        numbers = [number for _, number in counted]
        value = aggregate(entry["op"], numbers)
        values[entry["name"]] = value
        record = dict(entry)
        record["eligible_rows"] = len(numbers)
        record["value"] = value
        index.append(record)

    names = sorted(values)
    aggregate_total = sum(values[name] for name in names)
    max_corpus = min(names, key=lambda name: (-values[name], name))

    profiles = {zone: policy.profile(zone) for zone in zones}
    artifacts = sorted(
        [
            "config.json",
            "aggregates.json",
            "aggregates.csv",
            "aggregates.tsv",
            "aggregates.xml",
            "aggregates.ini",
            "aggregates.env",
            "aggregates.md",
            "aggregates.txt",
            "corpus_index.json",
            "posture.json",
            "rejected_ops.json",
            "summary.json",
            "validation_report.json",
            "zone_totals.json",
        ]
        + ["profile_%s.json" % zone for zone in zones]
    )

    write_json(out / "aggregates.json", values)
    for filename, text in render_views(names, values).items():
        write_text(out / filename, text)
    write_json(out / "zone_totals.json", zone_totals)
    write_json(out / "corpus_index.json", {"count": len(index), "corpora": index})
    write_json(
        out / "posture.json",
        {
            "aggregate_total": aggregate_total,
            "corpus_count": len(names),
            "max_corpus": max_corpus,
            "max_value": values[max_corpus],
            "nonzero_corpora": sum(1 for name in names if values[name] != 0),
        },
    )
    write_json(
        out / "rejected_ops.json",
        {"rejected": policy.rejected, "count": len(policy.rejected)},
    )
    for zone in zones:
        write_json(out / ("profile_%s.json" % zone), profiles[zone])

    inputs = sorted(p.name for p in data_dir.iterdir() if p.is_file())
    write_json(
        out / "summary.json",
        {
            "tool": TOOL_NAME,
            "profile_tag": spine["profile"],
            "trailer": spine["trailer"],
            "profiles": sorted(zones),
            "artifacts": artifacts,
            "artifact_count": len(artifacts),
            "inputs": inputs,
            "input_count": len(inputs),
            "corpus_count": len(names),
            "aggregate_total": aggregate_total,
        },
    )

    report_path = out / "validation_report.json"
    report_path.write_bytes(b"")
    checks = {
        "all_artifacts_present": all((out / name).exists() for name in artifacts),
        "config_matches_policy": config == spine,
        "config_scalar_flat": is_flat(config),
        "command_failures": [
            command["argv"][1] for command in commands if command["returncode"] != 0
        ],
        "rejected_ops": policy.rejected,
        "profiles": {
            zone: {
                "scalar_flat": is_flat(profiles[zone]),
                "trailer": profiles[zone]["trailer"],
            }
            for zone in zones
        },
        "corpus_count": len(names),
        "aggregate_total": aggregate_total,
    }
    ok = (
        checks["all_artifacts_present"]
        and checks["config_matches_policy"]
        and checks["config_scalar_flat"]
        and not checks["command_failures"]
    )
    write_json(report_path, {"ok": ok, "checks": checks})

    build_zip(Path(__file__).resolve().parent, out / "tool.zip")
    write_text(
        out / "manifest.sha256",
        "".join(
            "%s  %s\n" % (sha256_file(out / name), name)
            for name in artifacts
            if name not in ("tool.zip", "report.json", "manifest.sha256")
        ),
    )
    print("compiled %d artifacts" % len(artifacts))


def cmd_report(args):
    config = load_json(args.config)
    commands = json.loads(args.commands)
    write_json(
        args.out,
        {
            "ok": all(command["returncode"] == 0 for command in commands),
            "tool": TOOL_NAME,
            "config_path": str(args.config),
            "config_sha256": args.digest,
            "trailer": config["trailer"],
            "commands": commands,
        },
    )
    print("report " + str(args.out))


def main():
    parser = argparse.ArgumentParser(prog=TOOL_NAME)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)
    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)
    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)
    p = sub.add_parser("plan")
    p.add_argument("--data", required=True)
    p.add_argument("--env", required=True)
    p.set_defaults(func=cmd_plan)
    p = sub.add_parser("compile")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--commands", default="[]")
    p.set_defaults(func=cmd_compile)
    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", default="[]")
    p.set_defaults(func=cmd_report)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
