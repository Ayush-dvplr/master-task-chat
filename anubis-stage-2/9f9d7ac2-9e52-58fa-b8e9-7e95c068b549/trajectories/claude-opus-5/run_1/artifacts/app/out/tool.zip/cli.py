#!/usr/bin/env python3
"""sealb-ctl -- offline, stdlib-only security policy compiler."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

TOOL_NAME = "sealb-ctl"
TOOL_DIR = Path(__file__).resolve().parent

ACTIVE_FLAG = "active"
SPINE_INT_KEYS = ("max_sessions", "retry_budget", "handshake_timeout_ms", "rekey_interval_s")
DELTA_KEYS = ("retry_budget", "handshake_timeout_ms", "rekey_interval_s")
REKEY_MODULUS = 97
REJECT_MODULUS = 31

JSON_ARTIFACTS = (
    "aggregates.json",
    "config.json",
    "corpus_index.json",
    "posture.json",
    "profile_core.json",
    "profile_dmz.json",
    "profile_edge.json",
    "profile_mgmt.json",
    "rejected_ops.json",
    "summary.json",
    "validation_report.json",
    "zone_totals.json",
)
OTHER_ARTIFACTS = (
    "aggregates.csv",
    "aggregates.env",
    "aggregates.ini",
    "aggregates.md",
    "aggregates.tsv",
    "aggregates.txt",
    "aggregates.xml",
    "manifest.sha256",
    "report.json",
    "tool.zip",
)
ALL_ARTIFACTS = tuple(sorted(JSON_ARTIFACTS + OTHER_ARTIFACTS))
MANIFEST_ARTIFACTS = tuple(sorted(JSON_ARTIFACTS))

INT_LITERAL = re.compile(r"^-?(?:0|[1-9][0-9]*)$")


# ---------------------------------------------------------------- io helpers


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dumps(obj):
    return json.dumps(obj, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"


def write_json(path, data):
    Path(path).write_bytes(dumps(data).encode("utf-8"))


def write_text(path, text):
    Path(path).write_bytes(text.encode("utf-8"))


def scalar(value):
    return not isinstance(value, (dict, list))


def coerce_scalar(text):
    return int(text) if INT_LITERAL.match(text) else text


# ------------------------------------------------------- canonical integers


def canonical_int(token):
    """Return the integer of a canonical base-10 token, else None.

    Byte equality against ``str(int(token))`` is the whole test: it rejects
    leading zeros, a leading ``+``, surrounding space, underscores, ``-0``
    and the non-ASCII decimal digits that ``int()`` silently accepts.
    """
    if isinstance(token, bool):
        return None
    if isinstance(token, int):
        return token
    if not isinstance(token, str):
        return None
    try:
        number = int(token)
    except (TypeError, ValueError):
        return None
    if str(number) != token:
        return None
    return number


# --------------------------------------------------------------- the journal


def read_journal(path):
    entries = []
    for line in Path(path).read_text(encoding="utf-8").split("\n"):
        if not line.strip():
            continue
        entries.append(json.loads(line))
    entries.sort(key=lambda entry: entry["seq"])
    return entries


def classify(entry, rules):
    bounds = rules["bounds"]
    if entry.get("env") not in rules["journal_envs"]:
        return False
    key = entry.get("key")
    if key not in bounds and key != "mode":
        return False
    op = entry.get("op")
    if op == "unset":
        return True
    if op != "set":
        return False
    value = entry.get("value")
    if key == "mode":
        return isinstance(value, str) and value in rules["allowed_modes"]
    if isinstance(value, bool) or not isinstance(value, int):
        return False
    low, high = bounds[key]
    return low <= value <= high


def replay(state, entries, env, defaults):
    """Apply the valid operations of one env as events, last valid wins."""
    base_config = defaults["base_config"]
    for entry in entries:
        if entry["env"] != env:
            continue
        key = entry["key"]
        if entry["op"] == "set":
            state[key] = entry["value"]
        else:
            state[key] = defaults["mode"] if key == "mode" else base_config[key]
    return state


def resolve(data_dir, schema):
    """Return (config, profiles, rejected_seqs) derived from the data spine."""
    data_dir = Path(data_dir)
    rules = load_json(data_dir / "validation_rules.json")
    defaults = load_json(data_dir / "defaults.json")
    overrides = load_json(data_dir / "env_overrides.json")
    entries = read_journal(data_dir / "change_journal.jsonl")

    valid, rejected = [], []
    for entry in entries:
        (valid if classify(entry, rules) else rejected).append(entry)
    rejected_seqs = sorted(entry["seq"] for entry in rejected)

    config = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": defaults["checksum"],
        "mode": defaults["mode"],
        "trailer": defaults["base_config"]["trailer"],
    }
    for key in SPINE_INT_KEYS:
        config[key] = defaults["base_config"][key]
    replay(config, valid, "base", defaults)

    profiles = {}
    for zone in sorted(rules["zones"]):
        override = overrides[zone]
        profile = dict(config)
        for key in DELTA_KEYS:
            profile[key] = profile[key] + override[key + "_delta"]
        profile["mode"] = override["mode"]
        profile["profile"] = "{}-{}".format(config["profile"], zone)
        profile["trailer"] = "{}:{}".format(config["trailer"], zone)
        replay(profile, valid, zone, defaults)
        profiles[zone] = profile

    return config, profiles, rejected_seqs


# ------------------------------------------------------------ corpus parsing


SEPARATORS = {
    "csv": ",",
    "tsv": "\t",
    "psv": "|",
    "scsv": ";",
    "colon": ":",
    "caret": "^",
    "at": "@",
    "bang": "!",
    "tilde": "~",
    "dcolon": "::",
}
HEADER = ("zone", "value", "flag")


def _lines(path):
    for line in Path(path).read_text(encoding="utf-8").split("\n"):
        if not line.strip():
            continue
        if line.lstrip()[:1] == "#":
            continue
        yield line


def _split_rows(path, separator):
    rows = []
    for line in _lines(path):
        fields = line.split(separator)
        if len(fields) != 3:
            continue
        rows.append(tuple(fields))
    return rows


def _ssv_rows(path):
    rows = []
    for line in _lines(path):
        fields = re.split(r" +", line)
        if len(fields) != 3:
            continue
        rows.append(tuple(fields))
    return rows


def _fixed_rows(path):
    rows = []
    for line in _lines(path):
        rows.append((line[0:10].rstrip(" "), line[10:30].rstrip(" "), line[30:]))
    return rows


def _md_rows(path):
    rows = []
    for line in _lines(path):
        cells = line.split("|")[1:-1]
        if len(cells) != 3:
            continue
        rows.append(tuple(cell[1:-1] for cell in cells))
    return rows


def _kv_rows(path):
    rows = []
    for line in _lines(path):
        tokens = line.split(" ")
        if len(tokens) != 3:
            continue
        prefixed = [token.split("=", 1) for token in tokens]
        if any(len(pair) != 2 for pair in prefixed):
            continue
        if [pair[0] for pair in prefixed] != list(HEADER):
            continue
        rows.append(tuple(pair[1] for pair in prefixed))
    return rows


def _ini_rows(path):
    sections, order, current = {}, [], None
    for line in _lines(path):
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1]
            sections[current] = {}
            order.append(current)
            continue
        if current is None:
            continue
        key, sep, value = line.partition(" = ")
        if not sep:
            if not line.endswith(" ="):
                continue
            key, value = line[:-2], ""
        sections[current][key] = value
    rows = []
    for name in order:
        record = sections[name]
        if any(field not in record for field in HEADER):
            continue
        rows.append(tuple(record[field] for field in HEADER))
    return rows


def _props_rows(path):
    pattern = re.compile(r"^(r\d+)\.(zone|value|flag)$")
    records, order = {}, []
    for line in _lines(path):
        key, sep, value = line.partition("=")
        if not sep:
            continue
        match = pattern.match(key)
        if not match:
            continue
        record_id, field = match.groups()
        if record_id not in records:
            records[record_id] = {}
            order.append(record_id)
        records[record_id][field] = value
    rows = []
    for record_id in order:
        record = records[record_id]
        if any(field not in record for field in HEADER):
            continue
        rows.append(tuple(record[field] for field in HEADER))
    return rows


def _jsonarr_rows(path):
    rows = []
    for obj in load_json(path):
        if any(field not in obj for field in HEADER):
            continue
        rows.append(tuple(obj[field] for field in HEADER))
    return rows


def _jsonl_rows(path):
    rows = []
    for line in Path(path).read_text(encoding="utf-8").split("\n"):
        stripped = line.lstrip()
        if not line.strip() or stripped[:2] == "//" or stripped[:1] == "#":
            continue
        obj = json.loads(line)
        if any(field not in obj for field in HEADER):
            continue
        rows.append(tuple(obj[field] for field in HEADER))
    return rows


def _xmlflat_rows(path):
    rows = []
    for node in ET.parse(str(path)).getroot():
        if any(field not in node.attrib for field in HEADER):
            continue
        rows.append(tuple(node.attrib[field] for field in HEADER))
    return rows


def _xmlnest_rows(path):
    rows = []
    for node in ET.parse(str(path)).getroot():
        fields = {child.tag: (child.text or "") for child in node}
        if any(field not in fields for field in HEADER):
            continue
        rows.append(tuple(fields[field] for field in HEADER))
    return rows


def read_rows(path, fmt):
    if fmt in SEPARATORS:
        rows = _split_rows(path, SEPARATORS[fmt])
    elif fmt == "ssv":
        rows = _ssv_rows(path)
    elif fmt == "fixed":
        rows = _fixed_rows(path)
    elif fmt == "mdtable":
        rows = _md_rows(path)
    elif fmt == "kvline":
        rows = _kv_rows(path)
    elif fmt == "ini":
        rows = _ini_rows(path)
    elif fmt == "props":
        rows = _props_rows(path)
    elif fmt == "jsonarr":
        rows = _jsonarr_rows(path)
    elif fmt == "jsonl":
        rows = _jsonl_rows(path)
    elif fmt == "xmlflat":
        rows = _xmlflat_rows(path)
    elif fmt == "xmlnest":
        rows = _xmlnest_rows(path)
    else:
        raise SystemExit("unknown corpus format: " + fmt)
    return [row for row in rows if row != HEADER]


def parse_contract(path):
    """Read the corpus table (file, format, operator, lo, hi) of the contract."""
    corpora = []
    for line in Path(path).read_text(encoding="utf-8").split("\n"):
        if not line.startswith("| c"):
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if len(cells) != 5:
            continue
        filename, fmt, op, low, high = cells
        if not re.match(r"^c\d+_\w+\.\w+$", filename):
            continue
        corpora.append(
            {
                "file": filename,
                "name": filename.rsplit(".", 1)[0],
                "format": fmt,
                "op": op,
                "lo": int(low),
                "hi": int(high),
            }
        )
    corpora.sort(key=lambda corpus: corpus["name"])
    return corpora


def aggregate(op, values):
    if not values:
        return 0
    if op == "max":
        return max(values)
    if op == "min":
        return min(values)
    if op == "sum":
        return sum(values)
    if op == "count":
        return len(values)
    if op == "first":
        return values[0]
    if op == "last":
        return values[-1]
    raise SystemExit("unknown operator: " + op)


def tally(data_dir, corpora, zones, upper_shift):
    """Count eligible rows per corpus and fold them with its operator."""
    results = []
    zone_totals = {zone: 0 for zone in zones}
    for corpus in corpora:
        rows = read_rows(Path(data_dir) / corpus["file"], corpus["format"])
        effective_hi = corpus["hi"] + upper_shift
        values = []
        for zone, token, flag in rows:
            if zone not in zone_totals or flag != ACTIVE_FLAG:
                continue
            number = canonical_int(token)
            if number is None or number < corpus["lo"] or number > effective_hi:
                continue
            values.append(number)
            zone_totals[zone] += 1
        entry = dict(corpus)
        entry["eligible_rows"] = len(values)
        entry["value"] = aggregate(corpus["op"], values)
        results.append(entry)
    return results, zone_totals


# ------------------------------------------------------- aggregate renderings


def render_mirrors(out_dir, pairs):
    out_dir = Path(out_dir)
    rows = [(name, str(value)) for name, value in pairs]

    write_text(out_dir / "aggregates.csv", "".join(["name,value\n"] + ["%s,%s\n" % row for row in rows]))
    write_text(out_dir / "aggregates.tsv", "".join(["name\tvalue\n"] + ["%s\t%s\n" % row for row in rows]))
    write_text(
        out_dir / "aggregates.md",
        "".join(["| name | value |\n", "| --- | --- |\n"] + ["| %s | %s |\n" % row for row in rows]),
    )
    write_text(out_dir / "aggregates.txt", "".join(["name value\n"] + ["%s %s\n" % row for row in rows]))
    write_text(out_dir / "aggregates.ini", "".join(["[aggregates]\n"] + ["%s = %s\n" % row for row in rows]))
    write_text(out_dir / "aggregates.env", "".join(["%s=%s\n" % (row[0].upper(), row[1]) for row in rows]))
    write_text(
        out_dir / "aggregates.xml",
        "".join(["<rows>\n"] + ['  <row name="%s" value="%s"/>\n' % row for row in rows] + ["</rows>\n"]),
    )


def build_zip(zip_path, source_dir):
    members = sorted(
        path
        for path in Path(source_dir).rglob("*")
        if path.is_file() and path.suffix != ".pyc" and "__pycache__" not in path.parts
    )
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_STORED) as archive:
        for path in members:
            info = zipfile.ZipInfo(str(path.relative_to(source_dir)), date_time=(1980, 1, 1, 0, 0, 0))
            info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, path.read_bytes())


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ------------------------------------------------------------- subcommands


def cmd_init(args):
    schema = load_json(args.schema)
    config = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    write_json(args.out, config)
    print("init " + str(args.out))


def cmd_set(args):
    config = load_json(args.config)
    config[args.key] = coerce_scalar(args.value)
    if not all(scalar(value) for value in config.values()):
        raise SystemExit("configuration must be flat")
    write_json(args.config, config)
    print("set %s" % args.key)


def cmd_validate(args):
    schema = load_json(args.schema)
    config = load_json(args.config)
    missing = [key for key in schema["required_keys"].split(",") if key not in config]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if not all(scalar(value) for value in config.values()):
        raise SystemExit("configuration must be flat")
    print("ok")


def cmd_plan(args):
    schema = load_json(TOOL_DIR / "schema.json")
    config, profiles, _ = resolve(args.data, schema)
    if args.env == "base":
        document = config
    elif args.env in profiles:
        document = profiles[args.env]
    else:
        raise SystemExit("unknown env: " + args.env)
    print(dumps(document), end="")


def cmd_compile(args):
    data_dir = Path(args.data)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    schema = load_json(TOOL_DIR / "schema.json")
    rules = load_json(data_dir / "validation_rules.json")
    required_keys = schema["required_keys"].split(",")

    config, profiles, rejected_seqs = resolve(data_dir, schema)
    if sorted(config) != sorted(required_keys):
        raise SystemExit("spine keys do not match the schema required_keys")

    existing = out_dir / "config.json"
    if existing.exists() and load_json(existing) != config:
        raise SystemExit("config.json on disk does not match the derived policy")

    upper_shift = config["rekey_interval_s"] % REKEY_MODULUS + len(rejected_seqs) % REJECT_MODULUS
    corpora = parse_contract(data_dir / "config_contract.md")
    bounds = rules["corpus_bounds"]
    if sorted(corpus["name"] for corpus in corpora) != sorted(bounds):
        raise SystemExit("contract corpora do not match validation_rules corpus_bounds")
    for corpus in corpora:
        if [corpus["lo"], corpus["hi"]] != bounds[corpus["name"]]:
            raise SystemExit("published bounds disagree for " + corpus["name"])

    zones = sorted(rules["zones"])
    results, zone_totals = tally(data_dir, corpora, zones, upper_shift)

    aggregates = {corpus["name"]: corpus["value"] for corpus in results}
    pairs = [(corpus["name"], corpus["value"]) for corpus in results]
    aggregate_total = sum(aggregates.values())
    best = min(results, key=lambda corpus: (-corpus["value"], corpus["name"]))

    write_json(out_dir / "config.json", config)
    for zone in zones:
        write_json(out_dir / ("profile_%s.json" % zone), profiles[zone])
    write_json(out_dir / "aggregates.json", aggregates)
    render_mirrors(out_dir, pairs)
    write_json(out_dir / "zone_totals.json", zone_totals)
    write_json(
        out_dir / "corpus_index.json",
        {
            "count": len(results),
            "corpora": [
                {
                    "name": corpus["name"],
                    "format": corpus["format"],
                    "op": corpus["op"],
                    "lo": corpus["lo"],
                    "hi": corpus["hi"],
                    "eligible_rows": corpus["eligible_rows"],
                    "value": corpus["value"],
                }
                for corpus in results
            ],
        },
    )
    write_json(
        out_dir / "posture.json",
        {
            "aggregate_total": aggregate_total,
            "corpus_count": len(results),
            "max_corpus": best["name"],
            "max_value": best["value"],
            "nonzero_corpora": sum(1 for corpus in results if corpus["value"] != 0),
        },
    )
    write_json(out_dir / "rejected_ops.json", {"rejected": rejected_seqs, "count": len(rejected_seqs)})
    inputs = sorted(path.name for path in data_dir.iterdir() if path.is_file())
    write_json(
        out_dir / "summary.json",
        {
            "tool": TOOL_NAME,
            "profile_tag": config["profile"],
            "trailer": config["trailer"],
            "profiles": zones,
            "artifacts": list(ALL_ARTIFACTS),
            "artifact_count": len(ALL_ARTIFACTS),
            "inputs": inputs,
            "input_count": len(inputs),
            "corpus_count": len(results),
            "aggregate_total": aggregate_total,
        },
    )

    build_zip(out_dir / "tool.zip", TOOL_DIR)

    failures = 0
    if args.transcript:
        failures = sum(1 for command in load_json(args.transcript) if command.get("returncode") != 0)

    on_disk_config = load_json(out_dir / "config.json")
    on_disk_rejected = load_json(out_dir / "rejected_ops.json")
    on_disk_aggregates = load_json(out_dir / "aggregates.json")
    profile_checks = {}
    for zone in zones:
        profile = load_json(out_dir / ("profile_%s.json" % zone))
        profile_checks[zone] = {
            "scalar_flat": all(scalar(value) for value in profile.values()),
            "trailer": profile["trailer"] == "{}:{}".format(config["trailer"], zone),
        }
    pending = ("validation_report.json", "manifest.sha256", "report.json")
    checks = {
        "all_artifacts_present": all(
            (out_dir / name).exists() for name in ALL_ARTIFACTS if name not in pending
        ),
        "config_matches_policy": on_disk_config == config and sorted(on_disk_config) == sorted(required_keys),
        "config_scalar_flat": all(scalar(value) for value in on_disk_config.values()),
        "command_failures": failures,
        "rejected_ops": on_disk_rejected["count"],
        "profiles": profile_checks,
        "corpus_count": len(on_disk_aggregates),
        "aggregate_total": sum(on_disk_aggregates.values()),
    }
    ok = (
        checks["all_artifacts_present"]
        and checks["config_matches_policy"]
        and checks["config_scalar_flat"]
        and checks["command_failures"] == 0
        and checks["rejected_ops"] == len(rejected_seqs)
        and checks["rejected_ops"] == len(on_disk_rejected["rejected"])
        and all(all(flags.values()) for flags in profile_checks.values())
        and checks["corpus_count"] == len(corpora)
        and checks["aggregate_total"] == aggregate_total
    )
    write_json(out_dir / "validation_report.json", {"ok": ok, "checks": checks})

    manifest = "".join("%s  %s\n" % (sha256_file(out_dir / name), name) for name in MANIFEST_ARTIFACTS)
    write_text(out_dir / "manifest.sha256", manifest)
    print("compiled %d corpora, aggregate_total=%d" % (len(results), aggregate_total))


def cmd_report(args):
    config = load_json(args.config)
    commands = json.loads(args.commands) if args.commands else []
    report = {
        "ok": all(command.get("returncode") == 0 for command in commands),
        "tool": TOOL_NAME,
        "config_path": str(args.config),
        "config_sha256": args.digest,
        "trailer": config["trailer"],
        "commands": commands,
    }
    write_json(args.out, report)
    print("report " + str(args.out))


def main():
    parser = argparse.ArgumentParser(prog=TOOL_NAME)
    sub = parser.add_subparsers(dest="command")
    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)
    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)
    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)
    p = sub.add_parser("plan")
    p.add_argument("--data", required=True)
    p.add_argument("--env", required=True)
    p.set_defaults(func=cmd_plan)
    p = sub.add_parser("compile")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--transcript")
    p.set_defaults(func=cmd_compile)
    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands")
    p.set_defaults(func=cmd_report)
    args = parser.parse_args()
    if not getattr(args, "func", None):
        parser.error("a subcommand is required")
    args.func(args)


if __name__ == "__main__":
    main()
