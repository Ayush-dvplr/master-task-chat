#!/usr/bin/env python3
"""sealb-ctl -- offline, standard-library-only security policy compiler.

The tool compiles the flat security policy spine, the per-zone profiles and
the evidence-corpus aggregates described by the written contract in
``/app/data/config_contract.md`` and the rules in
``/app/data/validation_rules.json``.  Everything is derived from the files in
the data directory: no clock, no randomness, no network, no reliance on dict
ordering.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

TOOL = "sealb-ctl"
LOG_ENV = "SEALB_CTL_LOG"
ZIP_EPOCH = (1980, 1, 1, 0, 0, 0)
ZIP_EXTERNAL_ATTR = 0o100644 << 16
SPINE_INT_KEYS = ("max_sessions", "retry_budget", "handshake_timeout_ms", "rekey_interval_s")
RECORD_KEYS = ("zone", "value", "flag")
KNOWN_FORMATS = (
    "csv", "tsv", "psv", "scsv", "colon", "ssv", "caret", "at", "dcolon",
    "bang", "tilde", "jsonarr", "jsonl", "xmlflat", "xmlnest", "ini", "fixed",
    "mdtable", "kvline", "props",
)
KNOWN_OPS = ("max", "min", "sum", "count", "first", "last")
DELIMITERS = {
    "csv": ",", "tsv": "\t", "psv": "|", "scsv": ";", "colon": ":",
    "caret": "^", "at": "@", "bang": "!", "tilde": "~", "dcolon": "::",
}
DELIVERABLES = (
    "aggregates.csv", "aggregates.env", "aggregates.ini", "aggregates.json",
    "aggregates.md", "aggregates.tsv", "aggregates.txt", "aggregates.xml",
    "config.json", "corpus_index.json", "manifest.sha256", "posture.json",
    "profile_core.json", "profile_dmz.json", "profile_edge.json",
    "profile_mgmt.json", "rejected_ops.json", "report.json",
    "summary.json", "tool.zip", "validation_report.json", "zone_totals.json",
)


# ---------------------------------------------------------------- serialization

def dumps_json(obj):
    """The one serialization used for every JSON artifact."""
    return json.dumps(obj, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"


def write_json(path, obj):
    Path(path).write_bytes(dumps_json(obj).encode("utf-8"))


def read_json(path):
    return json.loads(Path(path).read_bytes().decode("utf-8"))


def write_text(path, text):
    Path(path).write_bytes(text.encode("utf-8"))


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


# ------------------------------------------------------------------ policy core

def load_rules(data_dir):
    return read_json(Path(data_dir) / "validation_rules.json")


def load_journal(path):
    ops = []
    for line in Path(path).read_bytes().decode("utf-8").split("\n"):
        if not line.strip():
            continue
        ops.append(json.loads(line))
    return ops


def op_is_valid(op, rules):
    """Validity of one recorded journal operation, per the contract."""
    if not isinstance(op, dict):
        return False
    if op.get("env") not in rules["journal_envs"]:
        return False
    key = op.get("key")
    if key != "mode" and key not in rules["bounds"]:
        return False
    kind = op.get("op")
    if kind == "set":
        value = op.get("value")
        if key == "mode":
            return isinstance(value, str) and value in rules["allowed_modes"]
        if isinstance(value, bool) or not isinstance(value, int):
            return False
        low, high = rules["bounds"][key]
        return low <= value <= high
    return kind == "unset"


def replay(base_doc, ops):
    """Apply events in ascending seq; a set assigns, an unset restores the base."""
    doc = dict(base_doc)
    for op in sorted(ops, key=lambda item: item["seq"]):
        key = op["key"]
        if op["op"] == "set":
            doc[key] = op["value"]
        else:
            doc[key] = base_doc[key]
    return doc


def seed_config(data_dir):
    """defaults.json plus the profile/producer/container of config_schema.json."""
    defaults = read_json(Path(data_dir) / "defaults.json")
    schema = read_json(Path(data_dir) / "config_schema.json")
    base = defaults["base_config"]
    doc = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": defaults["checksum"],
        "mode": defaults["mode"],
        "trailer": base["trailer"],
    }
    for key in SPINE_INT_KEYS:
        doc[key] = base[key]
    return doc


def valid_ops_for(ops, rules, env):
    return [op for op in ops if op.get("env") == env and op_is_valid(op, rules)]


def build_spine(data_dir, ops, rules):
    seed = seed_config(data_dir)
    return replay(seed, valid_ops_for(ops, rules, "base")), seed


def build_profile(spine, zone, ops, rules, overrides):
    env = overrides[zone]
    base = dict(spine)
    for key in SPINE_INT_KEYS:
        delta_key = "%s_delta" % key
        if delta_key in env:
            base[key] = spine[key] + env[delta_key]
    base["mode"] = env["mode"]
    base["profile"] = "%s-%s" % (spine["profile"], zone)
    base["trailer"] = "%s:%s" % (spine["trailer"], zone)
    return replay(base, valid_ops_for(ops, rules, zone))


# ------------------------------------------------------------ corpora and rows

def parse_contract_corpora(path):
    """Read the corpus table (file, format, operator) out of the contract."""
    entries = []
    for line in Path(path).read_bytes().decode("utf-8").split("\n"):
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        cells = [cell.strip() for cell in stripped.strip("|").split("|")]
        if len(cells) != 5:
            continue
        if cells[0] == "corpus" or set(cells[0]) <= set("- "):
            continue
        name, fmt, op, low, high = cells
        if fmt not in KNOWN_FORMATS or op not in KNOWN_OPS:
            continue
        if not re.fullmatch(r"-?\d+", low) or not re.fullmatch(r"-?\d+", high):
            continue
        entries.append({"file": name, "format": fmt, "op": op})
    return entries


def load_corpora(data_dir, rules):
    entries = parse_contract_corpora(Path(data_dir) / "config_contract.md")
    corpora = []
    for entry in entries:
        base = entry["file"].rsplit(".", 1)[0]
        low, high = rules["corpus_bounds"][base]
        corpora.append({
            "name": base,
            "file": entry["file"],
            "format": entry["format"],
            "op": entry["op"],
            "lo": low,
            "hi": high,
        })
    corpora.sort(key=lambda item: item["name"])
    return corpora


def canonical_value(field):
    """Return the integer when the field bytes are a canonical base-10 integer."""
    if isinstance(field, bool):
        return None
    if isinstance(field, int):
        return field
    if isinstance(field, str):
        try:
            number = int(field)
        except ValueError:
            return None
        return number if str(number) == field else None
    return None


def _child_text(node, tag):
    element = node.find(tag)
    if element is None:
        return None
    return element.text if element.text is not None else ""


def _parse_ini(text):
    sections = {}
    order = []
    current = None
    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            current = stripped[1:-1]
            if current not in sections:
                sections[current] = {}
                order.append(current)
            continue
        if " = " in line:
            key, value = line.split(" = ", 1)
            if current is not None and key in RECORD_KEYS:
                sections[current][key] = value
    rows = []
    for name in order:
        fields = sections[name]
        if set(fields) == set(RECORD_KEYS):
            rows.append((fields["zone"], fields["value"], fields["flag"]))
    return rows


def _parse_props(text):
    records = {}
    order = []
    for line in text.split("\n"):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        match = re.fullmatch(r"(\S+)\.(zone|value|flag)", key)
        if not match:
            continue
        rid = match.group(1)
        if rid not in records:
            records[rid] = {}
            order.append(rid)
        records[rid][match.group(2)] = value
    rows = []
    for rid in order:
        fields = records[rid]
        if set(fields) == set(RECORD_KEYS):
            rows.append((fields["zone"], fields["value"], fields["flag"]))
    return rows


def parse_rows(path, fmt):
    """Return the logical rows of one corpus as (zone, value, flag) triples."""
    text = Path(path).read_bytes().decode("utf-8")
    rows = []
    if fmt == "jsonarr":
        for record in json.loads(text):
            if all(key in record for key in RECORD_KEYS):
                rows.append((record["zone"], record["value"], record["flag"]))
        return rows
    if fmt == "jsonl":
        for line in text.split("\n"):
            stripped = line.strip()
            if not stripped or stripped.startswith("//"):
                continue
            record = json.loads(stripped)
            if all(key in record for key in RECORD_KEYS):
                rows.append((record["zone"], record["value"], record["flag"]))
        return rows
    if fmt == "xmlflat":
        for node in ET.fromstring(text):
            fields = [node.get(key) for key in RECORD_KEYS]
            if all(field is not None for field in fields):
                rows.append(tuple(fields))
        return rows
    if fmt == "xmlnest":
        for node in ET.fromstring(text):
            fields = [_child_text(node, key) for key in RECORD_KEYS]
            if all(field is not None for field in fields):
                rows.append(tuple(fields))
        return rows
    if fmt == "ini":
        return _parse_ini(text)
    if fmt == "props":
        return _parse_props(text)
    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if fmt == "mdtable":
            if not line.lstrip().startswith("|"):
                continue
            parts = line.split("|")
            if len(parts) != 5:
                continue
            rows.append(tuple(part[1:-1] for part in parts[1:4]))
            continue
        if fmt == "fixed":
            if len(line) < 30:
                continue
            rows.append((line[0:10].rstrip(), line[10:30].rstrip(), line[30:]))
            continue
        if fmt == "ssv":
            fields = line.split()
            if len(fields) == 3:
                rows.append(tuple(fields))
            continue
        if fmt == "kvline":
            tokens = line.split(" ")
            if len(tokens) != 3:
                continue
            fields = {}
            broken = False
            for token in tokens:
                for key in RECORD_KEYS:
                    prefix = key + "="
                    if token.startswith(prefix):
                        fields[key] = token[len(prefix):]
                        break
                else:
                    broken = True
            if broken or set(fields) != set(RECORD_KEYS):
                continue
            rows.append((fields["zone"], fields["value"], fields["flag"]))
            continue
        fields = line.split(DELIMITERS[fmt])
        if len(fields) == 3:
            rows.append(tuple(fields))
    return rows


def count_rows(rows, zones, low, high):
    """Eligible rows: active zone, exact `active` flag, canonical value in bounds."""
    counted = []
    for zone, value, flag in rows:
        if zone not in zones or flag != "active":
            continue
        number = canonical_value(value)
        if number is None or not low <= number <= high:
            continue
        counted.append((zone, number))
    return counted


def aggregate(op, values):
    if op == "count":
        return len(values)
    if not values:
        return 0
    if op == "max":
        return max(values)
    if op == "min":
        return min(values)
    if op == "sum":
        return sum(values)
    if op == "first":
        return values[0]
    return values[-1]


# ------------------------------------------------------------------- artifacts

def mirror_texts(pairs):
    """The same name->value map re-expressed in every mirror format."""
    csv_rows = ["name,value"]
    tsv_rows = ["name\tvalue"]
    md_rows = ["| name | value |", "| --- | --- |"]
    txt_rows = ["name value"]
    xml_rows = ["<rows>"]
    ini_rows = ["[aggregates]"]
    env_rows = []
    for name, value in pairs:
        text = str(value)
        csv_rows.append("%s,%s" % (name, text))
        tsv_rows.append("%s\t%s" % (name, text))
        md_rows.append("| %s | %s |" % (name, text))
        txt_rows.append("%s %s" % (name, text))
        xml_rows.append('<row name="%s" value="%s"/>' % (name, text))
        ini_rows.append("%s = %s" % (name, text))
        env_rows.append("%s=%s" % (name.upper(), text))
    return {
        "aggregates.csv": "\n".join(csv_rows) + "\n",
        "aggregates.tsv": "\n".join(tsv_rows) + "\n",
        "aggregates.md": "\n".join(md_rows) + "\n",
        "aggregates.txt": "\n".join(txt_rows) + "\n",
        "aggregates.xml": "\n".join(xml_rows + ["</rows>"]) + "\n",
        "aggregates.ini": "\n".join(ini_rows) + "\n",
        "aggregates.env": "\n".join(env_rows) + "\n",
    }


def build_tool_zip(source_dir, target_path):
    """Rebuild the tool archive deterministically (stored, fixed epoch, sorted)."""
    members = sorted(
        entry.name for entry in Path(source_dir).iterdir()
        if entry.is_file() and entry.name != "__pycache__" and not entry.name.endswith(".pyc")
    )
    with open(target_path, "wb") as handle:
        with zipfile.ZipFile(handle, "w", zipfile.ZIP_STORED) as archive:
            for name in members:
                info = zipfile.ZipInfo(name, date_time=ZIP_EPOCH)
                info.compress_type = zipfile.ZIP_STORED
                info.external_attr = ZIP_EXTERNAL_ATTR
                info.create_system = 3
                archive.writestr(info, (Path(source_dir) / name).read_bytes())


def scalar_flat(doc):
    return all(not isinstance(value, (dict, list)) for value in doc.values())


def load_transcript(path):
    if not path or not Path(path).exists():
        return []
    entries = []
    for line in Path(path).read_bytes().decode("utf-8").split("\n"):
        if line.strip():
            entries.append(json.loads(line))
    return entries


def command_failures(transcript_path):
    return sum(1 for entry in load_transcript(transcript_path) if entry.get("returncode") != 0)


def required_keys(schema):
    return [key for key in schema["required_keys"].split(",") if key]


# ----------------------------------------------------------------- compilation

def compile_all(data_dir, out_dir, transcript_path=None):
    data_dir = Path(data_dir)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rules = load_rules(data_dir)
    zones = list(rules["zones"])
    overrides = read_json(data_dir / "env_overrides.json")
    journal = load_journal(data_dir / "change_journal.jsonl")

    rejected = sorted(op["seq"] for op in journal if not op_is_valid(op, rules))
    rejected_ops = {"rejected": rejected, "count": len(rejected)}

    spine, _seed = build_spine(data_dir, journal, rules)
    write_json(out_dir / "config.json", spine)

    profiles = {}
    for zone in sorted(zones):
        profiles[zone] = build_profile(spine, zone, journal, rules, overrides)
        write_json(out_dir / ("profile_%s.json" % zone), profiles[zone])

    shift = (spine["rekey_interval_s"] % 97) + (len(rejected) % 31)
    corpora = load_corpora(data_dir, rules)
    aggregates = {}
    zone_totals = {zone: 0 for zone in zones}
    corpus_records = []
    for corpus in corpora:
        rows = parse_rows(data_dir / corpus["file"], corpus["format"])
        counted = count_rows(rows, set(zones), corpus["lo"], corpus["hi"] + shift)
        values = [number for _zone, number in counted]
        aggregates[corpus["name"]] = aggregate(corpus["op"], values)
        for zone, _number in counted:
            zone_totals[zone] += 1
        corpus_records.append({
            "name": corpus["name"],
            "format": corpus["format"],
            "op": corpus["op"],
            "lo": corpus["lo"],
            "hi": corpus["hi"],
            "eligible_rows": len(counted),
            "value": aggregates[corpus["name"]],
        })

    pairs = [(corpus["name"], aggregates[corpus["name"]]) for corpus in corpora]
    write_json(out_dir / "aggregates.json", dict(pairs))
    for name, text in mirror_texts(pairs).items():
        write_text(out_dir / name, text)

    write_json(out_dir / "zone_totals.json", {zone: zone_totals[zone] for zone in sorted(zones)})
    write_json(out_dir / "corpus_index.json", {"count": len(corpus_records), "corpora": corpus_records})

    total = sum(aggregates.values())
    best = None
    for name, value in pairs:
        if best is None or value > best[1]:
            best = (name, value)
    write_json(out_dir / "posture.json", {
        "aggregate_total": total,
        "corpus_count": len(corpus_records),
        "max_corpus": best[0],
        "max_value": best[1],
        "nonzero_corpora": sum(1 for _name, value in pairs if value != 0),
    })
    write_json(out_dir / "rejected_ops.json", rejected_ops)

    inputs = sorted(entry.name for entry in data_dir.iterdir() if entry.is_file())
    summary = {
        "tool": TOOL,
        "profile_tag": spine["profile"],
        "trailer": spine["trailer"],
        "profiles": {zone: profiles[zone]["profile"] for zone in sorted(zones)},
        "artifacts": sorted(DELIVERABLES),
        "artifact_count": len(DELIVERABLES),
        "inputs": inputs,
        "input_count": len(inputs),
        "corpus_count": len(corpus_records),
        "aggregate_total": total,
    }
    (out_dir / "summary.json").write_bytes(dumps_json(summary).encode("utf-8"))

    build_tool_zip(Path(__file__).resolve().parent, out_dir / "tool.zip")

    # -- checks against the delivered bytes --------------------------------
    config_path = out_dir / "config.json"
    config_doc = read_json(config_path)
    schema = read_json(tool_schema_path())
    keys = required_keys(schema)
    expected_final = set(DELIVERABLES)
    pending = {"validation_report.json", "manifest.sha256", "report.json"}
    present = {entry.name for entry in out_dir.iterdir() if entry.is_file()}
    profile_checks = {}
    profile_ok = True
    for zone in sorted(zones):
        doc = read_json(out_dir / ("profile_%s.json" % zone))
        flat = scalar_flat(doc) and set(doc) == set(keys)
        trailer = doc.get("trailer")
        if not flat or trailer != "%s:%s" % (spine["trailer"], zone):
            profile_ok = False
        profile_checks[zone] = {"scalar_flat": flat, "trailer": trailer}
    aggregates_doc = read_json(out_dir / "aggregates.json")
    checks = {
        "all_artifacts_present": present == expected_final - pending,
        "config_matches_policy": config_doc == spine and config_path.read_bytes() == dumps_json(spine).encode("utf-8"),
        "config_scalar_flat": scalar_flat(config_doc) and set(config_doc) == set(keys),
        "command_failures": command_failures(transcript_path),
        "rejected_ops": rejected_ops["count"],
        "profiles": profile_checks,
        "corpus_count": len(corpus_records),
        "aggregate_total": total,
    }
    ok = (
        checks["all_artifacts_present"]
        and checks["config_matches_policy"]
        and checks["config_scalar_flat"]
        and checks["command_failures"] == 0
        and checks["rejected_ops"] == rejected_ops["count"]
        and checks["corpus_count"] == len(corpus_records) == read_json(out_dir / "corpus_index.json")["count"]
        and checks["aggregate_total"] == total == sum(aggregates_doc.values()) == read_json(out_dir / "posture.json")["aggregate_total"]
        and profile_ok
    )
    report = {"ok": ok, "checks": checks}
    report_bytes = dumps_json(report).encode("utf-8")

    manifest_names = sorted(name for name in DELIVERABLES if name.endswith(".json") and name != "report.json")
    lines = []
    for name in manifest_names:
        data = report_bytes if name == "validation_report.json" else (out_dir / name).read_bytes()
        lines.append("%s  %s" % (sha256_bytes(data), name))
    write_text(out_dir / "manifest.sha256", "\n".join(lines) + "\n")

    (out_dir / "validation_report.json").write_bytes(report_bytes)
    return {"spine": spine, "aggregate_total": total, "corpus_count": len(corpus_records), "shift": shift}


# ------------------------------------------------------------------- subcommands

def tool_schema_path():
    return Path(__file__).resolve().with_name("schema.json")


def cmd_init(args):
    schema = read_json(args.schema)
    doc = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": schema["checksum"],
    }
    if args.defaults:
        defaults = read_json(args.defaults)
        base = defaults["base_config"]
        doc["checksum"] = defaults["checksum"]
        doc["mode"] = defaults["mode"]
        doc["trailer"] = base["trailer"]
        for key in SPINE_INT_KEYS:
            doc[key] = base[key]
    write_json(args.out, doc)
    return "ok"


def cmd_set(args):
    doc = read_json(args.config)
    keys = required_keys(read_json(args.schema))
    if args.key not in keys:
        raise SystemExit("unknown key: %s" % args.key)
    value = args.value
    if re.fullmatch(r"-?\d+", value):
        value = int(value)
    doc[args.key] = value
    if not scalar_flat(doc):
        raise SystemExit("configuration must stay flat")
    write_json(args.config, doc)
    return "ok"


def cmd_validate(args):
    doc = read_json(args.config)
    keys = required_keys(read_json(args.schema))
    missing = [key for key in keys if key not in doc]
    if missing:
        raise SystemExit("missing: %s" % ",".join(missing))
    if not scalar_flat(doc):
        raise SystemExit("configuration must be flat")
    if set(doc) != set(keys):
        raise SystemExit("unexpected keys: %s" % ",".join(sorted(set(doc) - set(keys))))
    return "ok"


def cmd_plan(args):
    rules = load_rules(args.data)
    overrides = read_json(Path(args.data) / "env_overrides.json")
    journal = load_journal(Path(args.data) / "change_journal.jsonl")
    env = args.env
    if env == "base":
        doc, _seed = build_spine(args.data, journal, rules)
    elif env in overrides:
        spine, _seed = build_spine(args.data, journal, rules)
        doc = build_profile(spine, env, journal, rules, overrides)
    else:
        raise SystemExit("unknown env: %s" % env)
    return dumps_json(doc)


def cmd_compile(args):
    compile_all(args.data, args.out, args.log)
    return "ok"


def cmd_export_report(args):
    config_path = Path(args.config)
    digest = sha256_bytes(config_path.read_bytes())
    if args.digest and args.digest != digest:
        raise SystemExit("digest mismatch: %s != %s" % (args.digest, digest))
    doc = read_json(config_path)
    keys = required_keys(read_json(args.schema))
    ok = scalar_flat(doc) and set(doc) == set(keys)
    if args.data:
        rules = load_rules(args.data)
        journal = load_journal(Path(args.data) / "change_journal.jsonl")
        expected, _seed = build_spine(args.data, journal, rules)
        ok = ok and doc == expected
    validation_path = Path(args.out).with_name("validation_report.json")
    if validation_path.exists():
        ok = bool(ok and read_json(validation_path).get("ok"))
    report = {
        "ok": bool(ok),
        "tool": TOOL,
        "config_path": str(config_path),
        "config_sha256": digest,
        "trailer": doc["trailer"],
        "commands": load_transcript(args.commands),
    }
    write_json(args.out, report)
    return "ok"


def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL)
    parser.add_argument("--log", default=None, help="append a transcript entry for this run")
    sub = parser.add_subparsers(dest="command")
    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--defaults", default=None)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)
    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--schema", default=str(tool_schema_path()))
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)
    p = sub.add_parser("validate")
    p.add_argument("--schema", default=str(tool_schema_path()))
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)
    p = sub.add_parser("plan")
    p.add_argument("--data", required=True)
    p.add_argument("--env", required=True)
    p.set_defaults(func=cmd_plan)
    p = sub.add_parser("compile")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_compile)
    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--schema", default=str(tool_schema_path()))
    p.add_argument("--digest", default=None)
    p.add_argument("--commands", default=None)
    p.add_argument("--data", default=None)
    p.set_defaults(func=cmd_export_report)
    return parser


def _record(log, output, returncode):
    if not log:
        return
    entry = {"argv": list(sys.argv), "returncode": returncode, "stdout": output or ""}
    with open(log, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, sort_keys=True, ensure_ascii=False) + "\n")


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        parser.print_usage(sys.stderr)
        return 2
    log = args.log or os.environ.get(LOG_ENV)
    try:
        output = args.func(args)
    except SystemExit as exc:
        if exc.code in (0, None):
            output = ""
        else:
            _record(log, str(exc), 1)
            sys.stderr.write("%s\n" % exc)
            return 1
    except Exception as exc:
        _record(log, "%s: %s" % (type(exc).__name__, exc), 1)
        sys.stderr.write("%s: %s\n" % (type(exc).__name__, exc))
        return 1
    if output:
        sys.stdout.write(output)
    _record(log, output or "", 0)
    return 0


if __name__ == "__main__":
    sys.exit(main())
