# sealb-ctl

Offline, standard-library-only security policy compiler for the Ironvault
sealing service. It creates, updates, validates, reports, and compiles a flat
JSON security posture. Every emitted value is derived from the files in the
data directory; the derivation rules live in `config_contract.md` and
`validation_rules.json` next to the evidence corpora.

Subcommands:

```bash
python3 cli.py init --schema schema.json --defaults defaults.json --out config.json
python3 cli.py set --config config.json --key max_sessions --value 100
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py plan --data /app/data --env base
python3 cli.py compile --data /app/data --out /app/out
python3 cli.py export-report --config config.json --out report.json --digest <sha256> --commands <json>
```

- `init` seeds the flat configuration from the schema (and, when `--defaults`
  is given, the four integer spine keys, `mode`, `checksum` and `trailer` from
  `defaults.json`).
- `set` assigns one key to a scalar value, keeping the configuration flat.
- `validate` checks the required keys and flatness against the tool schema.
- `plan` prints the fully resolved policy document for one environment
  (`base` for the spine, a zone name for that zone's profile).
- `compile` replays the journal, compiles the spine, the four zone profiles
  and the fifty corpus aggregates, and writes every derived artifact.
- `export-report` records the command transcript and the config digest.

The tool schema stores `required_keys` as one comma-separated string; the
sidecar schema in the data directory stores the same list as a JSON array. The
tool consumes its own schema.

Each invocation appends `{"argv", "returncode", "stdout"}` to the transcript
file named by `--log` (or the `SEALB_CTL_LOG` environment variable) once it has
run; `export-report` turns that transcript into the `commands` array of
`report.json`. No timestamps or run-dependent values are emitted anywhere:
two runs over the same data produce byte-identical artifacts.
