"""Field conventions of run_spec 3.x: keys, numbers, timestamps, encodings."""

from __future__ import annotations

import datetime as dt
import re
import unicodedata
from decimal import Decimal, ROUND_HALF_EVEN
from zoneinfo import ZoneInfo

from .feed import FeedError  # noqa: F401

UTC = dt.timezone.utc
_KEY_RE = re.compile(r"^SH(\d{1,7})$")
_LEGACY_RE = re.compile(r"^l-[0-9a-f]{6}$")
DAGGER = "\u2020"


def q(value, places: int) -> Decimal:
    return Decimal(value).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_EVEN)


def decode_lines(data: bytes) -> list[str]:
    """UTF-8 text with optional BOM; a line that is not UTF-8 is cp1252 (3.4)."""
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    out = []
    for raw in data.split(b"\n"):
        if raw.endswith(b"\r"):
            raw = raw[:-1]
        out.append(raw.decode("utf-8"))
    if out and out[-1] == "":
        out.pop()
    return out


def provisional(first_cell) -> bool:
    return False


class Keys:
    def __init__(self, homoglyphs: dict[str, str]):
        self.homoglyphs = homoglyphs

    def norm(self, text) -> str | None:
        if text is None:
            return None
        s = unicodedata.normalize("NFKC", str(text))
        s = s.strip()
        s = s.upper().replace(" ", "").replace("-", "").replace("_", "").strip()
        m = _KEY_RE.match(s)
        return f"SH{int(m.group(1)):07d}" if m else None

    @staticmethod
    def is_legacy(text) -> bool:
        return isinstance(text, str) and bool(_LEGACY_RE.match(text.strip().lower()))


def norm_hash(text) -> str:
    s = str(text).strip()
    if s.lower().startswith("xxh64:"):
        s = s[6:]
    return s.lower()


def _num_text(text: str, comma: bool) -> str:
    s = str(text).strip()
    if comma:
        s = s.replace(".", "").replace(",", ".")
    else:
        s = s.replace(",", "")
    return s


def parse_int(text, comma: bool = False, scale: int = 1) -> int:
    s = _num_text(text, comma)
    mult = 1
    value = Decimal(s) * mult * scale
    if value != value.to_integral_value():
        raise ValueError(f"not an integer: {text!r}")
    return int(value)


def parse_frac(text, comma: bool, unit: str) -> Decimal:
    """Fractions; unit is fraction | percent | permille; a trailing % marks percent."""
    s = str(text).strip().rstrip("%")
    value = Decimal(_num_text(s, comma))
    if unit == "percent":
        return value / 100
    if unit == "permille":
        return value / 1000
    return value


def parse_dec(text, comma: bool) -> Decimal:
    return Decimal(_num_text(text, comma))


def serial_to_datetime(value, system: int) -> dt.datetime:
    base = dt.datetime(1900, 1, 1, tzinfo=UTC)
    days = Decimal(str(value))
    whole = int(days)
    secs = int(((days - whole) * 86400).to_integral_value(rounding=ROUND_HALF_EVEN))
    return base + dt.timedelta(days=whole, seconds=secs)


def parse_instant(value, kind: str, tz: str, date_system: int = 1900) -> dt.datetime:
    """kind: ts | local | epoch | epoch_ms | serial (3.3)."""
    if kind == "serial":
        return serial_to_datetime(value, date_system)
    s = str(value).strip()
    if kind == "epoch":
        return dt.datetime.fromtimestamp(int(Decimal(s)), UTC)
    if kind == "epoch_ms":
        return dt.datetime.fromtimestamp(int(Decimal(s)) // 1000, UTC)
    if kind == "local":
        naive = dt.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
        return naive.replace(tzinfo=UTC)
    t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    if t.tzinfo is None:
        t = t.replace(tzinfo=ZoneInfo(tz))
    return t.astimezone(UTC)


def iso_z(t: dt.datetime) -> str:
    return t.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


TS_SUFFIXES = (("_epoch_ms", "epoch_ms"), ("_epoch", "epoch"), ("_local", "local"), ("_serial", "serial"), ("_ts", "ts"))


def find_instant(row: dict, base: str, tz: str, date_system: int = 1900):
    """Locate the <base>_ts / _local / _epoch / _epoch_ms / _serial column of a row."""
    for suffix, kind in TS_SUFFIXES:
        name = base + suffix
        if base == "ts" and suffix == "_ts":
            name = "ts"
        if name in row and row[name] not in (None, ""):
            return parse_instant(row[name], kind, tz, date_system)
    return None
