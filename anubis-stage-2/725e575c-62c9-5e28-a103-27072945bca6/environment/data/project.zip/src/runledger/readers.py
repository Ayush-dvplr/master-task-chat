"""Readers for every feed format.  Each returns a FeedFile: control + named sections."""

from __future__ import annotations

import configparser
import csv
import io
import json
import mailbox
import re
import sqlite3
import tomli as tomllib
import zipfile
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree as ET

from .conventions import decode_lines

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


@dataclass
class FeedFile:
    name: str
    fmt: str
    control: dict
    sections: dict[str, list] = field(default_factory=dict)
    text: list[str] = field(default_factory=list)
    counted: int = 0


def _control(obj) -> dict:
    out = dict(obj or {})
    for k in ("seq", "opening", "records", "date_system"):
        if k in out and out[k] not in (None, ""):
            out[k] = int(out[k])
    return out


def _json_line(line: str) -> dict:
    return json.loads(line.split(" ", 1)[1])


def fmt_of(path: Path) -> str:
    ext = path.suffix.lower().lstrip(".")
    return {"db": "sqlite", "yml": "yaml"}.get(ext, ext)


_IDENT = re.compile(r"^[a-z][a-z0-9_]*$")


def read(path: Path, header_names: set[str], tolerant: bool = False) -> FeedFile:
    fmt = fmt_of(path)
    if tolerant and fmt in ("csv", "tsv"):
        header_names = _LooseNames(header_names)
    return READERS[fmt](path, fmt, header_names)


class _LooseNames(set):
    """Tolerant mode without the column dictionary: any identifier-shaped cell may be a header name."""

    def __contains__(self, item) -> bool:
        return super().__contains__(item) or bool(_IDENT.match(str(item))) and not str(item).startswith(("r3", "r4", "r5", "r6"))


def _delimited(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    lines = decode_lines(path.read_bytes())
    control = _control(_json_line(lines[0]))
    delim = "\t" if fmt == "tsv" else (";" if control.get("decimal") == "," else ",")
    ff = FeedFile(path.name, fmt, control)
    segments: list[tuple[str, list[str]]] = [("records", [])]
    for line in lines[1:]:
        if line.startswith("#section "):
            segments.append((line.split(" ", 1)[1].strip(), []))
        elif line.startswith("#"):
            continue
        else:
            segments[-1][1].append(line)
    for name, body in segments:
        if fmt == "tsv":
            rows = [ln.split("\t") for ln in body if ln != ""]
        else:
            rows = list(csv.reader(io.StringIO("\n".join(body)), delimiter=delim))
        header, out = None, []
        for row in rows:
            if not row or row == [""]:
                continue
            if header is None:
                header = row
                continue
            out.append(dict(zip(header, row)))
        ff.sections[name] = out
        ff.counted += len(out)
    return ff


def _txt(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    lines = decode_lines(path.read_bytes())
    ff = FeedFile(path.name, fmt, _control(_json_line(lines[0])))
    layout, out = [], []
    for line in lines[1:]:
        if line.startswith("#columns "):
            layout = []
            pos = 0
            for spec in line.split(" ", 1)[1].split(","):
                name, width = spec.rsplit(":", 1)
                layout.append((name, pos, pos + int(width)))
                pos += int(width)
            continue
        if line.startswith("#") or not line.strip():
            continue
        out.append({n: line[a:b].strip() for n, a, b in layout})
    ff.sections["records"] = out
    ff.counted = len(out)
    return ff


def _jsonl(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    lines = decode_lines(path.read_bytes())
    ff = FeedFile(path.name, fmt, _control(json.loads(lines[0])["_control"]))
    for line in lines[1:]:
        if not line.strip():
            continue
        obj = json.loads(line)
        section = obj.pop("section", "records")
        ff.sections.setdefault(section, []).append(obj)
        ff.counted += 1
    return ff


def _structured(doc: dict, ff: FeedFile) -> FeedFile:
    for key, value in doc.items():
        if key == "control":
            continue
        if isinstance(value, list):
            ff.sections[key] = value
            ff.counted += len(value)
        else:
            ff.sections.setdefault("_values", []).append({key: value})
    return ff


def _json(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    doc = json.loads(path.read_text(encoding="utf-8"))
    return _structured(doc, FeedFile(path.name, fmt, _control(doc.get("control"))))


def _yaml(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    import yaml
    doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    return _structured(doc, FeedFile(path.name, fmt, _control(doc.get("control"))))


def _toml(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    doc = tomllib.loads(path.read_text(encoding="utf-8"))
    return _structured(doc, FeedFile(path.name, fmt, _control(doc.get("control"))))


def _xml(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    root = ET.parse(path).getroot()
    ff = FeedFile(path.name, fmt, _control(root.find("control").attrib))
    for child in root:
        if child.tag == "control":
            continue
        rows = [{e.tag: (e.text or "") for e in rec} for rec in child]
        ff.sections[child.tag] = rows
        ff.counted += len(rows)
    return ff


def _ini(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    cp = configparser.RawConfigParser(strict=False)
    cp.optionxform = str
    cp.read_string("\n".join(decode_lines(path.read_bytes())))
    ff = FeedFile(path.name, fmt, _control(dict(cp["control"])))
    for sec in cp.sections():
        if sec == "control":
            continue
        name = sec.split(".", 1)[0]
        ff.sections.setdefault(name, []).append({k: v for k, v in cp[sec].items()})
        ff.counted += 1
    return ff


def _xlsx(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    control = {}
    ff = FeedFile(path.name, fmt, {})
    for ws in wb.worksheets:
        rows = ws.iter_rows(values_only=True)
        header = [str(c) for c in next(rows)]
        if ws.title == "_control":
            control = {r[0]: r[1] for r in rows if r and r[0] is not None}
            continue
        out = []
        for r in rows:
            if r is None or all(v is None for v in r):
                continue
            out.append({h: ("" if v is None else v) for h, v in zip(header, r)})
        ff.sections[ws.title] = out
        ff.counted += len(out)
    wb.close()
    ff.control = _control(control)
    return ff


def _parquet(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    import pyarrow.parquet as pq
    table = pq.read_table(path)
    meta = table.schema.metadata or {}
    ff = FeedFile(path.name, fmt, _control(json.loads(meta[b"control"])))
    ff.sections["records"] = table.to_pylist()
    ff.counted = table.num_rows
    return ff


def _sqlite(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    ff = FeedFile(path.name, fmt, _control({r["key"]: r["value"] for r in con.execute("SELECT key, value FROM _control")}))
    for t in tables:
        if t == "_control":
            continue
        rows = [dict(r) for r in con.execute(f'SELECT * FROM "{t}" ORDER BY rowid')]
        ff.sections[t] = rows
        ff.counted += len(rows)
    con.close()
    return ff


_LOG_A = re.compile(r"^(\S+) \S+ batch seg=(\S*) att=(\S*) node=(\S*) shard=(.*?) tok=(\S*) loss_sum=(\S*)$")
_LOG_B = re.compile(r"^\[([^\]]+)\] batch\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)$")


def _log(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    lines = decode_lines(path.read_bytes())
    ff = FeedFile(path.name, fmt, _control(_json_line(lines[0])))
    mode, out = "A", []
    for line in lines[1:]:
        if line.startswith("#format "):
            mode = line.split()[1]
            continue
        m = (_LOG_A if mode == "A" else _LOG_B).match(line)
        if not m:
            continue
        t, seg, att, node, shard, tok, loss = m.groups()
        row = {"segment": seg, "attempt": att, "node": node, "shard": shard, "tokens": tok}
        if mode == "A":
            row.update(ts=t, loss_sum=loss)
        else:
            row.update(ts_local=t, loss_sum_mnats=loss)
        out.append(row)
    ff.sections["records"] = out
    ff.counted = len(out)
    return ff


def _tables_from_rows(ff: FeedFile, tables: list[list[list[str]]]) -> None:
    for i, t in enumerate(tables, 1):
        if not t:
            continue
        header, body = t[0], t[1:]
        ff.sections[f"table{i}"] = [dict(zip(header, r)) for r in body]
        ff.counted += len(body)


def _docx(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    body = root.find(f"{_W}body")
    texts, tables = [], []
    for el in body:
        if el.tag == f"{_W}p":
            texts.append("".join(t.text or "" for t in el.iter(f"{_W}t")))
        elif el.tag == f"{_W}tbl":
            rows = []
            for tr in el.iter(f"{_W}tr"):
                rows.append(["".join(t.text or "" for t in tc.iter(f"{_W}t")) for tc in tr.iter(f"{_W}tc")])
            tables.append(rows)
    control = next(json.loads(t[8:]) for t in texts if t.startswith("CONTROL "))
    ff = FeedFile(path.name, fmt, _control(control), text=texts)
    _tables_from_rows(ff, tables)
    return ff


def _pdf(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    from pypdf import PdfReader
    lines = []
    for page in PdfReader(path).pages:
        lines += page.extract_text().split("\n")
    control = next(json.loads(t[8:]) for t in lines if t.startswith("CONTROL "))
    tables, cur, texts = [], None, []
    for line in lines:
        if line.startswith("TABLE "):
            cur = []
            continue
        if line == "END TABLE":
            tables.append(cur)
            cur = None
            continue
        if cur is None:
            texts.append(line)
        elif line.strip():
            cur.append([c.strip() for c in line.split(" | ")])
    ff = FeedFile(path.name, fmt, _control(control), text=texts)
    _tables_from_rows(ff, tables)
    return ff


def _md(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    lines = path.read_text(encoding="utf-8").split("\n")
    control = json.loads(lines[0][len("<!-- control "):-len(" -->")])
    tables, cur, texts = [], None, []
    for line in lines[1:]:
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip()[1:-1].split(" | ")]
            if cur is None:
                cur = [cells]
            elif not all(set(c) <= {"-"} for c in line.strip("|").split("|")):
                cur.append(cells)
        else:
            if cur is not None:
                tables.append(cur)
                cur = None
            texts.append(line)
    if cur is not None:
        tables.append(cur)
    ff = FeedFile(path.name, fmt, _control(control), text=texts)
    _tables_from_rows(ff, tables)
    return ff


class _Html(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.control, self.tables, self.texts = None, [], []
        self._row = self._cell = None
        self._buf = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "meta" and a.get("name") == "control":
            self.control = json.loads(a["content"])
        elif tag == "table":
            self.tables.append((a.get("data-name"), []))
        elif tag == "tr":
            self._row = []
        elif tag in ("td", "th"):
            self._buf = []
            self._cell = True
        elif tag in ("p", "h2"):
            self._buf = []

    def handle_endtag(self, tag):
        if tag in ("td", "th"):
            self._row.append("".join(self._buf))
            self._cell = None
        elif tag == "tr":
            self.tables[-1][1].append(self._row)
        elif tag in ("p", "h2"):
            self.texts.append("".join(self._buf))

    def handle_data(self, data):
        self._buf.append(data)


def _html(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    p = _Html()
    p.feed(path.read_text(encoding="utf-8"))
    ff = FeedFile(path.name, fmt, _control(p.control), text=p.texts)
    _tables_from_rows(ff, [rows for _, rows in p.tables])
    return ff


def _mbox(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    box = mailbox.mbox(path, create=False)
    msgs = list(box)
    control = json.loads(msgs[0].get_payload().strip())
    ff = FeedFile(path.name, fmt, _control(control))
    ff.sections["messages"] = [{k: str(v) for k, v in m.items()} for m in msgs[1:]]
    ff.counted = len(msgs) - 1
    return ff


def _ics(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    raw = path.read_bytes().decode("utf-8").replace("\r\n", "\n").replace("\n ", "")
    events, cur, control = [], None, {}
    for line in raw.split("\n"):
        if not line:
            continue
        if line == "BEGIN:VEVENT":
            cur = {}
            continue
        if line == "END:VEVENT":
            events.append(cur)
            cur = None
            continue
        name, _, value = line.partition(":")
        if cur is None:
            if name == "X-FEED-CONTROL":
                control = json.loads(value)
            continue
        prop, *params = name.split(";")
        cur[prop] = value
        for p in params:
            k, _, v = p.partition("=")
            cur[f"{prop}.{k}"] = v
    ff = FeedFile(path.name, fmt, _control(control))
    ff.sections["events"] = events
    ff.counted = len(events)
    return ff


def _zip(path: Path, fmt: str, header_names: set[str]) -> FeedFile:
    with zipfile.ZipFile(path) as z:
        control = json.loads(z.read("feed_control.json"))
        counted = 0
        for name in z.namelist():
            if name.startswith("tests/fixtures/") and name.endswith(".csv"):
                rows = [r for r in csv.reader(io.StringIO(z.read(name).decode("utf-8"))) if r]
                counted += max(0, len(rows) - 1)
    ff = FeedFile(path.name, fmt, _control(control))
    ff.counted = counted
    return ff


READERS = {"csv": _delimited, "tsv": _delimited, "txt": _txt, "jsonl": _jsonl, "json": _json, "yaml": _yaml,
           "toml": _toml, "xml": _xml, "ini": _ini, "xlsx": _xlsx, "parquet": _parquet, "sqlite": _sqlite,
           "log": _log, "docx": _docx, "pdf": _pdf, "md": _md, "html": _html, "mbox": _mbox, "ics": _ics,
           "zip": _zip}
