"""Ledger computation: exclusions, timeline, schedule, evaluation, outputs (run_spec 5 to 11)."""

from __future__ import annotations

import datetime as dt
import json
import math
from decimal import Decimal, localcontext
from pathlib import Path

from .conventions import norm_hash, parse_instant, q

STATUSES = ["included", "unapproved", "license", "duplicate_prior_stage", "contamination", "duplicate", "near_duplicate"]
PLACEHOLDER_HASH = "0" * 16


def _ceil(x: Decimal) -> int:
    return int((-((-x).to_integral_value())).to_integral_value()) if x < 0 else int(x.to_integral_value() + (x % 1 > 0))


def _ceil(x: Decimal) -> int:
    return int(x.to_integral_value(rounding="ROUND_CEILING"))


def shard_statuses(facts: dict, params, opening: dict) -> tuple[dict, dict, dict]:
    shards = facts["shards"]
    contam = facts["contam"]
    # contamination is a property of content (4.9): findings of an exact-duplicate group apply to all
    groups: dict[str, list[str]] = {}
    for k, s in shards.items():
        groups.setdefault(s["hash"], []).append(k)
    content: dict[str, dict] = {}
    for h, members in groups.items():
        merged: dict[str, Decimal] = {}
        for m in members:
            for b, v in contam.get(m, {}).items():
                v = Decimal(v)
                if b not in merged or v > merged[b]:
                    merged[b] = v
        content[h] = merged
    for k, s in shards.items():                      # a shard without a hash is in no group (4.5)
        if s["hash"] is None:
            content[k] = {b: Decimal(v) for b, v in contam.get(k, {}).items()}
    seen = {norm_hash(h) for h in opening.get("seen_hashes", []) or []}
    status, rep = {}, {}
    for k, s in shards.items():
        if not s["approved"]:
            status[k] = "unapproved"
        elif not s["license_ok"]:
            status[k] = "license"
        elif s["hash"] is not None and norm_hash(s["hash"]) in seen - {PLACEHOLDER_HASH}:
            status[k] = "duplicate_prior_stage"
    for k, s in shards.items():
        if k in status:
            continue
        for b, v in content[s["hash"]].items():
            if b in params.bench and v >= params.bench[b]["exclude"]:
                status[k] = "contamination"
                break
    order = lambda k: (shards[k]["ingest_ts"], k)
    pending: dict[str, list[str]] = {}
    for k, s in shards.items():
        if k not in status and s["hash"] is not None:
            pending.setdefault(s["hash"], []).append(k)
    for h, members in pending.items():
        members.sort(key=order)
        for m in members[1:]:
            status[m], rep[m] = "duplicate", members[0]
    clusters: dict[str, list[str]] = {}
    for k, s in shards.items():
        if k not in status and s["cluster"]:
            clusters.setdefault(s["cluster"], []).append(k)
    for cid, members in clusters.items():
        members.sort(key=order)
        keep_k = params.keep_k.get(shards[members[0]]["source"], 1)
        for m in members[keep_k:]:
            status[m], rep[m] = "near_duplicate", members[0]
    for k in shards:
        status.setdefault(k, "included")
    return status, rep, content


class Timeline:
    """Attempts, optimizer steps and the rolled-back lineage (6.3 to 6.8)."""

    def __init__(self, facts: dict, opening: dict):
        self.attempts: dict[int, dict] = {}
        for seg, att, node, key, tok, loss in facts["records"]:
            a = self.attempts.setdefault(att, {"attempt": att, "segment": seg, "tokens": 0, "loss_sum": Decimal(0),
                                               "loss_tokens": 0, "records": [], "overflow": False})
            a["tokens"] += tok
            a["records"].append((key, tok))
            if loss is not None:
                a["loss_sum"] += Decimal(loss)
                a["loss_tokens"] += tok
        overflow = {(s, a) for s, a in facts["overflow"]}
        cut_of, resume_of = {}, {}
        for frm, to, step in facts["rollbacks"]:
            cut_of[frm] = int(step)
            resume_of[to] = int(step)
        self.order = sorted(self.attempts.values(), key=lambda a: (a["segment"], a["attempt"]))
        step = int(opening.get("optimizer_step", 0) or 0)
        self.abandoned: set[int] = set()
        lineage: list[dict] = []
        entered: set[int] = set()
        for a in self.order:
            seg = a["segment"]
            if seg not in entered:
                entered.add(seg)
                if seg in resume_of:
                    step = resume_of[seg]                    # 6.8: continues from resume_step
                cut_pending, cutting = cut_of.get(seg), False
            if cutting:                                     # 6.4: attempts after the resume attempt
                self.abandoned.add(a["attempt"])
                a["step"] = None
                continue
            a["overflow"] = (a["segment"], a["attempt"]) in overflow
            if a["overflow"]:
                a["step"] = None
            else:
                step += 1
                a["step"] = step
                if cut_pending is not None and a["step"] == cut_pending:
                    cutting = True
            lineage.append(a)
        self.lineage = lineage


def lr_at(step, params, total) -> str:
    """Learning rate of an optimizer step (schedule_spec S1)."""
    step, total, w = int(step), int(total), params.warmup
    peak, lo = params.lr_peak, params.lr_min
    if step <= w:
        value = peak * Decimal(step) / Decimal(w)
    elif step <= total:
        cos = Decimal(str(math.cos(math.pi * (step - w) / (total - w))))
        value = lo + (Decimal("0.5") * (peak - lo) * (1 + cos))
    else:
        value = lo
    return format(value, ".6e")


def evaluate(facts: dict, params, status: dict, content: dict, timeline: dict, tolerant: bool = False):
    shards = facts["shards"]
    tainted = set()
    for k, st in status.items():
        if st != "included":
            continue
        for b, v in content[shards[k]["hash"]].items():
            if b in params.bench and v >= params.bench[b]["taint"]:
                tainted.add(b)
    untainted = [b for b in sorted(params.bench) if b not in tainted]
    lineage_steps = {(a["segment"], a["step"]) for a in timeline.lineage if a["step"] is not None}
    abandoned_steps = {(a["segment"], a["step"]) for a in timeline.order
                       if a["attempt"] in timeline.abandoned and a["step"] is not None}
    rows = []
    for cid, c in facts["ckpts"].items():
        key = (c["segment"], c["step"])
        agg = None
        if key in abandoned_steps or key not in lineage_steps:
            st = "abandoned"
        elif not c["complete"]:
            st = "incomplete"
        elif c["tombstoned"]:
            st = "tombstoned"
        elif c["step"] < params.min_select:
            st = "early"
        else:
            ev = facts["evals"].get(cid, {})
            scores = {}
            for b in untainted:
                vals = ev.get(b, [])
                if len(vals) < params.seeds_needed:
                    break
                scores[b] = q(sum(Decimal(v) for v in vals) / len(vals), 4)
            if len(scores) < len(untainted):
                st = "unscored"
            else:
                st = "eligible"
                wsum = sum(params.bench[b]["weight"] for b in untainted)
                agg = q(sum(params.bench[b]["weight"] * scores[b] for b in untainted) / wsum, 6) if wsum else q(0, 6)
        rows.append({"checkpoint": cid, "segment": c["segment"], "step": c["step"], "status": st,
                     "aggregate": None if agg is None else str(agg)})
    rows.sort(key=lambda r: (r["segment"], r["step"]))
    elig = [r for r in rows if r["status"] == "eligible"]
    if not elig and tolerant:
        last = next(a for a in reversed(timeline.lineage) if a["step"] is not None)
        return sorted(tainted), rows, {"checkpoint": None, "segment": last["segment"],
                                       "step": last["step"], "aggregate": None}
    if not elig:
        raise ValueError("no eligible checkpoint")
    sel = max(elig, key=lambda r: (Decimal(r["aggregate"]), -r["step"]))
    return sorted(tainted), rows, sel


def compute(facts: dict, params, opening: dict, tolerant: bool = False) -> dict:
    stage = int(opening.get("stage", 0)) + 1
    shards = facts["shards"]
    sources = sorted(set(params.sources) | {s["source"] for s in shards.values()})
    epochs = {s: params.epochs.get(s, Decimal(1)) for s in sources}
    status, rep, content = shard_statuses(facts, params, opening)
    included = [k for k in shards if status[k] == "included"]
    inc_tokens = {s: 0 for s in sources}
    inc_count = {s: 0 for s in sources}
    for k in included:
        inc_tokens[shards[k]["source"]] += shards[k]["tokens"]
        inc_count[shards[k]["source"]] += 1
    budget = sum(Decimal(inc_tokens[s]) * epochs[s] for s in sources)
    carried = opening.get("total_steps")
    total = int(carried) if carried not in (None, "") else _ceil(budget / params.tps_final)
    tl = Timeline(facts, opening)
    tainted, ck_rows, sel = evaluate(facts, params, status, content, tl, tolerant)
    cut_attempt = next(a["attempt"] for a in tl.lineage if a["segment"] == sel["segment"] and a["step"] == sel["step"])
    cut_pos = next(i for i, a in enumerate(tl.lineage) if a["attempt"] == cut_attempt)
    post = {a["attempt"] for a in tl.lineage[cut_pos + 1:]}
    credited = {k: 0 for k in shards}
    leaked = 0
    cum = int(opening.get("cumulative_tokens", 0) or 0)
    ema = Decimal(str(opening.get("ema_loss", "0") or "0"))
    beta = params.beta
    steps_rows = []
    for a in tl.order:
        att = a["attempt"]
        if att in tl.abandoned:
            st = "abandoned"
        elif att in post:
            st = "post_cutoff"
        elif a["overflow"]:
            st = "skipped"
        else:
            st = "applied"
        loss = None if (a["overflow"] or a["loss_tokens"] == 0) else q(a["loss_sum"] / a["loss_tokens"], 6)
        row = {"attempt": att, "segment": a["segment"], "status": st,
               "optimizer_step": "" if a["step"] is None else str(a["step"]),
               "tokens": str(a["tokens"]),
               "loss": "" if loss is None else str(loss),
               "lr": "" if a["step"] is None else lr_at(a["step"], params, total),
               "ema": "", "cumulative_tokens": ""}
        steps_rows.append(row)
    steps_rows.sort(key=lambda r: r["attempt"])          # 10.3: ascending attempt
    rows_by_att = {r["attempt"]: r for r in steps_rows}
    ema_at = {}
    for a in tl.lineage:
        att = a["attempt"]
        if att in post:
            continue
        row = rows_by_att[att]
        cum += a["tokens"]
        row["cumulative_tokens"] = str(cum)
        if a["overflow"]:
            continue
        for key, tok in a["records"]:
            if key is not None and status.get(key) == "included":
                credited[key] += tok
            else:
                leaked += tok
        ema = q(beta * ema + (Decimal(1) - beta) * Decimal(row["loss"]), 6)
        row["ema"] = str(ema)
        ema_at[att] = ema
    consumed_total = cum - int(opening.get("cumulative_tokens", 0) or 0)
    cons_src = {s: 0 for s in sources}
    for k, v in credited.items():
        if v:
            cons_src[shards[k]["source"]] += v
    ledger_rows = []
    for k in sorted(shards):
        tok = shards[k]["tokens"]
        c = credited[k]
        ledger_rows.append({"shard_key": k, "source": shards[k]["source"], "tokens": str(tok), "status": status[k],
                            "representative": rep.get(k, ""), "consumed_tokens": str(c),
                            "epochs": str(q(Decimal(c) / tok, 4)) if tok else "0.0000"})
    chain = facts["chain"]
    rc = {"stage": stage, "records": chain["closing"], "opening_records": int(opening.get("records_closed", 0) or 0),
          "shards_included": len(included), "included_tokens": sum(inc_tokens.values()),
          "consumed_tokens": consumed_total, "optimizer_step": sel["step"],
          "selected_checkpoint": sel["checkpoint"], "total_steps": total}
    opening_cons = opening.get("consumed_by_source", {}) or {}
    mixture = []
    for s in sources:
        it = inc_tokens[s]
        mixture.append({"source": s, "included_shards": inc_count[s], "included_tokens": it,
                        "planned_epochs": format(epochs[s], "f"), "budget_tokens": _ceil(Decimal(it) * epochs[s]),
                        "consumed_tokens": cons_src[s],
                        "cumulative_consumed_tokens": int(opening_cons.get(s, 0) or 0) + cons_src[s],
                        "effective_epochs": str(q(Decimal(cons_src[s]) / it, 4)) if it else "0.0000"})
    counts = {st: 0 for st in STATUSES}
    for st in status.values():
        counts[st] += 1
    tl_counts = {"attempts": len(steps_rows), "applied": 0, "skipped": 0, "abandoned": 0, "post_cutoff": 0,
                 "replays_dropped": facts["replays"], "leaked_tokens": leaked}
    for r in steps_rows:
        tl_counts[r["status"]] += 1
    processed = sum(a["tokens"] for a in tl.order)
    secs = Decimal(0)
    for node, s, e in facts["sessions"]:
        span = parse_instant(e, "ts", "UTC") - parse_instant(s, "ts", "UTC")
        secs += Decimal(int(span.total_seconds())) * params.gpus.get(node, 0)
    recon = {"run_control": rc, "chain": chain, "shards": counts, "timeline": tl_counts,
             "compute": {"flops": 6 * params.n_params * processed, "gpu_hours": str(q(secs / 3600, 2))}}
    seen = {norm_hash(h) for h in (opening.get("seen_hashes") or [])}
    for k in included:
        if shards[k]["hash"] is not None:
            seen.add(norm_hash(shards[k]["hash"]))
    resume = {"stage": stage,
              "next_segment": max(a["segment"] for a in tl.order) + 1,
              "next_attempt": max(tl.attempts) + 1, "optimizer_step": sel["step"], "ema_loss": str(ema_at[cut_attempt]),
              "total_steps": total, "cumulative_tokens": cum,
              "consumed_by_source": {s: int(opening_cons.get(s, 0) or 0) + cons_src[s] for s in sources},
              "seen_hashes": sorted(seen), "selected_checkpoint": sel["checkpoint"], "best_aggregate": sel["aggregate"],
              "records_closed": int(opening.get("records_closed", 0) or 0) + chain["closing"]}
    return {"run_control": rc, "shard_ledger": ledger_rows, "step_ledger": steps_rows,
            "mixture": {"run_control": rc, "sources": mixture},
            "checkpoints": {"run_control": rc, "tainted_benchmarks": tainted, "checkpoints": ck_rows,
                            "selected": {k: sel[k] for k in ("checkpoint", "segment", "step", "aggregate")}},
            "reconciliation": recon, "resume": resume}


SHARD_COLS = ["shard_key", "source", "tokens", "status", "representative", "consumed_tokens", "epochs"]
STEP_COLS = ["attempt", "segment", "status", "optimizer_step", "tokens", "loss", "lr", "ema", "cumulative_tokens"]


def _csv(path: Path, cols: list[str], rows: list[dict], rc: dict) -> None:
    lines = [",".join(cols)] + [",".join(str(r[c]) for c in cols) for r in rows]
    lines.append("#run_control " + json.dumps(rc, sort_keys=True, separators=(",", ":")))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")


def _json(path: Path, obj) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")


def write_outputs(out: Path, result: dict) -> None:
    out.mkdir(parents=True, exist_ok=True)
    rc = result["run_control"]
    _csv(out / "shard_ledger.csv", SHARD_COLS, result["shard_ledger"], rc)
    _csv(out / "step_ledger.csv", STEP_COLS, result["step_ledger"], rc)
    _json(out / "mixture_report.json", result["mixture"])
    _json(out / "checkpoint_report.json", result["checkpoints"])
    _json(out / "reconciliation.json", result["reconciliation"])
    _json(out / "resume_state.json", result["resume"])
