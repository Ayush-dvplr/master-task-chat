"""Feed loading and stream decoding: files -> shard facts and timeline facts (run_spec 2, 4, 6, 8)."""

from __future__ import annotations

import datetime as dt
import email.utils
import json
import re
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo

from . import readers
from .conventions import (UTC, Keys, find_instant, iso_z, norm_hash, parse_dec, parse_frac, parse_instant,
                          parse_int, provisional, q)
from .readers import FeedFile

DOC_FORMATS = {"docx", "pdf", "md", "html"}


class FeedError(Exception):
    pass


class Feed:
    """All files of a stage feed, read through feed_index.json."""

    def __init__(self, root: Path, tolerant: bool = False):
        self.root = root
        self.tolerant = tolerant
        index_path = root / "feed_index.json"
        self.files: dict[str, FeedFile] = {}
        self.missing: list[str] = []
        if index_path.is_file() or not tolerant:
            self.index = json.loads(index_path.read_text(encoding="utf-8"))
            self.entries = sorted(self.index["files"], key=lambda e: e["seq"])
        else:
            self.index = {"files": [], "routing": []}
            self.entries = self._entries_from_controls(root)
        for e in [e for e in self.entries if readers.fmt_of(Path(e["name"])) in DOC_FORMATS]:
            self._load(e)
        self.params = Params(self, tolerant)
        names = self.params.header_names
        for e in self.entries:
            if e["name"] not in self.files and e["name"] not in self.missing:
                self._load(e, names)

    def _entries_from_controls(self, root: Path) -> list[dict]:
        out = []
        for path in sorted(root.iterdir()):
            if not path.is_file() or readers.fmt_of(path) not in readers.READERS:
                continue
            try:
                ff = readers.read(path, set())
            except Exception:
                continue
            out.append({"name": path.name, "stream": ff.control.get("stream"), "seq": ff.control.get("seq", 0)})
        return sorted(out, key=lambda e: e["seq"])

    def _load(self, entry: dict, names: set[str] | None = None) -> None:
        path = self.root / entry["name"]
        if not path.is_file():
            if not self.tolerant:
                raise FeedError(f"feed file missing: {entry['name']}")
            self.missing.append(entry["name"])
            return
        ff = readers.read(path, names or set(), self.tolerant)
        ff.stream = str(ff.control.get("stream") or entry["stream"] or "")
        self.files[entry["name"]] = ff

    def scope_of(self, ff: FeedFile) -> str | None:
        scope = ff.control.get("scope")
        return str(scope).strip() if scope not in (None, "") else None

    def stream(self, name: str, scope: str | None = "in_scope") -> list[FeedFile]:
        """Files of a stream; scope "in_scope" keeps only files without a declared scope."""
        out = []
        for e in self.entries:
            ff = self.files.get(e["name"])
            if ff is None or ff.stream != name:
                continue
            if scope == "in_scope":
                if self.scope_of(ff) is None:
                    out.append(ff)
            elif self.scope_of(ff) == scope:
                out.append(ff)
        return out

    def in_scope_docs(self) -> list[FeedFile]:
        return [ff for ff in self.files.values() if ff.fmt in DOC_FORMATS and self.scope_of(ff) is None]


def _table(feed: Feed, header: list[str]):
    for ff in feed.in_scope_docs():
        for rows in ff.sections.values():
            if rows and list(rows[0].keys()) == header:
                return rows
    raise FeedError(f"no in-scope table with header {header}")


def _all_tables(feed: Feed, header: list[str]):
    for ff in feed.in_scope_docs():
        for rows in ff.sections.values():
            if rows and list(rows[0].keys()) == header:
                yield from rows


_CANONICAL = {"shard_key", "source", "tokenizer_rev", "raw_tokens", "docs", "row_rev", "row_status", "notes",
              "legacy_id", "content_hash", "size_bytes", "storage_class", "license_class", "doc_id", "revision",
              "card_status", "recount_rev", "recount_tokens", "recount_status", "finding_id", "benchmark",
              "overlap", "scanner", "cluster_id", "similarity", "errata_id", "field", "value", "errata_status",
              "action_seq", "action", "reason", "retired_key", "surviving_key", "segment", "attempt", "node",
              "host", "shard", "tokens", "loss_sum", "ckpt_id", "rank", "rank_status", "step", "run_id",
              "h1_run_id", "seed", "score", "run_status"}
_EXTRA_NAMES = {"retracts", "raw_tokens_k", "overlap_pct", "overlap_permille", "score_pct", "loss_sum_mnats",
                "approved_date", "approved_serial", "effective_date", "merged_on"}
TS_BASES = ("ingest", "scan", "recount", "run", "saved", "effective", "merged")
TS_KINDS = ("_ts", "_local", "_epoch", "_epoch_ms", "_serial")
_TS_NAMES = {f"{b}{s}" for b in TS_BASES for s in TS_KINDS} | {"ts", "ts_local", "ts_epoch", "ts_epoch_ms"}


class Params:
    """Rule parameters read from the approved documents."""

    def __init__(self, feed: Feed, tolerant: bool = False):
        self.tolerant = tolerant
        parts = ("_homoglyph_part", "_policy_part", "_dict_part", "_ratio_part", "_cutover_part", "_licence_part",
                 "_bench_part", "_schedule_part", "_node_part", "_prose_part")
        if tolerant:
            for part in parts:
                try:
                    getattr(self, part)(feed)
                except (FeedError, KeyError, ValueError, ArithmeticError):
                    pass
        else:
            for part in parts:
                getattr(self, part)(feed)
        self.keys = Keys(self.homoglyphs)
        self.header_names = (set(self.alias_to_canon) | set(self.alias_to_canon.values())
                             | _CANONICAL | _EXTRA_NAMES | _TS_NAMES)

    def _homoglyph_part(self, feed):
        self.homoglyphs = {r["character"]: r["replace with"]
                           for r in _table(feed, ["character", "code point", "replace with"])}

    def _policy_part(self, feed):
        pol = _table(feed, ["source", "group", "planned_epochs", "keep_k", "legacy aliases"])
        self.sources = sorted(r["source"] for r in pol)
        self.group = {r["source"]: r["group"] for r in pol}
        self.epochs = {r["source"]: Decimal(r["planned_epochs"]) for r in pol}
        self.keep_k = {r["source"]: int(r["keep_k"]) for r in pol}
        self.source_alias = {}
        for r in pol:
            for a in str(r["legacy aliases"]).split():
                if a != "-":
                    self.source_alias[a] = r["source"]

    def _dict_part(self, feed):
        self.alias_to_canon = {r["alias"]: r["canonical"] for r in _table(feed, ["alias", "canonical"])}

    def _ratio_part(self, feed):
        self.ratios = {r["source"]: {"r3": Decimal(r["r3"]), "r4": Decimal(r["r4"]), "r5": Decimal(r["r5"])}
                       for r in _table(feed, ["source", "r3", "r4", "r5"])}

    def _cutover_part(self, feed):
        self.cutover = {int(r["stage"]): dt.date.fromisoformat(str(r["cutover (UTC midnight)"]).strip())
                        for r in _table(feed, ["stage", "cutover (UTC midnight)"])}

    def _licence_part(self, feed):
        self.license_ok = {r["license_class"] for r in _table(feed, ["license_class", "status"]) if r["status"] == "OK"}

    def _bench_part(self, feed):
        self.bench = {r["benchmark"]: {"weight": int(r["weight"]), "exclude": Decimal(r["exclude_threshold"]),
                                       "taint": Decimal(r["taint_threshold"]), "private": r["private"] == "yes"}
                      for r in _table(feed, ["benchmark", "weight", "exclude_threshold", "taint_threshold", "private"])}

    def _schedule_part(self, feed):
        sched = {r["parameter"]: r["value"] for r in _all_tables(feed, ["parameter", "value"])}
        self.lr_peak = Decimal(sched["lr_peak"])
        self.lr_min = Decimal(sched["lr_min"])
        self.warmup = int(sched["warmup_steps"])
        self.ramp = int(sched.get("ramp_steps", 0))
        self.tps_ramp = int(sched.get("tokens_per_step_ramp", 0))
        self.tps_final = int(sched["tokens_per_step_final"])
        self.ckpt_every = int(sched["checkpoint_every"])
        self.beta = Decimal(sched["ema_beta"])
        self.min_select = int(sched["min_select_step"])
        self.ranks = int(sched["ranks"])
        self.n_params = int(sched["n_params"])

    def _node_part(self, feed):
        nodes = _table(feed, ["node", "site_tz", "gpus"])
        self.node_tz = {r["node"]: r["site_tz"] for r in nodes}
        self.gpus = {r["node"]: int(r["gpus"]) for r in nodes}

    def _prose_part(self, feed):
        self.adopted = set()
        for ff in feed.in_scope_docs():
            for t in ff.text:
                m = re.search(r"Sources (.+?) were adopted to tokenizer r6", t)
                if m:
                    self.adopted = {s.strip() for s in re.split(r" and |, ", m.group(1)) if s.strip()}
        self.seeds_needed = 3
        for ff in feed.in_scope_docs():
            for t in ff.text:
                m = re.search(r"at least (\d+) seeds are needed", t)
                if m:
                    self.seeds_needed = int(m.group(1))

    def canon_source(self, name) -> str:
        name = str(name).strip()
        return self.source_alias.get(name, name)

    def cutover_of(self, stage: int):
        return self.cutover.get(stage, dt.date.max) if self.tolerant else self.cutover[stage]


class Ctx:
    """Per-file decoding context (decimal mark, zone, date system, unit)."""

    def __init__(self, ff: FeedFile, params: Params):
        self.ff = ff
        self.comma = ff.control.get("decimal") == ","
        self.tz = ff.control.get("tz", "UTC")
        self.ds = int(ff.control.get("date_system", 1900))
        self.params = params

    def canon(self, row: dict) -> dict:
        a2c = self.params.alias_to_canon
        return {a2c.get(k, k): v for k, v in row.items()}

    def instant(self, row: dict, base: str):
        return find_instant(row, base, self.tz, self.ds)

    def int(self, row: dict, name: str) -> int:
        if f"{name}_k" in row:
            return parse_int(row[f"{name}_k"], self.comma, 1000)
        return parse_int(row[name], self.comma)


def rows_of(ff: FeedFile, params: Params, sections=None):
    """Canonicalised rows of a file, provisional (dagger) rows dropped."""
    ctx = Ctx(ff, params)
    for name, rows in ff.sections.items():
        if sections and name not in sections:
            continue
        for raw in rows:
            if not isinstance(raw, dict):
                continue
            if provisional(next(iter(raw.values()), None)):
                continue
            yield ctx, name, ctx.canon(raw)


def _has(row: dict, *cols) -> bool:
    return all(c in row or f"{c}_k" in row for c in cols)


# --------------------------------------------------------------------- shards

def decode_shards(feed: Feed, stage: int) -> dict:
    P = feed.params
    K = P.keys
    cut = P.cutover_of(stage)
    # voids (4.3): the action with the highest action_seq decides
    last_void: dict[str, tuple[int, str]] = {}
    for ff in feed.stream("voids"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "action_seq", "shard_key"):
                continue
            k = K.norm(r["shard_key"])
            seq = ctx.int(r, "action_seq")
            if k and (k not in last_void or seq > last_void[k][0]):
                last_void[k] = (seq, str(r["action"]).strip().upper())
    void = {k for k, (_, a) in last_void.items() if a == "VOID"}
    # aliases (4.4): the row with the latest merged timestamp decides
    alias: dict[str, tuple] = {}
    for ff in feed.stream("aliases") + feed.stream("aliases", "draft"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "retired_key", "surviving_key"):
                continue
            rk, sk = K.norm(r["retired_key"]), K.norm(r["surviving_key"])
            t = ctx.instant(r, "merged") or dt.datetime.min.replace(tzinfo=UTC)
            if rk and sk and (rk not in alias or t > alias[rk][0]):
                alias[rk] = (t, sk)
    alias_map = {k: v[1] for k, v in alias.items()}
    # legacy crosswalk (registry snapshot, governance Table G2)
    legacy: dict[str, str] = {}
    for ff in feed.stream("registry", "snapshot"):
        for ctx, _, r in rows_of(ff, P):
            if "legacy_id" not in r or "shard_key" not in r:
                continue
            k = K.norm(r["shard_key"])
            if k and str(r["legacy_id"]).strip():
                legacy[str(r["legacy_id"]).strip().lower()] = k
    resolve = Resolver(K, alias_map, legacy)
    # registry (4.1): home partition, VOID rows withdrawn, highest row_rev decides
    routing = {K.norm(r.get("shard_key")): r.get("home") for r in feed.index.get("routing", []) if K.norm(r.get("shard_key"))}
    by_key: dict[str, dict[str, list]] = {}
    for ff in feed.stream("registry"):
        for ctx, _, r in rows_of(ff, P):
            if "shard_key" not in r:
                continue
            k = K.norm(r["shard_key"])
            if k:
                by_key.setdefault(k, {}).setdefault(ff.name, []).append((ctx, r))
    registry = {}
    for k, per_file in by_key.items():
        home = routing.get(k)
        if home not in per_file:
            home = sorted(per_file)[0]
        cand = per_file.get(home)
        if not cand:
            continue
        live = [(ctx, r) for ctx, r in cand if str(r.get("row_status", "")).strip().upper() != "VOID"]
        if not live:
            continue
        ctx, r = max(live, key=lambda cr: cr[0].int(cr[1], "row_rev"))
        registry[k] = {"source": P.canon_source(r["source"]), "rev": str(r["tokenizer_rev"]).strip(),
                       "raw": ctx.int(r, "raw_tokens"), "ingest": ctx.instant(r, "ingest")}
    resolve.existing = set(registry) - void
    # errata (4.8): approved on or before the cutover; latest date, ties by higher errata_id
    errata: dict[tuple, tuple] = {}
    sources = [(ff, False) for ff in feed.stream("errata")] + [(ff, True) for ff in feed.stream("errata", "draft")]
    for ff, carried in sources:
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "errata_id", "field"):
                continue
            status = str(r["errata_status"]).strip()
            if status != ("APPROVED-CARRIED" if carried else "APPROVED"):
                continue
            d = dt.date.fromisoformat(str(r["approved_date"]).strip())
            if d > cut:
                continue
            k = K.norm(r["shard_key"])
            if not k:
                continue
            key = (k, str(r["field"]).strip())
            rank = (d, _errata_rank(r["errata_id"]))
            if key not in errata or rank > errata[key][0]:
                errata[key] = (rank, r["value"], ctx)

    def erratum(k, field):
        e = errata.get((k, field))
        return None if e is None else (e[1], e[2])

    # recounts (4.2 b, c)
    r5: dict[str, tuple] = {}
    for ff in feed.stream("recount"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "recount_rev", "recount_tokens"):
                continue
            if str(r["recount_rev"]).strip() != "r5" or str(r["recount_status"]).strip() != "final":
                continue
            tok = parse_int(r["recount_tokens"], ctx.comma)
            if tok == -1:
                continue
            k = K.norm(r["shard_key"])
            t = ctx.instant(r, "recount") or dt.datetime.min.replace(tzinfo=UTC)
            if k and (k not in r5 or t > r5[k][0]):
                r5[k] = (t, tok)
    r6: dict[str, tuple] = {}
    for ff in feed.stream("recount", "preview"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "recount_rev", "recount_tokens"):
                continue
            if str(r["recount_rev"]).strip() != "r6" or str(r["recount_status"]).strip() != "final":
                continue
            tok = parse_int(r["recount_tokens"], ctx.comma)
            if tok == -1:
                continue
            k = K.norm(r["shard_key"])
            t = ctx.instant(r, "recount") or dt.datetime.min.replace(tzinfo=UTC)
            if k and (k not in r6 or t > r6[k][0]):
                r6[k] = (t, tok)
    # content hashes (4.5): the inventory row with the latest scan timestamp decides
    hashes: dict[str, tuple] = {}
    for ff, archive in ([(f, False) for f in feed.stream("inventory")] + [(f, True) for f in feed.stream("inventory", "archive")]):
        for ctx, _, r in rows_of(ff, P):
            if "content_hash" not in r:
                continue
            if archive and str(r.get("storage_class", "")).strip() != "glacier":
                continue
            k = resolve.key_only(r["shard_key"])
            t = ctx.instant(r, "scan") or dt.datetime.min.replace(tzinfo=UTC)
            if k and (k not in hashes or t > hashes[k][0]):
                hashes[k] = (t, norm_hash(r["content_hash"]))
    # licences (4.6): the row with the latest effective timestamp decides
    lic: dict[str, tuple] = {}
    for ff in feed.stream("license"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "shard_key", "license_class"):
                continue
            k = resolve.key_only(r["shard_key"])
            t = ctx.instant(r, "effective") or dt.datetime.min.replace(tzinfo=UTC)
            if k and (k not in lic or t > lic[k][0]):
                lic[k] = (t, str(r["license_class"]).strip())
    revoked = set()
    for ff in feed.stream("license", "vendor"):
        for ctx, _, r in rows_of(ff, P, sections={"revocation"}):
            k = resolve.key_only(r.get("shard_key"))
            if k:
                revoked.add(k)
    # data cards (4.7): the highest revision decides
    doc_index: dict[str, str] = {}
    for ff in feed.stream("datacard", "archive"):
        for ctx, _, r in rows_of(ff, P, sections={"doc_index"}):
            doc_index[str(r["doc_id"]).strip()] = K.norm(r["shard_key"])
    cards: dict[str, tuple] = {}
    for ff in feed.stream("datacard"):
        for ctx, _, r in rows_of(ff, P):
            if "revision" not in r or "card_status" not in r:
                continue
            if "doc_id" in r:
                k = doc_index.get(str(r["doc_id"]).strip())
                if k is None:
                    continue
            elif "shard_key" in r:
                k = K.norm(r["shard_key"])
            else:
                continue
            rev = int(parse_int(r["revision"], ctx.comma))
            if k and (k not in cards or rev > cards[k][0]):
                cards[k] = (rev, str(r["card_status"]).strip().upper(), _card_date(ctx, r))
    # near-duplicate clusters (4.10): a dissolved cluster does not exist
    dissolved = set()
    for ff in feed.stream("neardup", "v1"):
        for ctx, _, r in rows_of(ff, P, sections={"dissolved"}):
            dissolved.add(str(r["cluster_id"]).strip())
    cluster: dict[str, str] = {}
    for ff in feed.stream("neardup"):
        for ctx, _, r in rows_of(ff, P):
            if "cluster_id" not in r or "shard_key" not in r:
                continue
            cid = str(r["cluster_id"]).strip()
            k = resolve.key_only(r["shard_key"])
            if k and cid and cid not in dissolved:
                cluster[k] = cid
    # assemble (4.2 order)
    shards = {}
    for k in sorted(set(registry) - void):
        reg = registry[k]
        e_src = erratum(k, "source")
        src = P.canon_source(e_src[0]) if e_src else reg["source"]
        e_tok = erratum(k, "tokens")
        if e_tok:
            tokens = parse_int(e_tok[0], e_tok[1].comma)
        elif k in r6 and src in P.adopted:
            tokens = r6[k][1]
        elif k in r5:
            tokens = r5[k][1]
        else:
            tokens = _round_half_even(Decimal(reg["raw"]) * P.ratios.get(src, {}).get(reg["rev"], Decimal(1)))
        e_ing = erratum(k, "ingest_ts")
        ingest = parse_instant(e_ing[0], "ts", "UTC") if e_ing else reg["ingest"]
        e_lic = erratum(k, "license")
        cls = str(e_lic[0]).strip() if e_lic else lic.get(k, (None, None))[1]
        if cls is None:
            ok = False
        elif cls == "N/A":
            ok = P.group.get(src) == "A"
        else:
            ok = k not in revoked and cls in P.license_ok
        card = cards.get(k)
        approved = bool(card and card[1] == "APPROVED" and card[2] is not None and card[2] <= cut)
        shards[k] = {"source": src, "tokens": tokens, "ingest_ts": iso_z(ingest), "hash": hashes.get(k, (None, None))[1],
                     "license_ok": ok, "approved": approved, "cluster": cluster.get(k)}
    # contamination findings (4.9)
    retracted = set()
    for ff in feed.stream("contamination", "rerun"):
        for ctx, _, r in rows_of(ff, P, sections={"retracts"}):
            retracted.add(str(r["retracts"]).strip())
    contam: dict[str, dict] = {}
    for ff in feed.stream("contamination"):
        for ctx, _, r in rows_of(ff, P):
            if "finding_id" not in r:
                continue
            if str(r["finding_id"]).strip() in retracted:
                continue
            col = next((c for c in ("overlap", "overlap_pct", "overlap_permille") if c in r), None)
            if col is None or str(r[col]).strip().upper() == "N/A":
                continue
            k = resolve.key(r["shard_key"])
            if k is None:
                continue
            unit = {"overlap": "fraction", "overlap_pct": "percent", "overlap_permille": "permille"}[col]
            v = parse_frac(r[col], ctx.comma, unit)
            b = str(r["benchmark"]).strip()
            cur = contam.setdefault(k, {})
            if b not in cur or v > cur[b]:
                cur[b] = v
    return {"shards": shards, "contam": {k: {b: str(v) for b, v in sorted(m.items())} for k, m in sorted(contam.items())},
            "_resolve": resolve}


def _errata_rank(errata_id) -> tuple:
    s = str(errata_id).strip()
    m = re.search(r"(\d+)", s)
    return (int(m.group(1)) if m else -1, s)


def _round_half_even(value: Decimal) -> int:
    """Round to the nearest integer, ties to even (errata C4)."""
    return int(value.quantize(Decimal(1), rounding="ROUND_HALF_EVEN"))


def _card_date(ctx: Ctx, r: dict):
    if "approved_serial" in r:
        v = r["approved_serial"]
        if v in ("", None):
            return None
        from .conventions import serial_to_datetime
        return serial_to_datetime(v, ctx.ds).date()
    v = str(r.get("approved_date", "")).strip()
    if not v or v == "0000-00-00":
        return None
    return dt.date.fromisoformat(v)


class Resolver:
    """Shard references: legacy ids, retired keys, voids (3.1, 4.3, 4.4)."""

    def __init__(self, keys: Keys, alias: dict, legacy: dict, existing: set | None = None):
        self.keys, self.alias, self.legacy = keys, alias, legacy
        self.existing = set() if existing is None else existing

    def key_only(self, text):
        s = str(text).strip()
        k = self.legacy.get(s.lower()) if Keys.is_legacy(s) else self.keys.norm(s)
        if k in self.alias:
            k = self.alias[k]
        return k

    def key(self, text):
        k = self.key_only(text)
        return k if k in self.existing else None


# ------------------------------------------------------------------- timeline

def _msgid(v) -> str:
    return re.sub(r"\s", "", str(v).strip().strip("<>")).lower()


def decode_alerts(feed: Feed):
    msgs: dict[str, dict] = {}
    for ff in feed.stream("alerts"):
        for m in ff.sections.get("messages", []):
            msgs.setdefault(_msgid(m.get("Message-ID", "")), m)
    retracted = {_msgid(m.get("X-Retracts")) for m in msgs.values() if m.get("X-Alert-Type") == "RETRACT"}
    live = {i: m for i, m in msgs.items() if i not in retracted}
    overflow = sorted({(int(m["X-Segment"]), int(m["X-Attempt"]))
                       for m in live.values() if m.get("X-Alert-Type") == "OVERFLOW"})
    rollbacks = {}
    for m in live.values():
        if m.get("X-Alert-Type") != "ROLLBACK":
            continue
        key = (int(m["X-From-Segment"]), int(m["X-To-Segment"]))
        when = email.utils.parsedate_to_datetime(m["Date"]).astimezone(UTC)
        rank = (when, _msgid(m.get("Message-ID", "")))
        if key not in rollbacks or rank > rollbacks[key][0]:
            rollbacks[key] = (rank, int(m["X-Resume-Step"]))
    roll = sorted([list(k) + [v[1]] for k, v in rollbacks.items()])
    trunc = [(m["X-Node"], parse_instant(m["X-Window-Start"], "ts", "UTC"), parse_instant(m["X-Window-End"], "ts", "UTC"))
             for _, m in sorted(live.items()) if m.get("X-Alert-Type") == "TRUNCATION"]
    return overflow, roll, trunc


def _ics_time(ev: dict, prop: str, zone: str) -> dt.datetime:
    v = ev[prop]
    if v.endswith("Z"):
        return dt.datetime.strptime(v, "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
    tz = ev.get(f"{prop}.TZID") or zone
    return (dt.datetime.strptime(v, "%Y%m%dT%H%M%S").replace(tzinfo=ZoneInfo(tz), fold=0)).astimezone(UTC)


def decode_calendar(feed: Feed):
    P = feed.params
    latest = {}
    for ff in feed.stream("calendar"):
        for ev in ff.sections.get("events", []):
            uid = ev["UID"]
            if uid not in latest or int(ev.get("SEQUENCE", 0)) > int(latest[uid].get("SEQUENCE", 0)):
                latest[uid] = ev
    sessions, windows = [], {}
    for uid in sorted(latest):
        ev = latest[uid]
        if ev.get("STATUS") == "CANCELLED":
            continue
        node = ev["X-NODE"]
        tz = P.node_tz.get(node, "UTC")
        s, e = _ics_time(ev, "DTSTART", tz), _ics_time(ev, "DTEND", tz)
        if ev["CATEGORIES"] == "SESSION":
            sessions.append((node, s, e))
        elif ev["CATEGORIES"] in ("PREEMPTED", "MAINTENANCE"):
            windows.setdefault(node, []).append((s, e))
    return sorted(sessions), windows


def decode_trainlog(feed: Feed, resolve: Resolver, windows: dict, trunc: list):
    P = feed.params
    hosts: dict[str, str] = {}
    for ff in feed.stream("trainlog", "aggregate"):
        for ctx, _, r in rows_of(ff, P, sections={"hosts"}):
            hosts[str(r["host"]).strip()] = str(r["node"]).strip()
    trunc_of = {node: (lo, hi) for node, lo, hi in trunc}
    records, replays = [], 0

    def add(ctx, r, node):
        nonlocal replays
        t = ctx.instant(r, "ts")
        if any(s <= t < e for s, e in windows.get(node, [])):
            replays += 1
            return
        tokens = ctx.int(r, "tokens")
        if "loss_sum_mnats" in r:
            raw = str(r["loss_sum_mnats"]).strip()
            loss = None if raw.lower() in ("", "nan", "inf") else parse_dec(raw, ctx.comma) / 1000
        else:
            raw = str(r["loss_sum"]).strip()
            loss = None if raw.lower() in ("", "nan", "inf") else parse_dec(raw, ctx.comma)
        records.append([int(parse_int(r["segment"], ctx.comma)), parse_int(r["attempt"], ctx.comma), node,
                        resolve.key(r["shard"]), tokens, None if loss is None else str(q(loss, 3))])

    for ff in feed.stream("trainlog"):
        for ctx, _, r in rows_of(ff, P):
            if "attempt" not in r:
                continue
            node = str(r["node"]).strip() if "node" in r else hosts.get(str(r["host"]).strip())
            if node is None:
                raise FeedError(f"unmapped host {r.get('host')!r} in {ff.name}")
            t = ctx.instant(r, "ts")
            w = trunc_of.get(node)
            if w and t is not None and w[0] <= t < w[1]:
                continue
            add(ctx, r, node)
    for ff in feed.stream("trainlog", "replay"):
        node = str(ff.control.get("node", "")).strip()
        w = trunc_of.get(node)
        for ctx, _, r in rows_of(ff, P):
            if "attempt" not in r or w is None:
                continue
            t = ctx.instant(r, "ts")
            if t is None or not (w[0] <= t < w[1]):
                continue
            n = str(r["node"]).strip() if "node" in r else hosts.get(str(r["host"]).strip()) or node
            add(ctx, r, n)
    records.sort(key=lambda x: (x[0], x[1], x[2]))
    return records, replays


def decode_checkpoints(feed: Feed):
    P = feed.params
    ok: dict[str, set] = {}
    meta: dict[str, tuple] = {}
    for ff in feed.stream("checkpoints"):
        for ctx, _, r in rows_of(ff, P):
            if "rank" not in r:
                continue
            c = str(r["ckpt_id"]).strip()
            if c not in meta:
                meta[c] = (int(parse_int(r["segment"], ctx.comma)), parse_int(r["step"], ctx.comma))
            ok.setdefault(c, set())
            if str(r["rank_status"]).strip().lower() == "ok":
                ok[c].add(parse_int(r["rank"], ctx.comma))
    tomb = set()
    for ff in feed.stream("checkpoints", "mirror"):
        for ctx, _, r in rows_of(ff, P, sections={"tombstones"}):
            tomb.add(str(r["ckpt_id"]).strip())
    full = set(range(P.ranks))
    return {c: {"segment": meta[c][0], "step": meta[c][1], "complete": full <= ok.get(c, set()),
                "tombstoned": c in tomb} for c in sorted(meta)}


def decode_evals(feed: Feed):
    P = feed.params
    run_map, h1_map = {}, {}
    for ff in feed.stream("evals", "consolidated"):
        for ctx, _, r in rows_of(ff, P, sections={"run_map"}):
            run_map[str(r["run_id"]).strip()] = str(r["ckpt_id"]).strip()
    for ff in feed.stream("evals", "superseded"):
        for ctx, _, r in rows_of(ff, P):
            if "h1_run_id" in r and "ckpt_id" in r:
                h1_map[str(r["h1_run_id"]).strip()] = str(r["ckpt_id"]).strip()
    private = {b for b, v in P.bench.items() if v["private"]}
    best: dict[tuple, tuple] = {}
    files = [(ff, False) for ff in feed.stream("evals")] + [(ff, True) for ff in feed.stream("evals", "leaderboard")]
    for ff, board in files:
        for ctx, _, r in rows_of(ff, P):
            if "benchmark" not in r or "seed" not in r:
                continue
            b = str(r["benchmark"]).strip()
            if board and b not in private:
                continue
            if str(r["run_status"]).strip() != "ok":
                continue
            col = "score" if "score" in r else "score_pct"
            raw = str(r[col]).strip()
            if raw in ("-1", ""):
                continue
            if "ckpt_id" in r:
                ck = str(r["ckpt_id"]).strip()
            elif "run_id" in r:
                ck = run_map.get(str(r["run_id"]).strip())
            else:
                ck = h1_map.get(str(r["h1_run_id"]).strip())
            if ck is None:
                continue
            score = q(parse_frac(raw, ctx.comma, "fraction" if col == "score" else "percent"), 4)
            t = ctx.instant(r, "run") or dt.datetime.min.replace(tzinfo=UTC)
            key = (ck, b, parse_int(r["seed"], ctx.comma))
            if key not in best or t > best[key][0]:
                best[key] = (t, score)
    out: dict[str, dict] = {}
    for (ck, b, seed), (_, score) in sorted(best.items()):
        out.setdefault(ck, {}).setdefault(b, []).append(str(score))
    return out


def chain_report(feed: Feed) -> dict:
    files, breaks, running, expect_seq = [], [], 0, 1
    for e in feed.entries:
        ff = feed.files.get(e["name"])
        if ff is None:
            breaks.append(e["name"])
            files.append({"name": e["name"], "seq": e["seq"], "stream": e["stream"],
                          "opening": None, "records": None, "counted": None})
            expect_seq = e["seq"] + 1
            continue
        c = ff.control
        bad = c.get("seq") != e["seq"] or e["seq"] != expect_seq or c.get("records") != ff.counted
        if bad:
            breaks.append(e["name"])
        files.append({"name": e["name"], "seq": e["seq"], "stream": e["stream"], "opening": running,
                      "records": c.get("records"), "counted": ff.counted})
        running += ff.counted
        expect_seq = e["seq"] + 1
    return {"ok": not breaks, "closing": running, "breaks": breaks, "files": files}


def load_facts(root: Path, stage: int, tolerant: bool = False) -> tuple[Feed, dict]:
    """Decode a feed.  tolerant=True skips absent files and absent parameter tables."""
    feed = Feed(root, tolerant=tolerant)
    sh = decode_shards(feed, stage)
    overflow, rollbacks, trunc = decode_alerts(feed)
    sessions, windows = decode_calendar(feed)
    records, replays = decode_trainlog(feed, sh["_resolve"], windows, trunc)
    facts = {"shards": sh["shards"], "contam": sh["contam"], "overflow": [list(x) for x in overflow],
             "rollbacks": [list(x) for x in rollbacks], "records": records, "replays": replays,
             "ckpts": decode_checkpoints(feed), "evals": decode_evals(feed),
             "sessions": [[n, iso_z(s), iso_z(e)] for n, s, e in sessions],
             "chain": chain_report(feed)}
    return feed, facts
