"""Feed loading and stream decoding: files -> shard facts and timeline facts (run_spec 2, 4, 6, 8)."""

from __future__ import annotations

import datetime as dt
import json
import re
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo

from . import readers
from .conventions import (UTC, FeedError, Keys, find_date, find_instant, iso_z, norm_hash, parse_dec, parse_frac,
                          parse_instant, parse_int, provisional, q)

DOC_FORMATS = {"docx", "pdf", "md", "html"}


class Feed:
    """All files of a stage feed, read through feed_index.json."""

    def __init__(self, root: Path, tolerant: bool = False):
        self.root = root
        self.tolerant = tolerant
        index_path = root / "feed_index.json"
        self.files: dict[str, readers.FeedFile] = {}
        self.missing: list[str] = []
        if index_path.is_file() or not tolerant:
            self.index = json.loads(index_path.read_text(encoding="utf-8"))
            self.entries = sorted(self.index["files"], key=lambda e: e["seq"])
        else:
            self.index = {"files": [], "routing": []}
            self.entries = self._entries_from_controls(root)
        docs = [e for e in self.entries if readers.fmt_of(Path(e["name"])) in DOC_FORMATS]
        for e in docs:
            self._load(e, set())
        self.params = Params(self, tolerant)
        names = self.params.header_names
        for e in self.entries:
            if e["name"] not in self.files and e["name"] not in self.missing:
                self._load(e, names)

    def _entries_from_controls(self, root: Path) -> list[dict]:
        out = []
        for path in sorted(root.iterdir()):
            if not path.is_file() or readers.fmt_of(path) not in readers.READERS:
                continue
            try:
                ff = readers.read(path, set())
            except Exception:
                continue
            out.append({"name": path.name, "stream": ff.control.get("stream"), "seq": ff.control.get("seq", 0)})
        return sorted(out, key=lambda e: e["seq"])

    def _load(self, entry: dict, names: set[str]) -> None:
        path = self.root / entry["name"]
        if not path.is_file():
            if not self.tolerant:
                raise FeedError(f"feed file missing: {entry['name']}")
            self.missing.append(entry["name"])
            return
        ff = readers.read(path, names, self.tolerant)
        ff.stream = entry["stream"]
        self.files[entry["name"]] = ff

    def stream(self, name: str, scope: str | None = None) -> list[readers.FeedFile]:
        """Files of a stream in chain order; scope None means the in-scope files (governance G0)."""
        out = []
        for e in self.entries:
            ff = self.files.get(e["name"])
            if ff is None or e["stream"] != name:
                continue
            if ff.control.get("scope") == scope or (scope is None and not ff.control.get("scope")):
                out.append(ff)
        return out

    def in_scope_docs(self) -> list[readers.FeedFile]:
        out = []
        for e in self.entries:
            ff = self.files.get(e["name"])
            if ff is not None and ff.fmt in DOC_FORMATS and not ff.control.get("scope"):
                out.append(ff)
        return out


def _table(feed: Feed, header: list[str]):
    for ff in feed.in_scope_docs():
        for name, rows in ff.sections.items():
            if rows and list(rows[0].keys()) == header:
                return rows
    raise FeedError(f"no in-scope table with header {header}")


class Params:
    """Rule parameters read from the approved documents."""

    def __init__(self, feed: Feed, tolerant: bool = False):
        if tolerant:
            self._tolerant(feed)
            return
        self._read(feed)

    def _tolerant(self, feed: Feed) -> None:
        """Every table that is present is used; an absent one leaves its defaults."""
        self.tolerant = True
        self.homoglyphs, self.sources, self.group, self.epochs, self.keep_k = {}, [], {}, {}, {}
        self.source_alias, self.alias_to_canon, self.ratios, self.cutover = {}, {}, {}, {}
        self.license_ok, self.bench, self.node_tz, self.gpus, self.adopted = set(), {}, {}, {}, set()
        self.lr_peak, self.lr_min, self.warmup, self.tps_final = Decimal(0), Decimal(0), 1, 1
        self.ckpt_every, self.beta, self.min_select, self.ranks, self.n_params, self.seeds_needed = 1, Decimal("0.98"), 0, 64, 0, 3
        for part in ("_homoglyph_part", "_policy_part", "_dict_part", "_ratio_part", "_cutover_part", "_licence_part",
                     "_bench_part", "_schedule_part", "_node_part", "_prose_part"):
            try:
                getattr(self, part)(feed)
            except (FeedError, KeyError, ValueError, ArithmeticError):
                pass
        self.keys = Keys(self.homoglyphs)
        self.header_names = set(self.alias_to_canon) | set(self.alias_to_canon.values()) | _TS_NAMES | _CANONICAL

    def _read(self, feed: Feed) -> None:
        self.tolerant = False
        for part in ("_homoglyph_part", "_policy_part", "_dict_part", "_ratio_part", "_cutover_part", "_licence_part",
                     "_bench_part", "_schedule_part", "_node_part", "_prose_part"):
            getattr(self, part)(feed)
        self.keys = Keys(self.homoglyphs)
        self.header_names = set(self.alias_to_canon) | set(self.alias_to_canon.values()) | _TS_NAMES | _CANONICAL

    def _homoglyph_part(self, feed):
        self.homoglyphs = {r["character"]: r["replace with"] for r in _table(feed, ["character", "code point", "replace with"])}

    def _policy_part(self, feed):
        pol = _table(feed, ["source", "group", "planned_epochs", "keep_k", "legacy aliases"])
        self.sources = sorted(r["source"] for r in pol)
        self.group = {r["source"]: r["group"] for r in pol}
        self.epochs = {r["source"]: Decimal(r["planned_epochs"]) for r in pol}
        self.keep_k = {r["source"]: int(r["keep_k"]) for r in pol}
        self.source_alias = {}
        for r in pol:
            for a in r["legacy aliases"].split():
                if a != "-":
                    self.source_alias[a] = r["source"]

    def _dict_part(self, feed):
        self.alias_to_canon = {r["alias"]: r["canonical"] for r in _table(feed, ["alias", "canonical"])}

    def _ratio_part(self, feed):
        self.ratios = {r["source"]: {"r3": Decimal(r["r3"]), "r4": Decimal(r["r4"]), "r5": Decimal(r["r5"])}
                       for r in _table(feed, ["source", "r3", "r4", "r5"])}

    def _cutover_part(self, feed):
        self.cutover = {int(r["stage"]): dt.date.fromisoformat(r["cutover (UTC midnight)"])
                        for r in _table(feed, ["stage", "cutover (UTC midnight)"])}

    def _licence_part(self, feed):
        self.license_ok = {r["license_class"] for r in _table(feed, ["license_class", "status"]) if r["status"] == "OK"}

    def _bench_part(self, feed):
        self.bench = {r["benchmark"]: {"weight": int(r["weight"]), "exclude": Decimal(r["exclude_threshold"]),
                                       "taint": Decimal(r["taint_threshold"]), "private": r["private"] == "yes"}
                      for r in _table(feed, ["benchmark", "weight", "exclude_threshold", "taint_threshold", "private"])}

    def _schedule_part(self, feed):
        sched = {r["parameter"]: r["value"] for r in _all_tables(feed, ["parameter", "value"])}
        self.lr_peak = Decimal(sched["lr_peak"])
        self.lr_min = Decimal(sched["lr_min"])
        self.warmup = int(sched["warmup_steps"])
        self.tps_final = int(sched["tokens_per_step_final"])
        self.ckpt_every = int(sched["checkpoint_every"])
        self.beta = Decimal(sched["ema_beta"])
        self.min_select = int(sched["min_select_step"])
        self.ranks = int(sched["ranks"])
        self.n_params = int(sched["n_params"])

    def _node_part(self, feed):
        nodes = _table(feed, ["node", "site_tz", "gpus"])
        self.node_tz = {r["node"]: r["site_tz"] for r in nodes}
        self.gpus = {r["node"]: int(r["gpus"]) for r in nodes}

    def _prose_part(self, feed):
        self.adopted = set()
        for ff in feed.in_scope_docs():
            for t in ff.text:
                m = re.search(r"Sources (.+?) were adopted to tokenizer r6", t)
                if m:
                    self.adopted = {s.strip() for s in m.group(1).split(" and ")}
        self.seeds_needed = 3
        for ff in feed.in_scope_docs():
            for t in ff.text:
                m = re.search(r"at least (\d+) seeds are needed", t)
                if m:
                    self.seeds_needed = int(m.group(1))

    def canon_source(self, name: str) -> str:
        name = str(name).strip()
        return self.source_alias.get(name, name)


def _all_tables(feed: Feed, header: list[str]):
    for ff in feed.in_scope_docs():
        for rows in ff.sections.values():
            if rows and list(rows[0].keys()) == header:
                yield from rows


_CANONICAL = {"shard_key", "source", "tokenizer_rev", "raw_tokens", "docs", "row_rev", "row_status", "notes", "legacy_id",
              "content_hash", "size_bytes", "storage_class", "license_class", "doc_id", "revision", "card_status",
              "recount_rev", "recount_tokens", "recount_status", "finding_id", "benchmark", "overlap", "scanner", "cluster_id",
              "similarity", "errata_id", "field", "value", "errata_status", "action_seq", "action", "reason", "retired_key",
              "surviving_key", "segment", "attempt", "node", "host", "shard", "tokens", "loss_sum", "ckpt_id", "rank",
              "rank_status", "step", "run_id", "h1_run_id", "seed", "score", "run_status"}
_EXTRA_NAMES = {"retracts", "raw_tokens_k", "overlap_pct", "overlap_permille", "score_pct", "loss_sum_mnats",
                "approved_date", "approved_serial"}
_TS_NAMES = {f"{b}{s}" for b in ("ingest", "scan", "recount", "run", "saved", "effective", "merged")
             for s in ("_ts", "_local", "_epoch", "_epoch_ms", "_serial")} | {"ts", "ts_local", "ts_epoch", "ts_epoch_ms",
                                                                           "approved_date", "approved_serial", "overlap_pct",
                                                                           "overlap_permille", "score_pct", "raw_tokens_k",
                                                                           "loss_sum_mnats"}


class Ctx:
    """Per-file decoding context (decimal mark, zone, date system, unit)."""

    def __init__(self, ff: readers.FeedFile, params: Params):
        self.ff = ff
        self.comma = ff.control.get("decimal") == ","
        self.tz = ff.control.get("tz", "UTC")
        self.ds = int(ff.control.get("date_system", 1900))
        self.params = params

    def canon(self, row: dict) -> dict:
        a2c = self.params.alias_to_canon
        return {a2c.get(k, k): v for k, v in row.items()}

    def instant(self, row: dict, base: str):
        return find_instant(row, base, self.tz, self.ds)

    def date(self, row: dict, base: str):
        return find_date(row, base, self.ds)

    def int(self, row: dict, name: str) -> int:
        if f"{name}_k" in row:
            return parse_int(row[f"{name}_k"], self.comma, 1000)
        return parse_int(row[name], self.comma)


def rows_of(ff: readers.FeedFile, params: Params, sections=None):
    """Canonicalised rows of a file, provisional (dagger) rows dropped."""
    ctx = Ctx(ff, params)
    for name, rows in ff.sections.items():
        if sections and name not in sections:
            continue
        for raw in rows:
            if not isinstance(raw, dict):
                continue
            first = next(iter(raw.values()), None)
            if provisional(first):
                continue
            row = ctx.canon(raw)
            if params.tolerant and not set(row) <= _KNOWN:
                continue
            yield ctx, name, row


def _has(row: dict, *cols) -> bool:
    return all(c in row or f"{c}_k" in row for c in cols)


def _txt(value) -> str:
    return str(value).strip()


# --------------------------------------------------------------------- shards

def decode_shards(feed: Feed, stage: int) -> dict:
    P = feed.params
    K = P.keys
    cut = P.cutover.get(stage, dt.date.max) if feed.tolerant else P.cutover[stage]
    # voids (4.3): the action with the highest action_seq decides
    last_void: dict[str, tuple[int, str]] = {}
    for ff in feed.stream("voids"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "action_seq", "shard_key"):
                continue
            k = K.norm(r["shard_key"])
            seq = parse_int(r["action_seq"], ctx.comma)
            if k and (k not in last_void or seq > last_void[k][0]):
                last_void[k] = (seq, _txt(r["action"]).upper())
    void = {k for k, (_, a) in last_void.items() if a == "VOID"}
    # aliases (4.4): in-scope parts and the draft spec's part
    alias: dict[str, tuple] = {}
    for ff in feed.stream("aliases") + feed.stream("aliases", "draft"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "retired_key", "surviving_key"):
                continue
            rk, sk = K.norm(r["retired_key"]), K.norm(r["surviving_key"])
            t = ctx.instant(r, "merged")
            if rk and (rk not in alias or t > alias[rk][0]):
                alias[rk] = (t, sk)
    alias_map = {k: v[1] for k, v in alias.items()}
    # legacy crosswalk (registry snapshot) and host map (aggregate trainlog)
    legacy = {}
    for ff in feed.stream("registry", "snapshot"):
        for ctx, _, r in rows_of(ff, P):
            if "legacy_id" not in r or "shard_key" not in r:
                continue
            lid = _txt(r["legacy_id"]).lower()
            k = K.norm(r["shard_key"])
            if lid and k:
                legacy.setdefault(lid, k)
    # registry (4.1)
    routing = {}
    for r in feed.index.get("routing", []):
        routing[K.norm(r["shard_key"])] = r["home"]
    by_key: dict[str, dict[str, list]] = {}
    for ff in feed.stream("registry"):
        for ctx, _, r in rows_of(ff, P):
            if "shard_key" not in r:
                continue
            k = K.norm(r["shard_key"])
            if k is None:
                continue
            by_key.setdefault(k, {}).setdefault(ff.name, []).append((ctx, r))
    registry = {}
    for k, per_file in by_key.items():
        if len(per_file) > 1:
            home = routing.get(k)
        else:
            home = next(iter(per_file))
        cand = [cr for cr in per_file.get(home, []) if _txt(cr[1].get("row_status", "")).upper() != "VOID"]
        if not cand:
            continue
        ctx, r = max(cand, key=lambda cr: parse_int(cr[1]["row_rev"], cr[0].comma))
        registry[k] = {"source": P.canon_source(r["source"]), "rev": _txt(r["tokenizer_rev"]),
                       "raw": ctx.int(r, "raw_tokens"), "ingest": ctx.instant(r, "ingest")}
    resolve = Resolver(K, alias_map, legacy, set(registry) - void)
    # errata (4.8): revision A in scope, carried approvals of the draft revision
    errata: dict[tuple, tuple] = {}
    for ff, carried in [(f, False) for f in feed.stream("errata")] + [(f, True) for f in feed.stream("errata", "draft")]:
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "errata_id", "field"):
                continue
            status = _txt(r["errata_status"])
            if carried and status != "APPROVED-CARRIED":
                continue
            if not carried and status != "APPROVED":
                continue
            d = ctx.date(r, "approved")
            if d is None or d > cut:  # a correction applies from its approval
                continue
            k = K.norm(r["shard_key"])
            key = (k, _txt(r["field"]))
            rank = (d, _txt(r["errata_id"]))
            if key not in errata or rank > errata[key][0]:
                errata[key] = (rank, r["value"], ctx)

    def erratum(k, field):
        e = errata.get((k, field))
        return None if e is None else (e[1], e[2])

    # recounts (4.2)
    r5: dict[str, tuple] = {}
    for ff in feed.stream("recount"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "recount_rev", "recount_tokens"):
                continue
            if _txt(r["recount_rev"]) != "r5" or _txt(r["recount_status"]) != "final":
                continue
            tok = parse_int(r["recount_tokens"], ctx.comma)
            if tok == -1:
                continue
            k = K.norm(r["shard_key"])
            t = ctx.instant(r, "recount")
            if k not in r5 or t > r5[k][0]:
                r5[k] = (t, tok)
    r6: dict[str, tuple] = {}
    for ff in feed.stream("recount", "preview"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "recount_rev", "recount_tokens"):
                continue
            if _txt(r.get("recount_rev", "")) != "r6" or _txt(r.get("recount_status", "")) != "final":
                continue
            tok = parse_int(r["recount_tokens"], ctx.comma)
            if tok == -1:
                continue
            k = K.norm(r["shard_key"])
            t = ctx.instant(r, "recount")
            if k not in r6 or t > r6[k][0]:
                r6[k] = (t, tok)
    # content hashes (4.5): archive rows count for glacier objects only
    hashes: dict[str, tuple] = {}
    inv_rows = [(ff, False) for ff in feed.stream("inventory")] + [(ff, True) for ff in feed.stream("inventory", "archive")]
    for ff, archive in inv_rows:
        for ctx, _, r in rows_of(ff, P):
            if "content_hash" not in r:
                continue
            if archive and _txt(r.get("storage_class", "")).lower() != "glacier":
                continue
            k = resolve.key_only(r["shard_key"])
            t = ctx.instant(r, "scan")
            if k and (k not in hashes or t > hashes[k][0]):
                hashes[k] = (t, norm_hash(r["content_hash"]))
    # licences (4.6)
    lic: dict[str, tuple] = {}
    for ff in feed.stream("license"):
        for ctx, _, r in rows_of(ff, P):
            if not _has(r, "shard_key", "license_class"):
                continue
            k = K.norm(r["shard_key"])
            t = ctx.instant(r, "effective")
            if k not in lic or t > lic[k][0]:
                lic[k] = (t, _txt(r["license_class"]))
    revoked = set()
    for ff in feed.stream("license", "vendor"):
        for ctx, name, r in rows_of(ff, P):
            if "shard_key" in r and "license_class" not in r:
                k = K.norm(r["shard_key"])
                if k:
                    revoked.add(k)
    # data cards (4.7)
    doc_index = {}
    for ff in feed.stream("datacard", "archive"):
        for ctx, name, r in rows_of(ff, P, sections={"doc_index"}):
            doc_index[_txt(r["doc_id"])] = K.norm(r["shard_key"])
    cards: dict[str, tuple] = {}
    for ff in feed.stream("datacard"):
        for ctx, _, r in rows_of(ff, P):
            if "revision" not in r or "card_status" not in r:
                continue
            if "doc_id" in r:
                k = doc_index.get(_txt(r["doc_id"]))
            else:
                k = K.norm(r["shard_key"])
            if k is None:
                continue
            rev = parse_int(r["revision"], ctx.comma)
            if k not in cards or rev > cards[k][0]:
                cards[k] = (rev, _txt(r["card_status"]), ctx.date(r, "approved"))
    # near-duplicate clusters (4.10)
    dissolved = set()
    for ff in feed.stream("neardup", "v1"):
        for ctx, _, r in rows_of(ff, P):
            if "cluster_id" in r and "shard_key" not in r:
                dissolved.add(_txt(r["cluster_id"]))
    cluster = {}
    for ff in feed.stream("neardup"):
        for ctx, _, r in rows_of(ff, P):
            if _has(r, "shard_key", "cluster_id"):
                cid = _txt(r["cluster_id"])
                k = K.norm(r["shard_key"])
                if k and cid not in dissolved:
                    cluster[k] = cid
    # assemble (4.2 order)
    shards = {}
    for k in sorted(set(registry) - void):
        reg = registry[k]
        e_src = erratum(k, "source")
        src = P.canon_source(e_src[0]) if e_src else reg["source"]
        e_tok = erratum(k, "tokens")
        if e_tok:
            tokens = parse_int(e_tok[0], e_tok[1].comma)
        elif k in r6 and src in P.adopted:
            tokens = r6[k][1]
        elif k in r5:
            tokens = r5[k][1]
        else:
            tokens = int(q(Decimal(reg["raw"]) * P.ratios.get(src, {}).get(reg["rev"], Decimal(1)), 0))
        e_ing = erratum(k, "ingest_ts")
        ingest = parse_instant(e_ing[0], "ts", "UTC") if e_ing else reg["ingest"]
        e_lic = erratum(k, "license")
        cls = _txt(e_lic[0]) if e_lic else lic.get(k, (None, None))[1]
        ok = k not in revoked and (cls in P.license_ok or (cls == "N/A" and P.group.get(src) == "A"))
        card = cards.get(k)
        approved = bool(card and card[1] == "APPROVED" and card[2] is not None and card[2] <= cut)
        shards[k] = {"source": src, "tokens": tokens, "ingest_ts": iso_z(ingest), "hash": hashes.get(k, (None, None))[1],
                     "license_ok": ok, "approved": approved, "cluster": cluster.get(k)}
    # contamination findings (4.9)
    retracted = set()
    for ff in feed.stream("contamination", "rerun"):
        for ctx, _, r in rows_of(ff, P):
            if "retracts" in r:
                retracted.add(_txt(r["retracts"]))
    contam: dict[str, dict] = {}
    for ff in feed.stream("contamination"):
        for ctx, _, r in rows_of(ff, P):
            if "finding_id" not in r or _txt(r["finding_id"]) in retracted:
                continue
            col = next((c for c in ("overlap", "overlap_pct", "overlap_permille") if c in r), None)
            if col is None or _txt(r[col]).upper() == "N/A":
                continue
            unit = {"overlap": "fraction", "overlap_pct": "percent", "overlap_permille": "permille"}[col]
            k = resolve.key(r["shard_key"])
            if k is None:
                continue
            v = q(parse_frac(r[col], ctx.comma, unit), 4)
            b = _txt(r["benchmark"])
            cur = contam.setdefault(k, {})
            if b not in cur or v > cur[b]:
                cur[b] = v
    return {"shards": shards, "contam": {k: {b: str(v) for b, v in sorted(m.items())} for k, m in sorted(contam.items())},
            "_resolve": resolve}


class Resolver:
    """Shard references: legacy ids, retired keys, voids (3.1, 4.3, 4.4)."""

    def __init__(self, keys: Keys, alias: dict, legacy: dict, existing: set):
        self.keys, self.alias, self.legacy, self.existing = keys, alias, legacy, existing

    def key_only(self, text):
        s = str(text).strip()
        k = self.legacy.get(s.lower()) if Keys.is_legacy(s) else self.keys.norm(s)
        if k in self.alias:
            k = self.alias[k]
        return k

    def key(self, text):
        k = self.key_only(text)
        return k if k in self.existing else None


# ------------------------------------------------------------------- timeline

def _msgid(v) -> str:
    """Message-ids compare without angle brackets, surrounding space or letter case (6.3)."""
    return str(v).strip().strip("<>").strip().lower()


def decode_alerts(feed: Feed):
    msgs = {}
    for ff in feed.stream("alerts"):
        for m in ff.sections.get("messages", []):
            msgs.setdefault(_msgid(m.get("Message-ID", "")), m)
    retracted = {_msgid(m["X-Retracts"]) for m in msgs.values() if m.get("X-Alert-Type") == "RETRACT"}
    live = {i: m for i, m in msgs.items() if i not in retracted}
    overflow = sorted({(int(m["X-Segment"]), int(m["X-Attempt"])) for m in live.values() if m.get("X-Alert-Type") == "OVERFLOW"})
    rollbacks = sorted({(int(m["X-From-Segment"]), int(m["X-To-Segment"]), int(m["X-Resume-Step"]))
                        for m in live.values() if m.get("X-Alert-Type") == "ROLLBACK"})
    trunc = [(m["X-Node"], parse_instant(m["X-Window-Start"], "ts", "UTC"), parse_instant(m["X-Window-End"], "ts", "UTC"))
             for m in live.values() if m.get("X-Alert-Type") == "TRUNCATION"]
    return overflow, rollbacks, trunc


def _ics_time(ev: dict, prop: str, node_tz: str) -> dt.datetime:
    v = ev[prop]
    if v.endswith("Z"):
        return dt.datetime.strptime(v, "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
    zone = ev.get(f"{prop}.TZID", node_tz)
    return dt.datetime.strptime(v, "%Y%m%dT%H%M%S").replace(tzinfo=ZoneInfo(zone), fold=0).astimezone(UTC)


def decode_calendar(feed: Feed):
    P = feed.params
    latest = {}
    for ff in feed.stream("calendar"):
        for ev in ff.sections.get("events", []):
            uid = ev["UID"]
            if uid not in latest or int(ev.get("SEQUENCE", 0)) > int(latest[uid].get("SEQUENCE", 0)):
                latest[uid] = ev
    sessions, windows = [], {}
    for ev in latest.values():
        if ev.get("STATUS") == "CANCELLED":
            continue
        node = ev["X-NODE"]
        tz = P.node_tz.get(node, "UTC")
        s, e = _ics_time(ev, "DTSTART", tz), _ics_time(ev, "DTEND", tz)
        if ev["CATEGORIES"] == "SESSION":
            sessions.append((node, s, e))
        elif ev["CATEGORIES"] in ("PREEMPTED", "MAINTENANCE"):
            windows.setdefault(node, []).append((s, e))
    return sorted(sessions), windows


def decode_trainlog(feed: Feed, resolve: Resolver, windows: dict, trunc: list):
    P = feed.params
    hosts = {}
    for ff in feed.stream("trainlog", "aggregate"):
        for ctx, _, r in rows_of(ff, P):
            if "host" in r and "node" in r and "attempt" not in r:
                hosts[_txt(r["host"])] = _txt(r["node"])
    sources = [(ff, None) for ff in feed.stream("trainlog")]
    for ff in feed.stream("trainlog", "replay"):
        node = ff.control.get("node")
        for tn, lo, hi in trunc:
            if tn == node:
                sources.append((ff, (lo, hi)))
    records, replays = [], 0
    for ff, window in sources:
        for ctx, _, r in rows_of(ff, P):
            if "attempt" not in r:
                continue
            node = _txt(r["node"]) if "node" in r else hosts.get(_txt(r["host"]))
            if node is None:
                if feed.tolerant:
                    continue
                raise FeedError(f"unmapped host {r['host']!r} in {ff.name}")
            t = ctx.instant(r, "ts")
            if window is not None and not (window[0] <= t <= window[1]):
                continue
            if any(s <= t < e for s, e in windows.get(node, [])):
                replays += 1
                continue
            tokens = parse_int(r["tokens"], ctx.comma)
            if "loss_sum_mnats" in r:
                raw = _txt(r["loss_sum_mnats"])
                loss = None if raw.lower() in ("", "nan", "inf") else parse_dec(raw, ctx.comma) / 1000
            else:
                raw = _txt(r["loss_sum"])
                loss = None if raw.lower() in ("", "nan", "inf") else parse_dec(raw, ctx.comma)
            records.append([parse_int(r["segment"], ctx.comma), parse_int(r["attempt"], ctx.comma), node,
                            resolve.key(r["shard"]), tokens, None if loss is None else str(loss)])
    records.sort(key=lambda x: (x[0], x[1], x[2]))
    return records, replays


def decode_checkpoints(feed: Feed):
    P = feed.params
    ok: dict[str, set] = {}
    meta = {}
    for ff in feed.stream("checkpoints"):
        for ctx, _, r in rows_of(ff, P):
            if "rank" not in r:
                continue
            c = _txt(r["ckpt_id"])
            meta[c] = (parse_int(r["segment"], ctx.comma), parse_int(r["step"], ctx.comma))
            ok.setdefault(c, set())
            if _txt(r.get("rank_status", "ok")) == "ok":
                ok[c].add(parse_int(r["rank"], ctx.comma))
    tomb = set()
    for ff in feed.stream("checkpoints", "mirror"):
        for ctx, _, r in rows_of(ff, P):
            if "ckpt_id" in r and "rank" not in r:
                tomb.add(_txt(r["ckpt_id"]))
    full = set(range(P.ranks))
    return {c: {"segment": meta[c][0], "step": meta[c][1], "complete": full <= ok[c], "tombstoned": c in tomb}
            for c in sorted(meta)}


def decode_evals(feed: Feed):
    P = feed.params
    run_map, h1_map = {}, {}
    for ff in feed.stream("evals", "consolidated"):
        for _, name, r in rows_of(ff, P, sections={"run_map"}):
            run_map[_txt(r["run_id"])] = _txt(r["ckpt_id"])
    for ff in feed.stream("evals", "superseded"):
        for _, name, r in rows_of(ff, P):
            if "h1_run_id" in r and "ckpt_id" in r:
                h1_map[_txt(r["h1_run_id"])] = _txt(r["ckpt_id"])
    private = {b for b, v in P.bench.items() if v["private"]}
    best: dict[tuple, tuple] = {}
    files = [(ff, False) for ff in feed.stream("evals")] + [(ff, True) for ff in feed.stream("evals", "leaderboard")]
    for ff, board in files:
        for ctx, _, r in rows_of(ff, P):
            if "benchmark" not in r or "seed" not in r:
                continue
            b = _txt(r["benchmark"])
            if board and b not in private:
                continue
            if _txt(r["run_status"]) != "ok":
                continue
            col = "score" if "score" in r else "score_pct"
            raw = _txt(r[col])
            if raw == "" or raw.upper() == "N/A":
                continue
            if parse_dec(raw.rstrip("%").strip(), ctx.comma) == -1:  # score -1: benchmark not run (3.6)
                continue
            if "ckpt_id" in r:
                ck = _txt(r["ckpt_id"])
            elif "run_id" in r:
                ck = run_map.get(_txt(r["run_id"]))
            else:
                ck = h1_map.get(_txt(r["h1_run_id"]))
            if ck is None:
                continue
            score = q(parse_frac(raw, ctx.comma, "fraction" if col == "score" else "percent"), 4)
            t = ctx.instant(r, "run")
            key = (ck, b, parse_int(r["seed"], ctx.comma))
            if key not in best or t > best[key][0]:
                best[key] = (t, score)
    out: dict[str, dict] = {}
    for (ck, b, seed), (_, score) in sorted(best.items()):
        out.setdefault(ck, {}).setdefault(b, []).append(str(score))
    return out


def chain_report(feed: Feed) -> dict:
    files, breaks, running, expect_seq = [], [], 0, 1
    for e in feed.entries:
        ff = feed.files.get(e["name"])
        if ff is None:
            breaks.append(e["name"])
            files.append({"name": e["name"], "seq": e["seq"], "stream": e["stream"], "opening": None, "records": None, "counted": None})
            expect_seq = e["seq"] + 1
            continue
        c = ff.control
        bad = c.get("seq") != e["seq"] or e["seq"] != expect_seq or c.get("records") != ff.counted
        if bad:
            breaks.append(e["name"])
        files.append({"name": e["name"], "seq": e["seq"], "stream": e["stream"], "opening": running,
                      "records": c.get("records"), "counted": ff.counted})
        running += ff.counted
        expect_seq = e["seq"] + 1
    return {"ok": not breaks, "closing": running, "breaks": breaks, "files": files}


def load_facts(root: Path, stage: int, tolerant: bool = False) -> tuple[Feed, dict]:
    """Decode a feed.  tolerant=True skips absent files and absent parameter tables."""
    feed = Feed(root, tolerant=tolerant)
    sh = decode_shards(feed, stage)
    overflow, rollbacks, trunc = decode_alerts(feed)
    sessions, windows = decode_calendar(feed)
    records, replays = decode_trainlog(feed, sh["_resolve"], windows, trunc)
    facts = {"shards": sh["shards"], "contam": sh["contam"], "overflow": [list(x) for x in overflow],
             "rollbacks": [list(x) for x in rollbacks], "records": records, "replays": replays,
             "ckpts": decode_checkpoints(feed), "evals": decode_evals(feed),
             "sessions": [[n, iso_z(s), iso_z(e)] for n, s, e in sessions],
             "chain": chain_report(feed)}
    return feed, facts


_KNOWN = _CANONICAL | _TS_NAMES | _EXTRA_NAMES
