"""python -m runledger reconcile --feed DIR --resume STATE --out DIR [--tolerant]"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import FeedError, reconcile


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="runledger")
    sub = parser.add_subparsers(dest="command", required=True)
    rec = sub.add_parser("reconcile", help="build the stage ledger of one feed")
    rec.add_argument("--feed", required=True, type=Path)
    rec.add_argument("--resume", required=True, type=Path)
    rec.add_argument("--out", required=True, type=Path)
    rec.add_argument("--tolerant", action="store_true", help="skip files listed in the index but absent")
    args = parser.parse_args(argv)
    try:
        reconcile(args.feed, args.resume, args.out, tolerant=args.tolerant)
    except FeedError as exc:
        print(f"runledger: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
