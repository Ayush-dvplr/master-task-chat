"""runledger: stage run-ledger reconciliation for the pretraining feed."""

from __future__ import annotations

import json
from pathlib import Path

from .feed import FeedError, load_facts
from .ledger import compute, write_outputs

__version__ = "3.2.0"
__all__ = ["FeedError", "load_facts", "compute", "write_outputs", "reconcile", "__version__"]


def reconcile(feed_dir: Path, resume: Path, out_dir: Path, tolerant: bool = False) -> dict:
    if tolerant and not Path(resume).is_file():
        opening = {"stage": 0}
    else:
        opening = json.loads(Path(resume).read_text(encoding="utf-8"))
    opening.pop("control", None)
    stage = int(opening.get("stage", 0)) + 1
    feed, facts = load_facts(Path(feed_dir), stage, tolerant=tolerant)
    result = compute(facts, feed.params, opening, tolerant=tolerant)
    write_outputs(Path(out_dir), result)
    return result
