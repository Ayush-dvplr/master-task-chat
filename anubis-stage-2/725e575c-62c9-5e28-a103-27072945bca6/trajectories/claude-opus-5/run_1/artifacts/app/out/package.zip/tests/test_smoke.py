"""Smoke coverage the repaired package must keep."""

import datetime as dt
import unittest
from decimal import Decimal

from runledger import __version__
from runledger.conventions import Keys, norm_hash, parse_frac, parse_instant, parse_int, q


class ConventionsTest(unittest.TestCase):
    def test_version(self):
        self.assertEqual(__version__, "3.2.0")

    def test_plain_keys(self):
        keys = Keys({})
        self.assertEqual(keys.norm("SH0012345"), "SH0012345")
        self.assertEqual(keys.norm("sh-12345"), "SH0012345")
        self.assertIsNone(keys.norm("XX123"))

    def test_hash(self):
        self.assertEqual(norm_hash("00ff00ff00ff00ff"), "00ff00ff00ff00ff")

    def test_plain_numbers(self):
        self.assertEqual(parse_int("1234567"), 1234567)
        self.assertEqual(parse_frac("0.1250", False, "fraction"), Decimal("0.1250"))

    def test_utc_instant(self):
        self.assertEqual(parse_instant("2026-03-02T06:00:00Z", "ts", "UTC"),
                         dt.datetime(2026, 3, 2, 6, tzinfo=dt.timezone.utc))

    def test_quantize(self):
        self.assertEqual(str(q(Decimal("1.23456789"), 6)), "1.234568")


if __name__ == "__main__":
    unittest.main()
