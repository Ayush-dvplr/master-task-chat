# runledger

Builds the stage ledger of one pretraining feed: shard ledger, step ledger,
mixture report, checkpoint report, reconciliation and resume state.

    cd src
    python -m runledger reconcile --feed /path/to/feed --resume opening_state.json --out /path/to/out

The rules live in the feed's own documents; the approved specification
revision and its errata govern every output.
