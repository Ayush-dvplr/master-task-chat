"""Field conventions of run_spec 3.x: keys, numbers, timestamps, encodings."""

from __future__ import annotations

import datetime as dt
import re
import unicodedata
from decimal import Decimal, ROUND_HALF_EVEN
from zoneinfo import ZoneInfo

UTC = dt.timezone.utc
_KEY_RE = re.compile(r"^SH(\d{1,7})$")
_LEGACY_RE = re.compile(r"^l-[0-9a-f]{6}$")
DAGGER = "\u2020"


class FeedError(Exception):
    pass


def q(value, places: int) -> Decimal:
    return Decimal(value).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_EVEN)


def decode_lines(data: bytes) -> list[str]:
    """UTF-8 text with optional BOM; a line that is not UTF-8 is cp1252 (3.4)."""
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    out = []
    for raw in data.split(b"\n"):
        if raw.endswith(b"\r"):
            raw = raw[:-1]
        try:
            out.append(raw.decode("utf-8"))
        except UnicodeDecodeError:
            out.append(raw.decode("cp1252"))
    if out and out[-1] == "":
        out.pop()
    return out


def provisional(first_cell) -> bool:
    """A table row whose first cell ends with the dagger is a provisional entry (3.7)."""
    return first_cell is not None and str(first_cell).rstrip().endswith(DAGGER)


class Keys:
    def __init__(self, homoglyphs: dict[str, str]):
        self.homoglyphs = homoglyphs

    def norm(self, text) -> str | None:
        if text is None:
            return None
        s = unicodedata.normalize("NFKC", str(text)).strip()
        for bad, good in self.homoglyphs.items():
            s = s.replace(bad, good)
        s = s.upper().replace(" ", "").replace("-", "").replace("_", "").strip()
        m = _KEY_RE.match(s)
        return f"SH{int(m.group(1)):07d}" if m else None

    @staticmethod
    def is_legacy(text) -> bool:
        return isinstance(text, str) and bool(_LEGACY_RE.match(text.strip().lower()))


def norm_hash(text) -> str:
    s = str(text).strip().lower()
    if s.startswith("xxh64:"):
        s = s[6:]
    return s.strip()


def _num_text(text: str, comma: bool) -> str:
    s = str(text).strip().replace("\u00a0", " ").replace("\u202f", " ")
    if comma:
        s = s.replace(".", "").replace(" ", "").replace(",", ".")
    else:
        s = s.replace(",", "").replace(" ", "")
    return s


_SUFFIX = {"k": 1000, "K": 1000, "M": 1000000}


def _split_suffix(text) -> tuple[str, int]:
    """A suffix k multiplies by 1000 and M by 1000000 (3.2)."""
    s = str(text).strip()
    if len(s) > 1 and s[-1] in _SUFFIX:
        return s[:-1].strip(), _SUFFIX[s[-1]]
    return s, 1


def parse_int(text, comma: bool = False, scale: int = 1) -> int:
    s, mult = _split_suffix(text)
    value = Decimal(_num_text(s, comma)) * mult * scale
    if value != value.to_integral_value():
        raise ValueError(f"not an integer: {text!r}")
    return int(value)


def parse_frac(text, comma: bool, unit: str) -> Decimal:
    """Fractions; unit is fraction | percent | permille; a trailing % marks percent."""
    s = str(text).strip()
    if s.endswith("%"):
        s = s[:-1].strip()
        unit = "percent"
    value = Decimal(_num_text(s, comma))
    if unit == "percent":
        return value / 100
    if unit == "permille":
        return value / 1000
    return value


def parse_dec(text, comma: bool) -> Decimal:
    return Decimal(_num_text(text, comma))


def serial_to_datetime(value, system: int) -> dt.datetime:
    """Spreadsheet serials: 1900 system day 0 is 1899-12-30, 1904 system day 0 is 1904-01-01 (3.3)."""
    base = dt.datetime(1904, 1, 1, tzinfo=UTC) if int(system) == 1904 else dt.datetime(1899, 12, 30, tzinfo=UTC)
    days = Decimal(str(value))
    whole = int(days)
    secs = int(((days - whole) * 86400).to_integral_value(rounding=ROUND_HALF_EVEN))
    return base + dt.timedelta(days=whole, seconds=secs)


def parse_instant(value, kind: str, tz: str, date_system: int = 1900) -> dt.datetime:
    """kind: ts | local | epoch | epoch_ms | serial | date (3.3)."""
    if kind == "serial":
        return serial_to_datetime(value, date_system)
    s = str(value).strip()
    if kind == "epoch":
        return dt.datetime.fromtimestamp(int(Decimal(s)), UTC)
    if kind == "epoch_ms":
        return dt.datetime.fromtimestamp(int(Decimal(s)) // 1000, UTC)
    if kind == "date":
        return dt.datetime.combine(dt.date.fromisoformat(s[:10]), dt.time(), tzinfo=UTC)
    if kind == "local":
        naive = dt.datetime.fromisoformat(s)
        if naive.tzinfo is None:
            # an ambiguous wall time is the earlier instant
            naive = naive.replace(tzinfo=ZoneInfo(tz), fold=0)
        return naive.astimezone(UTC)
    t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    if t.tzinfo is None:
        t = t.replace(tzinfo=ZoneInfo(tz), fold=0)
    return t.astimezone(UTC)


def iso_z(t: dt.datetime) -> str:
    return t.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


TS_SUFFIXES = (("_epoch_ms", "epoch_ms"), ("_epoch", "epoch"), ("_local", "local"), ("_serial", "serial"),
               ("_ts", "ts"), ("_date", "date"), ("_on", "date"))


def find_instant(row: dict, base: str, tz: str, date_system: int = 1900):
    """Locate the <base>_ts / _local / _epoch / _epoch_ms / _serial column of a row."""
    for suffix, kind in TS_SUFFIXES:
        name = base + suffix
        if base == "ts" and suffix == "_ts":
            name = "ts"
        if name in row and row[name] not in (None, ""):
            return parse_instant(row[name], kind, tz, date_system)
    return None


def find_date(row: dict, base: str, date_system: int = 1900):
    """Calendar date of a <base>_date / _serial / ... column; None when absent or a sentinel."""
    for suffix, kind in (("_date", "date"), ("_on", "date"), ("_serial", "serial"), ("_ts", "ts"),
                         ("_local", "local"), ("_epoch", "epoch"), ("_epoch_ms", "epoch_ms")):
        name = base + suffix
        if name not in row:
            continue
        v = row[name]
        if v in (None, ""):
            return None
        s = str(v).strip()
        if not s or s.startswith("0000-00-00"):
            return None
        return parse_instant(s if kind != "serial" else v, kind, "UTC", date_system).date()
    return None
