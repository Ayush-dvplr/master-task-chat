"""Renders the derived documents of one routing cycle as bytes."""
from fractions import Fraction

from daybreak.allocate import (_instance_of, _resolved_of, stage_r10,
                               stage_r11, stage_r12, stage_r13, stage_r14)
from daybreak.loading import (LAYER_ORDER, POLICY_FIELDS, convert, live_rows,
                             load_all)
from daybreak.stages import (demand_of, stage_r01, stage_r02, stage_r03,
                             stage_r04, stage_r05, stage_r06, stage_r07,
                             stage_r08, stage_r09)
from daybreak.util import (canonical_json, compact_json, half_even, ratio12,
                           sha256_hex, NL)

STAGE_IDS = ["r01", "r02", "r03", "r04", "r05", "r06", "r07",
             "r08", "r09", "r10", "r11", "r12", "r13", "r14"]

DOCUMENTS = [
    "unit_normalization.json", "alias_resolution.jsonl",
    "expansion_ledger.csv", "config_resolution.json", "parameter_audit.csv",
    "trigger_eligibility_index.json", "dependency_graph.json",
    "cycle_break_ledger.json", "canonical_action_order.json",
    "resource_demand.csv", "window_capacity_report.csv",
    "initial_allocation.json", "displaced_action_queue.json",
    "fallback_expansion.json", "precedence_reconciliation.json",
    "final_action_order.json", "cooldown_state.csv", "derived_state.json",
    "suppression_ledger.csv", "next_state_snapshot.json",
    "per_context_manifest.json", "per_device_manifest.csv",
    "daily_automation_manifest.json", "resource_utilization_report.csv",
    "terminal_action_report.md", "audit_ledger.jsonl",
]


def _json(obj):
    return (canonical_json(obj) + NL).encode("utf-8")


def _jsonl(records):
    if not records:
        return b""
    return (NL.join(compact_json(r) for r in records) + NL).encode("utf-8")


def _csv(header, rows):
    body = [",".join(str(h) for h in header)]
    for row in rows:
        body.append(",".join(str(c) for c in row))
    return (NL.join(body) + NL).encode("utf-8")


def _text(lines):
    return (NL.join(str(x) for x in lines) + NL).encode("utf-8")


def run_chain(root):
    data = load_all(root)
    r01 = stage_r01(data)
    r02 = stage_r02(data, r01)
    r03 = stage_r03(data, r01, r02)
    r04 = stage_r04(data, r01, r02, r03)
    r05 = stage_r05(data, r01, r02, r03, r04)
    r06 = stage_r06(data, r01, r02)
    tier_index = {}
    by_id = {i["instance_id"]: i for i in r03["instances"]}
    for iid in r05["eligible"]:
        aid = by_id[iid]["action_id"]
        tier = r04["resolved"][iid]["tier"]
        if aid not in tier_index or tier < tier_index[aid]:
            tier_index[aid] = tier
    fallback_tier = r04["layers"]["global"]["tier"]
    r07 = stage_r07(data, r06, tier_index, fallback_tier)
    r08 = stage_r08(data, r01, r03, r05, r07)
    r09 = stage_r09(data, r01, r02, r04, r08)
    r10 = stage_r10(data, r01, r02, r04, r08, r09)
    r11 = stage_r11(data, r01, r02, r04, r07, r08, r09, r10)
    r12 = stage_r12(data, r01, r02, r04, r07, r08, r09, r10, r11)
    r13 = stage_r13(data, r01, r02, r04, r08, r12)
    r14 = stage_r14(data, r01, r02, r04, r05, r07, r08, r09, r10, r12, r13)
    r13b = stage_r13(data, r01, r02, r04, r08,
                     {"survivors": r14["survivors"],
                      "proposal_index": r12["proposal_index"]})
    state = {"data": data, "r01": r01, "r02": r02, "r03": r03, "r04": r04,
             "r05": r05, "r06": r06, "r07": r07, "r08": r08, "r09": r09,
             "r10": r10, "r11": r11, "r12": r12, "r13": r13, "r14": r14,
             "r13b": r13b, "tier_index": tier_index}
    return render(state)


def render(state):
    data = state["data"]
    r01, r02, r03, r04 = state["r01"], state["r02"], state["r03"], state["r04"]
    r05, r06, r07, r08 = state["r05"], state["r06"], state["r07"], state["r08"]
    r09, r10, r11, r12 = state["r09"], state["r10"], state["r11"], state["r12"]
    r13, r14, r13b = state["r13"], state["r14"], state["r13b"]
    header = data["header"]
    out = {}

    out["unit_normalization.json"] = _json({
        "cycle_key": header["cycle_key"],
        "base_units": header["base_units"],
        "unit_counts": r01["unit_counts"],
        "totals": r01["totals"],
        "quarantined": sorted(r01["notes"],
                              key=lambda n: (n["record"], n["field"])),
    })

    out["alias_resolution.jsonl"] = _jsonl(
        sorted(r02["decisions"],
               key=lambda d: (d["alias"], d["source"], d["status"])))

    out["expansion_ledger.csv"] = _csv(
        ["routine_id", "instance_id", "action_id", "occurrence_index",
         "trigger_ms", "window_id", "status", "reason"],
        [[e["routine_id"], e["instance_id"], e["action_id"],
          e["occurrence_index"], e["trigger_ms"], e["window_id"],
          e["status"], e["reason"]]
         for e in sorted(r03["ledger"],
                         key=lambda e: (e["routine_id"],
                                        e["occurrence_index"]))])

    frozen = header["device_frozen_revisions"]
    live = live_rows(data["device_policy_rows"], "device_id",
                     lambda k: frozen.get(k))
    live_dev = {did: int(row["revision"]) for did, row in sorted(live.items())}
    out["config_resolution.json"] = _json({
        "instances": len(r03["instances"]),
        "layer_ranks": {name: r04["layers"]["ranks"][name] for name in LAYER_ORDER},
        "settled_by_layer": {k: v for k, v in sorted(r04["counts"].items())},
        "live_device_policy_revisions": live_dev,
        "cooldown_floors_ms": {k: v for k, v in sorted(r04["floors"].items())},
        "reserve_bp": int(data["directive"]["reserve_bp"]),
    })

    rows = []
    for iid in sorted(r04["resolved"]):
        rec = r04["resolved"][iid]
        win = r04["winners"][iid]
        for field in POLICY_FIELDS:
            value = rec[field]
            if field == "fallback_chain":
                value = ";".join(value)
            elif isinstance(value, bool):
                value = "true" if value else "false"
            rows.append([iid, field, value, win[field]])
    out["parameter_audit.csv"] = _csv(
        ["instance_id", "field", "value", "winning_layer"], rows)

    counts = {}
    for entry in r05["withheld"]:
        counts[entry["reason"]] = counts.get(entry["reason"], 0) + 1
    out["trigger_eligibility_index.json"] = _json({
        "eligible": sorted(r05["eligible"]),
        "withheld": sorted(r05["withheld"],
                           key=lambda w: (w["instance_id"], w["reason"])),
        "counts": {k: counts[k] for k in sorted(counts)},
    })

    out["dependency_graph.json"] = _json({
        "nodes": r06["nodes"],
        "edges": [{"prereq": e["prereq"], "dependent": e["dependent"],
                   "strength_bp": e["strength_bp"],
                   "declared_seq": e["declared_seq"], "kind": e["kind"]}
                  for e in r06["edges"]],
        "dropped": sorted(r06["dropped"],
                          key=lambda d: (d["declared_seq"], d["reason"])),
    })

    out["cycle_break_ledger.json"] = _json({
        "rounds": len(r07["ledger"]),
        "removals": r07["ledger"],
        "surviving_edges": len(r07["edges"]),
    })

    out["canonical_action_order.json"] = _json({
        "action_order": r08["action_order"],
        "instance_order": r08["instance_order"],
        "withheld": sorted(r08["withheld"],
                           key=lambda w: (w["instance_id"], w["reason"])),
    })

    out["resource_demand.csv"] = _csv(
        ["window_id", "device_id", "instance_id", "action_id",
         "base_energy_mwh", "intensity_bp", "surcharge_bp",
         "window_scale_bp", "demand_mwh"],
        [[r["window_id"], r["device_id"], r["instance_id"], r["action_id"],
          r["base_energy_mwh"], r["intensity_bp"], r["surcharge_bp"],
          r["window_scale_bp"], r["demand_mwh"]]
         for r in sorted(r09["rows"],
                         key=lambda r: (r02["windows"][r["window_id"]]["ordinal"],
                                        r["device_id"], r["instance_id"]))])

    out["window_capacity_report.csv"] = _csv(
        ["window_id", "device_id", "ceiling_mwh", "reserve_mwh",
         "mandatory_mwh", "allocated_mwh", "pool_remaining_mwh", "overrun"],
        [[r["window_id"], r["device_id"], r["ceiling_mwh"], r["reserve_mwh"],
          r["mandatory_mwh"], r["allocated_mwh"], r["pool_remaining_mwh"],
          r["overrun"]] for r in r10["report"]])

    out["initial_allocation.json"] = _json({
        "count": len(r10["allocated"]),
        "allocated": [{"instance_id": iid, "window_id": key[0],
                       "device_id": key[1]}
                      for iid, key in sorted(r10["allocated"].items())],
    })

    out["displaced_action_queue.json"] = _json({
        "count": len(r10["displaced"]),
        "displaced": sorted(r10["displaced"],
                            key=lambda d: (d["instance_id"], d["reason"])),
    })

    out["fallback_expansion.json"] = _json({
        "proposals": [{"instance_id": p["instance"]["instance_id"],
                       "action_id": p["instance"]["action_id"],
                       "stands_in_for": p["stands_in_for"],
                       "window_id": p["instance"]["window_id"],
                       "device_id": p["resolved"]["device_id"],
                       "demand_mwh": p["demand"]["demand_mwh"]}
                      for p in sorted(r11["proposals"],
                                      key=lambda p: p["instance"]["instance_id"])],
        "terminal": sorted(r11["terminal"],
                           key=lambda t: (t["instance_id"], t["reason"])),
    })

    out["precedence_reconciliation.json"] = _json({
        "round_cap": int(r12["round_cap"]),
        "groups": sorted(r12["report"],
                         key=lambda g: (g["round"], g["window_id"],
                                        g["device_id"])),
        "overturned": sorted(r12["overturned"],
                             key=lambda o: o["instance_id"]),
    })

    out["final_action_order.json"] = _json({
        "count": len(r14["order"]),
        "order": r14["order"],
    })

    out["cooldown_state.csv"] = _csv(
        ["action_id", "cooldown_until_ms", "source_layer"],
        [[rec["action_id"], rec["cooldown_until_ms"], rec["source_layer"]]
         for _aid, rec in sorted(r13["cooldowns"].items())])

    out["derived_state.json"] = _json({
        "state": {k: r13["state"][k] for k in sorted(r13["state"])},
        "set_at": {k: {"trigger_ms": r13["set_at"][k][0],
                       "action_id": r13["set_at"][k][1]}
                   for k in sorted(r13["set_at"])},
    })

    ledger = []
    for entry in r03["ledger"]:
        if entry["reason"]:
            ledger.append([entry["instance_id"] or entry["routine_id"],
                           entry["reason"], "r03"])
    for entry in r05["withheld"]:
        ledger.append([entry["instance_id"], entry["reason"], "r05"])
    for entry in r08["withheld"]:
        ledger.append([entry["instance_id"], entry["reason"], "r08"])
    for entry in r09["quarantined"]:
        ledger.append([entry["instance_id"], entry["reason"], "r09"])
    for entry in r10["displaced"]:
        ledger.append([entry["instance_id"], entry["reason"], "r10"])
    for entry in r12["terminal"]:
        ledger.append([entry["instance_id"], entry["reason"], "r12"])
    for entry in r14["withdrawn"]:
        ledger.append([entry["instance_id"], entry["reason"], "r14"])
    for entry in r14["readmitted"]:
        ledger.append([entry["instance_id"], entry["reason"], "r14"])
    out["suppression_ledger.csv"] = _csv(
        ["instance_id", "reason", "stage"], sorted(ledger))

    remaining = dict(data["snapshot"].get("oneshot_remaining", {}))
    for oid, used in r13b["consumed"].items():
        left = int(remaining.get(oid, 0)) - used
        remaining[oid] = left if left > 0 else 0
    out["next_state_snapshot.json"] = _json({
        "cycle_key": header["cycle_key"],
        "cycle_index": int(data["runtime"]["cycle_index"]) + 1,
        "actions": {aid: {"last_fired_ms": r13b["last_fired"][aid],
                          "cooldown_until_ms":
                          r13b["cooldowns"][aid]["cooldown_until_ms"]}
                    for aid in sorted(r13b["last_fired"])},
        "oneshot_remaining": {k: int(remaining[k]) for k in sorted(remaining)},
        "state": {k: r13b["state"][k] for k in sorted(r13b["state"])},
    })

    per_context = {}
    per_device = {}
    per_window = {}
    total_demand = 0
    for iid in r14["order"]:
        inst = _instance_of(iid, r08, r12)
        rec = _resolved_of(iid, r04, r12)
        demand = (r09["by_instance"].get(iid) or r14["demand"].get(iid)
                  or r12["proposal_index"][iid]["demand"])
        value = demand["demand_mwh"]
        total_demand += value
        ctx = per_context.setdefault(rec["context_id"],
                                     {"instances": [], "demand_mwh": 0})
        ctx["instances"].append(iid)
        ctx["demand_mwh"] += value
        dev = per_device.setdefault(rec["device_id"],
                                    {"instances": 0, "demand_mwh": 0})
        dev["instances"] += 1
        dev["demand_mwh"] += value
        win = per_window.setdefault(inst["window_id"],
                                    {"instances": [], "demand_mwh": 0})
        win["instances"].append(iid)
        win["demand_mwh"] += value
    out["per_context_manifest.json"] = _json({
        "contexts": {cid: {"instances": sorted(per_context[cid]["instances"]),
                           "demand_mwh": per_context[cid]["demand_mwh"]}
                     for cid in sorted(per_context)},
    })

    circuit_of = {}
    for entry in data["circuits"]:
        if entry.get("role") != "member":
            continue
        circuit_of[entry["device"]] = entry["id"]
    out["per_device_manifest.csv"] = _csv(
        ["device_id", "circuit_id", "instances", "demand_mwh"],
        [[did, circuit_of.get(did, ""), per_device[did]["instances"],
          per_device[did]["demand_mwh"]] for did in sorted(per_device)])

    out["daily_automation_manifest.json"] = _json({
        "cycle_key": header["cycle_key"],
        "profile": header["profile"],
        "windows": [{"window_id": wid,
                     "ordinal": r02["windows"][wid]["ordinal"],
                     "instances": sorted(per_window[wid]["instances"]),
                     "demand_mwh": per_window[wid]["demand_mwh"]}
                    for wid in sorted(per_window,
                                      key=lambda w: r02["windows"][w]["ordinal"])],
        "totals": {"instances": len(r14["order"]),
                   "demand_mwh": total_demand,
                   "terminal": len(r12["terminal"]) + len(r14["withdrawn"]),
                   "readmitted": len(r14["readmitted"])},
    })

    prior = {}
    for rec in data["ledger"]:
        did = rec["device_id"]
        idx = int(rec["cycle_index"])
        value, _base = convert(data["units"], rec["consumed"]["value"],
                               rec["consumed"]["unit"])
        if value is None:
            continue
        cur = prior.get(did)
        if cur is None or idx > cur[0]:
            prior[did] = (idx, value)
    util_rows = []
    for did in sorted(set(list(per_device.keys()) + list(circuit_of.keys()))):
        ceiling = 0
        for (wid, dev), entry in data["workbook"]["ceilings"].items():
            if dev != did:
                continue
            value, _b = _convert_cell(data, entry)
            ceiling += value
        allocated = per_device.get(did, {}).get("demand_mwh", 0)
        ratio = ratio12(Fraction(allocated, ceiling)) if ceiling else ratio12(0)
        prior_value = prior.get(did, (0, 0))[1]
        util_rows.append([circuit_of.get(did, ""), did, ceiling, allocated,
                          ratio, prior_value, allocated - prior_value])
    out["resource_utilization_report.csv"] = _csv(
        ["circuit_id", "device_id", "ceiling_mwh", "allocated_mwh",
         "utilisation_ratio", "prior_cycle_mwh", "delta_mwh"],
        sorted(util_rows, key=lambda r: (r[0], r[1])))

    lines = ["# Terminal actions for cycle " + header["cycle_key"], ""]
    terminal = {}
    for entry in r12["terminal"]:
        terminal[entry["instance_id"]] = entry["reason"]
    for entry in r14["withdrawn"]:
        terminal[entry["instance_id"]] = entry["reason"]
    lines.append("| instance_id | reason |")
    lines.append("| --- | --- |")
    for iid in sorted(terminal):
        lines.append("| " + iid + " | " + terminal[iid] + " |")
    lines.append("")
    lines.append("Total terminal instances: " + str(len(terminal)))
    out["terminal_action_report.md"] = _text(lines)

    audit = []
    sizes = {"r01": len(r01["actions"]), "r02": len(r02["decisions"]),
             "r03": len(r03["instances"]), "r04": len(r04["resolved"]),
             "r05": len(r05["eligible"]), "r06": len(r06["edges"]),
             "r07": len(r07["ledger"]), "r08": len(r08["instance_order"]),
             "r09": len(r09["rows"]), "r10": len(r10["allocated"]),
             "r11": len(r11["proposals"]), "r12": len(r12["survivors"]),
             "r13": len(r13["order"]), "r14": len(r14["order"])}
    for sid in STAGE_IDS:
        audit.append({"stage": sid, "records": sizes[sid]})
    out["audit_ledger.jsonl"] = _jsonl(audit)

    core_names = ["unit_normalization.json", "canonical_action_order.json",
                  "final_action_order.json", "daily_automation_manifest.json",
                  "next_state_snapshot.json"]
    core_digest = sha256_hex(b"".join(out[name] for name in core_names))
    manifest_lines = []
    for name in sorted(DOCUMENTS):
        manifest_lines.append(sha256_hex(out[name]) + "  " + name)
    publication = sha256_hex(
        "".join(line + NL for line in manifest_lines).encode("utf-8"))
    manifest_lines.append("core " + core_digest)
    manifest_lines.append("publication " + publication)
    out["run_manifest.txt"] = _text(manifest_lines)

    out["summary.json"] = _json({
        "cycle_key": header["cycle_key"],
        "profile": header["profile"],
        "core_digest": core_digest,
        "publication_digest": publication,
        "control_totals": {
            "actions_read": len(r01["actions"]),
            "aliases_bound": sum(1 for d in r02["decisions"]
                                 if d["status"] == "bound"),
            "instances_expanded": len(r03["instances"]),
            "instances_eligible": len(r05["eligible"]),
            "edges_kept": len(r06["edges"]),
            "cycles_settled": len(r07["ledger"]),
            "demand_rows": len(r09["rows"]),
            "initial_allocations": len(r10["allocated"]),
            "displaced": len(r10["displaced"]),
            "fallback_proposals": len(r11["proposals"]),
            "overturned": len(r12["overturned"]),
            "final_instances": len(r14["order"]),
            "readmitted": len(r14["readmitted"]),
            "terminal": len(r12["terminal"]) + len(r14["withdrawn"]),
            "total_demand_mwh": total_demand,
        },
    })
    return out


def _convert_cell(data, entry):
    from daybreak.loading import convert
    from daybreak.stages import _absent
    if _absent(entry[0]):
        return 0, None
    value, base = convert(data["units"], entry[0], entry[1])
    return (value if value is not None else 0), base
