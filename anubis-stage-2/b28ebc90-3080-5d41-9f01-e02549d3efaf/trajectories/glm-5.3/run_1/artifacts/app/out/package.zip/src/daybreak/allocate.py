"""Stages r10 to r14 of the daybreak routing chain."""
from fractions import Fraction

from daybreak.loading import convert
from daybreak.stages import _absent, demand_of, hard_prereqs, resolve_policy
from daybreak.util import half_even, PIPE


def _ceiling(data, window_id, device_id):
    entry = data["workbook"]["ceilings"].get((window_id, device_id))
    if entry is None or _absent(entry[0]):
        return None
    value, _base = convert(data["units"], entry[0], entry[1])
    return value


def _order_key(rec, r04, r08):
    inst = rec["instance"]
    resolved = rec["resolved"]
    return (resolved["tier"], -rec["demand"]["demand_mwh"],
            inst["trigger_ms"], inst["instance_id"])


def _select(pool, candidates, r04, r08):
    """Candidates taken from a pool, candidates set aside, pool left. A demand
    at or below the pool fits; one above it displaces its instance and the
    next candidate is still considered."""
    taken = []
    rejected = []
    for rec in sorted(candidates, key=lambda c: _order_key(c, r04, r08)):
        if rec["demand"]["demand_mwh"] <= pool:
            pool -= rec["demand"]["demand_mwh"]
            taken.append(rec)
        else:
            rejected.append(rec)
    return taken, rejected, pool


def stage_r10(data, r01, r02, r04, r08, r09):
    reserve_bp = int(data["directive"]["reserve_bp"])
    groups = {}
    for row in r09["rows"]:
        groups.setdefault((row["window_id"], row["device_id"]), []).append(row)
    report = []
    allocated = {}
    displaced = []
    pools = {}
    for key in sorted(groups, key=lambda k: (r02["windows"][k[0]]["ordinal"],
                                             k[1])):
        window_id, device_id = key
        ceiling = _ceiling(data, window_id, device_id)
        if ceiling is None:
            for row in groups[key]:
                displaced.append({"instance_id": row["instance_id"],
                                  "reason": "UNKNOWN_CEILING"})
            continue
        reserve = half_even(Fraction(ceiling * reserve_bp, 10000))
        mandatory = []
        discretionary = []
        for row in groups[key]:
            rec = {"instance": r08["by_id"][row["instance_id"]],
                   "resolved": r04["resolved"][row["instance_id"]],
                   "demand": row}
            if rec["resolved"]["mandatory"]:
                mandatory.append(rec)
            else:
                discretionary.append(rec)
        mandatory.sort(key=lambda c: r09["order"].index(c["instance"]["instance_id"]))
        drawn = 0
        for rec in mandatory:
            drawn += rec["demand"]["demand_mwh"]
            allocated[rec["instance"]["instance_id"]] = key
        remaining = ceiling - drawn
        overrun = remaining < 0
        if overrun:
            remaining = 0
        withheld = reserve - drawn
        if withheld < 0:
            withheld = 0
        pool = remaining - withheld
        if pool < 0:
            pool = 0
        taken, rejected, left = _select(pool, discretionary, r04, r08)
        for rec in taken:
            allocated[rec["instance"]["instance_id"]] = key
        for rec in rejected:
            displaced.append({"instance_id": rec["instance"]["instance_id"],
                              "reason": "CAPACITY_DISPLACED"})
        pools[key] = {"ceiling_mwh": ceiling, "reserve_mwh": reserve,
                      "mandatory_mwh": drawn, "pool_start_mwh": pool,
                      "pool_remaining_mwh": left, "overrun": overrun}
        report.append({"window_id": window_id, "device_id": device_id,
                       "ceiling_mwh": ceiling, "reserve_mwh": reserve,
                       "mandatory_mwh": drawn,
                       "allocated_mwh": pool - left,
                       "pool_remaining_mwh": left,
                       "overrun": "yes" if overrun else "no"})
    return {"allocated": allocated, "displaced": displaced, "report": report,
            "pools": pools, "groups": groups}


def _allocated_actions(r02, r08, r10):
    out = {}
    for iid, key in r10["allocated"].items():
        inst = r08["by_id"][iid]
        out.setdefault(inst["action_id"], []).append(
            r02["windows"][key[0]]["ordinal"])
    return out


def _expand(data, r01, r02, r04, r08, r09, prereqs, allocated_actions,
            displaced_ids, taken_here):
    depth_cap = int(data["controls"]["fallback_chain_depth_cap"])
    proposals = []
    unplaced = []
    for iid in sorted(displaced_ids, key=r09["order"].index):
        inst = r08["by_id"][iid]
        resolved = r04["resolved"][iid]
        key = (inst["window_id"], resolved["device_id"])
        chain = list(resolved["fallback_chain"])[:depth_cap]
        placed = None
        for candidate in chain:
            if candidate not in r01["actions"]:
                continue
            synthetic = {"instance_id": candidate + "@" + iid,
                         "routine_id": inst["routine_id"],
                         "action_id": candidate,
                         "occurrence_index": 0,
                         "trigger_ms": inst["trigger_ms"],
                         "window_id": inst["window_id"]}
            crec, _win = resolve_policy(r04["layers"], r04["floors"], r01,
                                        r02, synthetic)
            if crec["suppress"]:
                continue
            ordinal = r02["windows"][inst["window_id"]]["ordinal"]
            satisfied = True
            for pre in sorted(prereqs.get(candidate, set())):
                seen = [o for o in allocated_actions.get(pre, [])
                        if o <= ordinal]
                if not seen:
                    satisfied = False
                    break
            if not satisfied:
                continue
            if (candidate, key) in taken_here:
                continue
            crec = dict(crec)
            crec["device_id"] = resolved["device_id"]
            demand = demand_of(data, r01, r02, r04, synthetic["instance_id"],
                               candidate, inst["window_id"], crec)
            placed = {"instance": synthetic, "resolved": crec,
                      "demand": demand, "stands_in_for": iid, "group": key}
            taken_here.add((candidate, key))
            break
        if placed is None:
            unplaced.append(iid)
        else:
            proposals.append(placed)
    return proposals, unplaced


def stage_r11(data, r01, r02, r04, r07, r08, r09, r10):
    proposals, unplaced = _expand(
        data, r01, r02, r04, r08, r09, hard_prereqs(r07["edges"]),
        _allocated_actions(r02, r08, r10),
        [entry["instance_id"] for entry in r10["displaced"]], set())
    terminal = [{"instance_id": iid, "reason": "NO_FALLBACK_FITS"}
                for iid in unplaced]
    return {"proposals": proposals, "terminal": terminal}


def stage_r12(data, r01, r02, r04, r07, r08, r09, r10, r11):
    cap = int(data["directive"]["round_cap"])
    prereqs = hard_prereqs(r07["edges"])
    allocated_actions = _allocated_actions(r02, r08, r10)
    taken_here = {(rec["instance"]["action_id"], rec["group"])
                  for rec in r11["proposals"]}
    holders = {}
    for iid, gkey in r10["allocated"].items():
        resolved = r04["resolved"][iid]
        if resolved["mandatory"]:
            continue
        holders.setdefault(gkey, []).append(
            {"instance": r08["by_id"][iid], "resolved": resolved,
             "demand": r09["by_instance"][iid], "stands_in_for": "",
             "group": gkey})
    survivors = dict(r10["allocated"])
    terminal = list(r11["terminal"])
    overturned = []
    report = []
    index = {}
    pending = list(r11["proposals"])
    rnd = 2
    while pending and rnd <= cap:
        by_group = {}
        for rec in pending:
            index[rec["instance"]["instance_id"]] = rec
            by_group.setdefault(rec["group"], []).append(rec)
        displaced_now = []
        for key in sorted(by_group,
                          key=lambda k: (r02["windows"][k[0]]["ordinal"], k[1])):
            pools = r10["pools"].get(key)
            if pools is None:
                for rec in by_group[key]:
                    terminal.append({"instance_id": rec["instance"]["instance_id"],
                                     "reason": "FALLBACK_DISPLACED"})
                continue
            incumbents = list(holders.get(key, []))
            candidates = incumbents + list(by_group[key])
            taken, rejected, left = _select(pools["pool_start_mwh"], candidates,
                                            r04, r08)
            holders[key] = taken
            for rec in taken:
                survivors[rec["instance"]["instance_id"]] = key
            for rec in rejected:
                iid = rec["instance"]["instance_id"]
                survivors.pop(iid, None)
                if rec["stands_in_for"]:
                    terminal.append({"instance_id": iid,
                                     "reason": "FALLBACK_DISPLACED"})
                    continue
                overturned.append({"instance_id": iid, "window_id": key[0],
                                   "device_id": key[1], "round": rnd})
                terminal.append({"instance_id": iid,
                                 "reason": "DISPLACED_FINAL"})
                if rnd < cap:
                    displaced_now.append(iid)
            report.append({"window_id": key[0], "device_id": key[1],
                           "round": rnd, "proposals": len(by_group[key]),
                           "incumbents": len(incumbents),
                           "kept": len(taken),
                           "pool_remaining_mwh": left})
        rnd += 1
        pending, _unplaced = _expand(data, r01, r02, r04, r08, r09, prereqs,
                                     allocated_actions, displaced_now,
                                     taken_here)
    return {"survivors": survivors, "terminal": terminal,
            "overturned": overturned, "report": report, "round_cap": cap,
            "proposal_index": index}


def _instance_of(iid, r08, r12):
    if iid in r08["by_id"]:
        return r08["by_id"][iid]
    return r12["proposal_index"][iid]["instance"]


def _resolved_of(iid, r04, r12):
    if iid in r04["resolved"]:
        return r04["resolved"][iid]
    return r12["proposal_index"][iid]["resolved"]


def final_order(survivors, r02, r04, r08, r12):
    items = []
    for iid in survivors:
        inst = _instance_of(iid, r08, r12)
        ordinal = r02["windows"][inst["window_id"]]["ordinal"]
        rank = r08["rank"].get(inst["action_id"], len(r08["rank"]))
        items.append((ordinal, inst["trigger_ms"], rank, iid))
    items.sort()
    return [item[3] for item in items]


def stage_r13(data, r01, r02, r04, r08, r12):
    order = final_order(r12["survivors"], r02, r04, r08, r12)
    effects = sorted(data["effects"], key=lambda e: int(e["declared_seq"]))
    by_action = {}
    for rec in effects:
        by_action.setdefault(rec["action_id"], []).append(rec)
    state = {}
    set_at = {}
    history = {}
    cooldowns = {}
    last_fired = {}
    consumed = {}
    for iid in order:
        inst = _instance_of(iid, r08, r12)
        resolved = _resolved_of(iid, r04, r12)
        aid = inst["action_id"]
        last_fired[aid] = inst["trigger_ms"]
        cooldowns[aid] = {"action_id": aid,
                          "cooldown_until_ms": inst["trigger_ms"]
                          + resolved["cooldown_ms"],
                          "source_layer": "resolved"}
        if resolved["oneshot_id"] and resolved["oneshot_id"] not in consumed:
            consumed[resolved["oneshot_id"]] = 1
        for rec in by_action.get(aid, []):
            state[rec["sets_key"]] = rec["sets_value"]
            set_at[rec["sets_key"]] = (inst["trigger_ms"], aid)
            history.setdefault(rec["sets_key"], []).append(
                (inst["trigger_ms"], rec["sets_value"], aid))
    return {"order": order, "state": state, "set_at": set_at,
            "history": history, "cooldowns": cooldowns,
            "last_fired": last_fired, "consumed": consumed}


def _value_in_force(r13, key, trigger_ms):
    """The value a state key holds at a trigger: the value of the last write
    the first pass made to it strictly before that trigger, writes at one
    instant settling on the later one in the pass order."""
    best = None
    for pos, (when, wrote, _aid) in enumerate(r13.get("history", {}).get(key, [])):
        if when < trigger_ms and (best is None or (when, pos) > best[0]):
            best = ((when, pos), wrote)
    return None if best is None else best[1]


def stage_r14(data, r01, r02, r04, r05, r07, r08, r09, r10, r12, r13):
    gates = {}
    for key, spec in data["gates"].items():
        if key == "layer":
            continue
        parts = str(spec).split(PIPE)
        if len(parts) == 2:
            gates[key] = (parts[0], parts[1])
    survivors = dict(r12["survivors"])
    withdrawn = []
    for iid in list(r13["order"]):
        if iid not in survivors:
            continue
        inst = _instance_of(iid, r08, r12)
        gate = gates.get(inst["action_id"])
        if gate is None:
            continue
        key, required = gate
        value = _value_in_force(r13, key, inst["trigger_ms"])
        if value is None:
            continue
        if value != required:
            survivors.pop(iid, None)
            withdrawn.append({"instance_id": iid, "reason": "GATE_CLOSED"})
    prereqs = hard_prereqs(r07["edges"])
    changed = True
    while changed:
        changed = False
        for iid in sorted(survivors):
            inst = _instance_of(iid, r08, r12)
            need = prereqs.get(inst["action_id"], set())
            for pre in sorted(need):
                ok = False
                for other in survivors:
                    cand = _instance_of(other, r08, r12)
                    if (cand["action_id"] == pre
                            and cand["trigger_ms"] <= inst["trigger_ms"]):
                        ok = True
                        break
                if not ok:
                    survivors.pop(iid, None)
                    withdrawn.append({"instance_id": iid,
                                      "reason": "PREREQ_WITHDRAWN"})
                    changed = True
                    break
            if changed:
                break
    readmitted = []
    readmit_demand = {}
    pools = {}
    for key, rec in r10["pools"].items():
        pools[key] = rec["pool_start_mwh"]

    def pool_for(key):
        """A window and device that carried no demand in r10 still has a
        pool: its ceiling less the reserve, with no mandatory draw."""
        if key in pools:
            return pools[key]
        ceiling = _ceiling(data, key[0], key[1])
        if ceiling is None:
            return None
        reserve = half_even(Fraction(ceiling * int(
            data["directive"]["reserve_bp"]), 10000))
        value = ceiling - reserve
        pools[key] = value if value > 0 else 0
        return pools[key]
    for iid, key in survivors.items():
        demand = (r09["by_instance"].get(iid)
                  or r12["proposal_index"][iid]["demand"])
        resolved = _resolved_of(iid, r04, r12)
        if resolved["mandatory"]:
            continue
        if key in pools:
            pools[key] -= demand["demand_mwh"]
    for entry in sorted(r05["withheld"], key=lambda w: w["instance_id"]):
        if entry["reason"] != "SUPPRESSED":
            continue
        iid = entry["instance_id"]
        inst = r08["by_id"].get(iid)
        if inst is None:
            continue
        gate = gates.get(inst["action_id"])
        if gate is None:
            continue
        key, required = gate
        value = _value_in_force(r13, key, inst["trigger_ms"])
        if value is None or value != required:
            continue
        resolved = r04["resolved"][iid]
        row = demand_of(data, r01, r02, r04, iid, inst["action_id"],
                        inst["window_id"], resolved)
        group = (inst["window_id"], resolved["device_id"])
        if pool_for(group) is None:
            continue
        if row["demand_mwh"] <= pools[group]:
            pools[group] -= row["demand_mwh"]
            survivors[iid] = group
            readmit_demand[iid] = row
            readmitted.append({"instance_id": iid, "reason": "READMITTED",
                               "demand_mwh": row["demand_mwh"]})
    order = final_order(survivors, r02, r04, r08, r12)
    return {"survivors": survivors, "order": order, "withdrawn": withdrawn,
            "readmitted": readmitted, "pools": pools,
            "demand": readmit_demand}
