"""Reads the working papers into plain records under the documented rules."""
import re
from fractions import Fraction
from pathlib import Path

from daybreak.util import (as_fraction, half_even, read_conf, read_delim,
                           read_docx_blocks, read_flat_toml, read_flat_yaml,
                           read_json, read_jsonl, read_pdf_lines,
                           read_sqlite_table, read_text, read_xlsx_sheets,
                           read_xml, PIPE, TAB)

LAYER_ORDER = ["mandatory", "oneshot", "context", "device", "action",
               "routine", "global"]
POLICY_FIELDS = ["tier", "intensity_bp", "cooldown_ms", "mandatory",
                 "max_occurrences", "suppress", "fallback_chain"]


class Unresolved(Exception):
    pass


def unit_table(root):
    """token -> (base, num, den, status)."""
    out = {}
    for raw in read_text(root / "unit_registry_dictionary.toml").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or line.startswith("[") or "=" not in line:
            continue
        token, spec = line.split("=", 1)
        token = token.strip()
        parts = spec.strip().strip(chr(34)).split(PIPE)
        if len(parts) != 4:
            continue
        out[token] = (parts[0], int(parts[1]), int(parts[2]), parts[3])
    return out


def convert(units, value, token):
    """Quantity in base units, or (None, reason) when it cannot be carried."""
    if token not in units:
        return None, "UNCONVERTIBLE_UNIT"
    base, num, den, status = units[token]
    if status != "live" or den == 0:
        return None, "UNCONVERTIBLE_UNIT"
    return half_even(as_fraction(value) * Fraction(num, den)), base


def live_rows(rows, key_field, frozen_for, rev_field="revision"):
    """Rows in force, one per key: the greatest revision that does not exceed
    that key's frozen revision. Two rows that share a key and a revision settle
    on the one appearing later in the file."""
    best = {}
    for idx, row in enumerate(rows):
        key = row[key_field]
        rev = int(row[rev_field])
        limit = frozen_for(key)
        if limit is None or rev > int(limit):
            continue
        prev = best.get(key)
        if prev is None or (rev, idx) >= (prev[0], prev[1]):
            best[key] = (rev, idx, row)
    return {k: v[2] for k, v in best.items()}


def _memo_scalar(lines, label):
    for line in lines:
        stripped = line.strip()
        if stripped.startswith(label):
            rest = stripped[len(label):].strip()
            parts = rest.split()
            if parts:
                return parts[0], (parts[1] if len(parts) > 1 else "")
    raise Unresolved("memo scalar not found: " + label)


def read_memo(root, units=None):
    lines = read_pdf_lines(root / "household_operations_memo.pdf")
    if units is None:
        units = unit_table(root)
    ctl = {}
    for key, label in (("implausible_demand_mwh", "implausible demand ceiling"),
                       ("fallback_chain_depth_cap", "fallback chain depth cap"),
                       ("default_max_occurrences", "default max occurrences"),
                       ("alias_hop_cap", "alias hop cap")):
        value, token = _memo_scalar(lines, label)
        if token in units and units[token][3] == "live" and units[token][2] != 0:
            ctl[key] = convert(units, value, token)[0]
        else:
            ctl[key] = int(value)
    caps = {}
    for line in lines:
        parts = line.strip().split()
        if len(parts) != 2:
            continue
        if parts[1] == "-":
            caps[parts[0]] = None
        elif parts[1].isdigit():
            caps[parts[0]] = int(parts[1])
    return ctl, caps


def read_directive(root):
    blocks = read_docx_blocks(root / "precedence_directive.docx")
    ranks = {}
    keys = []
    reserve_bp = None
    round_cap = None
    mandates = []
    mode = None
    for block in blocks:
        if isinstance(block, str):
            if "basis point" in block:
                found = re.search(r"(\d+)\s+basis points", block)
                if found is not None:
                    reserve_bp = int(found.group(1))
            if re.search(r"(\d+)\s+rounds", block) and round_cap is None:
                round_cap = int(re.search(r"(\d+)\s+rounds", block).group(1))
            mode = None
            continue
        head = [c.strip().lower() for c in block]
        if len(head) >= 2 and head[0] == "rank" and head[1] == "layer":
            mode = "ranks"
            continue
        if len(head) >= 2 and head[0] == "order" and head[1] == "key":
            mode = "keys"
            continue
        if len(head) >= 2 and head[0] == "seq" and head[1] == "action_id":
            mode = "mandates"
            continue
        if mode == "ranks" and len(block) >= 2 and block[0].strip().isdigit():
            ranks[block[1].strip()] = int(block[0])
        elif mode == "keys" and len(block) >= 3 and block[0].strip().isdigit():
            keys.append((int(block[0]), block[1].strip(), block[2].strip()))
        elif (mode == "mandates" and len(block) >= 5
              and block[0].strip().isdigit()):
            mandates.append({"seq": int(block[0]), "action": block[1].strip(),
                             "window": block[2].strip(),
                             "mandatory": block[3].strip() == "yes",
                             "tier": int(block[4])})
    if reserve_bp is None:
        raise Unresolved("directive carries no mandatory reserve")
    if round_cap is None:
        raise Unresolved("directive carries no reconciliation round cap")
    if sorted(ranks) != sorted(LAYER_ORDER):
        raise Unresolved("directive does not rank every layer")
    keys.sort(key=lambda k: k[0])
    return {"ranks": ranks, "settlement_keys": keys, "reserve_bp": reserve_bp,
            "round_cap": round_cap, "mandates": mandates}


def read_workbook(root, cycle_key):
    """Capacity grid and surcharge scales from the workbook. The live grid is
    the one whose key cell equals the cycle key byte for byte."""
    sheets = read_xlsx_sheets(root / "capacity_and_intensity_workbook.xlsx")
    live = None
    scales = None
    for name, rows in sheets.items():
        if not rows:
            continue
        head = rows[0]
        if len(head) >= 2 and head[0] == "grid_key" and live is None:
            if head[1] == cycle_key:
                live = rows
        elif len(head) >= 2 and head[0] == "surcharge_key" and scales is None:
            if head[1] == cycle_key:
                scales = rows
    if live is None:
        raise Unresolved("no workbook grid carries the cycle key")
    if scales is None:
        raise Unresolved("workbook carries no class scale table")
    recorded_unit = ""
    for row in live:
        if row and row[0] == "recorded_unit":
            recorded_unit = row[1] if len(row) > 1 else ""
    header_at = None
    columns = []
    for pos, row in enumerate(live):
        if row and row[0] == "window_id":
            header_at = pos
            columns = row
            break
    if header_at is None:
        raise Unresolved("workbook grid carries no header row")
    ceilings = {}
    for row in live[header_at + 1:]:
        if len(row) < len(columns):
            row = row + [""] * (len(columns) - len(row))
        record = dict(zip(columns, row))
        ceilings[(record.get("window_id", ""),
                  record.get("device_id", ""))] = (
            record.get("ceiling_value", ""),
            record.get("ceiling_unit", "") or recorded_unit)
    surcharge = {}
    capacity_scale = {}
    reserve = None
    mode = None
    for row in scales:
        if not row:
            continue
        first = row[0]
        if first == "action_class":
            mode = "surcharge"
            continue
        if first == "capacity_class":
            mode = "capacity"
            continue
        if first == "reserve":
            reserve = int(row[1])
            continue
        if first == "surcharge_key":
            continue
        if len(row) < 2 or not row[1]:
            continue
        if mode == "surcharge":
            surcharge[first] = row[1]
        else:
            capacity_scale[first] = row[1]
    return {"ceilings": ceilings, "surcharge": surcharge,
            "capacity_scale": capacity_scale, "workbook_reserve_bp": reserve}


def load_all(root):
    root = Path(root)
    data = {}
    data["header"] = read_json(root / "cycle_header.json")
    data["runtime"] = read_conf(root / "assistant_runtime.conf")
    data["units"] = unit_table(root)
    data["rounding"] = read_flat_yaml(root / "rounding_and_arithmetic_policy.yaml")
    data["precedence"] = read_flat_toml(root / "precedence_and_overturn.toml")
    data["binding"] = read_flat_yaml(root / "capacity_binding_policy.yaml")
    data["settlement"] = read_flat_toml(root / "cycle_break_policy.toml")
    data["expansion"] = read_flat_yaml(root / "expansion_policy.yaml")
    data["publication"] = read_flat_toml(root / "publication_form_rules.toml")
    data["window_rows"] = read_delim(root / "window_grid.csv", ",")
    data["device_rows"] = read_delim(root / "device_register.csv", ",")
    data["device_policy_rows"] = read_delim(root / "device_policies.csv", ",")
    data["catalogue"] = read_delim(root / "action_catalogue.csv", ",")
    data["routines"] = read_delim(root / "routine_register.csv", ",")
    data["edges"] = read_delim(root / "dependency_edges.tsv", TAB)
    data["context_spans"] = read_delim(root / "context_activity_spans.tsv", TAB)
    data["context_policies"] = read_delim(root / "context_policies.tsv", TAB)
    data["cooldown_rows"] = read_delim(root / "cooldown_register.psv", PIPE)
    data["action_policies"] = read_jsonl(root / "action_policies.jsonl")
    data["routine_defaults"] = read_flat_toml(root / "routine_defaults.toml")
    data["global_defaults"] = read_flat_yaml(root / "global_defaults.yaml")
    data["overrides"] = read_jsonl(root / "override_journal.jsonl")
    data["snapshot"] = read_json(root / "state_snapshot.json")
    data["prior_journal"] = read_jsonl(root / "prior_cycle_journal.jsonl")
    data["effects"] = read_jsonl(root / "state_effects.jsonl")
    data["gates"] = read_flat_toml(root / "gating_rules.toml")
    data["sources"] = read_delim(root / "source_priority_register.csv", ",")
    data["alias_primary"] = read_delim(root / "alias_crosswalk.tsv", TAB)
    data["alias_supplement"] = read_delim(root / "identifier_supplement.psv", PIPE)
    data["ledger"] = read_jsonl(root / "energy_ledger_history.ndjson")
    data["archive"] = read_sqlite_table(root / "prior_cycle_archive.sqlite3",
                                        data["runtime"]["archive_table"])
    _scalars, groups = read_xml(root / "home_topology.xml")
    data["circuits"] = groups.get("circuits", [])
    ctl, caps = read_memo(root, data["units"])
    data["controls"] = ctl
    data["memo_caps"] = caps
    data["directive"] = read_directive(root)
    data["workbook"] = read_workbook(root, data["header"]["cycle_key"])
    return data
