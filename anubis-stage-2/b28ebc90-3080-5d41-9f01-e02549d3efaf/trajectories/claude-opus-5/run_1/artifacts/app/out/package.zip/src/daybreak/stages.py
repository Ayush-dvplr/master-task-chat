"""Stages r01 to r09 of the daybreak routing chain."""
from fractions import Fraction

from daybreak.loading import (LAYER_ORDER, POLICY_FIELDS, Unresolved, convert,
                              live_rows)
from daybreak.util import half_even, PIPE

ABSENT = "-"
GEN_CAP = 512


def _absent(text):
    """True when a policy cell records nothing. A written zero is not absent:
    under RR4 it settles the field where it is written."""
    return text is None or str(text).strip() in ("", ABSENT)


def _q(rec, field, unit_field, units, notes, where):
    value, base = convert(units, rec[field], rec[unit_field])
    if value is None:
        notes.append({"record": where, "field": field,
                      "unit": rec[unit_field], "reason": "UNCONVERTIBLE_UNIT"})
    return value


# --------------------------------------------------------------------------
# r01 unit normalisation
# --------------------------------------------------------------------------
def stage_r01(data):
    units = data["units"]
    notes = []
    counts = {}
    totals = {"duration_ms": 0, "energy_mwh": 0, "weight_bp": 0}
    actions = {}
    for row in data["catalogue"]:
        aid = row["action_id"]
        where = "action_catalogue.csv:" + aid
        energy = _q(row, "energy_value", "energy_unit", units, notes, where)
        duration = _q(row, "duration_value", "duration_unit", units, notes, where)
        for token in (row["energy_unit"], row["duration_unit"]):
            counts[token] = counts.get(token, 0) + 1
        if energy is None or duration is None:
            continue
        actions[aid] = {
            "action_id": aid, "name": row["action_name"],
            "device_ref": row["device_ref"], "context_ref": row["context_ref"],
            "energy_mwh": energy, "duration_ms": duration,
            "action_class": row["action_class"],
            "declared_seq": int(row["declared_seq"]), "role": row["role"],
        }
        totals["energy_mwh"] += energy
        totals["duration_ms"] += duration
    strength = {}
    for row in data["edges"]:
        seq = int(row["declared_seq"])
        counts[row["strength_unit"]] = counts.get(row["strength_unit"], 0) + 1
        value = _q(row, "strength_value", "strength_unit", units, notes,
                   "dependency_edges.tsv:" + str(seq))
        if value is None:
            continue
        strength[seq] = value
    totals["weight_bp"] = sum(strength.values())
    return {"actions": actions, "edge_strength": strength,
            "unit_counts": counts, "notes": notes, "totals": totals}


# --------------------------------------------------------------------------
# r02 identifier resolution
# --------------------------------------------------------------------------
def stage_r02(data, r01):
    ranks = {}
    for row in data["sources"]:
        if row["status"] != "in_force":
            continue
        ranks[row["source_name"]] = int(row["source_rank"])
    pool = []
    for name, rows in (("alias_crosswalk.tsv", data["alias_primary"]),
                       ("identifier_supplement.psv", data["alias_supplement"])):
        if name not in ranks:
            continue
        for row in rows:
            alias = row.get("alias", "")
            if not alias:
                continue
            pool.append((ranks[name], int(row["declared_seq"]), name,
                         alias, row["canonical"], row["kind"]))
    pool.sort(key=lambda item: (item[0], item[1], item[3]))
    bindings = {}
    decisions = []
    for rank, seq, source, alias, canonical, kind in pool:
        if alias == canonical:
            decisions.append({"alias": alias, "canonical": canonical,
                              "kind": kind, "source": source, "hops": 0,
                              "status": "self"})
            continue
        if alias in bindings:
            decisions.append({"alias": alias, "canonical": canonical,
                              "kind": kind, "source": source, "hops": 0,
                              "status": "collision"})
            continue
        bindings[alias] = canonical
        decisions.append({"alias": alias, "canonical": canonical,
                          "kind": kind, "source": source, "hops": 1,
                          "status": "bound"})
    cap = int(data["controls"]["alias_hop_cap"])
    resolved_cache = {}
    cyclic = set()

    def resolve(name):
        if name in resolved_cache:
            return resolved_cache[name]
        seen = [name]
        cur = name
        hops = 0
        while cur in bindings and hops < cap:
            cur = bindings[cur]
            hops += 1
            if cur in seen:
                cyclic.add(name)
                cur = name
                break
            seen.append(cur)
        resolved_cache[name] = cur
        return cur

    for decision in decisions:
        if decision["status"] == "bound":
            target = resolve(decision["alias"])
            decision["canonical"] = target
            decision["hops"] = 0 if target == decision["alias"] else 1
            if decision["alias"] in cyclic:
                decision["status"] = "cycle"
    windows = window_grid(data)
    devices = device_grid(data)
    contexts = context_grid(data)
    known = {"action": set(r01["actions"]), "device": set(devices),
             "context": set(contexts)}
    return {"bindings": bindings, "decisions": decisions, "resolve": resolve,
            "known": known, "windows": windows, "devices": devices,
            "contexts": contexts, "cyclic": sorted(cyclic)}


def window_grid(data):
    """Window id -> ordinal, start and end."""
    units = data["units"]
    frozen = data["header"]["window_frozen_revisions"]
    rows = data["window_rows"]
    live = live_rows(rows, "window_id", lambda k: frozen.get(k))
    out = {}
    cursor = int(data["header"]["origin_ms"])
    for wid in sorted(live, key=lambda k: int(live[k]["ordinal"])):
        row = live[wid]
        delta, _b = convert(units, row["start_delta_value"],
                            row["start_delta_unit"])
        span, _b2 = convert(units, row["span_value"], row["span_unit"])
        if delta is None or span is None:
            raise Unresolved("window grid carries an unconvertible quantity")
        cursor = cursor + delta
        start = cursor
        out[wid] = {"window_id": wid, "ordinal": int(row["ordinal"]),
                    "start_ms": start, "end_ms": start + span,
                    "capacity_class": row["capacity_class"]}
    return out


def device_grid(data):
    frozen = data["header"]["device_frozen_revisions"]
    live = live_rows(data["device_rows"], "device_id", lambda k: frozen.get(k))
    return {did: {"device_id": did, "device_class": row["device_class"],
                  "slots": int(row["slots"])}
            for did, row in live.items()}


def context_grid(data):
    units = data["units"]
    out = {}
    cursor = int(data["header"]["origin_ms"])
    for row in data["context_spans"]:
        cid = row["context_id"]
        delta, _b = convert(units, row["start_delta_value"],
                            row["start_delta_unit"])
        length, _b2 = convert(units, row["length_value"], row["length_unit"])
        if delta is None or length is None:
            continue
        if row["start_delta_sign"] == "-":
            delta = -delta
        cursor = cursor + delta
        if "." in cid or "hist" in cid:
            continue
        out[cid] = {"context_id": cid, "context_name": row["context_name"],
                    "start_ms": cursor, "end_ms": cursor + length}
    return out


# --------------------------------------------------------------------------
# r03 routine expansion
# --------------------------------------------------------------------------
def _routine_cap(data, rid, routine_layer):
    """Occurrence cap of one routine."""
    cap = data["memo_caps"].get(rid)
    if cap is not None:
        return cap, "memo"
    rec = routine_layer.get(rid, {})
    if "max_occurrences" in rec:
        return rec["max_occurrences"], "routine"
    return int(data["controls"]["default_max_occurrences"]), "default"


def routine_layer_records(data):
    out = {}
    for key, spec in data["routine_defaults"].items():
        if not key.startswith("RT-"):
            continue
        parts = str(spec).split(PIPE)
        rec = {}
        if len(parts) == 4:
            if not _absent(parts[0]):
                rec["tier"] = int(parts[0])
            if not _absent(parts[1]):
                rec["intensity_bp"] = int(parts[1])
            if not _absent(parts[2]):
                rec["cooldown_ms"] = int(parts[2]) * 60000
            if not _absent(parts[3]):
                rec["max_occurrences"] = int(parts[3])
        out[key] = rec
    return out


def stage_r03(data, r01, r02):
    units = data["units"]
    routine_layer = routine_layer_records(data)
    windows = r02["windows"]
    ordered = sorted(windows.values(), key=lambda w: w["ordinal"])
    instances = []
    ledger = []
    for row in sorted(data["routines"], key=lambda r: r["routine_id"]):
        rid = row["routine_id"]
        aid = r02["resolve"](row["action_ref"])
        if row["enabled"] != "yes":
            ledger.append({"routine_id": rid, "instance_id": "",
                           "action_id": aid, "occurrence_index": -1,
                           "trigger_ms": 0, "window_id": "",
                           "status": "withheld", "reason": "RETIRED_ROUTINE"})
            continue
        if aid not in r01["actions"]:
            ledger.append({"routine_id": rid, "instance_id": "",
                           "action_id": aid, "occurrence_index": -1,
                           "trigger_ms": 0, "window_id": "",
                           "status": "withheld", "reason": "UNRESOLVED_ACTION"})
            continue
        anchor, _b = convert(units, row["anchor_value"], row["anchor_unit"])
        period, _b2 = convert(units, row["period_value"], row["period_unit"])
        span0, _b3 = convert(units, row["span_start_value"],
                             row["span_start_unit"])
        span1, _b4 = convert(units, row["span_end_value"], row["span_end_unit"])
        if None in (anchor, period, span0, span1):
            ledger.append({"routine_id": rid, "instance_id": "",
                           "action_id": aid, "occurrence_index": -1,
                           "trigger_ms": 0, "window_id": "",
                           "status": "withheld",
                           "reason": "UNCONVERTIBLE_UNIT"})
            continue
        if row["anchor_sign"] == "-":
            anchor = -anchor
        cap, _src = _routine_cap(data, rid, routine_layer)
        if cap <= 0:
            ledger.append({"routine_id": rid, "instance_id": "",
                           "action_id": aid, "occurrence_index": -1,
                           "trigger_ms": 0, "window_id": "",
                           "status": "withheld",
                           "reason": "OCCURRENCE_CAP_ZERO"})
            continue
        kept = 0
        step = 0
        while step < GEN_CAP and kept < cap:
            trigger = anchor + step * period
            if trigger >= span1:
                break
            if trigger >= span0:
                wid = ""
                for win in ordered:
                    if win["start_ms"] <= trigger < win["end_ms"]:
                        wid = win["window_id"]
                        break
                iid = rid + "#" + str(kept).rjust(2, "0")
                if wid == "":
                    ledger.append({"routine_id": rid, "instance_id": iid,
                                   "action_id": aid, "occurrence_index": kept,
                                   "trigger_ms": trigger, "window_id": "",
                                   "status": "withheld",
                                   "reason": "OUT_OF_DAY"})
                else:
                    instances.append({"instance_id": iid, "routine_id": rid,
                                      "action_id": aid, "occurrence_index": kept,
                                      "trigger_ms": trigger, "window_id": wid})
                    ledger.append({"routine_id": rid, "instance_id": iid,
                                   "action_id": aid, "occurrence_index": kept,
                                   "trigger_ms": trigger, "window_id": wid,
                                   "status": "expanded", "reason": ""})
                kept += 1
            if period == 0:
                break
            step += 1
    return {"instances": instances, "ledger": ledger,
            "routine_layer": routine_layer}


# --------------------------------------------------------------------------
# r04 policy layer resolution
# --------------------------------------------------------------------------
def _layer_records(data, r01, r02, r03):
    units = data["units"]
    mandatory = {}
    for row in data["directive"]["mandates"]:
        key = (row["action"], row["window"])
        prev = mandatory.get(key)
        if prev is None or row["seq"] > prev["seq"]:
            mandatory[key] = row
    oneshot = {}
    snapshot_remaining = data["snapshot"].get("oneshot_remaining", {})
    for rec in data["overrides"]:
        oid = rec["override_id"]
        aid = rec["action_id"]
        expires, _b = convert(units, rec["expires"]["value"],
                              rec["expires"]["unit"])
        remaining = snapshot_remaining.get(oid, rec.get("remaining", 0))
        entry = {"override_id": oid, "action_id": aid,
                 "expires_ms": expires if expires is not None else 0,
                 "remaining": int(remaining)}
        if "tier" in rec:
            entry["tier"] = int(rec["tier"])
        if "intensity" in rec:
            entry["intensity_bp"] = convert(units, rec["intensity"]["value"],
                                            rec["intensity"]["unit"])[0]
        if "cooldown" in rec:
            entry["cooldown_ms"] = convert(units, rec["cooldown"]["value"],
                                           rec["cooldown"]["unit"])[0]
        oneshot.setdefault(aid, []).append(entry)
    for aid in oneshot:
        oneshot[aid].sort(key=lambda e: e["override_id"])
    context = {}
    for row in data["context_policies"]:
        cid = row["context_id"]
        if cid not in r02["contexts"]:
            continue
        rec = {}
        if not _absent(row["tier"]):
            rec["tier"] = int(row["tier"])
        if not _absent(row["intensity_value"]) and not _absent(row["intensity_unit"]):
            rec["intensity_bp"] = convert(units, row["intensity_value"],
                                          row["intensity_unit"])[0]
        if not _absent(row["suppress"]):
            rec["suppress"] = row["suppress"] == "true"
        context[cid] = rec
    frozen = data["header"]["device_frozen_revisions"]
    device = {}
    live = live_rows(data["device_policy_rows"], "device_id",
                     lambda k: frozen.get(k))
    for did, row in live.items():
        rec = {}
        if not _absent(row["tier"]):
            rec["tier"] = int(row["tier"])
        if not _absent(row["intensity_value"]) and not _absent(row["intensity_unit"]):
            rec["intensity_bp"] = convert(units, row["intensity_value"],
                                          row["intensity_unit"])[0]
        if not _absent(row["cooldown_value"]) and not _absent(row["cooldown_unit"]):
            rec["cooldown_ms"] = convert(units, row["cooldown_value"],
                                         row["cooldown_unit"])[0]
        device[did] = rec
    action = {}
    for rec in data["action_policies"]:
        out = {}
        if "tier" in rec:
            out["tier"] = int(rec["tier"])
        if "intensity" in rec:
            out["intensity_bp"] = convert(units, rec["intensity"]["value"],
                                          rec["intensity"]["unit"])[0]
        if "cooldown" in rec:
            out["cooldown_ms"] = convert(units, rec["cooldown"]["value"],
                                         rec["cooldown"]["unit"])[0]
        if "suppress" in rec:
            out["suppress"] = bool(rec["suppress"])
        if "fallback_chain" in rec:
            out["fallback_chain"] = list(rec["fallback_chain"])
        action[rec["action_id"]] = out
    g = data["global_defaults"]
    glob = {
        "tier": int(g["tier"]),
        "intensity_bp": convert(units, g["intensity_value"],
                                g["intensity_unit"])[0],
        "cooldown_ms": convert(units, g["cooldown_value"],
                               g["cooldown_unit"])[0],
        "mandatory": g["mandatory"] == "true",
        "max_occurrences": int(g["max_occurrences"]),
        "suppress": g["suppress"] == "true",
        "fallback_chain": [],
    }
    ranks = {name: int(data["directive"]["ranks"][name]) for name in LAYER_ORDER}
    return {"mandatory": mandatory, "oneshot": oneshot, "context": context,
            "device": device, "action": action,
            "routine": r03["routine_layer"], "global": glob, "ranks": ranks}


def cooldown_floors(data):
    frozen = int(data["snapshot"]["frozen_revision_cooldown_register"])
    live = live_rows(data["cooldown_rows"], "action_class", lambda k: frozen)
    out = {}
    for cls, row in live.items():
        value, _b = convert(data["units"], row["floor_value"], row["floor_unit"])
        out[cls] = value if value is not None else 0
    return out


def resolve_policy(layers, floors, r01, r02, instance):
    """Resolved policy of one instance and the layer that settled each field."""
    action = r01["actions"][instance["action_id"]]
    did = r02["resolve"](action["device_ref"])
    cid = r02["resolve"](action["context_ref"])
    trigger = instance["trigger_ms"]
    applicable = []
    mrec = layers["mandatory"].get((instance["action_id"],
                                    instance["window_id"]))
    if mrec is not None:
        applicable.append(("mandatory", {"tier": mrec["tier"],
                                         "mandatory": mrec["mandatory"]}))
    else:
        applicable.append(("mandatory", {}))
    chosen = None
    for entry in layers["oneshot"].get(instance["action_id"], []):
        if entry["remaining"] > 0 and trigger < entry["expires_ms"]:
            chosen = entry
            break
    if chosen is None:
        applicable.append(("oneshot", {}))
    else:
        rec = {k: v for k, v in chosen.items()
               if k in ("tier", "intensity_bp", "cooldown_ms")}
        applicable.append(("oneshot", rec))
    ctx = r02["contexts"].get(cid)
    if ctx is not None and ctx["start_ms"] <= trigger < ctx["end_ms"]:
        applicable.append(("context", layers["context"].get(cid, {})))
    else:
        applicable.append(("context", {}))
    applicable.append(("device", layers["device"].get(did, {})))
    applicable.append(("action", layers["action"].get(instance["action_id"], {})))
    applicable.append(("routine", layers["routine"].get(instance["routine_id"], {})))
    applicable.append(("global", layers["global"]))
    applicable.sort(key=lambda item: int(layers["ranks"][item[0]]))
    resolved = {}
    winner = {}
    for field in POLICY_FIELDS:
        for name, rec in applicable:
            if field in rec and rec[field] is not None:
                resolved[field] = rec[field]
                winner[field] = name
                break
    floor = floors.get(action["action_class"], 0)
    if resolved["cooldown_ms"] < floor:
        resolved["cooldown_ms"] = floor
        winner["cooldown_ms"] = "class_floor"
    resolved["device_id"] = did
    resolved["context_id"] = cid
    resolved["oneshot_id"] = chosen["override_id"] if chosen else ""
    return resolved, winner


def stage_r04(data, r01, r02, r03):
    layers = _layer_records(data, r01, r02, r03)
    floors = cooldown_floors(data)
    resolved = {}
    winners = {}
    counts = {name: 0 for name in LAYER_ORDER}
    counts["class_floor"] = 0
    for inst in r03["instances"]:
        rec, win = resolve_policy(layers, floors, r01, r02, inst)
        resolved[inst["instance_id"]] = rec
        winners[inst["instance_id"]] = win
        for field in POLICY_FIELDS:
            counts[win[field]] = counts.get(win[field], 0) + 1
    return {"layers": layers, "floors": floors, "resolved": resolved,
            "winners": winners, "counts": counts}


# --------------------------------------------------------------------------
# r05 initial eligibility
# --------------------------------------------------------------------------
def prior_state(data):
    units = data["units"]
    snapshot = data["snapshot"].get("actions", {})
    last = {}
    suppressed = {}
    for aid, rec in snapshot.items():
        if "last_fired_ms" in rec:
            last[aid] = int(rec["last_fired_ms"])
        if "suppressed_until_ms" in rec:
            suppressed[aid] = int(rec["suppressed_until_ms"])
    for row in data["archive"]:
        aid = row["action_id"]
        if aid not in last:
            last[aid] = int(row["last_fired_ms"])
    preceding = int(data["runtime"]["preceding_cycle_index"])
    carried = {}
    for rec in data["prior_journal"]:
        if int(rec["cycle_index"]) != preceding:
            continue
        value, _b = convert(units, rec["carried_cooldown"]["value"],
                            rec["carried_cooldown"]["unit"])
        if value is None:
            continue
        aid = rec["action_id"]
        if aid not in carried or value > carried[aid]:
            carried[aid] = value
    return last, suppressed, carried


def stage_r05(data, r01, r02, r03, r04):
    last, suppressed, carried = prior_state(data)
    eligible = []
    withheld = []
    for inst in r03["instances"]:
        aid = inst["action_id"]
        rec = r04["resolved"][inst["instance_id"]]
        cooldown = rec["cooldown_ms"]
        if aid in carried and carried[aid] > cooldown:
            cooldown = carried[aid]
        trigger = inst["trigger_ms"]
        if rec["suppress"]:
            withheld.append({"instance_id": inst["instance_id"],
                             "reason": "SUPPRESSED"})
            continue
        if trigger < suppressed.get(aid, 0):
            withheld.append({"instance_id": inst["instance_id"],
                             "reason": "SUPPRESSED"})
            continue
        if aid in last and trigger - last[aid] < cooldown:
            withheld.append({"instance_id": inst["instance_id"],
                             "reason": "COOLDOWN"})
            continue
        eligible.append(inst["instance_id"])
    return {"eligible": eligible, "withheld": withheld, "last": last,
            "suppressed": suppressed, "carried": carried}


# --------------------------------------------------------------------------
# r06 dependency graph
# --------------------------------------------------------------------------
def stage_r06(data, r01, r02):
    dropped = []
    kept = {}
    for row in data["edges"]:
        seq = int(row["declared_seq"])
        strength = r01["edge_strength"].get(seq)
        prereq = r02["resolve"](row["prereq_ref"])
        dependent = r02["resolve"](row["dependent_ref"])
        if strength is None:
            dropped.append({"declared_seq": seq, "prereq": prereq,
                            "dependent": dependent,
                            "reason": "UNCONVERTIBLE_UNIT"})
            continue
        if prereq not in r01["actions"] or dependent not in r01["actions"]:
            dropped.append({"declared_seq": seq, "prereq": prereq,
                            "dependent": dependent,
                            "reason": "UNRESOLVED_ENDPOINT"})
            continue
        if prereq == dependent:
            dropped.append({"declared_seq": seq, "prereq": prereq,
                            "dependent": dependent, "reason": "SELF_EDGE"})
            continue
        key = (prereq, dependent)
        if key in kept:
            prev = kept[key]
            dropped.append({"declared_seq": seq, "prereq": prereq,
                            "dependent": dependent, "reason": "DUPLICATE_EDGE"})
            if strength > prev["strength_bp"]:
                prev["strength_bp"] = strength
            if seq < prev["declared_seq"]:
                prev["declared_seq"] = seq
            continue
        kept[key] = {"prereq": prereq, "dependent": dependent,
                     "strength_bp": strength, "declared_seq": seq,
                     "kind": row["edge_kind"]}
    edges = [kept[k] for k in sorted(kept)]
    nodes = sorted({e["prereq"] for e in edges} | {e["dependent"] for e in edges})
    return {"edges": edges, "nodes": nodes, "dropped": dropped}


# --------------------------------------------------------------------------
# r07 cycle settlement
# --------------------------------------------------------------------------
def find_cycle(nodes, out_edges):
    """Deterministic search. Nodes are entered in ascending order and each
    node's successors are visited in ascending order; the first back edge
    reached names the cycle."""
    colour = {n: 0 for n in nodes}
    stack = []

    def walk(node):
        colour[node] = 1
        stack.append(node)
        for nxt in out_edges.get(node, []):
            if colour.get(nxt, 0) == 1:
                idx = stack.index(nxt)
                return stack[idx:] + [nxt]
            if colour.get(nxt, 0) == 0:
                found = walk(nxt)
                if found is not None:
                    return found
        stack.pop()
        colour[node] = 2
        return None

    for node in nodes:
        if colour[node] == 0:
            found = walk(node)
            if found is not None:
                return found
    return None


def _tier_of(action_id, tier_index, fallback_tier):
    return tier_index.get(action_id, fallback_tier)


def _settlement_values(keys, edge, tier):
    """One comparable value per settlement key, in the directive's own order
    and with its own direction folded in, so an ascending sort picks the
    removable edge."""
    out = []
    for _order, name, direction in keys:
        label = name.lower()
        descending = "greatest" in direction.lower()
        if "strength" in label:
            value = edge["strength_bp"]
        elif "tier" in label:
            value = tier
        elif "declared" in label or "sequence" in label:
            value = edge["declared_seq"]
        else:
            text = edge["prereq"] + PIPE + edge["dependent"]
            out.append(_neg_key(text) if descending
                       else tuple(ord(ch) for ch in text))
            continue
        out.append(-value if descending else value)
    return tuple(out)


def stage_r07(data, r06, tier_index, fallback_tier):
    edges = [dict(e) for e in r06["edges"]]
    ledger = []
    rounds = 0
    while True:
        rounds += 1
        if rounds > 4096:
            raise Unresolved("cycle settlement did not terminate")
        out_edges = {}
        index = {}
        for e in edges:
            out_edges.setdefault(e["prereq"], []).append(e["dependent"])
            index[(e["prereq"], e["dependent"])] = e
        for key in out_edges:
            out_edges[key].sort()
        nodes = sorted(set(list(out_edges.keys())
                           + [d for v in out_edges.values() for d in v]))
        cycle = find_cycle(nodes, out_edges)
        if cycle is None:
            break
        members = []
        for i in range(len(cycle) - 1):
            members.append(index[(cycle[i], cycle[i + 1])])
        keys = sorted(data["directive"]["settlement_keys"])
        ranked = []
        for e in members:
            tier = _tier_of(e["dependent"], tier_index, fallback_tier)
            ranked.append((_settlement_values(keys, e, tier), e))
        ranked.sort(key=lambda item: item[0])
        removed = ranked[0][1]
        settled = len(keys)
        for pos in range(len(keys)):
            values = {item[0][pos] for item in ranked}
            if len(values) > 1:
                settled = pos + 1
                break
        ledger.append({"round": len(ledger) + 1,
                       "cycle": cycle[:-1],
                       "removed_prereq": removed["prereq"],
                       "removed_dependent": removed["dependent"],
                       "strength_bp": removed["strength_bp"],
                       "dependent_tier": _tier_of(removed["dependent"],
                                                  tier_index, fallback_tier),
                       "declared_seq": removed["declared_seq"],
                       "key_settled_at": settled})
        edges = [e for e in edges
                 if not (e["prereq"] == removed["prereq"]
                         and e["dependent"] == removed["dependent"])]
    return {"edges": edges, "ledger": ledger}


def _neg_key(text):
    """Sort helper that orders text descending inside an ascending sort."""
    return tuple(-ord(ch) for ch in text)


# --------------------------------------------------------------------------
# r08 canonical order
# --------------------------------------------------------------------------
def hard_prereqs(edges):
    """Only a hard edge imposes the instance level prerequisite. A soft or
    advisory edge orders the graph and withholds nothing."""
    out = {}
    for e in edges:
        if e["kind"] != "hard":
            continue
        out.setdefault(e["dependent"], set()).add(e["prereq"])
    return out


def stage_r08(data, r01, r03, r05, r07):
    edges = r07["edges"]
    nodes = sorted(r01["actions"])
    incoming = {n: 0 for n in nodes}
    out_edges = {}
    for e in edges:
        out_edges.setdefault(e["prereq"], []).append(e["dependent"])
        incoming[e["dependent"]] = incoming.get(e["dependent"], 0) + 1
    ready = sorted([n for n in nodes if incoming.get(n, 0) == 0])
    order = []
    while ready:
        node = ready.pop(0)
        order.append(node)
        for nxt in sorted(out_edges.get(node, [])):
            incoming[nxt] -= 1
            if incoming[nxt] == 0:
                ready.append(nxt)
                ready.sort()
    rank = {aid: i for i, aid in enumerate(order)}
    by_id = {i["instance_id"]: i for i in r03["instances"]}
    eligible = set(r05["eligible"])
    prereqs = hard_prereqs(edges)
    withheld = []
    changed = True
    while changed:
        changed = False
        for iid in sorted(eligible):
            inst = by_id[iid]
            need = prereqs.get(inst["action_id"], set())
            for pre in sorted(need):
                ok = False
                for other in eligible:
                    cand = by_id[other]
                    if (cand["action_id"] == pre
                            and cand["trigger_ms"] <= inst["trigger_ms"]):
                        ok = True
                        break
                if not ok:
                    eligible.discard(iid)
                    withheld.append({"instance_id": iid,
                                     "reason": "PREREQ_MISSING"})
                    changed = True
                    break
            if changed:
                break
    ordered = sorted(eligible, key=lambda iid: (by_id[iid]["trigger_ms"],
                                                rank.get(by_id[iid]["action_id"],
                                                         len(order)), iid))
    return {"action_order": order, "rank": rank, "instance_order": ordered,
            "withheld": withheld, "by_id": by_id}


# --------------------------------------------------------------------------
# r09 demand
# --------------------------------------------------------------------------
def demand_of(data, r01, r02, r04, instance_id, action_id, window_id,
              resolved):
    action = r01["actions"][action_id]
    surcharge = data["workbook"]["surcharge"].get(action["action_class"], 0)
    intensity = resolved["intensity_bp"] + surcharge
    if intensity < 0:
        intensity = 0
    window = r02["windows"][window_id]
    scale = data["workbook"]["capacity_scale"].get(window["capacity_class"],
                                                   10000)
    first = half_even(Fraction(action["energy_mwh"] * intensity, 10000))
    second = half_even(first * Fraction(scale, 10000))
    return {"instance_id": instance_id, "action_id": action_id,
            "window_id": window_id, "device_id": resolved["device_id"],
            "base_energy_mwh": action["energy_mwh"],
            "intensity_bp": resolved["intensity_bp"],
            "surcharge_bp": surcharge, "window_scale_bp": scale,
            "demand_mwh": second}


def stage_r09(data, r01, r02, r04, r08):
    ceiling = int(data["controls"]["implausible_demand_mwh"])
    rows = []
    quarantined = []
    kept = []
    for iid in r08["instance_order"]:
        inst = r08["by_id"][iid]
        rec = r04["resolved"][iid]
        row = demand_of(data, r01, r02, r04, iid, inst["action_id"],
                        inst["window_id"], rec)
        if row["demand_mwh"] > ceiling:
            quarantined.append({"instance_id": iid,
                                "reason": "IMPLAUSIBLE_DEMAND"})
            continue
        rows.append(row)
        kept.append(iid)
    return {"rows": rows, "quarantined": quarantined, "order": kept,
            "by_instance": {r["instance_id"]: r for r in rows}}
