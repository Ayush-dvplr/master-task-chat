"""Reading and arithmetic helpers for the daybreak router.

Nothing here knows anything about this cycle. Every value the router uses is
read from the paper directory it is pointed at.
"""
import hashlib
import json
import sqlite3
import zipfile
import xml.etree.ElementTree as ET
from fractions import Fraction
from pathlib import Path

NL = chr(10)
BS = chr(92)
Q = chr(34)
TAB = chr(9)
PIPE = chr(124)


def half_even(value):
    """Nearest integer, halves to even. The only rounding this package does."""
    frac = Fraction(value)
    floor = frac.numerator // frac.denominator
    rest = frac - floor
    if rest < Fraction(1, 2):
        return floor
    if rest > Fraction(1, 2):
        return floor + 1
    return floor if floor % 2 == 0 else floor + 1


def as_fraction(text):
    """Exact rational value of a recorded decimal. No binary floating point."""
    text = str(text).strip()
    if text == "":
        raise ValueError("empty quantity")
    sign = 1
    if text[0] in "+-":
        if text[0] == "-":
            sign = -1
        text = text[1:]
    if "." in text:
        whole, part = text.split(".", 1)
    else:
        whole, part = text, ""
    whole = whole or "0"
    part = part or ""
    num = int(whole + part) if part else int(whole)
    den = 10 ** len(part)
    return Fraction(sign * num, den)


def ratio12(value):
    """Twelve decimal places, half to even, never negative zero."""
    frac = Fraction(value)
    scaled = half_even(frac * 10 ** 12)
    sign = "-" if scaled < 0 else ""
    scaled = abs(scaled)
    whole, part = divmod(scaled, 10 ** 12)
    text = sign + str(whole) + "." + str(part).rjust(12, "0")
    if text == "-0." + "0" * 12:
        text = "0." + "0" * 12
    return text


def canonical_json(obj):
    return json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=True)


def compact_json(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def sha256_hex(blob):
    return hashlib.sha256(blob).hexdigest()


def read_text(path):
    text = Path(path).read_bytes().decode("utf-8")
    if text.startswith("\ufeff"):
        text = text[1:]
    return text


def split_delim(line, sep):
    """One record of a delimited register. A field opening with a double quote
    runs to its closing quote; a doubled quote inside is one literal quote."""
    fields = []
    i = 0
    n = len(line)
    while True:
        if i < n and line[i] == Q:
            buf = []
            i += 1
            while i < n:
                if line[i] == Q:
                    if i + 1 < n and line[i + 1] == Q:
                        buf.append(Q)
                        i += 2
                        continue
                    i += 1
                    break
                buf.append(line[i])
                i += 1
            while i < n and line[i] != sep:
                i += 1
            fields.append("".join(buf))
        else:
            stop = line.find(sep, i)
            if stop < 0:
                stop = n
            fields.append(line[i:stop])
            i = stop
        if i >= n:
            return fields
        i += 1


def read_delim(path, sep=","):
    lines = [ln.rstrip(chr(13)) for ln in read_text(path).split("\n")]
    lines = [ln for ln in lines if ln.strip() != ""]
    header = [name.strip() for name in split_delim(lines[0], sep)]
    return [dict(zip(header, split_delim(ln, sep))) for ln in lines[1:]]


def read_json(path):
    return json.loads(read_text(path))


def read_jsonl(path):
    return [json.loads(ln) for ln in read_text(path).splitlines() if ln.strip()]


def read_flat_yaml(path):
    out = {}
    for raw in read_text(path).splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip() or ":" not in line:
            continue
        key, val = line.split(":", 1)
        key = key.strip()
        val = val.strip()
        if val.startswith("[") and val.endswith("]"):
            inner = val[1:-1].strip()
            out[key] = [p.strip() for p in inner.split(",") if p.strip()] if inner else []
        elif val:
            out[key] = val
    return out


def read_flat_toml(path):
    out = {}
    for raw in read_text(path).splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or line.startswith("[") or "=" not in line:
            continue
        key, val = line.split("=", 1)
        key = key.strip()
        val = val.strip()
        if val.startswith("[") and val.endswith("]"):
            inner = val[1:-1].strip()
            out[key] = [p.strip().strip(Q) for p in inner.split(",") if p.strip()]
        else:
            out[key] = val.strip(Q)
    return out


def read_conf(path):
    """key = value, one per line, section headers ignored."""
    return read_flat_toml(path)


def read_xml(path):
    root = ET.parse(str(path)).getroot()
    scalars = {}
    groups = {}
    for child in root:
        if len(child) == 0:
            scalars[child.tag] = (child.text or "").strip()
        else:
            groups[child.tag] = [dict(g.attrib) for g in child]
    return scalars, groups


def read_sqlite_table(path, table):
    con = sqlite3.connect(str(path))
    try:
        cur = con.cursor()
        cur.execute("SELECT * FROM " + table)
        cols = [c[0] for c in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]
    finally:
        con.close()


def _col_to_idx(ref):
    col = 0
    for ch in ref:
        if ch.isalpha():
            col = col * 26 + (ord(ch.upper()) - 64)
        else:
            break
    return col


def read_xlsx_sheets(path):
    with zipfile.ZipFile(path) as zf:
        shared = []
        if "xl/sharedStrings.xml" in zf.namelist():
            sroot = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in sroot:
                shared.append("".join(t.text or "" for t in si.iter()
                                      if t.tag.endswith("}t")))
        wb = ET.fromstring(zf.read("xl/workbook.xml"))
        names = []
        for sh in wb.iter():
            if sh.tag.endswith("}sheet"):
                names.append(sh.attrib.get("name"))
        out = {}
        for idx, name in enumerate(names, start=1):
            member = "xl/worksheets/sheet" + str(idx) + ".xml"
            if member not in zf.namelist():
                continue
            sroot = ET.fromstring(zf.read(member))
            rows = []
            for row in sroot.iter():
                if not row.tag.endswith("}row"):
                    continue
                cells = {}
                width = 0
                for c in row:
                    if not c.tag.endswith("}c"):
                        continue
                    ci = _col_to_idx(c.attrib.get("r", "A1"))
                    val = ""
                    for v in c:
                        if v.tag.endswith("}v"):
                            val = v.text or ""
                    if c.attrib.get("t") == "s" and val != "":
                        val = shared[int(val)]
                    cells[ci] = val
                    width = max(width, ci)
                rows.append([cells.get(i, "") for i in range(1, width + 1)])
            out[name] = rows
        return out


W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def read_docx_blocks(path):
    with zipfile.ZipFile(path) as zf:
        root = ET.fromstring(zf.read("word/document.xml"))
    out = []
    body = None
    for node in root:
        if node.tag == W_NS + "body":
            body = node
    if body is None:
        return out
    for node in body:
        if node.tag == W_NS + "p":
            out.append("".join(t.text or "" for t in node.iter(W_NS + "t")))
        elif node.tag == W_NS + "tbl":
            for tr in node.findall(W_NS + "tr"):
                out.append(["".join(t.text or "" for t in tc.iter(W_NS + "t"))
                            for tc in tr.findall(W_NS + "tc")])
    return out


def read_pdf_lines(path):
    raw = Path(path).read_bytes()
    out = []
    depth = 0
    cur = []
    esc = False
    for i in range(len(raw)):
        ch = raw[i:i + 1]
        if depth == 0:
            if ch == b"(":
                depth = 1
                cur = []
        else:
            if esc:
                cur.append(ch)
                esc = False
            elif ch == BS.encode("latin-1"):
                esc = True
            elif ch == b"(":
                depth += 1
                cur.append(ch)
            elif ch == b")":
                depth -= 1
                if depth == 0:
                    out.append(b"".join(cur).decode("latin-1"))
                else:
                    cur.append(ch)
            else:
                cur.append(ch)
    return out
