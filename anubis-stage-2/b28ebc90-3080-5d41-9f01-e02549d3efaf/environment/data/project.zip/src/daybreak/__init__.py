"""daybreak - the household assistant routing chain.

Fourteen stages turn one directory of working papers into the derived
documents of one routing cycle. Nothing about a cycle is held here.
"""
__all__ = ["main", "run_chain"]

VERSION = "3.4.0"


def main(argv=None):
    from daybreak.cli import main as _main
    return _main(argv)


def run_chain(root):
    from daybreak.publish import run_chain as _run
    return _run(root)
