"""Command line entry point for the daybreak router."""
import sys
from pathlib import Path

from daybreak.publish import run_chain


USAGE = "usage: python3 -m daybreak --data <papers> --out <destination>"


def parse_args(argv):
    data = None
    out = None
    i = 0
    while i < len(argv):
        token = argv[i]
        if token == "--data" and i + 1 < len(argv):
            data = argv[i + 1]
            i += 2
            continue
        if token == "--out" and i + 1 < len(argv):
            out = argv[i + 1]
            i += 2
            continue
        raise SystemExit(USAGE)
    if data is None or out is None:
        raise SystemExit(USAGE)
    return Path(data), Path(out)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    data, out = parse_args(argv)
    if not data.is_dir():
        raise SystemExit("paper directory not found: " + str(data))
    blobs = run_chain(data)
    out.mkdir(parents=True, exist_ok=True)
    for name in sorted(blobs):
        (out / name).write_bytes(blobs[name])
    return 0
