import sys

from daybreak.cli import main

if __name__ == "__main__":
    sys.exit(main())
