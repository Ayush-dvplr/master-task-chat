"""Arithmetic and parsing checks that hold for every cycle.

These cover the helpers, not the chain. They pass on the package exactly as
it shipped and they pass on a repaired package too, so a green suite says
nothing about whether the chain is right.
"""
import unittest
from fractions import Fraction

from daybreak.cli import parse_args
from daybreak.util import as_fraction, half_even, ratio12, sha256_hex


class HalfEven(unittest.TestCase):
    def test_exact_integers_are_unchanged(self):
        for value in (-4, -1, 0, 1, 7, 1000):
            self.assertEqual(half_even(value), value)

    def test_halves_go_to_even(self):
        self.assertEqual(half_even(Fraction(1, 2)), 0)
        self.assertEqual(half_even(Fraction(3, 2)), 2)
        self.assertEqual(half_even(Fraction(5, 2)), 2)
        self.assertEqual(half_even(Fraction(-1, 2)), 0)
        self.assertEqual(half_even(Fraction(-3, 2)), -2)

    def test_non_halves_go_to_nearest(self):
        self.assertEqual(half_even(Fraction(7, 3)), 2)
        self.assertEqual(half_even(Fraction(8, 3)), 3)


class Quantities(unittest.TestCase):
    def test_decimal_strings_are_exact(self):
        self.assertEqual(as_fraction("7.5"), Fraction(15, 2))
        self.assertEqual(as_fraction("-0.125"), Fraction(-1, 8))
        self.assertEqual(as_fraction("12"), Fraction(12))

    def test_ratio_has_twelve_places(self):
        text = ratio12(Fraction(1, 3))
        self.assertEqual(len(text.split(".")[1]), 12)
        self.assertEqual(ratio12(0), "0.000000000000")
        self.assertEqual(ratio12(Fraction(-1, 10 ** 15)), "0.000000000000")


class Invocation(unittest.TestCase):
    def test_options_are_order_free(self):
        a = parse_args(["--data", "x", "--out", "y"])
        b = parse_args(["--out", "y", "--data", "x"])
        self.assertEqual(str(a[0]), str(b[0]))
        self.assertEqual(str(a[1]), str(b[1]))

    def test_missing_option_is_refused(self):
        with self.assertRaises(SystemExit):
            parse_args(["--data", "x"])


class Digests(unittest.TestCase):
    def test_digest_is_lower_case_hex(self):
        text = sha256_hex(b"daybreak")
        self.assertEqual(len(text), 64)
        self.assertEqual(text, text.lower())


if __name__ == "__main__":
    unittest.main()
