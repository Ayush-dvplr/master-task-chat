"""Reader checks over documents this test writes for itself."""
import tempfile
import unittest
from pathlib import Path

from daybreak.util import (read_conf, read_delim, read_flat_toml,
                           read_flat_yaml, read_json, read_jsonl, PIPE, TAB)


class Readers(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="daybreak-readers-"))

    def test_comma_and_tab_and_pipe(self):
        (self.root / "a.csv").write_text("k,v" + chr(10) + "x,1" + chr(10))
        (self.root / "b.tsv").write_text("k" + TAB + "v" + chr(10)
                                         + "x" + TAB + "1" + chr(10))
        (self.root / "c.psv").write_text("k" + PIPE + "v" + chr(10)
                                         + "x" + PIPE + "1" + chr(10))
        self.assertEqual(read_delim(self.root / "a.csv", ",")[0]["v"], "1")
        self.assertEqual(read_delim(self.root / "b.tsv", TAB)[0]["v"], "1")
        self.assertEqual(read_delim(self.root / "c.psv", PIPE)[0]["v"], "1")

    def test_empty_cell_survives_reading(self):
        (self.root / "d.csv").write_text("k,v" + chr(10) + "x," + chr(10))
        self.assertEqual(read_delim(self.root / "d.csv", ",")[0]["v"], "")

    def test_flat_mappings(self):
        (self.root / "e.yaml").write_text("a: 1" + chr(10)
                                          + "b: [p, q]" + chr(10))
        (self.root / "f.toml").write_text("a = " + chr(34) + "1" + chr(34)
                                          + chr(10))
        self.assertEqual(read_flat_yaml(self.root / "e.yaml")["b"], ["p", "q"])
        self.assertEqual(read_flat_toml(self.root / "f.toml")["a"], "1")

    def test_json_and_jsonl(self):
        (self.root / "g.json").write_text("{" + chr(34) + "a" + chr(34)
                                          + ": 2}")
        (self.root / "h.jsonl").write_text("{" + chr(34) + "a" + chr(34)
                                           + ": 3}" + chr(10))
        self.assertEqual(read_json(self.root / "g.json")["a"], 2)
        self.assertEqual(read_jsonl(self.root / "h.jsonl")[0]["a"], 3)

    def test_conf_reads_key_equals_value(self):
        (self.root / "i.conf").write_text("[s]" + chr(10) + "k = v" + chr(10))
        self.assertEqual(read_conf(self.root / "i.conf")["k"], "v")


if __name__ == "__main__":
    unittest.main()
