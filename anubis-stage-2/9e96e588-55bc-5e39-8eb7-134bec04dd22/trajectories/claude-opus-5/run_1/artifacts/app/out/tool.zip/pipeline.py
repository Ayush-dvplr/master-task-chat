#!/usr/bin/env python3
"""Deterministic, offline driver: builds every delivered artifact by calling cli.py."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

TOOL = Path(__file__).resolve().parent
CLI = str(TOOL / "cli.py")
SCHEMA = str(TOOL / "schema.json")
DATA = "/app/data"
OUT = "/app/out"
STATE = Path("/app/state")
COMMANDS = STATE / "commands.json"
ZONES = ("core", "dmz", "edge", "mgmt")
SPINE_SET_KEYS = (
    "handshake_timeout_ms",
    "max_sessions",
    "mode",
    "rekey_interval_s",
    "retry_budget",
    "trailer",
)

transcript = []


def dump_json(obj):
    return json.dumps(obj, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"


def run(*cli_args):
    argv = ["python3", CLI] + [str(arg) for arg in cli_args]
    proc = subprocess.run(argv, capture_output=True, text=True)
    transcript.append({"argv": argv, "returncode": proc.returncode, "stdout": proc.stdout})
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr)
        raise SystemExit("command failed: " + " ".join(argv))
    return proc.stdout


def save_transcript():
    STATE.mkdir(parents=True, exist_ok=True)
    COMMANDS.write_text(dump_json(transcript), encoding="utf-8")


def main():
    Path(OUT).mkdir(parents=True, exist_ok=True)
    config = Path(OUT) / "config.json"

    run("init", "--schema", SCHEMA, "--out", config)
    policy = json.loads(run("plan", "--data", DATA, "--env", "base"))
    for key in SPINE_SET_KEYS:
        run("set", "--config", config, "--key", key, "--value", policy[key])
    run("validate", "--schema", SCHEMA, "--config", config)
    for zone in ZONES:
        run("plan", "--data", DATA, "--env", zone)
    run("compile", "--data", DATA, "--out", OUT)
    run("pack", "--tool", str(TOOL), "--out", Path(OUT) / "tool.zip")
    run("summarize", "--data", DATA, "--out", OUT)

    save_transcript()
    digest = hashlib.sha256(config.read_bytes()).hexdigest()
    run(
        "export-report",
        "--config",
        config,
        "--out",
        Path(OUT) / "report.json",
        "--digest",
        digest,
        "--commands",
        COMMANDS,
    )

    save_transcript()
    run("finalize", "--data", DATA, "--out", OUT, "--commands", COMMANDS)
    print("pipeline commands=%d" % len(transcript))


if __name__ == "__main__":
    main()
