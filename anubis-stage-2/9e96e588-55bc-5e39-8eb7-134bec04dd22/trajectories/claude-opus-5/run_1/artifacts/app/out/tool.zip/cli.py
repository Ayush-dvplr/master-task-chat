#!/usr/bin/env python3
"""sealb-ctl: offline, standard-library-only security policy compiler."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

TOOL_NAME = "sealb-ctl"
INT_KEYS = ("max_sessions", "retry_budget", "handshake_timeout_ms", "rekey_interval_s")
SPINE_KEYS = INT_KEYS + ("mode",)
ZONES = ("core", "edge", "dmz", "mgmt")
AGG_MIRRORS = ("csv", "tsv", "xml", "ini", "env", "md", "txt")
ZIP_EPOCH = (1980, 1, 1, 0, 0, 0)
ZIP_ATTR = 0o100644 << 16
TOOL_MEMBERS = ("README.md", "cli.py", "pipeline.py", "schema.json")

ARTIFACTS = (
    ["config.json"]
    + ["profile_%s.json" % zone for zone in ZONES]
    + ["aggregates.json"]
    + ["aggregates.%s" % ext for ext in AGG_MIRRORS]
    + [
        "zone_totals.json",
        "corpus_index.json",
        "posture.json",
        "rejected_ops.json",
        "validation_report.json",
        "summary.json",
        "report.json",
        "manifest.sha256",
        "tool.zip",
    ]
)
MANIFEST_SKIP = ("report.json",)

CORPORA = (
    ("c01_cve_severity", "csv", "csv", "max"),
    ("c02_cipher_grade", "tsv", "tsv", "min"),
    ("c03_port_exposure", "psv", "psv", "sum"),
    ("c04_tls_versions", "scsv", "scsv", "count"),
    ("c05_key_age_days", "colon", "colon", "last"),
    ("c06_iam_priv_level", "ssv", "ssv", "first"),
    ("c07_mfa_factor_count", "caret", "caret", "max"),
    ("c08_patch_lag_hours", "at", "at", "min"),
    ("c09_firewall_hits", "dcolon", "dcolon", "sum"),
    ("c10_cert_days_left", "bang", "bang", "count"),
    ("c11_session_ttl", "tilde", "tilde", "last"),
    ("c12_rate_budget", "json", "jsonarr", "first"),
    ("c13_scope_bits", "jsonl", "jsonl", "max"),
    ("c14_audit_gap_min", "xml", "xmlflat", "min"),
    ("c15_sudo_grants", "nxml", "xmlnest", "sum"),
    ("c16_ssh_keybits", "ini", "ini", "count"),
    ("c17_kms_rotations", "fixed", "fixed", "last"),
    ("c18_acl_depth", "md", "mdtable", "first"),
    ("c19_quota_caps", "kv", "kvline", "max"),
    ("c20_login_fails", "properties", "props", "min"),
    ("c21_privilege_escal", "csv", "csv", "sum"),
    ("c22_dns_ttl_sec", "tsv", "tsv", "count"),
    ("c23_backup_age_hrs", "psv", "psv", "last"),
    ("c24_vuln_count", "scsv", "scsv", "first"),
    ("c25_handshake_ms", "colon", "colon", "max"),
    ("c26_nonce_reuse", "ssv", "ssv", "min"),
    ("c27_hsts_max_age", "caret", "caret", "sum"),
    ("c28_cookie_ttl", "at", "at", "count"),
    ("c29_jwt_exp_min", "dcolon", "dcolon", "last"),
    ("c30_replay_window", "bang", "bang", "first"),
    ("c31_entropy_bits", "tilde", "tilde", "max"),
    ("c32_salt_rounds", "json", "jsonarr", "min"),
    ("c33_cidr_size", "jsonl", "jsonl", "sum"),
    ("c34_egress_ports", "xml", "xmlflat", "count"),
    ("c35_ingress_ports", "nxml", "xmlnest", "last"),
    ("c36_trust_score", "ini", "ini", "first"),
    ("c37_risk_weight", "fixed", "fixed", "max"),
    ("c38_drift_count", "md", "mdtable", "min"),
    ("c39_seal_depth", "kv", "kvline", "sum"),
    ("c40_vault_leases", "properties", "props", "count"),
    ("c41_rotation_days", "csv", "csv", "last"),
    ("c42_throttle_rps", "tsv", "tsv", "first"),
    ("c43_ban_minutes", "psv", "psv", "max"),
    ("c44_cap_drops", "scsv", "scsv", "min"),
    ("c45_syscall_allow", "colon", "colon", "sum"),
    ("c46_namespace_ct", "ssv", "ssv", "count"),
    ("c47_cgroup_limit", "caret", "caret", "last"),
    ("c48_seccomp_rules", "at", "at", "first"),
    ("c49_apparmor_hits", "dcolon", "dcolon", "max"),
    ("c50_oauth_scopes", "bang", "bang", "min"),
)

DELIMS = {
    "csv": ",",
    "tsv": "\t",
    "psv": "|",
    "scsv": ";",
    "colon": ":",
    "caret": "^",
    "at": "@",
    "bang": "!",
    "tilde": "~",
    "dcolon": "::",
}


# --------------------------------------------------------------------------
# serialization helpers
# --------------------------------------------------------------------------
def dump_json(obj):
    return json.dumps(obj, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"


def write_json(path, obj):
    Path(path).write_text(dump_json(obj), encoding="utf-8")


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical_int(raw):
    """Return int(raw) when raw is a canonical base-10 integer string, else None."""
    if not isinstance(raw, str) or not raw:
        return None
    for ch in raw:
        if ch != "-" and not ("0" <= ch <= "9"):
            return None
    try:
        num = int(raw)
    except ValueError:
        return None
    return num if str(num) == raw else None


def field_value(raw):
    """Canonical integer of one evidence field (a JSON integer is already canonical)."""
    if isinstance(raw, bool):
        return None
    if isinstance(raw, int):
        return raw
    return canonical_int(raw)


# --------------------------------------------------------------------------
# journal replay
# --------------------------------------------------------------------------
def read_journal(data_dir):
    ops = []
    with open(Path(data_dir) / "change_journal.jsonl", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                ops.append(json.loads(line))
    ops.sort(key=lambda op: op["seq"])
    return ops


def op_is_valid(op, rules):
    if op.get("env") not in rules["journal_envs"]:
        return False
    key = op.get("key")
    if key not in SPINE_KEYS:
        return False
    kind = op.get("op")
    if kind == "unset":
        return True
    if kind != "set":
        return False
    value = op.get("value")
    if key == "mode":
        return isinstance(value, str) and value in rules["allowed_modes"]
    if isinstance(value, bool) or not isinstance(value, int):
        return False
    low, high = rules["bounds"][key]
    return low <= value <= high


def default_of(key, defaults):
    return defaults["mode"] if key == "mode" else defaults["base_config"][key]


def apply_op(config, op, defaults):
    key = op["key"]
    if op["op"] == "set":
        config[key] = op["value"]
    else:
        config[key] = default_of(key, defaults)


def classify(data_dir):
    """Replay the journal in seq order: returns (spine, rejected_seqs, valid_ops)."""
    data = Path(data_dir)
    rules = load_json(data / "validation_rules.json")
    defaults = load_json(data / "defaults.json")
    schema = load_json(data / "config_schema.json")

    spine = {
        "profile": schema["profile"],
        "producer": schema["producer"],
        "container": schema["container"],
        "checksum": defaults["checksum"],
        "mode": defaults["mode"],
        "trailer": defaults["base_config"]["trailer"],
    }
    for key in INT_KEYS:
        spine[key] = defaults["base_config"][key]

    rejected = []
    valid = []
    for op in read_journal(data):
        if op_is_valid(op, rules):
            valid.append(op)
            apply_op(spine, op, defaults)
        else:
            rejected.append(op["seq"])
    return spine, rejected, valid


def build_profile(spine, zone, data_dir, valid_ops=None):
    data = Path(data_dir)
    defaults = load_json(data / "defaults.json")
    overrides = load_json(data / "env_overrides.json")[zone]
    if valid_ops is None:
        valid_ops = classify(data)[2]

    profile = dict(spine)
    profile["retry_budget"] = spine["retry_budget"] + overrides["retry_budget_delta"]
    profile["handshake_timeout_ms"] = spine["handshake_timeout_ms"] + overrides["handshake_timeout_ms_delta"]
    profile["rekey_interval_s"] = spine["rekey_interval_s"] + overrides["rekey_interval_s_delta"]
    profile["mode"] = overrides["mode"]
    profile["profile"] = "%s-%s" % (spine["profile"], zone)
    profile["trailer"] = "%s:%s" % (spine["trailer"], zone)
    for op in valid_ops:
        if op["env"] == zone:
            apply_op(profile, op, defaults)
    return profile


# --------------------------------------------------------------------------
# corpus readers: each returns (zone, value_field, flag) triples in file order
# --------------------------------------------------------------------------
def _lines(path):
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            if line.lstrip()[0] == "#":
                continue
            yield line


def read_delimited(path, delim):
    rows = []
    for line in _lines(path):
        parts = line.split(delim)
        if len(parts) == 3:
            rows.append(tuple(parts))
    return rows


def read_ssv(path):
    rows = []
    for line in _lines(path):
        parts = re.split(r" +", line)
        if len(parts) == 3:
            rows.append(tuple(parts))
    return rows


def read_jsonarr(path):
    rows = []
    for item in load_json(path):
        if isinstance(item, dict) and {"zone", "value", "flag"} <= set(item):
            rows.append((item["zone"], item["value"], item["flag"]))
    return rows


def read_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line or line.startswith("//") or line.startswith("#"):
                continue
            item = json.loads(line)
            if isinstance(item, dict) and {"zone", "value", "flag"} <= set(item):
                rows.append((item["zone"], item["value"], item["flag"]))
    return rows


def read_xmlflat(path):
    rows = []
    for row in ET.parse(path).getroot().findall("row"):
        attrs = row.attrib
        if {"zone", "value", "flag"} <= set(attrs):
            rows.append((attrs["zone"], attrs["value"], attrs["flag"]))
    return rows


def read_xmlnest(path):
    rows = []
    for row in ET.parse(path).getroot().findall("row"):
        cells = [row.find(tag) for tag in ("zone", "value", "flag")]
        if any(cell is None for cell in cells):
            continue
        rows.append(tuple("" if cell.text is None else cell.text for cell in cells))
    return rows


def _unpad_left(text):
    return text[1:] if text.startswith(" ") else text


def read_ini(path):
    records = []
    current = None
    for line in _lines(path):
        if line.startswith("[") and line.endswith("]"):
            current = {}
            records.append(current)
            continue
        if current is None or "=" not in line:
            continue
        key, raw = line.split("=", 1)
        current[key.strip()] = _unpad_left(raw)
    return [
        (rec["zone"], rec["value"], rec["flag"])
        for rec in records
        if {"zone", "value", "flag"} <= set(rec)
    ]


def read_fixed(path):
    return [(line[0:10].rstrip(" "), line[10:30].rstrip(" "), line[30:]) for line in _lines(path)]


def read_mdtable(path):
    rows = []
    for line in _lines(path):
        cells = line.split("|")
        if len(cells) != 5 or cells[0].strip() or cells[4].strip():
            continue
        trimmed = []
        for cell in cells[1:4]:
            cell = _unpad_left(cell)
            if cell.endswith(" "):
                cell = cell[:-1]
            trimmed.append(cell)
        rows.append(tuple(trimmed))
    return rows


def read_kvline(path):
    rows = []
    for line in _lines(path):
        fields = {}
        for token in line.split():
            if "=" in token:
                key, raw = token.split("=", 1)
                fields[key] = raw
        if {"zone", "value", "flag"} <= set(fields):
            rows.append((fields["zone"], fields["value"], fields["flag"]))
    return rows


def read_props(path):
    order = []
    records = {}
    for line in _lines(path):
        if "=" not in line:
            continue
        left, raw = line.split("=", 1)
        if "." not in left:
            continue
        record, key = left.split(".", 1)
        if record not in records:
            records[record] = {}
            order.append(record)
        records[record][key] = raw
    rows = []
    for record in order:
        fields = records[record]
        if {"zone", "value", "flag"} <= set(fields):
            rows.append((fields["zone"], fields["value"], fields["flag"]))
    return rows


def read_corpus(path, wire):
    if wire in DELIMS:
        return read_delimited(path, DELIMS[wire])
    readers = {
        "ssv": read_ssv,
        "jsonarr": read_jsonarr,
        "jsonl": read_jsonl,
        "xmlflat": read_xmlflat,
        "xmlnest": read_xmlnest,
        "ini": read_ini,
        "fixed": read_fixed,
        "mdtable": read_mdtable,
        "kvline": read_kvline,
        "props": read_props,
    }
    return readers[wire](path)


# --------------------------------------------------------------------------
# corpus reduction
# --------------------------------------------------------------------------
def reduce_corpus(values, op):
    if op == "count":
        return len(values)
    if not values:
        return 0
    if op == "max":
        return max(values)
    if op == "min":
        return min(values)
    if op == "sum":
        return sum(values)
    if op == "first":
        return values[0]
    if op == "last":
        return values[-1]
    raise SystemExit("unknown operator: " + op)


def aggregate(data_dir, shift, rules):
    data = Path(data_dir)
    zones = set(rules["zones"])
    aggregates = {}
    index = []
    zone_totals = {zone: 0 for zone in rules["zones"]}
    for name, ext, wire, op in CORPORA:
        low, high = rules["corpus_bounds"][name]
        limit = high + shift
        counted = []
        for zone, raw, flag in read_corpus(data / ("%s.%s" % (name, ext)), wire):
            if zone not in zones or flag != "active":
                continue
            num = field_value(raw)
            if num is None or num < low or num > limit:
                continue
            counted.append(num)
            zone_totals[zone] += 1
        value = reduce_corpus(counted, op)
        aggregates[name] = value
        index.append(
            {
                "name": name,
                "format": wire,
                "op": op,
                "lo": low,
                "hi": high,
                "eligible_rows": len(counted),
                "value": value,
            }
        )
    return aggregates, index, zone_totals


# --------------------------------------------------------------------------
# aggregate mirrors
# --------------------------------------------------------------------------
def mirror_aggregates(out_dir, aggregates):
    out = Path(out_dir)
    rows = [(name, aggregates[name]) for name in sorted(aggregates)]

    write_text(out / "aggregates.csv", "".join(["corpus,value\n"] + ["%s,%d\n" % row for row in rows]))
    write_text(out / "aggregates.tsv", "".join(["corpus\tvalue\n"] + ["%s\t%d\n" % row for row in rows]))

    xml = ["<aggregates>"]
    for name, value in rows:
        xml.append('  <corpus name="%s" value="%d" />' % (name, value))
    xml.append("</aggregates>")
    write_text(out / "aggregates.xml", "\n".join(xml) + "\n")

    write_text(out / "aggregates.ini", "".join(["[aggregates]\n"] + ["%s = %d\n" % row for row in rows]))
    write_text(out / "aggregates.env", "".join("%s=%d\n" % (name.upper(), value) for name, value in rows))

    md = ["| corpus | value |", "| --- | --- |"] + ["| %s | %d |" % row for row in rows]
    write_text(out / "aggregates.md", "\n".join(md) + "\n")

    write_text(out / "aggregates.txt", "".join("%s %d\n" % row for row in rows))


# --------------------------------------------------------------------------
# subcommands
# --------------------------------------------------------------------------
def cmd_init(args):
    schema = load_json(args.schema)
    write_json(
        args.out,
        {
            "profile": schema["profile"],
            "producer": schema["producer"],
            "container": schema["container"],
            "checksum": schema["checksum"],
        },
    )
    print("init " + str(args.out))


def cmd_set(args):
    config = load_json(args.config)
    num = canonical_int(args.value)
    config[args.key] = args.value if num is None else num
    write_json(args.config, config)
    print("set " + args.key)


def cmd_validate(args):
    schema = load_json(args.schema)
    config = load_json(args.config)
    required = [key for key in schema["required_keys"].split(",") if key]
    missing = [key for key in required if key not in config]
    if missing:
        raise SystemExit("missing: " + ",".join(missing))
    if any(isinstance(value, (dict, list)) for value in config.values()):
        raise SystemExit("configuration must be flat")
    print("ok")


def cmd_plan(args):
    spine, _rejected, valid = classify(args.data)
    document = spine if args.env == "base" else build_profile(spine, args.env, args.data, valid)
    print(dump_json(document), end="")


def cmd_compile(args):
    data = Path(args.data)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rules = load_json(data / "validation_rules.json")
    _policy, rejected, valid = classify(data)
    spine = load_json(out / "config.json")

    for zone in rules["zones"]:
        write_json(out / ("profile_%s.json" % zone), build_profile(spine, zone, data, valid))

    shift = spine["rekey_interval_s"] % 97 + len(rejected) % 31
    aggregates, index, zone_totals = aggregate(data, shift, rules)

    write_json(out / "aggregates.json", aggregates)
    mirror_aggregates(out, aggregates)
    write_json(out / "zone_totals.json", zone_totals)
    write_json(out / "corpus_index.json", {"count": len(index), "corpora": index})

    best = None
    for name in sorted(aggregates):
        if best is None or aggregates[name] > aggregates[best]:
            best = name
    write_json(
        out / "posture.json",
        {
            "aggregate_total": sum(aggregates.values()),
            "corpus_count": len(aggregates),
            "max_corpus": best,
            "max_value": aggregates[best],
            "nonzero_corpora": sum(1 for value in aggregates.values() if value != 0),
        },
    )
    write_json(out / "rejected_ops.json", {"rejected": rejected, "count": len(rejected)})
    print("compile corpora=%d shift=%d rejected=%d" % (len(aggregates), shift, len(rejected)))


def cmd_summarize(args):
    data = Path(args.data)
    out = Path(args.out)
    rules = load_json(data / "validation_rules.json")
    spine = load_json(out / "config.json")
    posture = load_json(out / "posture.json")
    inputs = sorted(path.name for path in data.iterdir() if path.is_file())
    write_json(
        out / "summary.json",
        {
            "tool": TOOL_NAME,
            "profile_tag": spine["profile"],
            "trailer": spine["trailer"],
            "profiles": rules["profiles"],
            "artifacts": sorted(ARTIFACTS),
            "artifact_count": len(ARTIFACTS),
            "inputs": inputs,
            "input_count": len(inputs),
            "corpus_count": posture["corpus_count"],
            "aggregate_total": posture["aggregate_total"],
        },
    )
    print("summarize artifacts=%d inputs=%d" % (len(ARTIFACTS), len(inputs)))


def cmd_finalize(args):
    data = Path(args.data)
    out = Path(args.out)
    commands = load_json(args.commands)
    rules = load_json(data / "validation_rules.json")
    spine = load_json(out / "config.json")
    posture = load_json(out / "posture.json")
    rejected = load_json(out / "rejected_ops.json")
    policy = classify(data)[0]

    # validation_report.json is this file and manifest.sha256 hashes it, so
    # neither can already be on disk while this check runs.
    pending = {"validation_report.json", "manifest.sha256"}
    missing = [name for name in ARTIFACTS if name not in pending and not (out / name).exists()]

    profiles = {}
    for zone in rules["zones"]:
        profile = load_json(out / ("profile_%s.json" % zone))
        profiles[zone] = {
            "scalar_flat": not any(isinstance(value, (dict, list)) for value in profile.values()),
            "trailer": profile["trailer"],
        }

    checks = {
        "all_artifacts_present": not missing,
        "config_matches_policy": spine == policy,
        "config_scalar_flat": not any(isinstance(value, (dict, list)) for value in spine.values()),
        "command_failures": sum(1 for entry in commands if entry["returncode"] != 0),
        "rejected_ops": rejected["count"],
        "profiles": profiles,
        "corpus_count": posture["corpus_count"],
        "aggregate_total": posture["aggregate_total"],
    }
    ok = (
        checks["all_artifacts_present"]
        and checks["config_matches_policy"]
        and checks["config_scalar_flat"]
        and checks["command_failures"] == 0
        and checks["corpus_count"] == len(CORPORA)
        and all(entry["scalar_flat"] for entry in profiles.values())
    )
    write_json(out / "validation_report.json", {"ok": ok, "checks": checks})

    lines = []
    for name in sorted(ARTIFACTS):
        if name in MANIFEST_SKIP or not name.endswith(".json"):
            continue
        lines.append("%s  %s\n" % (sha256_file(out / name), name))
    write_text(out / "manifest.sha256", "".join(lines))
    print("finalize ok=%s entries=%d" % (str(ok).lower(), len(lines)))


def cmd_pack(args):
    root = Path(args.tool)
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_STORED) as archive:
        for name in sorted(TOOL_MEMBERS):
            info = zipfile.ZipInfo(name, date_time=ZIP_EPOCH)
            info.compress_type = zipfile.ZIP_STORED
            info.external_attr = ZIP_ATTR
            info.create_system = 3
            archive.writestr(info, (root / name).read_bytes())
    print("pack members=%d" % len(TOOL_MEMBERS))


def cmd_report(args):
    config = load_json(args.config)
    digest = sha256_file(args.config)
    if args.digest != digest:
        raise SystemExit("digest mismatch: %s != %s" % (args.digest, digest))
    write_json(
        args.out,
        {
            "ok": True,
            "tool": TOOL_NAME,
            "config_path": str(args.config),
            "config_sha256": digest,
            "trailer": config["trailer"],
            "commands": load_json(args.commands),
        },
    )
    print("export-report " + str(args.out))


def main():
    parser = argparse.ArgumentParser(prog=TOOL_NAME)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("plan")
    p.add_argument("--data", required=True)
    p.add_argument("--env", required=True, choices=("base",) + ZONES)
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("compile")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("summarize")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_summarize)

    p = sub.add_parser("finalize")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_finalize)

    p = sub.add_parser("pack")
    p.add_argument("--tool", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_pack)

    p = sub.add_parser("export-report")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", required=True)
    p.add_argument("--commands", required=True)
    p.set_defaults(func=cmd_report)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
