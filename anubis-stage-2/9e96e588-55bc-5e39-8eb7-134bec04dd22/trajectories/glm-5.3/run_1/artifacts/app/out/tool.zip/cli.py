#!/usr/bin/env python3
"""sealb-ctl: offline, standard-library-only security policy compiler.

Every value the compiler emits is derived from the files in the data
directory (the written derivation contract, the schema, defaults, env
overrides, validation rules, the change journal and the evidence
corpora).  Nothing is invented, nothing is fetched, no wall-clock time
and no randomness is used, so repeated runs are byte-identical.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

TOOL = "sealb-ctl"
DEFAULT_DATA = "/app/data"
JSON_KW = {"sort_keys": True, "indent": 2, "separators": (",", ": "), "ensure_ascii": False}
ZIP_EPOCH = (1980, 1, 1, 0, 0, 0)
ZIP_EXTERNAL_ATTR = 0o100644 << 16
OPS = ("max", "min", "sum", "count", "first", "last")
FORMATS = ("csv", "tsv", "psv", "scsv", "colon", "caret", "at", "bang", "tilde",
           "dcolon", "ssv", "jsonarr", "jsonl", "xmlflat", "xmlnest", "ini",
           "fixed", "mdtable", "kvline", "props")
HEADER_ROW = ("zone", "value", "flag")
JSON_ARTIFACTS = ("aggregates.json", "config.json", "corpus_index.json",
                  "posture.json", "profile_core.json", "profile_dmz.json",
                  "profile_edge.json", "profile_mgmt.json", "rejected_ops.json",
                  "report.json", "summary.json", "validation_report.json",
                  "zone_totals.json")
MIRRORS = ("aggregates.csv", "aggregates.env", "aggregates.ini", "aggregates.md",
           "aggregates.tsv", "aggregates.txt", "aggregates.xml")
OTHER_ARTIFACTS = ("manifest.sha256", "tool.zip")


def dump_json(obj):
    """The one canonical serialization used for every JSON artifact."""
    return json.dumps(obj, **JSON_KW) + "\n"


def write_json(path, obj):
    Path(path).write_text(dump_json(obj), encoding="utf-8")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    return sha256_bytes(Path(path).read_bytes())


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")


def ensure_parent(path):
    parent = Path(path).parent
    if str(parent) not in ("", "."):
        parent.mkdir(parents=True, exist_ok=True)


def is_scalar(value):
    return not isinstance(value, (dict, list))


def is_flat(config):
    return isinstance(config, dict) and all(is_scalar(v) for v in config.values())


# --------------------------------------------------------------------------
# the data spine
# --------------------------------------------------------------------------

class PolicyData:
    """Every input the compiler derives its output from."""

    def __init__(self, data_dir):
        self.dir = Path(data_dir)
        self.defaults = read_json(self.dir / "defaults.json")
        self.rules = read_json(self.dir / "validation_rules.json")
        self.overrides = read_json(self.dir / "env_overrides.json")
        self.sidecar = read_json(self.dir / "config_schema.json")
        self.journal = self._load_journal()
        self.corpora = load_corpus_table(self.dir, self.rules)

    def _load_journal(self):
        ops = []
        for line in (self.dir / "change_journal.jsonl").read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            ops.append(json.loads(line))
        ops.sort(key=lambda record: record["seq"])
        return ops

    # -- seeding -----------------------------------------------------------
    def seed(self, schema=None):
        """The flat configuration before any journal replay."""
        source = self.sidecar if schema is None else schema
        base = self.defaults["base_config"]
        return {
            "profile": source["profile"],
            "producer": source["producer"],
            "container": source["container"],
            "checksum": source.get("checksum", self.defaults["checksum"]),
            "mode": self.defaults["mode"],
            "max_sessions": base["max_sessions"],
            "retry_budget": base["retry_budget"],
            "handshake_timeout_ms": base["handshake_timeout_ms"],
            "rekey_interval_s": base["rekey_interval_s"],
            "trailer": base["trailer"],
        }

    def default_for(self, key):
        base = self.defaults["base_config"]
        if key in base:
            return base[key]
        return self.defaults[key]

    # -- journal classification -------------------------------------------
    def op_valid(self, record):
        if record.get("env") not in self.rules["journal_envs"]:
            return False
        key = record.get("key")
        op = record.get("op")
        if op == "set":
            if key in self.rules["bounds"]:
                value = record.get("value")
                if isinstance(value, bool) or not isinstance(value, int):
                    return False
                low, high = self.rules["bounds"][key]
                return low <= value <= high
            if key == "mode":
                return record.get("value") in self.rules["allowed_modes"]
            return False
        if op == "unset":
            return key in self.rules["bounds"] or key == "mode"
        return False

    def rejected(self):
        return [record["seq"] for record in self.journal if not self.op_valid(record)]

    def replay(self, start, env):
        """Apply one environment's valid journal operations in seq order."""
        config = dict(start)
        for record in self.journal:
            if not self.op_valid(record) or record["env"] != env:
                continue
            key = record["key"]
            if record["op"] == "set":
                config[key] = record["value"]
            else:
                config[key] = self.default_for(key)
        return config

    def resolve(self, env, schema=None):
        """The fully resolved policy document for one environment."""
        spine = self.replay(self.seed(schema), "base")
        if env == "base":
            return spine
        if env not in self.overrides:
            raise SystemExit("unknown environment: %s" % env)
        zone = self.overrides[env]
        config = dict(spine)
        config["retry_budget"] = spine["retry_budget"] + zone["retry_budget_delta"]
        config["handshake_timeout_ms"] = spine["handshake_timeout_ms"] + zone["handshake_timeout_ms_delta"]
        config["rekey_interval_s"] = spine["rekey_interval_s"] + zone["rekey_interval_s_delta"]
        config["mode"] = zone["mode"]
        config["profile"] = "%s-%s" % (spine["profile"], env)
        config["trailer"] = "%s:%s" % (spine["trailer"], env)
        return self.replay(config, env)


# --------------------------------------------------------------------------
# corpora
# --------------------------------------------------------------------------

def load_corpus_table(data_dir, rules):
    """Read the corpus table out of the written derivation contract."""
    text = (Path(data_dir) / "config_contract.md").read_text(encoding="utf-8")
    corpora = []
    for line in text.splitlines():
        stripped = line.strip()
        if not (stripped.startswith("|") and stripped.endswith("|")):
            continue
        parts = [part.strip() for part in stripped[1:-1].split("|")]
        if len(parts) != 5:
            continue
        name, fmt, op, low, high = parts
        if fmt not in FORMATS or op not in OPS:
            continue
        if not re.fullmatch(r"c\d\d_.+\.[a-z]+", name):
            continue
        if not (re.fullmatch(r"-?\d+", low) and re.fullmatch(r"-?\d+", high)):
            continue
        if not (Path(data_dir) / name).is_file():
            raise SystemExit("missing corpus file: %s" % name)
        stem = name.rsplit(".", 1)[0]
        published = rules["corpus_bounds"].get(stem)
        if published is None or published != [int(low), int(high)]:
            raise SystemExit("bound mismatch for %s" % name)
        corpora.append({"name": name, "format": fmt, "op": op,
                        "lo": int(low), "hi": int(high)})
    if not corpora:
        raise SystemExit("no corpora found in the contract")
    names = [corpus["name"] for corpus in corpora]
    if len(set(names)) != len(names):
        raise SystemExit("duplicate corpus in the contract")
    return sorted(corpora, key=lambda corpus: corpus["name"])


def _data_lines(path):
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        if line.lstrip().startswith("#"):
            continue
        yield line


def _three(fields):
    return tuple(fields) if len(fields) == 3 else None


def _is_header(row):
    return row is not None and tuple(row) == HEADER_ROW


def _rows_delimited(path, sep, header):
    for line in _data_lines(path):
        row = _three(line.split(sep))
        if row is None or (header and _is_header(row)):
            continue
        yield row


def _rows_dcolon(path):
    for line in _data_lines(path):
        row = _three(line.split("::"))
        if row is None:
            continue
        yield row


def _rows_ssv(path):
    for line in _data_lines(path):
        row = _three(line.split())
        if row is None or _is_header(row):
            continue
        yield row


def _record_of(obj):
    if not isinstance(obj, dict) or set(obj) != set(HEADER_ROW):
        return None
    return (obj["zone"], obj["value"], obj["flag"])


def _rows_jsonarr(path):
    payload = read_json(path)
    if not isinstance(payload, list):
        return
    for obj in payload:
        row = _record_of(obj)
        if row is not None:
            yield row


def _rows_jsonl(path):
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("//") or stripped.startswith("#"):
            continue
        row = _record_of(json.loads(stripped))
        if row is not None:
            yield row


def _rows_xmlflat(path):
    for element in ET.parse(str(path)).getroot().findall("row"):
        if set(element.keys()) != set(HEADER_ROW):
            continue
        yield (element.get("zone"), element.get("value"), element.get("flag"))


def _rows_xmlnest(path):
    for element in ET.parse(str(path)).getroot().findall("row"):
        fields = {}
        for child in element:
            fields[child.tag] = child.text if child.text is not None else ""
        if set(fields) != set(HEADER_ROW):
            continue
        yield (fields["zone"], fields["value"], fields["flag"])


def _rows_ini(path):
    sections = []
    current = None
    for line in _data_lines(path):
        if line.startswith("[") and line.endswith("]"):
            if current is not None:
                sections.append(current)
            current = {}
            continue
        if current is None:
            continue
        match = re.match(r"^([A-Za-z0-9_]+) = (.*)$", line)
        if match is None:
            continue
        current[match.group(1)] = match.group(2)
    if current is not None:
        sections.append(current)
    for section in sections:
        if set(section) != set(HEADER_ROW):
            continue
        yield (section["zone"], section["value"], section["flag"])


def _rows_fixed(path):
    """Fixed columns: zone 0-10, value 10-30, flag from 30.

    Zone and value are right-padded fields, so trailing padding is part of
    the column, not of the field; the flag column runs to end of line.
    """
    for line in _data_lines(path):
        if len(line) < 30:
            continue
        if line[0:10].rstrip() == "zone":
            continue
        yield (line[0:10].rstrip(), line[10:30].rstrip(), line[30:])


def _rows_mdtable(path):
    for line in _data_lines(path):
        if not (line.startswith("|") and line.endswith("|")):
            continue
        fields = []
        for part in line[1:-1].split("|"):
            if part.startswith(" "):
                part = part[1:]
            if part.endswith(" "):
                part = part[:-1]
            fields.append(part)
        row = _three(fields)
        if row is None or _is_header(row):
            continue
        if all(re.fullmatch(r"-+", field) for field in row):
            continue
        yield row


def _rows_kvline(path):
    for line in _data_lines(path):
        tokens = line.split(" ")
        if len(tokens) != 3 or any("=" not in token for token in tokens):
            continue
        fields = {}
        for token in tokens:
            key, _, value = token.partition("=")
            fields[key] = value
        if set(fields) != set(HEADER_ROW):
            continue
        yield (fields["zone"], fields["value"], fields["flag"])


def _rows_props(path):
    records = {}
    order = []
    for line in _data_lines(path):
        match = re.match(r"^([^.]+)\.([^.]+)=(.*)$", line)
        if match is None:
            continue
        prefix = match.group(1)
        if prefix not in records:
            records[prefix] = {}
            order.append(prefix)
        records[prefix][match.group(2)] = match.group(3)
    for prefix in order:
        record = records[prefix]
        if set(record) != set(HEADER_ROW):
            continue
        yield (record["zone"], record["value"], record["flag"])


READERS = {
    "csv": lambda path: _rows_delimited(path, ",", True),
    "tsv": lambda path: _rows_delimited(path, "\t", True),
    "psv": lambda path: _rows_delimited(path, "|", False),
    "scsv": lambda path: _rows_delimited(path, ";", False),
    "colon": lambda path: _rows_delimited(path, ":", False),
    "caret": lambda path: _rows_delimited(path, "^", False),
    "at": lambda path: _rows_delimited(path, "@", False),
    "bang": lambda path: _rows_delimited(path, "!", False),
    "tilde": lambda path: _rows_delimited(path, "~", False),
    "dcolon": _rows_dcolon,
    "ssv": _rows_ssv,
    "jsonarr": _rows_jsonarr,
    "jsonl": _rows_jsonl,
    "xmlflat": _rows_xmlflat,
    "xmlnest": _rows_xmlnest,
    "ini": _rows_ini,
    "fixed": _rows_fixed,
    "mdtable": _rows_mdtable,
    "kvline": _rows_kvline,
    "props": _rows_props,
}


def canonical_int(field):
    """The integer for a canonical base-10 field, otherwise None.

    The test is `str(int(value)) == value` on the exact field bytes, so
    leading zeros, a leading `+`, surrounding whitespace, underscores, hex,
    floats, units, words, scientific notation, `-0`-style strings and every
    non-ASCII decimal digit are rejected.  A JSON integer is canonical.
    """
    if isinstance(field, bool):
        return None
    if isinstance(field, int):
        return field
    text = "" if field is None else (field if isinstance(field, str) else str(field))
    try:
        number = int(text)
    except ValueError:
        return None
    if str(number) != text:
        return None
    return number


def reduce_corpus(path, corpus, shift, zones):
    """Return the counted values and the per-zone counted-row counts."""
    high = corpus["hi"] + shift
    values = []
    per_zone = {}
    for zone, field, flag in READERS[corpus["format"]](path):
        if zone not in zones or flag != "active":
            continue
        number = canonical_int(field)
        if number is None or number < corpus["lo"] or number > high:
            continue
        values.append(number)
        per_zone[zone] = per_zone.get(zone, 0) + 1
    return values, per_zone


def aggregate(op, values):
    if op == "count":
        return len(values)
    if not values:
        return 0
    if op == "max":
        return max(values)
    if op == "min":
        return min(values)
    if op == "sum":
        return sum(values)
    if op == "first":
        return values[0]
    return values[-1]


# --------------------------------------------------------------------------
# artifact helpers
# --------------------------------------------------------------------------

def delivered_artifacts():
    return sorted(JSON_ARTIFACTS + MIRRORS + OTHER_ARTIFACTS)


def manifest_names():
    """Delivered JSON artifacts the manifest covers, in sorted order."""
    return sorted(name for name in JSON_ARTIFACTS if name != "report.json")


def present_artifacts(outdir):
    """Artifacts that exist when the validation report is written."""
    return [name for name in delivered_artifacts()
            if name not in ("manifest.sha256", "report.json", "validation_report.json")]


def write_aggregate_mirrors(outdir, aggregates):
    names = sorted(aggregates)

    write_text(outdir / "aggregates.csv",
               "\n".join(["corpus,value"] + ["%s,%d" % (n, aggregates[n]) for n in names]) + "\n")
    write_text(outdir / "aggregates.tsv",
               "\n".join(["corpus\tvalue"] + ["%s\t%d" % (n, aggregates[n]) for n in names]) + "\n")
    xml = ['<?xml version="1.0" encoding="UTF-8"?>', "<aggregates>"]
    xml += ['  <aggregate name="%s" value="%d"/>' % (n, aggregates[n]) for n in names]
    xml.append("</aggregates>")
    write_text(outdir / "aggregates.xml", "\n".join(xml) + "\n")
    ini = []
    for name in names:
        ini.extend(["[%s]" % name, "value = %d" % aggregates[name], ""])
    write_text(outdir / "aggregates.ini", "\n".join(ini).rstrip("\n") + "\n")
    write_text(outdir / "aggregates.env",
               "\n".join(["%s=%d" % (name.upper(), aggregates[name]) for name in names]) + "\n")
    md = ["| corpus | value |", "| --- | --- |"]
    md += ["| %s | %d |" % (n, aggregates[n]) for n in names]
    write_text(outdir / "aggregates.md", "\n".join(md) + "\n")
    write_text(outdir / "aggregates.txt",
               "\n".join(["%s %d" % (n, aggregates[n]) for n in names]) + "\n")


def build_tool_zip(tool_dir, dest):
    """Rebuild the tool deterministically: ZIP_STORED, fixed epoch and attrs."""
    tool_dir = Path(tool_dir)
    members = []
    for path in sorted(tool_dir.rglob("*")):
        if not path.is_file():
            continue
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        members.append(path)
    members.sort(key=lambda path: path.relative_to(tool_dir).as_posix())
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_STORED) as archive:
        for path in members:
            info = zipfile.ZipInfo(path.relative_to(tool_dir).as_posix(), date_time=ZIP_EPOCH)
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = ZIP_EXTERNAL_ATTR
            archive.writestr(info, path.read_bytes())
    Path(dest).write_bytes(buffer.getvalue())


def command_failures(commands):
    failures = 0
    for entry in commands or []:
        if not isinstance(entry, dict) or "returncode" not in entry:
            raise SystemExit("malformed command transcript")
        if entry["returncode"] != 0:
            failures += 1
    return failures


def load_commands(path):
    if not path:
        return []
    commands = read_json(path)
    if not isinstance(commands, list):
        raise SystemExit("command transcript must be a JSON list")
    return commands


# --------------------------------------------------------------------------
# subcommands
# --------------------------------------------------------------------------

def cmd_init(args):
    data = PolicyData(args.data)
    schema = read_json(args.schema)
    config = data.seed(schema)
    missing = [key for key in required_keys(schema) if key not in config]
    if missing:
        raise SystemExit("schema does not seed: %s" % ",".join(missing))
    if not is_flat(config):
        raise SystemExit("seeded configuration must be flat")
    ensure_parent(args.out)
    write_json(args.out, config)
    return 0


def cmd_set(args):
    data = PolicyData(args.data)
    config = read_json(args.config)
    if not isinstance(config, dict):
        raise SystemExit("configuration must be an object")
    if args.key in data.rules.get("forbidden_keys", []):
        raise SystemExit("forbidden key: %s" % args.key)
    value = args.value
    if args.key in data.rules["bounds"]:
        number = canonical_int(value)
        if number is None or str(number) != value:
            raise SystemExit("value for %s must be a canonical integer: %r" % (args.key, value))
        value = number
    config[args.key] = value
    if not is_flat(config):
        raise SystemExit("configuration must stay flat")
    write_json(args.config, config)
    return 0


def cmd_validate(args):
    schema = read_json(args.schema)
    config = read_json(args.config)
    missing = [key for key in required_keys(schema) if key not in config]
    if missing:
        raise SystemExit("missing: %s" % ",".join(missing))
    if schema.get("scalar_only") and not is_flat(config):
        raise SystemExit("configuration must be flat")
    if args.data:
        forbidden = read_json(Path(args.data) / "validation_rules.json").get("forbidden_keys", [])
        blocked = sorted(key for key in config if key in forbidden)
        if blocked:
            raise SystemExit("forbidden keys: %s" % ",".join(blocked))
    print("ok")
    return 0


def cmd_plan(args):
    data = PolicyData(args.data)
    schema = read_json(args.schema) if args.schema else None
    config = data.resolve(args.env, schema)
    if not is_flat(config):
        raise SystemExit("resolved policy must be flat")
    sys.stdout.write(dump_json(config))
    if args.out:
        ensure_parent(args.out)
        write_json(args.out, config)
    return 0


def cmd_compile(args):
    data = PolicyData(args.data)
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    config_path = Path(args.config) if args.config else outdir / "config.json"
    delivered = read_json(config_path)
    schema = read_json(args.schema) if args.schema else None
    spine = data.resolve("base", schema)

    # the delivered configuration is itself a delivered artifact
    if config_path != outdir / "config.json":
        write_json(outdir / "config.json", delivered)

    # the journal classification drives every corpus bound
    rejected = data.rejected()
    rejected_count = len(rejected)
    write_json(outdir / "rejected_ops.json", {"count": rejected_count, "rejected": rejected})
    shift = (delivered["rekey_interval_s"] % 97) + (rejected_count % 31)

    zones = list(data.rules["zones"])
    zone_set = set(zones)
    aggregates = {}
    corpora_index = []
    zone_totals = dict((zone, 0) for zone in zones)
    for corpus in data.corpora:
        values, per_zone = reduce_corpus(data.dir / corpus["name"], corpus, shift, zone_set)
        value = aggregate(corpus["op"], values)
        aggregates[corpus["name"]] = value
        corpora_index.append({"name": corpus["name"], "format": corpus["format"],
                              "op": corpus["op"], "lo": corpus["lo"], "hi": corpus["hi"],
                              "eligible_rows": len(values), "value": value})
        for zone in zones:
            zone_totals[zone] += per_zone.get(zone, 0)

    write_json(outdir / "aggregates.json", aggregates)
    write_aggregate_mirrors(outdir, aggregates)
    write_json(outdir / "zone_totals.json", zone_totals)
    write_json(outdir / "corpus_index.json",
               {"count": len(corpora_index), "corpora": corpora_index})

    total = sum(aggregates[name] for name in sorted(aggregates))
    max_name = None
    max_value = None
    for name in sorted(aggregates):
        if max_value is None or aggregates[name] > max_value:
            max_name = name
            max_value = aggregates[name]
    nonzero = [name for name in sorted(aggregates) if aggregates[name] != 0]
    write_json(outdir / "posture.json",
               {"aggregate_total": total, "corpus_count": len(aggregates),
                "max_corpus": max_name, "max_value": max_value,
                "nonzero_corpora": len(nonzero)})

    build_tool_zip(Path(__file__).resolve().parent, outdir / "tool.zip")

    for zone in zones:
        profile = data.resolve(zone, schema)
        write_json(outdir / ("profile_%s.json" % zone), profile)

    profiles = ["profile_%s.json" % zone for zone in zones]
    inputs = sorted(path.name for path in data.dir.iterdir() if path.is_file())
    artifacts = delivered_artifacts()
    write_json(outdir / "summary.json",
               {"aggregate_total": total, "artifact_count": len(artifacts),
                "artifacts": artifacts, "corpus_count": len(aggregates),
                "input_count": len(inputs), "inputs": inputs,
                "profile_tag": spine["profile"], "profiles": sorted(profiles),
                "tool": TOOL, "trailer": spine["trailer"]})

    profile_checks = {}
    profile_ok = True
    for zone in zones:
        path = outdir / ("profile_%s.json" % zone)
        observed = read_json(path) if path.is_file() else None
        expected = data.resolve(zone, schema)
        flat = is_flat(observed) if observed is not None else False
        trailer = (observed or {}).get("trailer", expected["trailer"])
        profile_checks[zone] = {"scalar_flat": flat, "trailer": trailer}
        if observed != expected or not flat:
            profile_ok = False
    checks = {
        "all_artifacts_present": all((outdir / name).is_file()
                                     and (outdir / name).stat().st_size > 0
                                     for name in present_artifacts(outdir)),
        "aggregate_total": total,
        "command_failures": command_failures(load_commands(args.commands)),
        "config_matches_policy": delivered == spine,
        "config_scalar_flat": is_flat(delivered),
        "corpus_count": len(aggregates),
        "profiles": profile_checks,
        "rejected_ops": rejected_count,
    }
    ok = (checks["all_artifacts_present"] and profile_ok
          and checks["command_failures"] == 0 and checks["config_matches_policy"]
          and checks["config_scalar_flat"] and len(aggregates) == len(data.corpora)
          and rejected_count == len(rejected))
    write_json(outdir / "validation_report.json", {"checks": checks, "ok": ok})

    lines = ["%s  %s" % (sha256_file(outdir / name), name) for name in manifest_names()]
    write_text(outdir / "manifest.sha256", "\n".join(lines) + "\n")

    print("ok corpora=%d aggregate_total=%d rejected_ops=%d"
          % (len(aggregates), total, rejected_count))
    return 0 if ok else 1


def cmd_export_report(args):
    config_path = Path(args.config)
    config = read_json(config_path)
    digest = sha256_file(config_path)
    if args.digest and args.digest != digest:
        raise SystemExit("digest mismatch: %s != %s" % (args.digest, digest))
    commands = list(load_commands(args.commands))
    argv = [sys.executable, os.path.abspath(sys.argv[0])] + list(sys.argv[1:])
    commands.append({"argv": argv, "returncode": 0, "stdout": ""})
    ensure_parent(args.out)
    write_json(args.out, {"commands": commands, "config_path": str(config_path),
                          "config_sha256": digest, "ok": True, "tool": TOOL,
                          "trailer": config["trailer"]})
    return 0


def required_keys(schema):
    required = schema.get("required_keys", [])
    if isinstance(required, str):
        required = [key.strip() for key in required.split(",") if key.strip()]
    return list(required)


def build_parser():
    parser = argparse.ArgumentParser(prog=TOOL, description="offline security policy compiler")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="seed the flat configuration from the schema")
    p.add_argument("--schema", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--data", default=DEFAULT_DATA)
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("set", help="assign one key to a scalar value")
    p.add_argument("--config", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True)
    p.add_argument("--data", default=DEFAULT_DATA)
    p.set_defaults(func=cmd_set)

    p = sub.add_parser("validate", help="check the required keys and flatness")
    p.add_argument("--schema", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--data", default=None)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("plan", help="print the resolved policy for one environment")
    p.add_argument("--data", default=DEFAULT_DATA)
    p.add_argument("--env", required=True)
    p.add_argument("--schema", default=None)
    p.add_argument("--out", default=None)
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("compile", help="read the corpora and write every derived artifact")
    p.add_argument("--data", default=DEFAULT_DATA)
    p.add_argument("--out", required=True)
    p.add_argument("--config", default=None)
    p.add_argument("--schema", default=None)
    p.add_argument("--commands", default=None)
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("export-report", help="record the command transcript and config digest")
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--digest", default=None)
    p.add_argument("--commands", default=None)
    p.set_defaults(func=cmd_export_report)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    return args.func(args) or 0


if __name__ == "__main__":
    sys.exit(main())
