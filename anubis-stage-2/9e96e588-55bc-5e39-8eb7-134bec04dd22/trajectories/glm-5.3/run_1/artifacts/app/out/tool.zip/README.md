# sealb-ctl

Offline, standard-library-only security policy compiler for the Ironvault
sealing service. It creates, updates, validates, reports, and compiles a flat
JSON security posture. Every value it emits is derived from the files in the
data directory; nothing is invented, nothing is fetched, and no wall-clock
time or randomness is used, so repeated runs are byte-identical.

Subcommands:

```bash
python3 cli.py init --schema schema.json --out config.json
python3 cli.py set --config config.json --key max_sessions --value 100
python3 cli.py validate --schema schema.json --config config.json
python3 cli.py plan --data /app/data --env base
python3 cli.py compile --data /app/data --out /app/out
python3 cli.py export-report --config config.json --out report.json --digest <sha256> --commands <json>
```

- `init` seeds the flat configuration from the schema.
- `set` assigns one key to a scalar value, keeping the configuration flat.
- `validate` checks the required keys and flatness against the tool schema.
- `plan` prints the fully resolved policy document for one environment.
- `compile` reads the evidence corpora and writes every derived artifact.
- `export-report` records the command transcript and the config digest.

The tool schema stores `required_keys` as one comma-separated string; the
sidecar schema in `/app/data` stores the same list as a JSON array. The tool
consumes its own schema.

## Derivation

The spine and the four zone profiles come from the written derivation
contract in `config_contract.md`, seeded from `defaults.json` and
`config_schema.json`, then driven by the recorded operations in
`change_journal.jsonl` replayed strictly in ascending `seq` order. An
operation is applied only when its `env` is listed in `journal_envs`, its
`key` is one of the four integer spine keys or `mode`, and a `set` carries a
JSON integer inside the inclusive `bounds` pair (or a `mode` from
`allowed_modes`). A `set` on an integer key carrying a JSON string of digits
is rejected. A valid `unset` restores the `defaults.json` value for that key,
so a later `unset` clears an earlier `set`; keeping only the last `set` and
ignoring `unset` is wrong.

The fifty evidence corpora are reduced with the published `lo` and the
effective upper bound `hi + (R mod 97) + (J mod 31)`, where `R` is the
finished-spine `rekey_interval_s` and `J` is the rejected-ops count. A row
counts only when its `zone` is byte-exactly an active zone, its `flag` is
byte-exactly `active`, and `str(int(value)) == value` on the raw field
bytes, which rejects leading zeros, a leading `+`, surrounding whitespace,
underscores, hex, floats, units, words, scientific notation, `-0`-style
strings and every non-ASCII decimal digit.

## Serialization

Every JSON artifact is written with
`json.dumps(obj, sort_keys=True, indent=2, separators=(",", ": "),
ensure_ascii=False)` followed by exactly one trailing newline. The tool
archive is rebuilt with `ZIP_STORED`, a fixed epoch, fixed external
attributes and sorted member order, so its sha256 is reproducible across
runs.
