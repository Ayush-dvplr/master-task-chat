"""Stage r06. Replay window construction.

The requested range is start inclusive and end exclusive. The restored
watermark is a processed position, never a position to replay again, so the
window opens at the later of the requested start and the watermark plus one.
It closes one before the requested end or at the last canonical position,
whichever comes first. Neither the watermark position nor the end position is
ever replayed.
"""


def build(start, end, watermark, total):
    requested_start = int(start)
    requested_end = int(end)
    window_start = max(requested_start, int(watermark) + 1)
    window_end = min(requested_end, int(total) + 1)
    last = min(requested_end - 1, int(total))
    positions = list(range(window_start, last + 1))
    return window_start, window_end, positions


def skipped_before(start, watermark):
    """The positions the checkpoint already covers, never less than zero."""
    return max(0, int(watermark) - int(start) + 1)
