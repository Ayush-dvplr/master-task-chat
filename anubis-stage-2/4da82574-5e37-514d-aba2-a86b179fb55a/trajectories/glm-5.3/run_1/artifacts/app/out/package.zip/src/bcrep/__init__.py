"""bcrep: the deterministic custody replay engine.

The package reconstructs the credit state of one observation epoch from an
append only event journal, a sealed checkpoint and the working papers that
govern them, and publishes the epoch as a fixed set of documents.
"""
from pathlib import Path

from . import publish

__all__ = ["run", "publish"]
VERSION = "3.4.0"


def run(data, out):
    """Replay one epoch out of the paper directory and publish it."""
    return publish.publish(Path(data), Path(out))
