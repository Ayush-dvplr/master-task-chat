"""Stage r01. The parameter layers of one epoch.

Three papers are not plain text. The workbook carries the class scales, the
carry quanta and the per revision ceilings on two sheets, one in force and one
superseded. The memo carries the round ceiling and the two quantity limits.
The directive carries the re offer ladder and the two compensation rules.
"""
from . import reading

Q = chr(34)


def _int(text):
    return int(str(text).strip())


def live_sheet(root, header):
    """The sheet in force is the one whose epoch key cell equals the epoch key
    the header names. Sheet name and sheet position settle nothing."""
    sheets = reading.read_xlsx_sheets(root / "custody_parameter_workbook.xlsx")
    wanted = str(header["workbook_epoch_key"]).strip()
    for name in sheets:
        for row in sheets[name]:
            if len(row) >= 2 and str(row[0]).strip() == "epoch_key":
                if str(row[1]).strip() == wanted:
                    return name, sheets[name]
                break
    raise SystemExit("no workbook sheet carries the epoch key in force")


def workbook_layers(rows):
    classes = {}
    ceilings = {}
    for row in rows:
        if not row:
            continue
        tag = str(row[0]).strip()
        if tag == "conversion" and len(row) >= 4:
            cls = str(row[1]).strip()
            classes.setdefault(cls, {})["conversion_num"] = _int(row[2])
            classes[cls]["conversion_den"] = _int(row[3])
        elif tag == "reversal" and len(row) >= 4:
            cls = str(row[1]).strip()
            classes.setdefault(cls, {})["reversal_num"] = _int(row[2])
            classes[cls]["reversal_den"] = _int(row[3])
        elif tag == "carry_quantum" and len(row) >= 3:
            cls = str(row[1]).strip()
            classes.setdefault(cls, {})["carry_quantum"] = _int(row[2])
        elif tag == "ceiling" and len(row) >= 4:
            ceilings[(_int(row[1]), str(row[2]).strip())] = _int(row[3])
    return classes, ceilings


def memo_resolutions(root):
    """A resolution carries the sitting that adopted it. A line that begins
    RESCINDED carries no force at all. Where two live resolutions carry the
    same subject the later sitting governs."""
    held = {}
    for line in reading.read_pdf_lines(root / "custody_board_memo.pdf"):
        text = line.strip()
        if text.startswith("RESCINDED"):
            continue
        if not text.startswith("RESOLUTION "):
            continue
        parts = text.split(" ")
        if len(parts) < 5 or parts[2] != "SITTING":
            continue
        try:
            sitting = int(parts[3])
        except ValueError:
            continue
        body = " ".join(parts[4:])
        name, sep, value = body.partition(" = ")
        if not sep:
            continue
        name = name.strip()
        if name not in held or sitting > held[name][0]:
            held[name] = (sitting, value.strip())
    return {name: held[name][1] for name in held}


def directive_rules(root):
    """The five level ladder, the duplicate target rule and the dependency
    closure rule, read out of the directive in level order."""
    levels = []
    duplicate_rule = ""
    closure_rule = ""
    for block in reading.read_docx_blocks(root / "precedence_directive.docx"):
        if isinstance(block, list) and len(block) >= 3 and block[0] == "level":
            levels.append((_int(block[1]), block[2].strip()))
        elif isinstance(block, str) and block.startswith("DUPLICATE TARGET RULE: "):
            duplicate_rule = block.split(": ", 1)[1].strip()
        elif isinstance(block, str) and block.startswith("DEPENDENCY CLOSURE RULE: "):
            closure_rule = block.split(": ", 1)[1].strip()
    levels.sort()
    return [name for _rank, name in levels], duplicate_rule, closure_rule


def load(root):
    header = reading.read_json(root / "epoch_header.json")
    name, rows = live_sheet(root, header)
    classes, ceilings = workbook_layers(rows)
    memo = memo_resolutions(root)
    levels, duplicate_rule, closure_rule = directive_rules(root)

    units = reading.read_flat_toml(root / "unit_registry.toml").get("units", {})
    units = {k: int(v) for k, v in units.items()}

    policy = reading.read_flat_yaml(root / "eligibility_policy.yaml")
    screen_order = policy["screen_order"]["order"]

    arithmetic = reading.read_flat_yaml(root / "rounding_and_arithmetic_policy.yaml")
    places = int(arithmetic["ratio"]["places"])

    form = reading.read_flat_toml(root / "publication_form_rules.toml")
    core_documents = form["core_digest"]["documents"]

    comp = reading.read_flat_toml(root / "compensation_policy.toml")
    counter_map = dict(comp["reversal_counter_map"])

    conf = reading.read_conf(root / "reporting_station_roster.conf")
    regions = {k: int(v) for k, v in conf.get("region_rank", {}).items()}

    modules = []
    expectations = root / "package_expectations.toml"
    if expectations.is_file():
        held = reading.read_flat_toml(expectations)
        modules = list(held.get("modules", {}).get("names", []))

    return {
        "header": header,
        "live_sheet": name,
        "classes": classes,
        "ceilings": ceilings,
        "round_ceiling": int(memo["revalidation round ceiling"]),
        "implausible_ceiling": int(memo["implausible quantity ceiling cu"]),
        "settlement_floor": int(memo["settlement floor cu"]),
        "levels": levels,
        "duplicate_rule": duplicate_rule,
        "closure_rule": closure_rule,
        "units": units,
        "screen_order": screen_order,
        "ratio_places": places,
        "core_documents": core_documents,
        "counter_map": counter_map,
        "regions": regions,
        "modules": [str(m) for m in modules],
    }
