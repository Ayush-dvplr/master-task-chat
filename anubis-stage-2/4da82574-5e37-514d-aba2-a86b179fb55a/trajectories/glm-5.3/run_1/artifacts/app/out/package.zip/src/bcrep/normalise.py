"""Stages r01 and r02. Registers, aliases, quantities and exact arithmetic."""
from fractions import Fraction

from . import reading

TAB = chr(9)


def _int(text):
    return int(str(text).strip())


def half_up(value):
    """Nearest integer, halves away from zero, on an exact rational."""
    f = Fraction(value)
    n, d = f.numerator, f.denominator
    if d == 1:
        return n
    if n >= 0:
        return (2 * n + d) // (2 * d)
    return -((2 * (-n) + d) // (2 * d))


def ratio_text(value, places):
    scale = 10 ** places
    scaled = half_up(Fraction(value) * scale)
    sign = "-" if scaled < 0 else ""
    scaled = abs(scaled)
    whole, frac = divmod(scaled, scale)
    text = sign + str(whole) + "." + str(frac).rjust(places, "0")
    if text == "-0." + "0" * places:
        text = "0." + "0" * places
    return text


def safe_ratio(num, den, places):
    if den == 0:
        return ratio_text(0, places)
    return ratio_text(Fraction(int(num), int(den)), places)


def latest_by(rows, key, revision_field, frozen):
    """One row per key: the greatest revision at or below the frozen register
    revision. A row above that revision is a draft and governs nothing."""
    out = {}
    for row in rows:
        if _int(row[revision_field]) > frozen:
            continue
        name = row[key].strip()
        prior = out.get(name)
        if prior is None or _int(row[revision_field]) >= _int(prior[revision_field]):
            out[name] = row
    return out


def load_registers(root, frozen):
    """The frozen station register governs; the current register carries later
    lodges of the same keys and governs nothing here."""
    station_rows = reading.read_delim(root / "station_register_frozen.csv")
    stations = latest_by(station_rows, "station", "revision", frozen)
    programmes = latest_by(reading.read_delim(root / "programme_register.csv"),
                           "programme", "revision", frozen)
    rows_by_station = {}
    for row in station_rows:
        if _int(row["revision"]) > frozen:
            continue
        rows_by_station.setdefault(row["station"].strip(), []).append(row)
    alias = {}
    for row in reading.read_delim(root / "alias_crosswalk.tsv", TAB):
        if _int(row["in_force_from_revision"]) > frozen:
            continue
        key = (row["kind"].strip(), row["alias"].strip())
        prior = alias.get(key)
        if prior is None or _int(row["in_force_from_revision"]) >= _int(
                prior["in_force_from_revision"]):
            alias[key] = row
    scope = {}
    for node in reading.read_xml_rows(root / "topology_and_scope.xml", "station"):
        if _int(node["revision"]) > frozen:
            continue
        held = scope.get(node["id"].strip())
        if held is None or _int(node["revision"]) >= _int(held["revision"]):
            scope[node["id"].strip()] = node
    return stations, programmes, alias, scope, rows_by_station


def class_at_revision(rows_by_station, station, revision, frozen):
    """The class the frozen station register carried for a station at a
    revision: the register row with the greatest revision at or below it.
    Where the register carries no row for the station that early, the class in
    force at the frozen register revision is used."""
    best = None
    for row in rows_by_station.get(str(station).strip(), []):
        rev = _int(row["revision"])
        if rev > revision:
            continue
        if best is None or rev >= _int(best["revision"]):
            best = row
    if best is not None:
        return str(best["class"]).strip()
    return None


def resolve_alias(alias, kind, name):
    row = alias.get((kind, str(name).strip()))
    if row is None:
        return str(name).strip()
    return row["canonical"].strip()


def normalise_quantity(rec, params, stations):
    """The recorded quantity is carried into credit units through the unit
    registry and the class conversion factor, in exact rational arithmetic,
    and rounded once here. A record whose quantity is absent normalises to
    nothing at all."""
    station = stations.get(str(rec["station"]).strip())
    if station is None:
        return None, None
    cls = str(station["class"]).strip()
    factors = params["classes"].get(cls)
    if factors is None:
        return None, cls
    if rec.get("quantity") is None:
        return None, cls
    scale = params["units"].get(str(rec.get("unit")).strip())
    if scale is None:
        return None, cls
    value = (Fraction(int(rec["quantity"]) * scale)
             * Fraction(factors["conversion_num"], factors["conversion_den"]))
    return half_up(value), cls
