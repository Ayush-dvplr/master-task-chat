"""Stages r01, r08 and r12. Screening, ordinary transitions and the closed
predicate vocabulary read against the state as it stands immediately before
the event is offered."""
from . import derived, normalise, reading


def _int(text):
    return int(str(text).strip())


def load_predicates(root, frozen):
    """One row per form: the greatest revision at or below the frozen register
    revision. A form the register in force does not carry as active is false
    whenever it is read."""
    best = {}
    for row in reading.read_delim(root / "eligibility_predicates.csv"):
        if _int(row["revision"]) > frozen:
            continue
        key = row["predicate_id"].strip()
        prior = best.get(key)
        if prior is None or _int(row["revision"]) >= _int(prior["revision"]):
            best[key] = row
    return best


def predicate_holds(text, state, stations, forms=None):
    """The closed predicate vocabulary. A predicate writes its form and then
    its arguments, separated by colons, in the order the form in force lists
    them. Arguments are read as written; the crosswalk is not applied to them.
    A form the register in force does not carry as active, and a predicate
    whose argument count disagrees with its form, is false whenever it is
    read. Where no register is offered at all the plain reading of the closed
    vocabulary applies."""
    if text is None or str(text).strip() == "":
        return True
    parts = [part.strip() for part in str(text).split(":")]
    head = parts[0]
    if forms is None:
        return _plain_predicate(head, parts, state, stations)
    row = forms.get(head)
    if row is None:
        return False
    order = [name.strip() for name in str(row["form"]).split(":")[1:]]
    if (str(row["status"]).strip() != "active"
            or len(parts) - 1 != _int(row["argument_count"])
            or len(parts) - 1 != len(order)):
        return False
    args = dict(zip(order, parts[1:]))
    if head == "balance_at_least":
        return state["balances"].get(args["station"], 0) >= _int(args["amount_cu"])
    if head == "allotment_below":
        inner = state["allotments"].get(args["station"], {})
        return inner.get(args["programme"], 0) < _int(args["amount_cu"])
    if head == "counter_at_least":
        return state["counters"].get(args["counter"], 0) >= _int(args["amount"])
    if head == "no_pending":
        return not state["pending"]
    if head == "station_active":
        row = stations.get(args["station"])
        return row is not None and str(row["status"]).strip() == "active"
    return False


def _plain_predicate(head, parts, state, stations):
    """The plain reading of a form the predicate register carries no in force
    row for. A form the register does not carry at all is false whenever it is
    read, so is one whose argument count disagrees with its form."""
    plain = {
        "balance_at_least": 2,
        "allotment_below": 3,
        "counter_at_least": 2,
        "no_pending": 0,
        "station_active": 1,
    }
    if head not in plain or len(parts) - 1 != plain[head]:
        return False
    if head == "balance_at_least":
        return state["balances"].get(parts[1], 0) >= _int(parts[2])
    if head == "allotment_below":
        inner = state["allotments"].get(parts[1], {})
        return inner.get(parts[2], 0) < _int(parts[3])
    if head == "counter_at_least":
        return state["counters"].get(parts[1], 0) >= _int(parts[2])
    if head == "no_pending":
        return not state["pending"]
    row = stations.get(parts[1])
    return row is not None and str(row["status"]).strip() == "active"


def admissible(ctx, state, rec):
    """A compensating event is never deferred, so a requires field it carries
    is not read."""
    if str(rec["kind"]).strip() == "compensate":
        return True
    return predicate_holds(rec.get("requires"), state, ctx["stations"],
                           ctx["forms"])


def apply_transition(ctx, state, rec, log, order):
    eid = rec["event_id"]
    quantity = ctx["norm"][eid]
    station = str(rec["station"]).strip()
    programme = str(rec["programme"]).strip()
    touched = {station}
    kind = str(rec["kind"]).strip()
    if kind == "grant":
        derived.move(state, station, programme, quantity)
        state["counters"]["grants"] += 1
        state["counters"]["granted_cu"] += quantity
    elif kind == "retire":
        derived.move(state, station, programme, -quantity)
        state["counters"]["retires"] += 1
        state["counters"]["retired_cu"] += quantity
    else:
        other = str(rec["counterparty"]).strip()
        derived.move(state, station, programme, -quantity)
        derived.move(state, other, programme, quantity)
        touched.add(other)
        state["counters"]["transfers"] += 1
        state["counters"]["transferred_cu"] += quantity
    derived.settle(state, ctx, touched)
    state["applied"].append(eid)
    log.append({"order": order[0], "event_id": eid,
                "position": int(rec["position"]), "kind": kind,
                "station": station, "programme": programme,
                "quantity_cu": quantity,
                "balance_after": state["balances"].get(station, 0)})
    order[0] += 1


def screen(ctx, rec):
    """Stage r01 and r09 screening. The order the policy paper puts the tests
    in decides which code a record that fails two tests carries. The dependency
    tests sit last in that order and are settled after them."""
    checks = {
        "EVT-DRAFTREVISION": lambda: bool(rec["draft"]),
        "EVT-WITHDRAWN": lambda: bool(rec["withdrawn"]),
        "EVT-UNKNOWNSTATION": lambda: _station_unknown(ctx, rec),
        "EVT-UNKNOWNPROGRAMME": lambda: _programme_unknown(ctx, rec),
        "EVT-NONPOSITIVE": lambda: _nonpositive(ctx, rec),
        "EVT-IMPLAUSIBLE": lambda: _implausible(ctx, rec),
        "CMP-WITHDRAWN": lambda: _link_absent(ctx, rec),
        "CMP-NOTARGET": lambda: _target_absent(ctx, rec),
    }
    for code in ctx["params"]["screen_order"]:
        test = checks.get(code)
        if test is not None and test():
            return code
    return None


def _station_unknown(ctx, rec):
    if str(rec["station"]).strip() not in ctx["stations"]:
        return True
    if str(rec["kind"]).strip() == "transfer":
        other = str(rec.get("counterparty") or "").strip()
        return other == "" or other not in ctx["stations"]
    return False


def _programme_unknown(ctx, rec):
    if str(rec["kind"]).strip() == "compensate":
        return False
    return str(rec["programme"]).strip() not in ctx["programmes"]


def _nonpositive(ctx, rec):
    if str(rec["kind"]).strip() == "compensate":
        return False
    quantity = ctx["norm"].get(rec["event_id"])
    return quantity is None or quantity <= 0


def _implausible(ctx, rec):
    if str(rec["kind"]).strip() == "compensate":
        return False
    quantity = ctx["norm"].get(rec["event_id"])
    if quantity is None:
        return False
    return quantity > ctx["params"]["implausible_ceiling"]


def _link_absent(ctx, rec):
    if str(rec["kind"]).strip() != "compensate":
        return False
    link = ctx["links"].get(rec["event_id"])
    return link is None or link["status"].strip() != "registered"


def _target_absent(ctx, rec):
    if str(rec["kind"]).strip() != "compensate":
        return False
    link = ctx["links"].get(rec["event_id"])
    if link is None:
        return False
    return link["target_event_id"].strip() not in ctx["by_id"]
