"""Command line entry point.

    python3 -m bcrep --data <papers> --out <destination>

The two options are accepted in either order. The destination is created when
it is absent. The paper directory is only read.
"""
import sys
from pathlib import Path

from . import run


def parse(argv):
    data = None
    out = None
    index = 0
    while index < len(argv):
        token = argv[index]
        if token == "--data" and index + 1 < len(argv):
            data = argv[index + 1]
            index += 2
            continue
        if token == "--out" and index + 1 < len(argv):
            out = argv[index + 1]
            index += 2
            continue
        raise SystemExit("usage: python3 -m bcrep --data DIR --out DIR")
    if data is None or out is None:
        raise SystemExit("usage: python3 -m bcrep --data DIR --out DIR")
    return Path(data), Path(out)


def main(argv):
    data, out = parse(argv)
    out.mkdir(parents=True, exist_ok=True)
    run(data, out)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
