"""Stage r03. Merge, screen and place the lodged records in canonical order.

Arrival order, file order and json key order settle nothing. The canonical
order is sequence, then stamp, then the kind rank in force, then the tie break
key, and the event identifier settles a full tie.
"""
from . import normalise, reading

TAB = chr(9)
RESERVED_PREFIX = "EVT-8"


def _int(text):
    return int(str(text).strip())


def source_priority(root, frozen):
    out = {}
    for row in reading.read_delim(root / "source_priority_register.csv"):
        if _int(row["revision"]) > frozen:
            continue
        name = row["source"].strip()
        prior = out.get(name)
        if prior is None or _int(row["revision"]) >= prior[0]:
            out[name] = (_int(row["revision"]), _int(row["priority"]))
    return {k: v[1] for k, v in out.items()}


def provenance_sources(root):
    out = {}
    for row in reading.read_delim(root / "row_provenance_ledger.csv"):
        out.setdefault(row["record_id"].strip(), {})[
            row["file"].strip()] = row["source"].strip()
    return out


def kind_ranks(root, frozen):
    out = {}
    for row in reading.read_delim(root / "event_kind_ranks.csv"):
        if _int(row["revision"]) > frozen:
            continue
        name = row["kind"].strip()
        prior = out.get(name)
        if prior is None or _int(row["revision"]) >= prior[0]:
            out[name] = (_int(row["revision"]), _int(row["rank"]))
    return {k: v[1] for k, v in out.items()}


def withdrawn_ids(root, frozen):
    out = set()
    for row in reading.read_delim(root / "withdrawn_event_journal.tsv", TAB):
        if _int(row["withdrawn_at_revision"]) <= frozen:
            out.add(row["event_id"].strip())
    return out


def load_events(root, frozen, alias):
    """One record survives per event identifier: the one whose lodging source
    carries the greater priority, and among records of one source the greater
    revision. A record that carries no source takes the source the provenance
    ledger names for it. An event is its identifier, so two identifiers are two
    events however alike their payloads look."""
    priority = source_priority(root, frozen)
    provenance = provenance_sources(root)
    ranks = kind_ranks(root, frozen)
    withdrawn = withdrawn_ids(root, frozen)

    raw = []
    for name in ("event_journal.jsonl", "event_supplement.ndjson"):
        for rec in reading.read_jsonl(root / name):
            if name == "event_supplement.ndjson" and str(
                    rec.get("event_id")).strip().startswith(RESERVED_PREFIX):
                continue
            rec = dict(rec)
            rec["lodged_in"] = name
            raw.append(rec)

    merged = {}
    for rec in raw:
        eid = str(rec["event_id"]).strip()
        source = str(rec.get("source") or "").strip()
        if not source:
            source = provenance.get(eid, {}).get(rec["lodged_in"], "")
        rec["lodging_source"] = source
        rank = (priority.get(source, 0), int(rec["revision"]))
        prior = merged.get(eid)
        if prior is None or rank > prior[0]:
            merged[eid] = (rank, rec)

    events = []
    for eid in merged:
        rec = dict(merged[eid][1])
        rec["event_id"] = eid
        rec["withdrawn"] = eid in withdrawn
        rec["draft"] = int(rec["revision"]) > frozen
        rec["station"] = normalise.resolve_alias(alias, "station",
                                                 rec.get("station"))
        rec["programme"] = normalise.resolve_alias(alias, "programme",
                                                   rec.get("programme"))
        if rec.get("counterparty"):
            rec["counterparty"] = normalise.resolve_alias(
                alias, "station", rec["counterparty"])
        rec["rank"] = ranks.get(str(rec["kind"]).strip(), 99)
        events.append(rec)

    events.sort(key=canonical_key)
    for position, rec in enumerate(events, start=1):
        rec["position"] = position
    return events


def canonical_key(rec):
    """Sequence, then stamp, then the kind rank in force, then the tie break
    key as text, then the event identifier as text."""
    return (int(rec["sequence"]), int(rec["stamp"]), int(rec["rank"]),
            str(rec.get("tiebreak") or ""), str(rec["event_id"]))
