"""Stages r05 to r12. One forward pass over the window, then the re offer
rounds.

An event whose eligibility predicate is false when it is first offered is not
discarded and is not quarantined. It waits in the pending queue and is offered
again after the window is exhausted, because a compensating event later in the
window can change the state its predicate reads. Each round offers the queue in
the order the precedence directive's ladder gives, never in queue order, and a
round that admits nothing ends the run. A run that reaches the round ceiling
in the board memo while its last round was still admitting stops there and has
not settled.
"""
from . import checkpointing, compensation, depends, derived, normalise
from . import ordering, params, transitions

STAGE_IDS = ["r01", "r02", "r03", "r04", "r05", "r06", "r07",
             "r08", "r09", "r10", "r11", "r12", "r13", "r14"]


def build_context(root):
    settings = params.load(root)
    frozen = int(settings["header"]["frozen_register_revision"])
    stations, programmes, alias, scope, rows_by_station = (
        normalise.load_registers(root, frozen))
    events = ordering.load_events(root, frozen, alias)
    edges = depends.load_edges(root, frozen)
    links = compensation.load_links(root, frozen)
    forms = transitions.load_predicates(root, frozen)
    by_id = {rec["event_id"]: rec for rec in events}
    norm = {}
    cls_at = {}
    for rec in events:
        quantity, _klass = normalise.normalise_quantity(rec, settings, stations)
        norm[rec["event_id"]] = quantity
        klass = normalise.class_at_revision(rows_by_station, rec["station"],
                                             int(rec["revision"]), frozen)
        if klass is None:
            row = stations.get(str(rec["station"]).strip())
            klass = str(row["class"]).strip() if row is not None else None
        cls_at[rec["event_id"]] = klass
    return {
        "root": root, "params": settings, "frozen": frozen,
        "stations": stations, "programmes": programmes, "alias": alias,
        "scope": scope, "events": events, "by_id": by_id, "edges": edges,
        "links": links, "forms": forms, "norm": norm, "cls_at": cls_at,
        "cycles": depends.cycle_members(events, edges, by_id),
    }


def stage_of(reason):
    table = {"EVT-DRAFTREVISION": "r01", "EVT-WITHDRAWN": "r01",
             "EVT-UNKNOWNSTATION": "r02", "EVT-UNKNOWNPROGRAMME": "r02",
             "EVT-NONPOSITIVE": "r01", "EVT-IMPLAUSIBLE": "r01",
             "CMP-WITHDRAWN": "r09", "CMP-NOTARGET": "r09",
             "DEP-SELF": "r07", "DEP-CYCLE": "r07", "DEP-MISSING": "r07"}
    return table[reason]


def ladder_key(ctx, rec):
    """The directive ladder: scope rank with mandatory before standard, then
    region rank on the reporting roster, then normalised quantity ascending,
    then canonical position ascending, then the event identifier."""
    regions = ctx["params"]["regions"]
    station = str(rec["station"]).strip()
    row = ctx["stations"].get(station)
    region = str(row["region"]).strip() if row is not None else ""
    quantity = ctx["norm"].get(rec["event_id"])
    if quantity is None:
        quantity = 0
    scope = str(rec.get("scope") or "").strip()
    return (0 if scope == "mandatory" else 1, regions.get(region, len(regions)),
            int(quantity), int(rec["position"]), str(rec["event_id"]))


def run(ctx, start, end, body=None, run_rounds=True):
    events = ctx["events"]
    total = len(events)
    if body is None:
        state = derived.new_state()
        watermark = 0
    else:
        state = derived.restore(body)
        watermark = int(body["position"])

    from . import window as window_mod
    window_start, window_end, positions = window_mod.build(
        start, end, watermark, total)

    quarantine = []
    deferred = []
    log = []
    register = []
    closure = {"checkpoint": 0, "window": 0}
    unsatisfied = []
    order = [1]

    for p in positions:
        rec = events[p - 1]
        reason = transitions.screen(ctx, rec)
        if reason is None:
            reason, sources = depends.dependency_reason(ctx, rec, window_start,
                                                        window_end)
            if reason is None:
                for _dep, where in sources:
                    closure[where] += 1
        if reason is not None:
            quarantine.append({"event_id": rec["event_id"], "position": p,
                               "stage": stage_of(reason),
                               "reason_code": reason,
                               "detail": str(rec["kind"])})
            if reason.startswith("DEP-"):
                unsatisfied.append({"event_id": rec["event_id"],
                                    "reason": reason})
            continue
        if str(rec["kind"]).strip() == "compensate":
            compensation.apply_compensation(ctx, state, rec, register, order)
            continue
        if transitions.admissible(ctx, state, rec):
            transitions.apply_transition(ctx, state, rec, log, order)
        else:
            state["pending"].append(rec["event_id"])
            deferred.append(rec["event_id"])

    rounds = []
    stable = True
    if run_rounds:
        ceiling = int(ctx["params"]["round_ceiling"])
        stable = False
        index = 0
        while index < ceiling:
            index += 1
            queue = sorted(state["pending"],
                           key=lambda eid: ladder_key(ctx, ctx["by_id"][eid]))
            admitted = []
            for eid in queue:
                rec = ctx["by_id"][eid]
                if transitions.admissible(ctx, state, rec):
                    state["pending"].remove(eid)
                    transitions.apply_transition(ctx, state, rec, log, order)
                    state["counters"]["deferred_admitted"] += 1
                    admitted.append(eid)
            if not admitted:
                stable = True
                break
            rounds.append({"round": index, "admitted": admitted,
                           "admitted_count": len(admitted)})

    return {"state": state, "watermark": watermark,
            "window_start": window_start, "window_end": window_end,
            "positions": positions, "quarantine": quarantine,
            "deferred": deferred, "log": log, "register": register,
            "closure": closure, "unsatisfied": unsatisfied,
            "rounds": rounds, "stable": stable}


def select_checkpoint(ctx, end):
    return checkpointing.select(ctx, end)
