"""Stage r07. Dependency closure across the checkpoint and the window.

The pipe file is the authoritative edge set. The depends_on list inside a
journal record is a convenience copy carried over from an earlier revision and
governs nothing. An event that names itself carries DEP-SELF, and an event on
a cycle carries DEP-CYCLE; both are tested before any other dependency test.
"""
from . import reading

PIPE = chr(124)


def _int(text):
    return int(str(text).strip())


def load_edges(root, frozen):
    """Only requires edges at a revision in force are edges."""
    edges = {}
    for row in reading.read_delim(root / "dependency_edges.psv", PIPE):
        if _int(row["revision"]) > frozen:
            continue
        if row["edge_kind"].strip() != "requires":
            continue
        key = row["event_id"].strip()
        edges.setdefault(key, [])
        target = row["depends_on"].strip()
        if target and target not in edges[key]:
            edges[key].append(target)
    for key in edges:
        edges[key].sort()
    return edges


def cycle_members(events, edges, by_id):
    """Every event that sits on a cycle in the edge graph, however long the
    path and wherever a walk that finds it begins. An edge naming an
    identifier the canonical history does not carry takes no part in the cycle
    test, and a self edge is a cycle of one."""
    nodes = [rec["event_id"] for rec in events]
    live = {}
    for node in nodes:
        live[node] = [nxt for nxt in edges.get(node, []) if nxt in by_id]
    index = {}
    low = {}
    on_stack = {}
    stack = []
    found = set()
    counter = [0]

    for root_node in nodes:
        if root_node in index:
            continue
        work = [(root_node, 0)]
        while work:
            node, at = work[-1]
            if at == 0:
                counter[0] += 1
                index[node] = counter[0]
                low[node] = counter[0]
                stack.append(node)
                on_stack[node] = True
            advance = False
            children = live.get(node, [])
            while at < len(children):
                nxt = children[at]
                at += 1
                if nxt not in index:
                    work[-1] = (node, at)
                    work.append((nxt, 0))
                    advance = True
                    break
                if on_stack.get(nxt):
                    low[node] = min(low[node], index[nxt])
            if advance:
                continue
            work.pop()
            if work:
                parent = work[-1][0]
                low[parent] = min(low[parent], low[node])
            if low[node] == index[node]:
                group = []
                while True:
                    member = stack.pop()
                    on_stack[member] = False
                    group.append(member)
                    if member == node:
                        break
                if len(group) > 1:
                    found.update(group)
    for node in nodes:
        if node in live.get(node, []):
            found.add(node)
    return found


def dependency_reason(ctx, rec, window_start, window_end):
    """A dependency whose position stands before the window opening is already
    folded into the restored checkpoint and is satisfied without being
    replayed. A dependency that stands at or after the window opening and
    before the depending event is satisfied inside the window. Anything else,
    including a dependency naming an identifier that is not in the canonical
    history and a dependency standing later than the depending event, leaves
    the event with DEP-MISSING."""
    eid = rec["event_id"]
    deps = ctx["edges"].get(eid, [])
    sources = []
    for dep in deps:
        if dep == eid:
            return "DEP-SELF", sources
    if eid in ctx["cycles"]:
        return "DEP-CYCLE", sources
    for dep in deps:
        target = ctx["by_id"].get(dep)
        if target is None:
            return "DEP-MISSING", sources
        pos = int(target["position"])
        if pos < window_start:
            sources.append((dep, "checkpoint"))
        elif pos < int(rec["position"]):
            sources.append((dep, "window"))
        else:
            return "DEP-MISSING", sources
    return None, sources
