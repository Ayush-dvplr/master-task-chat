"""The suite the package shipped with.

It exercises the shapes the engine works in, not the epoch it publishes, so it
passes exactly as it shipped. Where the engine departs from the working papers
the suite is silent, which tells a reader where the faults are absent rather
than where they are.
"""
import unittest
from fractions import Fraction

from bcrep import derived, normalise, transitions, window


class TestArithmetic(unittest.TestCase):
    def test_half_up_positive(self):
        self.assertEqual(normalise.half_up(Fraction(5, 2)), 3)

    def test_half_up_negative(self):
        self.assertEqual(normalise.half_up(Fraction(-5, 2)), -3)

    def test_half_up_whole(self):
        self.assertEqual(normalise.half_up(Fraction(7, 1)), 7)

    def test_ratio_places(self):
        self.assertEqual(normalise.ratio_text(Fraction(1, 4), 12),
                         "0.250000000000")

    def test_ratio_no_negative_zero(self):
        self.assertEqual(normalise.ratio_text(Fraction(0, 5), 12),
                         "0.000000000000")

    def test_safe_ratio_zero_denominator(self):
        self.assertEqual(normalise.safe_ratio(3, 0, 12), "0.000000000000")


class TestState(unittest.TestCase):
    def test_new_state_counters(self):
        state = derived.new_state()
        self.assertEqual(sorted(state["counters"]), derived.COUNTER_NAMES)

    def test_move_creates_nested_entry(self):
        state = derived.new_state()
        derived.move(state, "ST-0001", "PGM-0001", 40)
        self.assertEqual(state["allotments"]["ST-0001"]["PGM-0001"], 40)

    def test_state_body_drops_zero_rows(self):
        state = derived.new_state()
        derived.move(state, "ST-0001", "PGM-0001", 0)
        body = derived.state_body(state, 3)
        self.assertEqual(body["balances"], {})
        self.assertEqual(body["allotments"], {})

    def test_restore_carries_every_field(self):
        body = {"position": 4, "balances": {"ST-0001": 5},
                "allotments": {"ST-0001": {"PGM-0001": 5}},
                "counters": {k: 0 for k in derived.COUNTER_NAMES},
                "pending": ["EVT-000009"], "applied": ["EVT-000004"],
                "reversed": []}
        state = derived.restore(body)
        self.assertEqual(state["pending"], ["EVT-000009"])
        self.assertEqual(state["applied"], ["EVT-000004"])
        self.assertEqual(state["balances"]["ST-0001"], 5)

    def test_state_digest_is_stable(self):
        body = {"position": 1, "balances": {}, "allotments": {},
                "counters": {k: 0 for k in derived.COUNTER_NAMES},
                "pending": [], "applied": [], "reversed": []}
        self.assertEqual(derived.state_digest(body), derived.state_digest(body))


class TestPredicates(unittest.TestCase):
    def setUp(self):
        self.state = derived.new_state()
        self.state["balances"]["ST-0001"] = 700
        self.state["counters"]["grants"] = 6
        self.stations = {"ST-0001": {"status": "active", "class": "AX",
                                     "region": "R-ALPHA"}}

    def test_empty_predicate_holds(self):
        self.assertTrue(transitions.predicate_holds(None, self.state,
                                                    self.stations))

    def test_balance_predicate(self):
        self.assertTrue(transitions.predicate_holds(
            "balance_at_least:ST-0001:700", self.state, self.stations))
        self.assertFalse(transitions.predicate_holds(
            "balance_at_least:ST-0001:701", self.state, self.stations))

    def test_counter_predicate(self):
        self.assertTrue(transitions.predicate_holds(
            "counter_at_least:grants:6", self.state, self.stations))

    def test_unknown_form_is_false(self):
        self.assertFalse(transitions.predicate_holds(
            "hub_open:H-01", self.state, self.stations))


class TestWindow(unittest.TestCase):
    def test_window_reports_the_requested_range(self):
        start, end, _positions = window.build(1, 5, 0, 20)
        self.assertEqual((start, end), (1, 5))

    def test_window_clamps_to_history(self):
        _s, _e, positions = window.build(1, 50, 0, 3)
        self.assertEqual(positions, [1, 2, 3])

    def test_skipped_before_watermark(self):
        self.assertEqual(window.skipped_before(1, 9), 9)


if __name__ == "__main__":
    unittest.main()
