"""Stages r04 and r05. Checkpoint selection and restoration.

A checkpoint that carries watermark N is the state after the event at
canonical position N was processed. Position N is therefore behind the
engine, and the first candidate the window can replay is position N plus one.
"""
from . import derived, reading


def _int(text):
    return int(str(text).strip())


def bodies(root):
    out = {}
    for rec in reading.read_jsonl(root / "checkpoint_states.jsonl"):
        out[str(rec["checkpoint_id"]).strip()] = rec
    return out


def _ledger_past_watermark(body, positions):
    """Every identifier in the applied ledger has to stand at or before the
    body position in the canonical order. An identifier the canonical history
    does not carry stands at no position and fails the test."""
    at = int(body["position"])
    for eid in body["applied"]:
        held = positions.get(str(eid).strip())
        if held is None or held > at:
            return True
    return False


def select(ctx, end):
    """Usable means lodged at or below the frozen revision, sealed, present,
    digest matching, carrying no applied identifier past its own watermark,
    and standing strictly before the requested end boundary. The greatest
    usable position wins."""
    root = ctx["root"]
    held = bodies(root)
    positions = {rec["event_id"]: int(rec["position"]) for rec in ctx["events"]}
    usable = []
    rejected = []
    for row in reading.read_delim(root / "checkpoint_register.csv"):
        cid = row["checkpoint_id"].strip()
        if _int(row["revision"]) > ctx["frozen"]:
            rejected.append({"checkpoint_id": cid, "reason": "draft_revision"})
            continue
        if row["status"].strip() != "sealed":
            rejected.append({"checkpoint_id": cid, "reason": "not_sealed"})
            continue
        body = held.get(cid)
        if body is None:
            rejected.append({"checkpoint_id": cid, "reason": "body_missing"})
            continue
        if derived.state_digest(body) != row["state_digest"].strip():
            rejected.append({"checkpoint_id": cid, "reason": "digest_mismatch"})
            continue
        if _ledger_past_watermark(body, positions):
            rejected.append({"checkpoint_id": cid,
                             "reason": "ledger_past_watermark"})
            continue
        if int(body["position"]) >= int(end):
            rejected.append({"checkpoint_id": cid,
                             "reason": "position_at_or_after_end"})
            continue
        usable.append((int(body["position"]), cid, body, row))
    usable.sort(key=lambda item: (item[0], item[1]))
    rejected.sort(key=lambda r: (r["checkpoint_id"], r["reason"]))
    if not usable:
        return None, [], rejected
    return usable[-1], [c for _p, c, _b, _r in usable], rejected
