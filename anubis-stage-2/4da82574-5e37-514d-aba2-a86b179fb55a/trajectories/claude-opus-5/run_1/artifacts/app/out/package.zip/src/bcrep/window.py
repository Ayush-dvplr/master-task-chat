"""Stage r06. Replay window construction.

The requested range is start inclusive and end exclusive. The restored
watermark is a processed position, never a position to replay again, so the
window opens at the later of the requested start and the watermark plus one.
"""


def build(start, end, watermark, total):
    window_start = max(int(start), int(watermark) + 1)
    window_end = int(end)
    last = min(window_end - 1, int(total))
    positions = list(range(window_start, last + 1))
    return window_start, window_end, positions


def skipped_before(start, watermark):
    return max(0, int(watermark) - int(start) + 1)
