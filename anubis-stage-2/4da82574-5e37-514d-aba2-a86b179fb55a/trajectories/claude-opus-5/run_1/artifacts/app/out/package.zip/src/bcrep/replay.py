"""Stages r05 to r12. One forward pass over the window, then the re offer
rounds.

An event whose eligibility predicate is false when it is first offered is not
discarded. It waits in the pending queue and is offered again after the window
is exhausted, because a compensating event later in the window can change the
state the predicate reads. The rounds run until a round admits nothing or the
round ceiling in the board memo is reached.
"""
from . import checkpointing, compensation, depends, derived, normalise
from . import ordering, params, reading, transitions

PIPE = chr(124)


def build_context(root):
    settings = params.load(root)
    frozen = settings["frozen"]
    registers = normalise.load_registers(root, frozen)
    stations, programmes, alias, scope, station_history = registers
    events = ordering.load_events(root, frozen, alias,
                                  settings["reserved_prefix"])
    edges = depends.load_edges(root, frozen)
    links = compensation.load_links(root, frozen)
    by_id = {rec["event_id"]: rec for rec in events}
    norm = {}
    cls = {}
    for rec in events:
        quantity, klass = normalise.normalise_quantity(rec, settings, stations)
        norm[rec["event_id"]] = quantity
        cls[rec["event_id"]] = klass
    return {
        "root": root, "params": settings, "frozen": frozen,
        "stations": stations, "programmes": programmes, "alias": alias,
        "scope": scope, "station_history": station_history,
        "events": events, "by_id": by_id, "edges": edges,
        "links": links, "norm": norm, "cls": cls,
        "stages": stage_table(root, settings["frozen"]),
        "cycles": depends.cycle_members(events, edges, by_id),
    }


def stage_table(root, frozen):
    """The stage each reason code sits in, out of the reason code catalogue
    filtered to the rows in force."""
    out = {}
    for row in reading.read_delim(root / "quarantine_reason_catalogue.psv",
                                  PIPE):
        if int(str(row["revision"]).strip()) > frozen:
            continue
        out[row["code"].strip()] = row["stage"].strip()
    return out


def ladder_key(ctx, eid):
    """The five level re offer ladder the precedence directive gives: scope
    rank with mandatory before standard, then the region rank the reporting
    roster gives the region the frozen register carries for the station, then
    the normalised quantity ascending, then the canonical position, then the
    identifier."""
    rec = ctx["by_id"][eid]
    scope = str(rec.get("scope") or "").strip()
    scope_rank = (0, "") if scope == "mandatory" else (
        (1, "") if scope == "standard" else (2, scope))
    row = ctx["stations"].get(str(rec["station"]).strip())
    region = "" if row is None else str(row["region"]).strip()
    ranks = ctx["params"]["regions"]
    region_rank = ranks.get(region, len(ranks) + 1)
    quantity = ctx["norm"].get(eid)
    return (scope_rank, region_rank, 0 if quantity is None else quantity,
            int(rec["position"]), str(eid))


def run(ctx, start, end, body=None, run_rounds=True):
    events = ctx["events"]
    total = len(events)
    if body is None:
        state = derived.new_state()
        watermark = 0
    else:
        state = derived.restore(body)
        watermark = int(body["position"])

    from . import window as window_mod
    window_start, window_end, positions = window_mod.build(
        start, end, watermark, total)

    quarantine = []
    deferred = []
    log = []
    register = []
    closure = {"checkpoint": 0, "window": 0}
    unsatisfied = []
    order = [1]

    for p in positions:
        rec = events[p - 1]
        reason = transitions.screen(ctx, rec)
        if reason is None:
            reason, sources = depends.dependency_reason(ctx, rec, window_start,
                                                        window_end)
            if reason is None:
                for _dep, where in sources:
                    closure[where] += 1
        if reason is not None:
            quarantine.append({"event_id": rec["event_id"], "position": p,
                               "stage": ctx["stages"][reason],
                               "reason_code": reason,
                               "detail": str(rec["kind"])})
            if reason.startswith("DEP-"):
                unsatisfied.append({"event_id": rec["event_id"],
                                    "reason": reason})
            continue
        if str(rec["kind"]).strip() == "compensate":
            compensation.apply_compensation(ctx, state, rec, register, order)
            continue
        if transitions.admissible(ctx, state, rec):
            transitions.apply_transition(ctx, state, rec, log, order)
        else:
            state["pending"].append(rec["event_id"])
            deferred.append(rec["event_id"])

    rounds = []
    stable = True
    if run_rounds:
        ceiling = int(ctx["params"]["round_ceiling"])
        index = 0
        while index < ceiling:
            index += 1
            offers = sorted(state["pending"],
                            key=lambda eid: ladder_key(ctx, eid))
            admitted = []
            for eid in offers:
                rec = ctx["by_id"][eid]
                if transitions.admissible(ctx, state, rec):
                    state["pending"].remove(eid)
                    transitions.apply_transition(ctx, state, rec, log, order)
                    state["counters"]["deferred_admitted"] += 1
                    admitted.append(eid)
            if not admitted:
                stable = True
                break
            rounds.append({"round": index, "admitted": admitted,
                           "admitted_count": len(admitted)})
            stable = False

    return {"state": state, "watermark": watermark,
            "window_start": window_start, "window_end": window_end,
            "positions": positions, "quarantine": quarantine,
            "deferred": deferred, "log": log, "register": register,
            "closure": closure, "unsatisfied": unsatisfied,
            "rounds": rounds, "stable": stable}


def select_checkpoint(ctx, end):
    return checkpointing.select(ctx, end)
