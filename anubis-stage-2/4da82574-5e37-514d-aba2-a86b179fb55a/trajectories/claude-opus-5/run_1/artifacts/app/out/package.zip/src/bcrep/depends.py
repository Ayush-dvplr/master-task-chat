"""Stage r07. Dependency closure across the checkpoint and the window.

The pipe file is the authoritative edge set. The depends_on list inside a
journal record is a convenience copy carried over from an earlier revision and
governs nothing.
"""
from . import reading

PIPE = chr(124)


def _int(text):
    return int(str(text).strip())


def load_edges(root, frozen):
    edges = {}
    for row in reading.read_delim(root / "dependency_edges.psv", PIPE):
        if _int(row["revision"]) > frozen:
            continue
        if row["edge_kind"].strip() != "requires":
            continue
        key = row["event_id"].strip()
        edges.setdefault(key, [])
        target = row["depends_on"].strip()
        if target and target not in edges[key]:
            edges[key].append(target)
    for key in edges:
        edges[key].sort()
    return edges


def cycle_members(events, edges, by_id):
    """Every identifier some path of edges in force leads from back to itself,
    however long the path and wherever a walk that finds it begins. That is
    exactly the membership of the strongly connected components that carry more
    than one identifier, together with every self edge. An edge naming an
    identifier the canonical history does not carry takes no part."""
    nodes = [rec["event_id"] for rec in events]
    out = []
    for node in nodes:
        if node in edges.get(node, []):
            out.append(node)

    index = {}
    low = {}
    on_stack = set()
    stack = []
    counter = [0]

    def strong(root):
        work = [(root, 0)]
        while work:
            node, at = work.pop()
            if at == 0:
                index[node] = low[node] = counter[0]
                counter[0] += 1
                stack.append(node)
                on_stack.add(node)
            successors = [n for n in edges.get(node, []) if n in by_id]
            recursed = False
            while at < len(successors):
                nxt = successors[at]
                at += 1
                if nxt not in index:
                    work.append((node, at))
                    work.append((nxt, 0))
                    recursed = True
                    break
                if nxt in on_stack:
                    low[node] = min(low[node], index[nxt])
            if recursed:
                continue
            if low[node] == index[node]:
                component = []
                while True:
                    member = stack.pop()
                    on_stack.discard(member)
                    component.append(member)
                    if member == node:
                        break
                if len(component) > 1:
                    out.extend(component)
            if work:
                parent = work[-1][0]
                low[parent] = min(low[parent], low[node])

    for node in nodes:
        if node not in index:
            strong(node)
    return set(out)


def dependency_reason(ctx, rec, window_start, window_end):
    """A dependency already folded into the restored checkpoint is satisfied
    and is never replayed a second time. A dependency that would still have to
    be replayed later in the window is not satisfied."""
    eid = rec["event_id"]
    deps = ctx["edges"].get(eid, [])
    sources = []
    for dep in deps:
        if dep == eid:
            return "DEP-SELF", sources
    if eid in ctx["cycles"]:
        return "DEP-CYCLE", sources
    for dep in deps:
        target = ctx["by_id"].get(dep)
        if target is None:
            return "DEP-MISSING", sources
        pos = int(target["position"])
        if pos < window_start:
            sources.append((dep, "checkpoint"))
        elif pos < int(rec["position"]) and pos < window_end:
            sources.append((dep, "window"))
        else:
            return "DEP-MISSING", sources
    return None, sources
