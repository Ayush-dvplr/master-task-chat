"""Readers for the shapes the working papers arrive in.

Nothing in this module knows what any file means. It turns bytes into rows,
records, cells and lines, and the stage modules decide what governs.
"""
import hashlib
import json
import sqlite3
import zipfile
import zlib
import xml.etree.ElementTree as ET
from pathlib import Path

NL = chr(10)
BS = chr(92)
Q = chr(34)
TAB = chr(9)
PIPE = chr(124)
NS_WORD = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
W_NS = "{" + NS_WORD + "}"


def digest_bytes(payload):
    return hashlib.sha256(payload).hexdigest()


def compact_json(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"))


def canonical_json(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + NL


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_lines(path):
    return Path(path).read_text(encoding="utf-8").splitlines()


def read_jsonl(path):
    out = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out


def read_delim(path, sep=","):
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    lines = [ln for ln in lines if ln.strip() != ""]
    header = lines[0].split(sep)
    return [dict(zip(header, ln.split(sep))) for ln in lines[1:]]


def read_conf(path):
    out = {}
    section = "default"
    out[section] = {}
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            out.setdefault(section, {})
            continue
        key, _sep, value = line.partition("=")
        out[section][key.strip()] = value.strip()
    return out


def scalar(value):
    text = value.strip()
    if text.startswith("[") and text.endswith("]"):
        inner = text[1:-1].strip()
        if inner == "":
            return []
        return [scalar(part) for part in inner.split(",")]
    if len(text) >= 2 and text[0] == Q and text[-1] == Q:
        return text[1:-1]
    if text in ("true", "false"):
        return text == "true"
    try:
        return int(text)
    except ValueError:
        return text


def read_flat_yaml(path):
    out = {}
    section = None
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indented = raw.startswith(" ")
        key, _sep, value = raw.strip().partition(":")
        key = key.strip()
        value = value.strip()
        if value == "":
            if indented and section is not None:
                out[section][key] = {}
            else:
                section = key
                out[section] = {}
            continue
        parsed = scalar(value)
        if indented and section is not None:
            out[section][key] = parsed
        else:
            out[key] = parsed
    return out


def read_flat_toml(path):
    out = {}
    section = "root"
    out[section] = {}
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            out.setdefault(section, {})
            continue
        key, _sep, value = line.partition("=")
        out[section][key.strip()] = scalar(value)
    return out


def read_xml_rows(path, tag):
    root = ET.parse(str(path)).getroot()
    return [dict(node.attrib) for node in root.iter(tag)]


def read_sqlite_table(path, table):
    con = sqlite3.connect(str(path))
    try:
        cur = con.cursor()
        cur.execute("SELECT * FROM " + table)
        cols = [c[0] for c in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]
    finally:
        con.close()


def _col_to_idx(ref):
    col = 0
    for ch in ref:
        if ch.isalpha():
            col = col * 26 + (ord(ch.upper()) - 64)
        else:
            break
    return col


def _sheet_rows(payload, shared):
    rows = []
    for row in ET.fromstring(payload).iter():
        if not row.tag.endswith("}row"):
            continue
        cells = {}
        width = 0
        for c in row:
            if not c.tag.endswith("}c"):
                continue
            ci = _col_to_idx(c.attrib.get("r", "A1"))
            val = ""
            for v in c:
                if v.tag.endswith("}v"):
                    val = v.text or ""
            if c.attrib.get("t") == "s" and val != "":
                val = shared[int(val)]
            cells[ci] = val
            width = max(width, ci)
        rows.append([cells.get(i, "") for i in range(1, width + 1)])
    return rows


def _sheet_parts(zf):
    """The part each relationship identifier points at. Sheet order and the
    numbering of the worksheet parts are unrelated, so the name a sheet carries
    is only tied to its cells through the relationship target."""
    out = {}
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    for node in rels.iter():
        if not node.tag.endswith("}Relationship"):
            continue
        target = node.attrib.get("Target", "")
        if target.startswith("/"):
            member = target[1:]
        else:
            member = "xl/" + target.lstrip("./")
        out[node.attrib.get("Id")] = member
    return out


def read_xlsx_sheets(path):
    with zipfile.ZipFile(path) as zf:
        shared = []
        if "xl/sharedStrings.xml" in zf.namelist():
            sroot = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in sroot:
                shared.append("".join(t.text or "" for t in si.iter()
                                      if t.tag.endswith("}t")))
        parts = _sheet_parts(zf)
        names = zf.namelist()
        wb = ET.fromstring(zf.read("xl/workbook.xml"))
        out = {}
        for sh in wb.iter():
            if not sh.tag.endswith("}sheet"):
                continue
            rid = None
            for key in sh.attrib:
                if key.endswith("}id"):
                    rid = sh.attrib[key]
            member = parts.get(rid)
            if member is None or member not in names:
                continue
            out[sh.attrib.get("name")] = _sheet_rows(zf.read(member), shared)
        return out


def _pdf_streams(raw):
    """Every stream of a PDF as latin-1 text, inflated where its dictionary
    names FlateDecode."""
    marker = (">>" + NL + "stream" + NL).encode("latin-1")
    out = []
    at = raw.find(marker)
    while at >= 0:
        words = raw[raw.rfind(b"<<", 0, at):at].decode("latin-1").split()
        begin = at + len(marker)
        length = int(words[words.index("/Length") + 1])
        payload = raw[begin:begin + length]
        if "/FlateDecode" in words:
            payload = zlib.decompress(payload)
        out.append(payload.decode("latin-1"))
        at = raw.find(marker, begin + length)
    return out


def _pdf_string(content, at):
    """The literal string opening at content[at], and the index past it."""
    depth = 1
    text = []
    at += 1
    while at < len(content):
        ch = content[at]
        if ch == BS:
            text.append(content[at + 1:at + 2])
            at += 2
            continue
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return "".join(text), at + 1
        text.append(ch)
        at += 1
    return "".join(text), at


def _strings(content):
    """The text a content stream shows, one line per text showing operator.

    A line may be shown by `Tj` out of one string or by `TJ` out of an array
    that carries the line in pieces with kerning numbers between them. Both
    show one line, so the pieces of a `TJ` array are joined rather than taken
    for lines of their own.
    """
    out = []
    buffer = []
    at = 0
    size = len(content)
    while at < size:
        ch = content[at]
        if ch == "(":
            text, at = _pdf_string(content, at)
            buffer.append(text)
            continue
        if ch == "T" and content[at + 1:at + 2] in ("j", "J"):
            after = content[at + 2:at + 3]
            if after == "" or not (after.isalnum() or after == "*"):
                out.append("".join(buffer))
                buffer = []
                at += 2
                continue
        at += 1
    if buffer:
        out.append("".join(buffer))
    return out


def read_pdf_lines(path):
    out = []
    for content in _pdf_streams(Path(path).read_bytes()):
        out.extend(_strings(content))
    return out


def read_docx_blocks(path):
    with zipfile.ZipFile(path) as zf:
        root = ET.fromstring(zf.read("word/document.xml"))
    out = []
    body = None
    for node in root:
        if node.tag == W_NS + "body":
            body = node
    if body is None:
        return out
    for node in body:
        if node.tag == W_NS + "p":
            out.append("".join(t.text or "" for t in node.iter(W_NS + "t")))
        elif node.tag == W_NS + "tbl":
            for tr in node.findall(W_NS + "tr"):
                out.append(["".join(t.text or "" for t in tc.iter(W_NS + "t"))
                            for tc in tr.findall(W_NS + "tc")])
    return out


def write_text(path, text):
    if not text.endswith(NL):
        text += NL
    Path(path).write_bytes(text.encode("utf-8"))


def write_lines(path, lines):
    write_text(path, NL.join(str(x) for x in lines))


def write_json(path, obj):
    write_text(path, canonical_json(obj))


def write_jsonl(path, records):
    write_lines(path, [compact_json(r) for r in records])


def write_delim(path, header, rows, sep=","):
    out = [sep.join(str(h) for h in header)]
    for row in rows:
        out.append(sep.join(str(c) for c in row))
    write_lines(path, out)
