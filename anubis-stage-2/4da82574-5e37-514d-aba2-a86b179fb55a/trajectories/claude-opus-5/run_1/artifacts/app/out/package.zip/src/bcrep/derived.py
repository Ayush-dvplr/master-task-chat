"""Stages r11 and r13. Carry quantisation, state shape and the derived index."""
from . import reading

COUNTER_NAMES = ["compensations", "deferred_admitted", "granted_cu", "grants",
                 "retired_cu", "retires", "reversed_cu", "spilled_cu",
                 "transferred_cu", "transfers"]


def new_state():
    return {"balances": {}, "allotments": {}, "pending": [],
            "counters": {name: 0 for name in COUNTER_NAMES},
            "applied": [], "reversed": []}


def restore(body):
    """A restored checkpoint is a copy. The parsed body stays as it was read,
    so a second replay from the same checkpoint starts from the same state."""
    state = new_state()
    state["balances"] = dict(body["balances"])
    state["allotments"] = {station: dict(inner)
                           for station, inner in body["allotments"].items()}
    state["counters"].update({name: int(value)
                              for name, value in body["counters"].items()})
    state["pending"] = list(body["pending"])
    state["applied"] = list(body["applied"])
    state["reversed"] = list(body["reversed"])
    return state


def state_body(state, position):
    balances = {k: v for k, v in state["balances"].items() if v != 0}
    allotments = {}
    for station in state["allotments"]:
        inner = {k: v for k, v in state["allotments"][station].items() if v != 0}
        if inner:
            allotments[station] = inner
    return {"position": position, "balances": balances,
            "allotments": allotments, "counters": dict(state["counters"]),
            "pending": list(state["pending"]),
            "applied": sorted(state["applied"]),
            "reversed": sorted(state["reversed"])}


def state_digest(body):
    payload = {k: body[k] for k in ("position", "balances", "allotments",
                                    "counters", "pending", "applied",
                                    "reversed")}
    return reading.digest_bytes(reading.compact_json(payload).encode("utf-8"))


def move(state, station, programme, amount):
    state["balances"][station] = state["balances"].get(station, 0) + amount
    inner = state["allotments"].setdefault(station, {})
    inner[programme] = inner.get(programme, 0) + amount


def settle(state, ctx, touched):
    """A balance above its class ceiling spills. The spill is quantised down
    to a whole number of carry quanta, the quantised part leaves the balance,
    and the remainder stays where it is."""
    stations = ctx["stations"]
    params = ctx["params"]
    frozen = ctx["frozen"]
    for station in sorted(touched):
        row = stations.get(station)
        if row is None:
            continue
        cls = str(row["class"]).strip()
        ceiling = params["ceilings"].get((frozen, cls))
        factors = params["classes"].get(cls) or {}
        quantum = factors.get("carry_quantum")
        if ceiling is None or not quantum:
            continue
        balance = state["balances"].get(station, 0)
        if balance <= ceiling:
            continue
        spill = balance - ceiling
        carried = (spill // quantum) * quantum
        if carried <= 0:
            continue
        state["balances"][station] = balance - carried
        state["counters"]["spilled_cu"] += carried
