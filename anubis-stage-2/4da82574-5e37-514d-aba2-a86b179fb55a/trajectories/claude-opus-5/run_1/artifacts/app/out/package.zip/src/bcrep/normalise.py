"""Stages r01 and r02. Registers, aliases, quantities and exact arithmetic."""
from fractions import Fraction

from . import reading

TAB = chr(9)


def _int(text):
    return int(str(text).strip())


def half_up(value):
    """Nearest integer, halves away from zero, on an exact rational."""
    f = Fraction(value)
    n, d = f.numerator, f.denominator
    if d == 1:
        return n
    if n >= 0:
        return (2 * n + d) // (2 * d)
    return -((2 * (-n) + d) // (2 * d))


def ratio_text(value, places):
    scale = 10 ** places
    scaled = half_up(Fraction(value) * scale)
    sign = "-" if scaled < 0 else ""
    scaled = abs(scaled)
    whole, frac = divmod(scaled, scale)
    text = sign + str(whole) + "." + str(frac).rjust(places, "0")
    if text == "-0." + "0" * places:
        text = "0." + "0" * places
    return text


def safe_ratio(num, den, places):
    if den == 0:
        return ratio_text(0, places)
    return ratio_text(Fraction(int(num), int(den)), places)


def latest_by(rows, key, revision_field, frozen):
    """One row per key: the greatest revision at or below the frozen register
    revision. A row above that revision is a draft and governs nothing."""
    out = {}
    for row in rows:
        if _int(row[revision_field]) > frozen:
            continue
        name = row[key].strip()
        prior = out.get(name)
        if prior is None or _int(row[revision_field]) >= _int(prior[revision_field]):
            out[name] = row
    return out


def class_at_revision(history, station, revision, fallback):
    """The class the frozen station register carried for a station at a given
    record revision: the register row with the greatest revision at or below
    it. When the register carries no row for the station that early the class
    in force at the frozen register revision is used."""
    held = None
    for candidate, cls in history.get(station, []):
        if candidate > revision:
            continue
        if held is None or candidate >= held[0]:
            held = (candidate, cls)
    if held is None:
        row = fallback.get(station)
        return None if row is None else str(row["class"]).strip()
    return held[1]


def load_registers(root, frozen):
    station_rows = reading.read_delim(root / "station_register_frozen.csv")
    stations = latest_by(station_rows, "station", "revision", frozen)
    station_history = {}
    for row in station_rows:
        if _int(row["revision"]) > frozen:
            continue
        station_history.setdefault(row["station"].strip(), []).append(
            (_int(row["revision"]), str(row["class"]).strip()))
    programmes = latest_by(reading.read_delim(root / "programme_register.csv"),
                           "programme", "revision", frozen)
    alias = {}
    for row in reading.read_delim(root / "alias_crosswalk.tsv", TAB):
        if _int(row["in_force_from_revision"]) > frozen:
            continue
        key = (row["kind"].strip(), row["alias"].strip())
        prior = alias.get(key)
        if prior is None or _int(row["in_force_from_revision"]) >= _int(
                prior["in_force_from_revision"]):
            alias[key] = row
    scope = {}
    for node in reading.read_xml_rows(root / "topology_and_scope.xml", "station"):
        if _int(node["revision"]) > frozen:
            continue
        key = node["id"].strip()
        prior = scope.get(key)
        if prior is None or _int(node["revision"]) >= _int(prior["revision"]):
            scope[key] = node
    return stations, programmes, alias, scope, station_history


def resolve_alias(alias, kind, name):
    row = alias.get((kind, str(name).strip()))
    if row is None:
        return str(name).strip()
    return row["canonical"].strip()


def normalise_quantity(rec, params, stations):
    """The recorded quantity is carried into credit units through the unit
    registry and the class conversion factor, in exact rational arithmetic,
    and rounded once here."""
    station = stations.get(str(rec["station"]).strip())
    if station is None:
        return None, None
    cls = str(station["class"]).strip()
    factors = params["classes"].get(cls)
    if factors is None:
        return None, cls
    scale = params["units"].get(str(rec["unit"]).strip())
    if scale is None:
        return None, cls
    value = (Fraction(int(rec["quantity"]) * scale)
             * Fraction(factors["conversion_num"], factors["conversion_den"]))
    return half_up(value), cls
