"""Stages r09 and r10. Compensating events.

A compensating event names the event it reverses through the link register.
The named target is resolved against the whole canonical history, which
reaches behind the restored checkpoint, and never against the replay window
alone. Reversing a target does not remove it from history, and a target is
reversed exactly once however many compensations name it.
"""
from fractions import Fraction

from . import derived, normalise, reading


def _int(text):
    return int(str(text).strip())


def load_links(root, frozen):
    best = {}
    for row in reading.read_delim(root / "compensation_links.csv"):
        if _int(row["revision"]) > frozen:
            continue
        key = row["compensation_id"].strip()
        prior = best.get(key)
        if prior is None or _int(row["revision"]) >= _int(prior["revision"]):
            best[key] = row
    return best


def count_counter(state, kind):
    """The count counter a kind moves is the plural of the kind."""
    name = kind + "s"
    return name if name in state["counters"] else None


def reversal_class(ctx, target):
    """The class the frozen station register carried for the target station at
    the revision of the target record that survived the merge."""
    return normalise.class_at_revision(ctx["station_history"],
                                       str(target["station"]).strip(),
                                       int(target["revision"]),
                                       ctx["stations"])


def apply_compensation(ctx, state, rec, register, order):
    """A target is reversed exactly once however many compensating events name
    it. The primary effect comes off and so does the derived counter the
    compensation policy names for the target kind, at the class reversal scale,
    rounded here and nowhere else."""
    eid = rec["event_id"]
    link = ctx["links"][eid]
    target_id = link["target_event_id"].strip()
    target = ctx["by_id"][target_id]
    row = {"compensation_id": eid, "target_event_id": target_id,
           "target_position": int(target["position"]),
           "disposition": "", "reversed_cu": 0, "applied_order": 0}
    if target_id in state["reversed"]:
        row["disposition"] = "void_duplicate"
        register.append(row)
        return
    if target_id not in state["applied"]:
        row["disposition"] = "void_unapplied"
        register.append(row)
        return
    quantity = ctx["norm"][target_id]
    klass = reversal_class(ctx, target)
    factors = ctx["params"]["classes"][klass]
    station = str(target["station"]).strip()
    programme = str(target["programme"]).strip()
    touched = {station}
    kind = str(target["kind"]).strip()
    if kind == "grant":
        derived.move(state, station, programme, -quantity)
    elif kind == "retire":
        derived.move(state, station, programme, quantity)
    else:
        other = str(target["counterparty"]).strip()
        derived.move(state, station, programme, quantity)
        derived.move(state, other, programme, -quantity)
        touched.add(other)
    reversed_cu = normalise.half_up(
        Fraction(quantity * factors["reversal_num"], factors["reversal_den"]))
    moved = ctx["params"]["counter_map"].get(kind)
    if moved is not None:
        state["counters"][moved] -= reversed_cu
    counted = count_counter(state, kind)
    if counted is not None:
        state["counters"][counted] -= 1
    state["counters"]["reversed_cu"] += reversed_cu
    state["counters"]["compensations"] += 1
    state["reversed"].append(target_id)
    derived.settle(state, ctx, touched)
    row["disposition"] = "applied"
    row["reversed_cu"] = reversed_cu
    row["applied_order"] = order[0]
    order[0] += 1
    register.append(row)
