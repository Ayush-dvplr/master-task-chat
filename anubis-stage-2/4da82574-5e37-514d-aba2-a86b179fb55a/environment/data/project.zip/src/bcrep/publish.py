"""Stage r14. Materialise the epoch and write it out.

Every document is written through one canonical serialisation: utf-8, line
feed endings, sorted keys, two space indentation for the indented json, one
trailing newline, and ratios at the number of places the arithmetic policy
names. The two digests are taken last, over the bytes already written.
"""
from pathlib import Path

from . import derived, normalise, reading, replay

TAB = chr(9)
PIPE = chr(124)

ARTIFACT_NAMES = [
    "alias_resolution.jsonl", "bounded_replay.json", "canonical_order.csv",
    "checkpoint_reconciliation.json", "checkpoint_selection.json",
    "compensation_register.csv", "defect_register.md", "derived_counters.csv",
    "derived_index.jsonl", "dependency_closure.json",
    "eligibility_passes.json", "equivalence_report.json", "final_state.json",
    "quarantine_ledger.csv", "replay_window.json", "repair_report.json",
    "run_manifest.txt", "selftest.json", "state_at_event.json",
    "summary.json", "transition_log.jsonl", "unit_normalisation.json",
    "verification_notes.md",
]

PACKAGE_MODULES = ["__init__", "__main__", "checkpointing", "compensation",
                   "derived", "depends", "normalise", "ordering", "params",
                   "publish", "reading", "replay", "transitions", "window"]

QUARANTINE_CODES = ["EVT-DRAFTREVISION", "EVT-WITHDRAWN",
                    "EVT-UNKNOWNSTATION", "EVT-UNKNOWNPROGRAMME",
                    "EVT-NONPOSITIVE", "EVT-IMPLAUSIBLE", "CMP-WITHDRAWN",
                    "CMP-NOTARGET", "DEP-SELF", "DEP-CYCLE", "DEP-MISSING"]


def _int(text):
    return int(str(text).strip())


def publish(root, out):
    root = Path(root)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    ctx = replay.build_context(root)
    settings = ctx["params"]
    header = settings["header"]
    frozen = ctx["frozen"]
    events = ctx["events"]
    total = len(events)
    places = settings["ratio_places"]

    start = int(header["replay_start_position"])
    end = int(header["replay_end_position"])
    probe = int(header["state_probe_position"])
    b_start = int(header["bounded_start_position"])
    b_end = int(header["bounded_end_position"])

    chosen, usable, rejected = replay.select_checkpoint(ctx, end)
    body = chosen[2] if chosen else None
    run = replay.run(ctx, start, end, body)
    scratch = replay.run(ctx, 1, end, None)
    probe_run = replay.run(ctx, 1, probe + 1, None, run_rounds=False)
    b_chosen, _bu, _br = replay.select_checkpoint(ctx, b_end)
    bounded = replay.run(ctx, b_start, b_end, b_chosen[2] if b_chosen else None)

    state = run["state"]

    reading.write_json(out / "unit_normalisation.json", {
        "epoch_id": header["epoch_id"],
        "workbook_epoch_key": header["workbook_epoch_key"],
        "live_sheet": settings["live_sheet"],
        "frozen_register_revision": frozen,
        "round_ceiling": settings["round_ceiling"],
        "implausible_ceiling_cu": settings["implausible_ceiling"],
        "settlement_floor_cu": settings["settlement_floor"],
        "precedence_levels": settings["levels"],
        "units": {k: settings["units"][k] for k in sorted(settings["units"])},
        "classes": {k: {j: settings["classes"][k][j]
                        for j in sorted(settings["classes"][k])}
                    for k in sorted(settings["classes"])},
        "ceilings": {str(rev) + ":" + cls: settings["ceilings"][(rev, cls)]
                     for rev, cls in sorted(settings["ceilings"])},
        "event_count": total,
        "normalised_total_cu": sum(v for v in ctx["norm"].values()
                                   if v is not None and v > 0),
    })

    alias_rows = []
    for kind, name in sorted(ctx["alias"]):
        row = ctx["alias"][(kind, name)]
        alias_rows.append({"alias": name, "canonical": row["canonical"].strip(),
                           "kind": kind,
                           "in_force_from_revision":
                               _int(row["in_force_from_revision"])})
    reading.write_jsonl(out / "alias_resolution.jsonl", alias_rows)

    reading.write_delim(out / "canonical_order.csv",
                        ["position", "event_id", "sequence", "stamp", "kind",
                         "rank", "tiebreak"],
                        [[rec["position"], rec["event_id"],
                          int(rec["sequence"]), int(rec["stamp"]),
                          rec["kind"], rec["rank"], rec["tiebreak"]]
                         for rec in events])

    reading.write_json(out / "checkpoint_selection.json", {
        "requested_start": start, "requested_end": end,
        "usable": sorted(usable),
        "selected": chosen[1] if chosen else "",
        "selected_position": chosen[0] if chosen else 0,
        "watermark_position": run["watermark"],
        "rejected": rejected,
    })

    from . import window as window_mod
    reading.write_json(out / "replay_window.json", {
        "start_position": run["window_start"],
        "end_position": run["window_end"],
        "replayed_count": len(run["positions"]),
        "first_replayed_position": run["positions"][0] if run["positions"] else 0,
        "last_replayed_position": run["positions"][-1] if run["positions"] else 0,
        "skipped_before_watermark": window_mod.skipped_before(start,
                                                              run["watermark"]),
        "boundary": "start inclusive, end exclusive",
    })

    reading.write_json(out / "dependency_closure.json", {
        "edges_in_force": sum(len(v) for v in ctx["edges"].values()),
        "satisfied_by_checkpoint": run["closure"]["checkpoint"],
        "satisfied_by_window": run["closure"]["window"],
        "unsatisfied": sorted(run["unsatisfied"],
                              key=lambda r: (r["event_id"], r["reason"])),
        "cycle_members": sorted(ctx["cycles"]),
    })

    reading.write_delim(out / "quarantine_ledger.csv",
                        ["event_id", "position", "stage", "reason_code",
                         "detail"],
                        [[r["event_id"], r["position"], r["stage"],
                          r["reason_code"], r["detail"]]
                         for r in sorted(run["quarantine"],
                                         key=lambda r: (r["position"],
                                                        r["event_id"]))])

    reading.write_jsonl(out / "transition_log.jsonl", run["log"])

    reading.write_delim(out / "compensation_register.csv",
                        ["compensation_id", "target_event_id",
                         "target_position", "disposition", "reversed_cu",
                         "applied_order"],
                        [[r["compensation_id"], r["target_event_id"],
                          r["target_position"], r["disposition"],
                          r["reversed_cu"], r["applied_order"]]
                         for r in sorted(run["register"],
                                         key=lambda r: r["compensation_id"])])

    reading.write_delim(out / "derived_counters.csv", ["counter", "value"],
                        [[name, state["counters"][name]]
                         for name in derived.COUNTER_NAMES])

    reading.write_json(out / "eligibility_passes.json", {
        "pass_ceiling": settings["round_ceiling"],
        "deferred_at_first_pass": sorted(run["deferred"]),
        "rounds": run["rounds"],
        "round_count": len(run["rounds"]),
        "stable": run["stable"],
        "deferred_remaining": list(state["pending"]),
    })

    final = derived.state_body(state, run["window_end"])
    reading.write_json(out / "final_state.json", final)

    index_rows = []
    for station in sorted(final["allotments"]):
        node = ctx["scope"].get(station, {})
        inner = final["allotments"][station]
        station_total = sum(inner.values())
        for programme in sorted(inner):
            index_rows.append({
                "region": node.get("region", ""), "hub": node.get("hub", ""),
                "station": station, "programme": programme,
                "allotment_cu": inner[programme],
                "share": normalise.safe_ratio(inner[programme], station_total,
                                              places),
            })
    index_rows.sort(key=lambda r: (r["region"], r["hub"], r["station"],
                                   r["programme"]))
    reading.write_jsonl(out / "derived_index.jsonl", index_rows)

    archive = {}
    for row in reading.read_sqlite_table(root / "prior_epoch_archive.db",
                                         "prior_counters"):
        archive[(row["checkpoint_id"], row["counter"])] = int(row["value"])
    history = {}
    for row in reading.read_delim(root / "allotment_ceiling_history.tsv", TAB):
        history[(_int(row["revision"]), row["class"].strip())] = _int(
            row["ceiling_cu"])
    deltas = {}
    historic_total = 0
    declared = ""
    recomputed = ""
    if chosen:
        for name in derived.COUNTER_NAMES:
            held = archive.get((chosen[1], name))
            if held is not None:
                deltas[name] = held - int(chosen[2]["counters"].get(name, 0))
        declared = chosen[3]["state_digest"].strip()
        recomputed = derived.state_digest(chosen[2])
        checkpoint_revision = _int(chosen[3]["revision"])
        historic_total = sum(v for (rev, _cls), v in history.items()
                             if rev == checkpoint_revision)
    reading.write_json(out / "checkpoint_reconciliation.json", {
        "selected": chosen[1] if chosen else "",
        "declared_digest": declared, "recomputed_digest": recomputed,
        "matches": declared == recomputed and declared != "",
        "archive_rows": len(archive),
        "counter_deltas": {k: deltas[k] for k in sorted(deltas)},
        "historic_ceiling_total_cu": historic_total,
        "rejected_count": len(rejected),
    })

    scratch_final = derived.state_body(scratch["state"], scratch["window_end"])
    reading.write_json(out / "equivalence_report.json", {
        "comparison_start": 1, "comparison_end": end,
        "checkpoint_used": chosen[1] if chosen else "",
        "from_scratch_digest": derived.state_digest(scratch_final),
        "from_checkpoint_digest": derived.state_digest(final),
        "identical": scratch_final == final,
        "scratch_replayed_count": len(scratch["positions"]),
        "checkpoint_replayed_count": len(run["positions"]),
    })

    reading.write_json(out / "state_at_event.json",
                       derived.state_body(probe_run["state"], probe))

    reading.write_json(out / "bounded_replay.json", {
        "start_position": bounded["window_start"],
        "end_position": bounded["window_end"],
        "replayed_count": len(bounded["positions"]),
        "state": derived.state_body(bounded["state"], bounded["window_end"]),
    })

    reading.write_json(out / "repair_report.json", {
        "package": "bcrep",
        "modules": PACKAGE_MODULES,
        "stage_ids": replay.STAGE_IDS,
        "stage_count": len(replay.STAGE_IDS),
        "entry_point": "bcrep.__main__",
        "standard_library_only": True,
        "reason_codes": QUARANTINE_CODES,
    })

    checks = [
        {"name": "canonical_order_total", "value": total},
        {"name": "checkpoint_digest_matches",
         "value": 1 if (chosen and declared == recomputed) else 0},
        {"name": "window_end_exclusive",
         "value": 1 if (not run["positions"] or run["positions"][-1] < end)
         else 0},
        {"name": "watermark_replayed_once",
         "value": 0 if run["watermark"] in run["positions"] else 1},
        {"name": "scratch_matches_checkpoint",
         "value": 1 if scratch_final == final else 0},
        {"name": "targets_reversed_once",
         "value": 1 if len(set(state["reversed"])) == len(state["reversed"])
         else 0},
        {"name": "pending_after_rounds", "value": len(state["pending"])},
        {"name": "rounds_run", "value": len(run["rounds"])},
    ]
    flags = [c["value"] for c in checks
             if c["name"] not in ("canonical_order_total",
                                  "pending_after_rounds", "rounds_run")]
    reading.write_json(out / "selftest.json", {
        "checks": checks,
        "passed": sum(1 for value in flags if value == 1),
        "failed": sum(1 for value in flags if value == 0),
    })

    catalogue = []
    for row in reading.read_delim(root / "quarantine_reason_catalogue.psv",
                                  PIPE):
        if _int(row["revision"]) > frozen:
            continue
        if row["code"].strip() in QUARANTINE_CODES:
            catalogue.append((row["code"].strip(), row["stage"].strip(),
                              row["meaning"].strip()))
    catalogue = sorted(set(catalogue))
    lines = ["# Defect register", "",
             "| stage | reason code | meaning |",
             "| --- | --- | --- |"]
    for code, stage, meaning in catalogue:
        lines.append("| " + stage + " | " + code + " | " + meaning + " |")
    lines.append("")
    lines.append("Stages in force: " + ", ".join(replay.STAGE_IDS))
    reading.write_lines(out / "defect_register.md", lines)

    floor = settings["settlement_floor"]
    breaches = sorted(k for k, v in final["balances"].items() if v < floor)
    applied_count = sum(1 for r in run["register"]
                        if r["disposition"] == "applied")
    void_count = len(run["register"]) - applied_count
    reading.write_lines(out / "verification_notes.md", [
        "# Verification notes", "",
        "epoch " + str(header["epoch_id"]),
        "live sheet " + str(settings["live_sheet"]),
        "watermark position " + str(run["watermark"]),
        "window " + str(run["window_start"]) + " to " + str(run["window_end"])
        + " end exclusive",
        "rounds run " + str(len(run["rounds"])),
        "stable " + ("yes" if run["stable"] else "no"),
        "pending after rounds " + str(len(state["pending"])),
        "compensations applied " + str(applied_count),
        "compensations void " + str(void_count),
        "reversed cu " + str(state["counters"]["reversed_cu"]),
        "spilled cu " + str(state["counters"]["spilled_cu"]),
        "settlement floor " + str(floor),
        "settlement floor breaches " + str(len(breaches)),
        "scratch equals checkpoint "
        + ("yes" if scratch_final == final else "no"),
        ""])

    balance_total = sum(final["balances"].values())
    allotment_total = sum(sum(v.values()) for v in final["allotments"].values())
    reading.write_json(out / "summary.json", {
        "epoch_id": header["epoch_id"],
        "live_sheet": settings["live_sheet"],
        "frozen_register_revision": frozen,
        "control_totals": {
            "canonical_events": total,
            "checkpoint_position": run["watermark"],
            "window_start": run["window_start"],
            "window_end": run["window_end"],
            "replayed_positions": len(run["positions"]),
            "quarantined_events": len(run["quarantine"]),
            "deferred_at_first_pass": len(run["deferred"]),
            "admitted_in_rounds": sum(r["admitted_count"]
                                      for r in run["rounds"]),
            "round_count": len(run["rounds"]),
            "pending_remaining": len(state["pending"]),
            "compensations_applied": applied_count,
            "compensations_void": void_count,
            "reversed_cu": state["counters"]["reversed_cu"],
            "spilled_cu": state["counters"]["spilled_cu"],
            "balance_total_cu": balance_total,
            "allotment_total_cu": allotment_total,
            "index_rows": len(index_rows),
            "settlement_floor_breaches": len(breaches),
        },
        "stable": run["stable"],
        "equivalence_identical": scratch_final == final,
        "balance_share": normalise.safe_ratio(balance_total, allotment_total,
                                              places),
    })

    core = b"".join((out / name).read_bytes()
                    for name in settings["core_documents"])
    publication = b"".join((out / name).read_bytes()
                           for name in sorted(ARTIFACT_NAMES)
                           if name != "run_manifest.txt")
    reading.write_lines(out / "run_manifest.txt",
                        ["core " + reading.digest_bytes(core),
                         "publication " + reading.digest_bytes(publication)])
    return out
