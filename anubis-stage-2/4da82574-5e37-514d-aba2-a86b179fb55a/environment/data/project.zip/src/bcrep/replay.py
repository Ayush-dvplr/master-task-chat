"""Stages r05 to r12. One forward pass over the window, then the re offer
rounds.

An event whose eligibility predicate is false when it is first offered is not
discarded. It waits in the pending queue and is offered again after the window
is exhausted, because a compensating event later in the window can change the
state the predicate reads. The rounds run until a round admits nothing or the
round ceiling in the board memo is reached.
"""
from . import checkpointing, compensation, depends, derived, normalise
from . import ordering, params, transitions

STAGE_IDS = ["r01", "r02", "r03", "r04", "r05", "r06", "r07",
             "r08", "r09", "r10", "r11", "r12", "r13", "r14"]


def build_context(root):
    settings = params.load(root)
    frozen = int(settings["header"]["frozen_register_revision"])
    stations, programmes, alias, scope = normalise.load_registers(root, frozen)
    events = ordering.load_events(root, frozen, alias)
    edges = depends.load_edges(root, frozen)
    links = compensation.load_links(root, frozen)
    by_id = {rec["event_id"]: rec for rec in events}
    norm = {}
    cls = {}
    for rec in events:
        quantity, klass = normalise.normalise_quantity(rec, settings, stations)
        norm[rec["event_id"]] = quantity
        cls[rec["event_id"]] = klass
    return {
        "root": root, "params": settings, "frozen": frozen,
        "stations": stations, "programmes": programmes, "alias": alias,
        "scope": scope, "events": events, "by_id": by_id, "edges": edges,
        "links": links, "norm": norm, "cls": cls,
        "cycles": depends.cycle_members(events, edges, by_id),
    }


def stage_of(reason):
    table = {"EVT-DRAFTREVISION": "r01", "EVT-WITHDRAWN": "r01",
             "EVT-UNKNOWNSTATION": "r02", "EVT-UNKNOWNPROGRAMME": "r02",
             "EVT-NONPOSITIVE": "r01", "EVT-IMPLAUSIBLE": "r01",
             "CMP-WITHDRAWN": "r09", "CMP-NOTARGET": "r09",
             "DEP-SELF": "r07", "DEP-CYCLE": "r07", "DEP-MISSING": "r07"}
    return table[reason]


def run(ctx, start, end, body=None, run_rounds=True):
    events = ctx["events"]
    total = len(events)
    if body is None:
        state = derived.new_state()
        watermark = 0
    else:
        state = derived.restore(body)
        watermark = int(body["position"])

    from . import window as window_mod
    window_start, window_end, positions = window_mod.build(
        start, end, watermark, total)

    quarantine = []
    deferred = []
    log = []
    register = []
    closure = {"checkpoint": 0, "window": 0}
    unsatisfied = []
    order = [1]

    for p in positions:
        rec = events[p - 1]
        reason = transitions.screen(ctx, rec)
        if reason is None:
            reason, sources = depends.dependency_reason(ctx, rec, window_start,
                                                        window_end)
            if reason is None:
                for _dep, where in sources:
                    closure[where] += 1
        if reason is not None:
            quarantine.append({"event_id": rec["event_id"], "position": p,
                               "stage": stage_of(reason),
                               "reason_code": reason,
                               "detail": str(rec["kind"])})
            if reason.startswith("DEP-"):
                unsatisfied.append({"event_id": rec["event_id"],
                                    "reason": reason})
            continue
        if str(rec["kind"]).strip() == "compensate":
            link = ctx["links"][rec["event_id"]]
            named = ctx["by_id"][link["target_event_id"].strip()]
            if int(named["position"]) < window_start:
                quarantine.append({"event_id": rec["event_id"],
                                   "position": p,
                                   "stage": "r09",
                                   "reason_code": "CMP-NOTARGET",
                                   "detail": str(rec["kind"])})
                continue
            compensation.apply_compensation(ctx, state, rec, register, order)
            continue
        if transitions.admissible(ctx, state, rec):
            transitions.apply_transition(ctx, state, rec, log, order)
        else:
            state["pending"].append(rec["event_id"])
            deferred.append(rec["event_id"])

    rounds = []
    stable = True
    if run_rounds:
        ceiling = 1
        stable = False
        for index in range(1, ceiling + 1):
            queue = list(state["pending"])
            admitted = []
            for eid in queue:
                rec = ctx["by_id"][eid]
                if transitions.admissible(ctx, state, rec):
                    state["pending"].remove(eid)
                    transitions.apply_transition(ctx, state, rec, log, order)
                    state["counters"]["deferred_admitted"] += 1
                    admitted.append(eid)
            if not admitted:
                stable = True
                break
            rounds.append({"round": index, "admitted": admitted,
                           "admitted_count": len(admitted)})

    return {"state": state, "watermark": watermark,
            "window_start": window_start, "window_end": window_end,
            "positions": positions, "quarantine": quarantine,
            "deferred": deferred, "log": log, "register": register,
            "closure": closure, "unsatisfied": unsatisfied,
            "rounds": rounds, "stable": stable}


def select_checkpoint(ctx, end):
    return checkpointing.select(ctx, end)
