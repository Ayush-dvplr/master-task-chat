"""Stages r08 and r12. Ordinary transitions and the eligibility predicate."""
from . import derived


def predicate_holds(text, state, stations):
    """The closed predicate vocabulary, read against the state as it stands
    immediately before the event is offered."""
    if not text:
        return True
    parts = str(text).split(":")
    head = parts[0]
    if head == "balance_at_least":
        return state["balances"].get(parts[1], 0) >= int(parts[2])
    if head == "allotment_below":
        inner = state["allotments"].get(parts[1], {})
        return inner.get(parts[2], 0) < int(parts[3])
    if head == "counter_at_least":
        return state["counters"].get(parts[1], 0) >= int(parts[2])
    if head == "no_pending":
        return not state["pending"]
    if head == "station_active":
        row = stations.get(parts[1])
        return row is not None and str(row["status"]).strip() == "active"
    return False


def admissible(ctx, state, rec):
    return predicate_holds(rec.get("requires"), state, ctx["stations"])


def apply_transition(ctx, state, rec, log, order):
    eid = rec["event_id"]
    quantity = ctx["norm"][eid]
    station = str(rec["station"]).strip()
    programme = str(rec["programme"]).strip()
    touched = {station}
    kind = str(rec["kind"]).strip()
    if kind == "grant":
        derived.move(state, station, programme, quantity)
        state["counters"]["grants"] += 1
        state["counters"]["granted_cu"] += quantity
    elif kind == "retire":
        derived.move(state, station, programme, -quantity)
        state["counters"]["retires"] += 1
        state["counters"]["retired_cu"] += quantity
    else:
        other = str(rec["counterparty"]).strip()
        derived.move(state, station, programme, -quantity)
        derived.move(state, other, programme, quantity)
        touched.add(other)
        state["counters"]["transfers"] += 1
        state["counters"]["transferred_cu"] += quantity
    derived.settle(state, ctx, touched)
    state["applied"].append(eid)
    log.append({"order": order[0], "event_id": eid,
                "position": int(rec["position"]), "kind": kind,
                "station": station, "programme": programme,
                "quantity_cu": quantity,
                "balance_after": state["balances"].get(station, 0)})
    order[0] += 1


def screen(ctx, rec):
    """Stage r01 and r09 screening. The order the policy paper puts the tests
    in decides which code a record that fails two tests carries."""
    eid = rec["event_id"]
    checks = {
        "EVT-DRAFTREVISION": lambda: bool(rec["draft"]),
        "EVT-WITHDRAWN": lambda: bool(rec["withdrawn"]),
        "EVT-UNKNOWNSTATION": lambda: _station_unknown(ctx, rec),
        "EVT-UNKNOWNPROGRAMME": lambda: _programme_unknown(ctx, rec),
        "EVT-NONPOSITIVE": lambda: _nonpositive(ctx, rec),
        "EVT-IMPLAUSIBLE": lambda: _implausible(ctx, rec),
        "CMP-WITHDRAWN": lambda: _link_absent(ctx, rec),
        "CMP-NOTARGET": lambda: _target_absent(ctx, rec),
    }
    for code in ctx["params"]["screen_order"]:
        test = checks.get(code)
        if test is not None and test():
            return code
    return None


def _station_unknown(ctx, rec):
    if str(rec["station"]).strip() not in ctx["stations"]:
        return True
    if str(rec["kind"]).strip() == "transfer":
        other = str(rec.get("counterparty") or "").strip()
        return other == "" or other not in ctx["stations"]
    return False


def _programme_unknown(ctx, rec):
    if str(rec["kind"]).strip() == "compensate":
        return False
    return str(rec["programme"]).strip() not in ctx["programmes"]


def _nonpositive(ctx, rec):
    if str(rec["kind"]).strip() == "compensate":
        return False
    quantity = ctx["norm"].get(rec["event_id"])
    return quantity is None or quantity <= 0


def _implausible(ctx, rec):
    if str(rec["kind"]).strip() == "compensate":
        return False
    quantity = ctx["norm"].get(rec["event_id"])
    if quantity is None:
        return False
    return quantity > ctx["params"]["implausible_ceiling"]


def _link_absent(ctx, rec):
    if str(rec["kind"]).strip() != "compensate":
        return False
    link = ctx["links"].get(rec["event_id"])
    return link is None or link["status"].strip() != "registered"


def _target_absent(ctx, rec):
    if str(rec["kind"]).strip() != "compensate":
        return False
    link = ctx["links"].get(rec["event_id"])
    if link is None:
        return False
    return link["target_event_id"].strip() not in ctx["by_id"]
