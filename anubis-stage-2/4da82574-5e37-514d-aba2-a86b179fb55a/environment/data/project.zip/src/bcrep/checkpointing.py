"""Stages r04 and r05. Checkpoint selection and restoration.

A checkpoint that carries watermark N is the state after the event at
canonical position N was processed. Position N is therefore behind the
engine, and the first candidate the window can replay is position N plus one.
"""
from . import derived, reading


def _int(text):
    return int(str(text).strip())


def bodies(root):
    out = {}
    for rec in reading.read_jsonl(root / "checkpoint_states.jsonl"):
        out[str(rec["checkpoint_id"]).strip()] = rec
    return out


def select(ctx, end):
    """Usable means sealed, present, digest matching, and standing strictly
    before the requested end boundary. The greatest usable position wins."""
    root = ctx["root"]
    held = bodies(root)
    usable = []
    rejected = []
    for row in reading.read_delim(root / "checkpoint_register.csv"):
        cid = row["checkpoint_id"].strip()
        if _int(row["revision"]) > ctx["frozen"]:
            rejected.append({"checkpoint_id": cid, "reason": "draft_revision"})
            continue
        if row["status"].strip() != "sealed":
            rejected.append({"checkpoint_id": cid, "reason": "not_sealed"})
            continue
        body = held.get(cid)
        if body is None:
            rejected.append({"checkpoint_id": cid, "reason": "body_missing"})
            continue
        if derived.state_digest(body) != row["state_digest"].strip():
            rejected.append({"checkpoint_id": cid, "reason": "digest_mismatch"})
            continue
        if int(body["position"]) >= int(end):
            rejected.append({"checkpoint_id": cid,
                             "reason": "position_at_or_after_end"})
            continue
        usable.append((int(body["position"]), cid, body, row))
    usable.sort()
    rejected.sort(key=lambda r: (r["checkpoint_id"], r["reason"]))
    if not usable:
        return None, [], rejected
    return usable[-1], [c for _p, c, _b, _r in usable], rejected
