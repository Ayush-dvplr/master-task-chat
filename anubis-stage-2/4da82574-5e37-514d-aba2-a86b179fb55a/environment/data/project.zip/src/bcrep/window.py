"""Stage r06. Replay window construction.

The requested range is start inclusive and end exclusive. The restored
watermark is a processed position, never a position to replay again, so the
window opens at the later of the requested start and the watermark plus one.
"""


def build(start, end, watermark, total):
    window_start = max(int(start), int(watermark))
    window_end = int(end)
    positions = [p for p in range(window_start, min(window_end, total) + 1)]
    return window_start, window_end, positions


def skipped_before(start, watermark):
    return max(0, int(watermark) - int(start) + 1)
