"""Stage r07. Dependency closure across the checkpoint and the window.

The pipe file is the authoritative edge set. The depends_on list inside a
journal record is a convenience copy carried over from an earlier revision and
governs nothing.
"""
from . import reading

PIPE = chr(124)


def _int(text):
    return int(str(text).strip())


def load_edges(root, frozen):
    edges = {}
    for row in reading.read_delim(root / "dependency_edges.psv", PIPE):
        if _int(row["revision"]) > frozen:
            continue
        if row["edge_kind"].strip() != "requires":
            continue
        key = row["event_id"].strip()
        edges.setdefault(key, [])
        target = row["depends_on"].strip()
        if target and target not in edges[key]:
            edges[key].append(target)
    for key in edges:
        edges[key].sort()
    return edges


def cycle_members(events, edges, by_id):
    found = set()
    stack = []
    seen = {}

    def walk(node):
        seen[node] = 1
        stack.append(node)
        for nxt in edges.get(node, []):
            if nxt not in by_id:
                continue
            if seen.get(nxt) == 1:
                cut = stack.index(nxt)
                for member in stack[cut:]:
                    found.add(member)
            elif seen.get(nxt) is None:
                walk(nxt)
        stack.pop()
        seen[node] = 2

    for rec in events:
        if seen.get(rec["event_id"]) is None:
            walk(rec["event_id"])
    return found


def dependency_reason(ctx, rec, window_start, window_end):
    """A dependency already folded into the restored checkpoint is satisfied
    and is never replayed a second time. A dependency that would still have to
    be replayed later in the window is not satisfied."""
    eid = rec["event_id"]
    deps = ctx["edges"].get(eid, [])
    sources = []
    for dep in deps:
        if dep == eid:
            return "DEP-SELF", sources
    if eid in ctx["cycles"]:
        return "DEP-CYCLE", sources
    for dep in deps:
        target = ctx["by_id"].get(dep)
        if target is None:
            return "DEP-MISSING", sources
        pos = int(target["position"])
        if pos < window_start:
            return "DEP-MISSING", sources
        elif pos < int(rec["position"]) and pos < window_end:
            sources.append((dep, "window"))
        else:
            return "DEP-MISSING", sources
    return None, sources
