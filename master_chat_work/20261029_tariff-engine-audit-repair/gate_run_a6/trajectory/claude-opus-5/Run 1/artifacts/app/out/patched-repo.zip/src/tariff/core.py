"""Rating, proration and settlement for the tariff engine.

Every amount is held as an exact :class:`~fractions.Fraction` of the decimal
values written in the input files and is only rounded, half to even, when a
line amount or a total is produced.
"""
import calendar
from fractions import Fraction


def round_cents(value):
    """Round an exact value to whole cents, half to even."""
    scaled = Fraction(value) * 100
    whole = scaled.numerator // scaled.denominator
    rest = scaled - whole
    if rest > Fraction(1, 2):
        return whole + 1
    if rest < Fraction(1, 2):
        return whole
    return whole if whole % 2 == 0 else whole + 1


def money(cents):
    """Format whole cents as an amount with exactly two decimals."""
    sign = "-" if cents < 0 else ""
    cents = abs(cents)
    return f"{sign}{cents // 100}.{cents % 100:02d}"


def rate_tiers(quantity, tiers, offset=0):
    """Split the units at account positions ``offset + 1 .. offset + quantity``.

    Returns (tier number, units, rate) for every tier that receives units.
    """
    rated = []
    low = 0
    top = offset + quantity
    for number, tier in enumerate(tiers, start=1):
        cap = tier["up_to"]
        high = top if cap is None else min(top, cap)
        units = high - max(offset, low)
        if units > 0:
            rated.append((number, units, tier["rate"]))
        if cap is None or top <= cap:
            break
        low = cap
    return rated


def energy_lines(meter, quantity, tiers, offset=0):
    """Energy lines of a meter whose units start at account position ``offset + 1``."""
    return [
        {"meter": meter, "kind": "energy", "tier": number, "units": units,
         "exact": units * rate}
        for number, units, rate in rate_tiers(quantity, tiers, offset)
    ]


def standing_charge(plan, day):
    """Standing charge of one month of supply under ``plan`` on ``day``."""
    charge = plan["standing_charge"]
    latest = None
    for change in plan.get("standing_changes") or ():
        start = change["from"]
        if start <= day and (latest is None or start > latest):
            latest = start
            charge = change["standing_charge"]
    return charge


def standing_line(meter, plan, days):
    """Standing line of a meter over ``days``, its active days of the period."""
    exact = Fraction(0)
    for day in days:
        exact += standing_charge(plan, day) / calendar.monthrange(day.year, day.month)[1]
    return {"meter": meter, "kind": "standing", "tier": 0, "units": len(days), "exact": exact}


def share_allowance(values, allowance):
    """Share ``allowance`` over the exact values of an invoice's energy lines.

    Returns the share of every line and the part of the allowance that no line
    could take.
    """
    shares = [Fraction(0)] * len(values)
    left = list(values)
    pool = Fraction(allowance)
    taking = list(range(len(values)))
    while pool > 0 and taking:
        part = pool / len(taking)
        for index in taking:
            take = part if part < left[index] else left[index]
            shares[index] += take
            left[index] -= take
            pool -= take
        taking = [index for index in taking if left[index] > 0]
    return shares, pool


def settle(line_amounts, commitment, credit_rate, allow_credit):
    """Return (subtotal, credit, total) of an invoice, in whole cents."""
    subtotal = sum(line_amounts)
    total = subtotal
    if allow_credit and Fraction(subtotal, 100) >= commitment:
        total = round_cents(Fraction(subtotal, 100) * (1 - credit_rate))
    return subtotal, subtotal - total, total


def best_vouchers(vouchers, balance):
    """Pick the vouchers whose amounts add up to the largest sum within ``balance``.

    ``vouchers`` pairs a voucher id with its amount in whole cents. A tie is
    broken by the first id list in ascending id order.
    """
    order = sorted(vouchers)
    limit = (1 << (min(balance, sum(cents for _, cents in order)) + 1)) - 1
    reachable = [1]
    for _, cents in reversed(order):
        tail = reachable[-1]
        reachable.append((tail | (tail << cents)) & limit)
    reachable.reverse()
    target = reachable[0].bit_length() - 1
    chosen = []
    for index, (voucher, cents) in enumerate(order):
        if cents <= target and (reachable[index + 1] >> (target - cents)) & 1:
            chosen.append(voucher)
            target -= cents
    return chosen
