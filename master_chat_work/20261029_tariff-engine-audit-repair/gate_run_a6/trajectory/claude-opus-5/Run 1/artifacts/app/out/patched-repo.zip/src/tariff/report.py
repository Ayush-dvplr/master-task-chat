"""Invoice assembly, statements and rendering for the tariff engine."""
import json
from datetime import timedelta
from fractions import Fraction
from pathlib import Path

from . import core, parser

INPUTS = ("meter_reads.jsonl", "accounts.csv", "billing_periods.csv", "rate_card.json")
OPTIONAL = ("payments.csv", "vouchers.csv")


def missing_input(data_dir):
    """Name of the first required input file ``data_dir`` does not hold."""
    root = Path(data_dir)
    for name in INPUTS:
        if not (root / name).is_file():
            return name
    return None


def _text_of(path, default=None):
    if default is not None and not path.is_file():
        return default
    return path.read_text(encoding="utf-8")


def _days(start, end):
    day = start
    while day <= end:
        yield day
        day += timedelta(days=1)


def _load(data_dir):
    """Read every input file of ``data_dir`` into the rating tables."""
    root = Path(data_dir)
    reads = parser.parse_reads(_text_of(root / "meter_reads.jsonl"))
    windows, meters = parser.parse_accounts(_text_of(root / "accounts.csv"))
    rows = parser.parse_periods(_text_of(root / "billing_periods.csv"))
    card = parser.parse_rate_card(_text_of(root / "rate_card.json"))
    payments = parser.parse_payments(_text_of(root / "payments.csv", default=""))
    vouchers = parser.parse_vouchers(_text_of(root / "vouchers.csv", default=""))
    rows_by_account = {}
    for row in rows:
        rows_by_account.setdefault(row["account"], []).append(row)
    for account in rows_by_account:
        rows_by_account[account].sort(key=lambda row: row["start"])
    ranges = {account: [(row["start"], row["end"]) for row in account_rows]
              for account, account_rows in rows_by_account.items()}
    accepted, exceptions = parser.classify(reads, windows, ranges)
    billed = parser.billed_quantities(accepted)
    usage = {}
    for read in accepted:
        usage.setdefault((read["account"], read["meter"]), []).append(
            (read["day"], billed[read["index"]]))
    return {
        "windows": windows,
        "meters": meters,
        "rows": rows,
        "rows_by_account": rows_by_account,
        "card": card,
        "names": parser.plan_names(card),
        "payments": payments,
        "vouchers": vouchers,
        "exceptions": exceptions,
        "usage": usage,
    }


def _invoice(data, row, plan, tiers, carry, allow_credit):
    """Rate one billing period row into (invoice, total in cents, allowance left)."""
    account = row["account"]
    lines = []
    energy = []
    position = 0
    for meter in data["meters"].get(account, ()):
        quantity = sum(units for day, units in data["usage"].get((account, meter), ())
                       if row["start"] <= day <= row["end"])
        meter_lines = core.energy_lines(meter, quantity, tiers, position)
        position += quantity
        lines.extend(meter_lines)
        energy.extend(meter_lines)
        active = [day for day in _days(row["start"], row["end"])
                  if parser.active_on(data["windows"][(account, meter)], day)]
        if active:
            lines.append(core.standing_line(meter, plan, active))
    shares, left = core.share_allowance([line["exact"] for line in energy],
                                        row["allowance"] + carry)
    for line, share in zip(energy, shares):
        line["exact"] -= share
    amounts = [core.round_cents(line["exact"]) for line in lines]
    subtotal, credit, total = core.settle(amounts, row["commitment"],
                                          plan["credit_rate"], allow_credit)
    invoice = {
        "account": account,
        "period": {"start": row["start"].isoformat(), "end": row["end"].isoformat()},
        "plan": row["plan"],
        "lines": [{"meter": line["meter"], "kind": line["kind"], "tier": line["tier"],
                   "units": line["units"], "amount": core.money(cents)}
                  for line, cents in zip(lines, amounts)],
        "subtotal": core.money(subtotal),
        "credit": core.money(credit),
        "total": core.money(total),
    }
    return invoice, total, left


def _rate(data, tiers_by_plan, accounts=None):
    """Rate the invoices of ``accounts``, in document order, as internal records."""
    if accounts is None:
        accounts = sorted(data["rows_by_account"])
    records = []
    for account in accounts:
        carry = Fraction(0)
        previous = None
        for row in data["rows_by_account"][account]:
            name = data["names"][row["plan"]]
            plan = data["card"]["plans"][name]
            allow_credit = not (previous is not None and previous["paid"] is not None
                                and previous["paid"] * 100 < previous["total"])
            invoice, total, carry = _invoice(data, row, plan, tiers_by_plan[name],
                                             carry, allow_credit)
            previous = {
                "total": total,
                "paid": data["payments"].get((account, row["start"])),
            }
            records.append({"invoice": invoice, "row": row, "plan": name,
                            "total": total, "paid": previous["paid"]})
    return records


def _plan_tiers(data):
    """Choose the tiers every plan's invoices are rated with."""
    plans = data["card"]["plans"]
    base = {name: plan["tiers"] for name, plan in plans.items()}
    chosen = dict(base)
    for name in sorted(plans):
        revisions = plans[name]["revisions"]
        if not revisions:
            continue
        accounts = sorted({row["account"] for row in data["rows"]
                           if data["names"][row["plan"]] == name})
        matching = [revision["tiers"] for revision in revisions
                    if _paid_as_rated(data, {**base, name: revision["tiers"]}, accounts, name)]
        if len(matching) == 1:
            chosen[name] = matching[0]
    return chosen


def _paid_as_rated(data, tiers_by_plan, accounts, name):
    """Tell whether every paid invoice on plan ``name`` totals its paid amount."""
    for record in _rate(data, tiers_by_plan, accounts):
        if record["plan"] != name or record["paid"] is None:
            continue
        if record["paid"] * 100 != record["total"]:
            return False
    return True


def _records(data_dir):
    data = _load(data_dir)
    return data, _rate(data, _plan_tiers(data))


def build_invoices(data_dir):
    """Rate every billing period of ``data_dir`` and return the invoice document."""
    data, records = _records(data_dir)
    return {"invoices": [record["invoice"] for record in records],
            "exceptions": data["exceptions"]}


def build_statements(data_dir):
    """Settle the vouchers of ``data_dir`` and return the statement document."""
    data, records = _records(data_dir)
    balances = {}
    for record in records:
        account = record["row"]["account"]
        paid = 0 if record["paid"] is None else record["paid"] * 100
        balances[account] = balances.get(account, 0) + record["total"] - paid
    statements = []
    for account in sorted(data["vouchers"]):
        balance = max(int(balances.get(account, 0)), 0)
        vouchers = [(voucher, int(amount * 100)) for voucher, amount in data["vouchers"][account]]
        redeemed = core.best_vouchers(vouchers, balance)
        taken = sum(cents for voucher, cents in vouchers if voucher in set(redeemed))
        statements.append({
            "account": account,
            "balance": core.money(balance),
            "redeemed": redeemed,
            "due": core.money(balance - taken),
        })
    return {"statements": statements}


def render(document):
    """Return a document as JSON text."""
    return json.dumps(document, indent=2, sort_keys=True)
