"""Input parsing and read classification for the tariff engine."""
import csv
import io
import json
from datetime import date
from fractions import Fraction

REASONS = (
    "malformed_quantity",
    "unknown_meter",
    "inactive_meter",
    "outside_period",
    "duplicate_read",
    "replaced_estimate",
)


def _text(value):
    return str(value).strip()


def _day(value):
    return date.fromisoformat(_text(value))


def _decimal(value):
    if isinstance(value, Fraction):
        return value
    return Fraction(_text(value))


def _flag(value):
    return value is True


def _quantity(value):
    """Return the metered quantity, or None when the read is unusable.

    Only a JSON integer of 0 or more is a usable quantity; text, a decimal,
    a boolean and a negative number are all malformed.
    """
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        return None
    return value


def rows(text):
    """Parse CSV text into dicts whose keys and values carry no outer spaces."""
    reader = csv.DictReader(io.StringIO(text, newline=""))
    return [{_text(key): _text(value or "") for key, value in row.items()} for row in reader]


def parse_reads(text):
    """Parse meter_reads.jsonl text into read dicts in file order."""
    reads = []
    for line in text.splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        reads.append({
            "index": len(reads),
            "read_id": _text(row["read_id"]),
            "account": _text(row["account"]),
            "meter": _text(row["meter"]),
            "day": _day(row["day"]),
            "quantity": _quantity(row.get("quantity")),
            "estimated": _flag(row.get("estimated")),
            "cumulative": _flag(row.get("cumulative")),
        })
    return reads


def parse_accounts(text):
    """Parse accounts.csv into the activity windows and the meters of each account.

    Returns a mapping of (account, meter) to its list of (active_from,
    active_to) windows, where an open window ends with None, and a mapping of
    an account to its meters in ascending order.
    """
    windows = {}
    meters = {}
    for row in rows(text):
        key = (row["account"], row["meter"])
        end = _day(row["active_to"]) if row["active_to"] else None
        windows.setdefault(key, []).append((_day(row["active_from"]), end))
        meters.setdefault(row["account"], set()).add(row["meter"])
    return windows, {account: sorted(names) for account, names in meters.items()}


def parse_periods(text):
    """Parse billing_periods.csv into one billing period row per invoice."""
    return [{
        "account": row["account"],
        "start": _day(row["start"]),
        "end": _day(row["end"]),
        "plan": row["plan"],
        "commitment": _decimal(row["commitment"]),
        "allowance": _decimal(row["allowance"]),
    } for row in rows(text)]


def parse_rate_card(text):
    """Parse rate_card.json, holding every rate and charge as an exact decimal."""
    card = json.loads(text, parse_float=Fraction)
    plans = {}
    for name, plan in card["plans"].items():
        entry = {
            "standing_charge": _decimal(plan["standing_charge"]),
            "credit_rate": _decimal(plan["credit_rate"]),
            "tiers": _tiers(plan["tiers"]),
            "codes": [_text(code) for code in plan.get("codes") or ()],
            "standing_changes": sorted(
                ({"from": _day(change["from"]),
                  "standing_charge": _decimal(change["standing_charge"])}
                 for change in plan.get("standing_changes") or ()),
                key=lambda change: change["from"]),
            "revisions": [{"tiers": _tiers(revision["tiers"])}
                          for revision in plan.get("revisions") or ()],
        }
        plans[_text(name)] = entry
    return {"currency": _text(card.get("currency", "")), "plans": plans}


def _tiers(tiers):
    return [{"up_to": None if tier["up_to"] is None else int(tier["up_to"]),
             "rate": _decimal(tier["rate"])} for tier in tiers]


def plan_names(card):
    """Map every name and code of the rate card to the plan it names."""
    names = {}
    for name, plan in card["plans"].items():
        names[name] = name
        for code in plan["codes"]:
            names[code] = name
    return names


def parse_payments(text):
    """Parse payments.csv into the paid amount of each (account, period start)."""
    paid = {}
    for row in rows(text):
        key = (row["account"], _day(row["start"]))
        paid[key] = paid.get(key, Fraction(0)) + _decimal(row["paid"])
    return paid


def parse_vouchers(text):
    """Parse vouchers.csv into the vouchers of each account."""
    vouchers = {}
    for row in rows(text):
        vouchers.setdefault(row["account"], []).append((row["voucher"], _decimal(row["amount"])))
    return vouchers


def active_on(windows, day):
    """Tell whether one of the activity ``windows`` covers ``day``."""
    return any(start <= day and (end is None or day <= end) for start, end in windows)


def _within(ranges, day):
    return any(start <= day <= end for start, end in ranges)


def classify(reads, meters, periods):
    """Split reads into accepted reads and exception rows.

    ``meters`` maps (account, meter) to its activity windows and ``periods``
    maps an account to its billing period ranges. Exception rows come back
    sorted by read id.
    """
    reasons = {}
    accepted_keys = set()
    for pass_estimated in (False, True):
        for read in reads:
            if read["estimated"] is not pass_estimated:
                continue
            key = (read["account"], read["meter"])
            day = read["day"]
            if read["quantity"] is None:
                reason = "malformed_quantity"
            elif key not in meters:
                reason = "unknown_meter"
            elif not active_on(meters[key], day):
                reason = "inactive_meter"
            elif not _within(periods.get(read["account"], ()), day):
                reason = "outside_period"
            elif (key[0], key[1], day, read["estimated"]) in accepted_keys:
                reason = "duplicate_read"
            elif read["estimated"] and (key[0], key[1], day, False) in accepted_keys:
                reason = "replaced_estimate"
            else:
                reason = None
            if reason is None:
                accepted_keys.add((key[0], key[1], day, read["estimated"]))
            else:
                reasons[read["index"]] = reason
    accepted = [read for read in reads if read["index"] not in reasons]
    exceptions = sorted(
        ({"read_id": reads[index]["read_id"],
          "account": reads[index]["account"],
          "reason": reason} for index, reason in reasons.items()),
        key=lambda row: row["read_id"])
    return accepted, exceptions


def billed_quantities(accepted):
    """Map the index of every accepted read to its billed quantity.

    A cumulative read bills the rise over the accepted cumulative read of the
    same account and meter on the latest earlier day.
    """
    billed = {read["index"]: read["quantity"] for read in accepted if not read["cumulative"]}
    previous = {}
    order = sorted((read for read in accepted if read["cumulative"]),
                   key=lambda read: (read["account"], read["meter"], read["day"], read["index"]))
    for read in order:
        key = (read["account"], read["meter"])
        before = previous.get(key)
        if before is None or before > read["quantity"]:
            billed[read["index"]] = read["quantity"] if before is not None else 0
        else:
            billed[read["index"]] = read["quantity"] - before
        previous[key] = read["quantity"]
    return billed
