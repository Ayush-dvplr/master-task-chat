# tariff

`tariff` rates the meter reads of a billing run into customer invoices.

    PYTHONPATH=src python3 -m tariff /path/to/data
    PYTHONPATH=src python3 -m tariff --statements /path/to/data

The data directory holds `meter_reads.jsonl`, `accounts.csv`,
`billing_periods.csv` and `rate_card.json`, and may also hold `payments.csv`
and `vouchers.csv`. The first command prints one JSON document with an
`invoices` list and an `exceptions` list; `--statements` prints the voucher
statements instead. A missing input file is reported on standard error as
`missing input: <file name>` and exits 2.

Every row of `billing_periods.csv` is billed as its own invoice. An invoice
carries one energy line per tier the account positions of a meter reach and one
standing line per meter, prorated over the days of the calendar month of each
active day. The period allowance is shared over the energy lines, and an
invoice whose subtotal reaches its commitment receives the plan's commitment
credit, unless the account's previous invoice was underpaid. Every amount is
written as a string with two decimals.

Run the unit tests with:

    PYTHONPATH=src python3 -m unittest discover -s tests -v
