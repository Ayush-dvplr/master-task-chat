# tariff

`tariff` rates the meter reads of a billing run into customer invoices, using
the Python standard library only.

    PYTHONPATH=src python3 -m tariff /path/to/data
    PYTHONPATH=src python3 -m tariff --statements /path/to/data

The data directory holds `meter_reads.jsonl`, `accounts.csv`,
`billing_periods.csv` and `rate_card.json`, and may hold `payments.csv` and
`vouchers.csv`. The first command prints one JSON document with an `invoices`
list and an `exceptions` list; the second prints the voucher statements of the
accounts listed in `vouchers.csv`. A missing input file is reported on standard
error as `missing input: <file name>` and exits 2.

Each row of `billing_periods.csv` is billed as its own invoice. A meter carries
one energy line per tier its units reach, the tiers being walked over the
account's meters in ascending meter order, and one standing line prorated over
the days of each day's own month. The invoice allowance is shared in equal
parts among the energy lines and what no line can take moves to the account's
next invoice. An invoice whose subtotal reaches its commitment receives the
plan's commitment credit, unless the account's previous invoice was underpaid.
Every amount is written as a string with two decimals, rounded half to even.

Run the unit tests with:

    PYTHONPATH=src python3 -m unittest discover -s tests -v
