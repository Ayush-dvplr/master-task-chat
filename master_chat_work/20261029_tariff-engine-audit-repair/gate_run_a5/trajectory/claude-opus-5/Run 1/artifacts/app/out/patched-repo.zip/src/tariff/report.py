"""Invoice assembly, statements and rendering for the tariff engine."""
import csv
import json
from datetime import date, timedelta
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

from . import core, parser

INPUTS = ("meter_reads.jsonl", "accounts.csv", "billing_periods.csv", "rate_card.json")
ZERO = Decimal("0.00")


def _rows(path):
    """Read a CSV file into dicts with every key and value stripped."""
    with open(path, newline="", encoding="utf-8") as handle:
        return [{(key or "").strip(): (value or "").strip() for key, value in row.items()}
                for row in csv.DictReader(handle)]


def _plan_lookup(plans):
    """Map every plan name and plan code to the plan it names."""
    lookup = {name: name for name in plans}
    for name, plan in plans.items():
        for code in plan.get("codes") or []:
            lookup.setdefault(str(code).strip(), name)
    return lookup


def _load(data_dir):
    """Read every input file of ``data_dir``."""
    root = Path(data_dir)
    card = json.loads((root / "rate_card.json").read_text(encoding="utf-8"),
                      parse_float=Decimal)
    plans = {str(name).strip(): plan for name, plan in card["plans"].items()}
    meters = {}
    for row in _rows(root / "accounts.csv"):
        end = date.fromisoformat(row["active_to"]) if row["active_to"] else None
        meters.setdefault((row["account"], row["meter"]), []).append(
            (date.fromisoformat(row["active_from"]), end))
    billing = {}
    for row in _rows(root / "billing_periods.csv"):
        billing.setdefault(row["account"], []).append({
            "account": row["account"],
            "start": date.fromisoformat(row["start"]),
            "end": date.fromisoformat(row["end"]),
            "plan": row["plan"],
            "commitment": Decimal(row["commitment"]),
            "allowance": Decimal(row["allowance"]),
        })
    for rows in billing.values():
        rows.sort(key=lambda row: row["start"])
    payments = {}
    if (root / "payments.csv").exists():
        for row in _rows(root / "payments.csv"):
            key = (row["account"], date.fromisoformat(row["start"]))
            payments[key] = payments.get(key, ZERO) + Decimal(row["paid"])
    vouchers = {}
    if (root / "vouchers.csv").exists():
        for row in _rows(root / "vouchers.csv"):
            vouchers.setdefault(row["account"], []).append(
                (row["voucher"], Decimal(row["amount"])))
    return {
        "reads": parser.parse_reads((root / "meter_reads.jsonl").read_text(encoding="utf-8")),
        "meters": meters,
        "billing": billing,
        "plans": plans,
        "lookup": _plan_lookup(plans),
        "payments": payments,
        "vouchers": vouchers,
    }


def _active_days(windows, start, end):
    """The days from ``start`` to ``end`` on which a meter is active."""
    days = []
    day = start
    while day <= end:
        if parser.is_active(windows, day):
            days.append(day)
        day += timedelta(days=1)
    return days


def _drafts(data):
    """Classify the reads and draft every invoice except its energy lines."""
    periods = {account: [(row["start"], row["end"]) for row in rows]
               for account, rows in data["billing"].items()}
    accepted, exceptions = parser.classify(data["reads"], data["meters"], periods)
    billed = parser.billed_quantities(accepted)
    usage = {}
    for read in accepted:
        for row in data["billing"][read["account"]]:
            if row["start"] <= read["day"] <= row["end"]:
                key = (read["account"], row["start"], read["meter"])
                usage[key] = usage.get(key, 0) + billed[read["read_id"]]
                break
    drafts = []
    for account in sorted(data["billing"]):
        names = sorted(meter for owner, meter in data["meters"] if owner == account)
        for row in data["billing"][account]:
            name = data["lookup"][row["plan"]]
            plan = data["plans"][name]
            meters = []
            for meter in names:
                days = _active_days(data["meters"][(account, meter)], row["start"], row["end"])
                meters.append({
                    "meter": meter,
                    "quantity": usage.get((account, row["start"], meter), 0),
                    "standing": core.standing_line(meter, plan, days) if days else None,
                })
            drafts.append({"row": row, "plan": plan, "plan_name": name, "meters": meters})
    return drafts, exceptions


def _assemble(drafts, tiers, payments):
    """Rate every draft with ``tiers`` and return the invoice list."""
    invoices = []
    carried = {}
    previous = {}
    for draft in drafts:
        row = draft["row"]
        account = row["account"]
        allowance = Fraction(row["allowance"]) + carried.get(account, Fraction(0))
        lines = []
        energy = []
        offset = 0
        for entry in draft["meters"]:
            for line in core.energy_lines(entry["meter"], offset, entry["quantity"],
                                          tiers[draft["plan_name"]]):
                energy.append(len(lines))
                lines.append(line)
            offset += entry["quantity"]
            if entry["standing"] is not None:
                lines.append(entry["standing"])
        shares, carried[account] = core.share_allowance(
            [lines[index]["value"] for index in energy], allowance)
        taken = dict(zip(energy, shares))
        billed_lines = [{
            "meter": line["meter"], "kind": line["kind"], "tier": line["tier"],
            "units": line["units"],
            "amount": core.money(line["value"] - taken.get(index, 0)),
        } for index, line in enumerate(lines)]
        subtotal = sum((Decimal(line["amount"]) for line in billed_lines), ZERO)
        last = previous.get(account)
        allowed = True
        if last is not None:
            paid = payments.get((account, last[0]))
            allowed = paid is None or paid >= last[1]
        credit, total = core.settle(subtotal, row["commitment"],
                                    draft["plan"]["credit_rate"], allowed)
        previous[account] = (row["start"], total)
        invoices.append({
            "account": account,
            "period": {"start": row["start"].isoformat(), "end": row["end"].isoformat()},
            "plan": row["plan"],
            "lines": billed_lines,
            "subtotal": f"{subtotal:.2f}",
            "credit": f"{credit:.2f}",
            "total": f"{total:.2f}",
        })
    return invoices


def _paid_as_billed(drafts, invoices, name, payments):
    """Whether every paid invoice on plan ``name`` totals its paid amount."""
    for draft, invoice in zip(drafts, invoices):
        if draft["plan_name"] != name:
            continue
        paid = payments.get((invoice["account"], draft["row"]["start"]))
        if paid is not None and paid != Decimal(invoice["total"]):
            return False
    return True


def _choose_tiers(data, drafts, payments):
    """Pick the tier list every plan's invoices are rated with.

    A plan is rated with the tiers of its single revision that explains every
    paid amount on the plan, and with its own tiers otherwise.
    """
    chosen = {name: plan["tiers"] for name, plan in data["plans"].items()}
    revised = {name: plan["revisions"] for name, plan in data["plans"].items()
               if plan.get("revisions")}
    for _ in range(len(revised) + 1):
        settled = True
        for name, revisions in revised.items():
            matching = [revision["tiers"] for revision in revisions
                        if _paid_as_billed(drafts,
                                           _assemble(drafts, {**chosen, name: revision["tiers"]},
                                                     payments),
                                           name, payments)]
            pick = matching[0] if len(matching) == 1 else data["plans"][name]["tiers"]
            if pick is not chosen[name]:
                chosen[name] = pick
                settled = False
        if settled:
            break
    return chosen


def _rate(data):
    """Return (invoices, exceptions) of a loaded data directory."""
    drafts, exceptions = _drafts(data)
    tiers = _choose_tiers(data, drafts, data["payments"])
    return _assemble(drafts, tiers, data["payments"]), exceptions


def _redeem(balance, vouchers):
    """The vouchers whose amounts add up to the largest sum within ``balance``.

    Ties go to the set whose ids come first one by one, so the smallest id is
    taken whenever the same sum stays reachable without it.
    """
    amounts = [int(amount * 100) for _, amount in vouchers]
    limit = min(int(balance * 100), sum(amounts))
    mask = (1 << (limit + 1)) - 1
    reach = [1] * (len(amounts) + 1)
    for index in range(len(amounts) - 1, -1, -1):
        reach[index] = (reach[index + 1] | (reach[index + 1] << amounts[index])) & mask
    redeemed = reach[0].bit_length() - 1
    left = redeemed
    taken = []
    for index, amount in enumerate(amounts):
        if amount <= left and (reach[index + 1] >> (left - amount)) & 1:
            taken.append(vouchers[index][0])
            left -= amount
    return taken, Decimal(redeemed).scaleb(-2)


def build_invoices(data_dir):
    """Rate every billing period of ``data_dir`` and return the invoice document."""
    invoices, exceptions = _rate(_load(data_dir))
    return {"invoices": invoices, "exceptions": exceptions}


def build_statements(data_dir):
    """Return the voucher statement document of ``data_dir``."""
    data = _load(data_dir)
    invoices, _ = _rate(data)
    owing = {}
    for invoice in invoices:
        account = invoice["account"]
        start = date.fromisoformat(invoice["period"]["start"])
        owing[account] = (owing.get(account, ZERO) + Decimal(invoice["total"])
                          - data["payments"].get((account, start), ZERO))
    statements = []
    for account in sorted(data["vouchers"]):
        balance = max(owing.get(account, ZERO), ZERO)
        taken, redeemed = _redeem(balance, sorted(data["vouchers"][account]))
        statements.append({
            "account": account,
            "balance": f"{balance:.2f}",
            "redeemed": taken,
            "due": f"{balance - redeemed:.2f}",
        })
    return {"statements": statements}


def render(document):
    """Return a document as JSON text."""
    return json.dumps(document, indent=2, sort_keys=True)
