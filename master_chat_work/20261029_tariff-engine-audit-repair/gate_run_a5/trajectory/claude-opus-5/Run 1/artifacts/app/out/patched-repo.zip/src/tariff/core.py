"""Rating, proration and settlement for the tariff engine."""
import calendar
from datetime import date
from decimal import Decimal
from fractions import Fraction


def rounded(value):
    """Round an exact value half to even to 0.01."""
    exact = Fraction(value)
    units, remainder = divmod(exact.numerator * 100, exact.denominator)
    doubled = 2 * remainder
    if doubled > exact.denominator or (doubled == exact.denominator and units % 2):
        units += 1
    return Decimal(units).scaleb(-2)


def money(value):
    """Render an exact value as an amount with two decimals."""
    return f"{rounded(value):.2f}"


def rate_tiers(offset, quantity, tiers):
    """Split ``quantity`` units starting at account position ``offset`` + 1.

    Returns (tier number, units, rate) for every tier that receives units.
    Tier 1 covers the positions 1 to its ``up_to`` included, every later tier
    the positions above the previous ``up_to`` to its own included.
    """
    rated = []
    floor = 0
    top = offset + quantity
    for number, tier in enumerate(tiers, start=1):
        cap = tier["up_to"]
        low = max(floor, offset)
        high = top if cap is None else min(top, cap)
        if high > low:
            rated.append((number, high - low, tier["rate"]))
        if cap is None or cap >= top:
            break
        floor = cap
    return rated


def energy_lines(meter, offset, quantity, tiers):
    """One line per tier that covers some of a meter's units."""
    return [
        {"meter": meter, "kind": "energy", "tier": number, "units": units,
         "value": units * Fraction(rate)}
        for number, units, rate in rate_tiers(offset, quantity, tiers)
    ]


def standing_charge(plan, day):
    """The standing charge of the plan in force on ``day``."""
    charge = plan["standing_charge"]
    latest = None
    for change in plan.get("standing_changes") or []:
        start = date.fromisoformat(str(change["from"]).strip())
        if start <= day and (latest is None or start > latest):
            latest = start
            charge = change["standing_charge"]
    return Fraction(charge)


def standing_line(meter, plan, days):
    """Standing line of a meter prorated over the days of each day's month."""
    value = sum(
        (standing_charge(plan, day) / calendar.monthrange(day.year, day.month)[1]
         for day in days),
        Fraction(0),
    )
    return {"meter": meter, "kind": "standing", "tier": 0, "units": len(days),
            "value": value}


def share_allowance(values, allowance):
    """Spread ``allowance`` over the exact energy values.

    Every energy line takes an equal part of the allowance, never more than its
    exact value; whatever stays unshared is spread again among the lines that
    are not yet at zero. Returns (shares, unshared).
    """
    shares = [Fraction(0)] * len(values)
    left = Fraction(allowance)
    taking = list(range(len(values)))
    while left > 0 and taking:
        part = left / len(taking)
        for index in taking:
            share = min(part, values[index] - shares[index])
            shares[index] += share
            left -= share
        taking = [index for index in taking if values[index] > shares[index]]
    return shares, left


def settle(subtotal, commitment, credit_rate, allowed):
    """Return (credit, total) of an invoice from its subtotal."""
    if allowed and subtotal >= commitment:
        total = rounded(subtotal * (1 - credit_rate))
        return subtotal - total, total
    return Decimal("0.00"), subtotal
