"""Command line entry: python -m tariff [--statements] DATA_DIR"""
import sys
from pathlib import Path

from .report import INPUTS, build_invoices, build_statements, render


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    statements = "--statements" in args
    data_dir = Path([arg for arg in args if arg != "--statements"][0])
    for name in INPUTS:
        if not (data_dir / name).exists():
            sys.stderr.write(f"missing input: {name}\n")
            return 2
    document = build_statements(data_dir) if statements else build_invoices(data_dir)
    sys.stdout.write(render(document) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
