"""Meter read parsing and read classification for the tariff engine."""
import json
from datetime import date

REASONS = (
    "malformed_quantity",
    "unknown_meter",
    "inactive_meter",
    "outside_period",
    "duplicate_read",
    "replaced_estimate",
)


def _text(value):
    return str(value).strip()


def _quantity(value):
    """Return the metered quantity, or None when the read is unusable.

    Only a JSON integer of 0 or more is a quantity: text, a decimal number and
    ``true``/``false`` are all malformed.
    """
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        return None
    return value


def parse_reads(text):
    """Parse meter_reads.jsonl text into read dicts in file order."""
    reads = []
    for line in text.splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        reads.append({
            "read_id": _text(row["read_id"]),
            "account": _text(row["account"]),
            "meter": _text(row["meter"]),
            "day": date.fromisoformat(_text(row["day"])),
            "quantity": _quantity(row.get("quantity")),
            "estimated": bool(row.get("estimated", False)),
            "cumulative": bool(row.get("cumulative", False)),
        })
    return reads


def is_active(windows, day):
    """Whether any activity window of a meter holds ``day``."""
    return any(start <= day and (end is None or day <= end) for start, end in windows)


def _in_period(periods, day):
    return any(start <= day <= end for start, end in periods)


def _reason(read, meters, periods):
    """The first exception of the read that does not depend on other reads."""
    key = (read["account"], read["meter"])
    if read["quantity"] is None:
        return "malformed_quantity"
    if key not in meters:
        return "unknown_meter"
    if not is_active(meters[key], read["day"]):
        return "inactive_meter"
    if not _in_period(periods.get(read["account"], ()), read["day"]):
        return "outside_period"
    return None


def classify(reads, meters, periods):
    """Split reads into accepted reads and exception rows.

    ``meters`` maps (account, meter) to its list of activity windows and
    ``periods`` maps an account to its list of (start, end) billing periods.
    Measured reads are settled before estimated ones, because only an
    estimated read can be replaced by a measured read of the same day.
    """
    reasons = {}
    accepted_days = set()
    for estimated in (False, True):
        for index, read in enumerate(reads):
            if read["estimated"] is not estimated:
                continue
            day = (read["account"], read["meter"], read["day"])
            reason = _reason(read, meters, periods)
            if reason is None and day + (estimated,) in accepted_days:
                reason = "duplicate_read"
            if reason is None and estimated and day + (False,) in accepted_days:
                reason = "replaced_estimate"
            if reason is None:
                accepted_days.add(day + (estimated,))
            else:
                reasons[index] = reason
    accepted = [read for index, read in enumerate(reads) if index not in reasons]
    exceptions = sorted(
        ({"read_id": reads[index]["read_id"], "account": reads[index]["account"],
          "reason": reason} for index, reason in reasons.items()),
        key=lambda row: row["read_id"],
    )
    return accepted, exceptions


def billed_quantities(accepted):
    """The billed quantity of every accepted read, by ``read_id``.

    A cumulative read bills the rise over the previous accepted cumulative
    read of its meter: nothing for the first one, and its whole quantity when
    the meter was reset.
    """
    billed = {}
    previous = {}
    for read in sorted(accepted, key=lambda read: (read["account"], read["meter"], read["day"])):
        quantity = read["quantity"]
        if read["cumulative"]:
            key = (read["account"], read["meter"])
            earlier = previous.get(key)
            if earlier is None:
                quantity = 0
            elif earlier <= read["quantity"]:
                quantity = read["quantity"] - earlier
            previous[key] = read["quantity"]
        billed[read["read_id"]] = quantity
    return billed
