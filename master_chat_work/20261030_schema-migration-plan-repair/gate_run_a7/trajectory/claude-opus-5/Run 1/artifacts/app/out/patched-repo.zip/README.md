# migrakit

Upgrades historical partner records to the canonical schema of their domain
through a graph of migration edges. Standard library only, Python 3.12.

Layout:

- `src/migrakit/parser/`: contract folder reader, feed reader, correction log
  reader, partner identity.
- `src/migrakit/core/`: field states (`records.py`), edge operations,
  planner, executor, replay fingerprint.
- `src/migrakit/report/`: record classification and the run summary.
- `src/migrakit/pipeline.py`: the end-to-end run.
- `src/migrakit/cli.py`: `python -m migrakit run ...`.

Field policy: an explicit null counts as present or absent according to the
`null_counts_as` column of `field_policy.tsv` when that column is not empty,
otherwise according to `[presence] explicit_null` in `null_semantics.ini`
(`null_counts_as` in `core/records.py`). The fill mode of `add:f` is read the
same way, from the `fill` column, otherwise from `[fill] mode`.

Run the visible tests from the repository root:

    PYTHONPATH=src python -m unittest discover -s tests
