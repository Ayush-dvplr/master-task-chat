"""Migration planning over (schema, field state)."""

from __future__ import annotations

import heapq

from ..errors import MigrationError
from ..parser.contracts import Edge, Registry
from .operations import apply_operations
from .records import ABSENT, NULL, FieldView, edge_allowed

_STAND_IN_VALUE = "<value>"


def state_signature(registry: Registry, schema_id: str, payload: dict) -> dict[str, str]:
    """State of every prerequisite field of the record's domain, sorted by name."""
    domain = registry.domain_of(schema_id)
    return FieldView.from_payload(payload).signature(registry.prerequisite_fields(domain))


def _stand_in(names: list[str], state: tuple[str, ...]) -> dict:
    return {
        name: (None if value == NULL else _STAND_IN_VALUE)
        for name, value in zip(names, state)
        if value != ABSENT
    }


def _advance(
    registry: Registry, domain: str, names: list[str], state: tuple[str, ...], edge: Edge
) -> tuple[str, ...]:
    record = apply_operations(registry, domain, _stand_in(names, state), edge.operations)
    return FieldView.from_payload(record).states(names)


def _better(best: tuple[int, list[str]] | None, candidate: tuple[int, list[str]]) -> tuple[int, list[str]]:
    """Prefer the cheaper plan, then the one whose edge ids compare smaller (M8)."""
    if best is None or candidate < best:
        return candidate
    return best


def _enumerate_paths(
    registry: Registry,
    domain: str,
    names: list[str],
    source: str,
    target: str,
    state: tuple[str, ...],
) -> list[str] | None:
    """Best plan (M8) from ``source`` to ``target``, or None when none applies.

    A label is (total cost, edge ids). Labels extend by the same suffix in the
    order they compare in, and equal-cost labels on one (schema, field state)
    are never prefixes of each other because every cost is positive, so keeping
    only the best label per (schema, field state) cannot lose the best plan.
    """
    reaching = registry.reaching(domain, target)
    if source not in reaching:
        return None
    best: dict[tuple[str, tuple[str, ...]], tuple[int, list[str]]] = {(source, state): (0, [])}
    queue: list[tuple[int, list[str], str, tuple[str, ...]]] = [(0, [], source, state)]
    while queue:
        cost, path, node, node_state = heapq.heappop(queue)
        if node == target:
            return path
        if best.get((node, node_state)) != (cost, path):
            continue
        view = FieldView(dict(zip(names, node_state)))
        for edge in registry.edges_from.get(node, ()):
            if edge.target not in reaching or not edge_allowed(registry, domain, view, edge):
                continue
            following = _advance(registry, domain, names, node_state, edge)
            candidate = (cost + edge.cost, path + [edge.edge_id])
            key = (edge.target, following)
            if _better(best.get(key), candidate) is candidate:
                best[key] = candidate
                heapq.heappush(queue, (candidate[0], candidate[1], edge.target, following))
    return None


def plan_migration(registry: Registry, schema_id: str, payload: dict) -> list[str]:
    """Cheapest plan to the canonical schema."""
    domain = registry.domain_of(schema_id)
    target = registry.canonical.get(domain)
    if target is None:
        raise MigrationError("E_UNREACHABLE", f"domain {domain} has no canonical schema")
    if schema_id == target:
        return []
    names = registry.named_fields(domain)
    origin = FieldView.from_payload(payload)
    plan = _enumerate_paths(registry, domain, names, schema_id, target, origin.states(names))
    if plan is None:
        raise MigrationError("E_UNREACHABLE", f"no feasible plan from {schema_id} to {target}")
    return plan
