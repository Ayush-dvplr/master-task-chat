"""Meter read parsing and read classification for the tariff engine."""
import json
from datetime import date

REASONS = (
    "malformed_quantity",
    "unknown_meter",
    "inactive_meter",
    "outside_period",
    "duplicate_read",
)


def _text(value):
    return str(value).strip()


def _quantity(value):
    """Return the quantity when it is a JSON integer of 0 or more, else None.

    A JSON string, a number written with a decimal point or an exponent,
    true, false, null and negative integers are all malformed.
    """
    if type(value) is int and value >= 0:
        return value
    return None


def parse_reads(text):
    """Parse meter_reads.jsonl text into read dicts in file order."""
    reads = []
    for line in text.splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        reads.append({
            "read_id": _text(row["read_id"]),
            "account": _text(row["account"]),
            "meter": _text(row["meter"]),
            "day": date.fromisoformat(_text(row["day"])),
            "quantity": _quantity(row["quantity"]),
        })
    return reads


def _active(window, day):
    start, end = window
    return start <= day and (end is None or day <= end)


def _reason(read, meters, periods, seen):
    key = (read["account"], read["meter"])
    if read["quantity"] is None:
        return "malformed_quantity"
    if key not in meters:
        return "unknown_meter"
    if not _active(meters[key], read["day"]):
        return "inactive_meter"
    period = periods[read["account"]]
    if not period["start"] <= read["day"] <= period["end"]:
        return "outside_period"
    if key + (read["day"],) in seen:
        return "duplicate_read"
    return None


def classify(reads, meters, periods):
    """Split reads into accepted reads and exception rows.

    ``meters`` maps (account, meter) to its (active_from, active_to) window and
    ``periods`` maps an account to its billing period row.  Each read gets the
    first exception of the contract list that applies.
    """
    accepted = []
    exceptions = []
    seen = set()
    for read in reads:
        reason = _reason(read, meters, periods, seen)
        if reason is None:
            seen.add((read["account"], read["meter"], read["day"]))
            accepted.append(read)
        else:
            exceptions.append({
                "read_id": read["read_id"],
                "account": read["account"],
                "reason": reason,
            })
    return accepted, exceptions
