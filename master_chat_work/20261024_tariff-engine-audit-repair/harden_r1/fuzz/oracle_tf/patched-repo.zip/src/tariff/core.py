"""Rating, proration and settlement for the tariff engine.

Every figure is a Decimal built from the values as written in the input
files; each line is rounded half to even to 0.01 once.
"""
from decimal import ROUND_HALF_EVEN, Decimal

CENT = Decimal("0.01")


def money(value):
    """Round an exact amount half to even to 0.01."""
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_EVEN)


def rate_tiers(quantity, tiers):
    """Split a period quantity across the plan tiers.

    Tier n covers the quantity above the previous ``up_to`` up to and
    including its own.  Returns (tier number, units, rate) for every tier
    that receives units.
    """
    rated = []
    floor = 0
    for number, tier in enumerate(tiers, start=1):
        cap = tier["up_to"]
        top = quantity if cap is None else min(quantity, cap)
        if top > floor:
            rated.append((number, top - floor, tier["rate"]))
        if cap is None or quantity <= cap:
            break
        floor = cap
    return rated


def energy_lines(meter, quantity, plan):
    return [
        {"meter": meter, "kind": "energy", "tier": number, "units": units,
         "amount": money(units * rate)}
        for number, units, rate in rate_tiers(quantity, plan["tiers"])
    ]


def standing_line(meter, plan, active_days, month_days):
    """Standing charge of a meter, prorated over the days of the billing period."""
    exact = plan["standing_charge"] * active_days / month_days
    return {"meter": meter, "kind": "standing", "tier": 0, "units": active_days,
            "amount": money(exact)}


def settle(lines, plan, commitment):
    """Return (subtotal, credit, total) for an invoice.

    The commitment credit is computed on the sum of the accepted, rated,
    prorated line amounts; the total is rounded once and the credit is the
    difference.
    """
    subtotal = sum((line["amount"] for line in lines), Decimal("0.00"))
    if subtotal >= commitment:
        total = money(subtotal * (1 - plan["credit_rate"]))
    else:
        total = subtotal
    return subtotal, subtotal - total, total
