import unittest

from quillfen.records import Origin, RateRow
from quillfen.report.penalty import RateCard, bucket, lateness_minutes
from quillfen.timebase import instant


class MoneyTests(unittest.TestCase):
    def test_bucket_bands(self):
        self.assertEqual(bucket(0), "B0")
        self.assertEqual(bucket(45), "B30")
        self.assertEqual(bucket(600), "B120")

    def test_whole_minute_lateness(self):
        self.assertEqual(lateness_minutes(7200), 120)

    def test_latest_rate_row_applies(self):
        o = Origin("ratecard.fwf", 1)
        card = RateCard([RateRow(2, "B30", instant(2026, 1, 1), "2", "1", o),
                         RateRow(2, "B30", instant(2026, 3, 1), "5", "2", o)])
        self.assertEqual(card.price(2, "B30", instant(2026, 2, 1), 40), 200 + 100 * 40)
        self.assertEqual(card.price(2, "B30", instant(2026, 3, 2), 40), 500 + 200 * 40)
        self.assertEqual(card.price(1, "B30", instant(2026, 3, 2), 40), 0)


if __name__ == "__main__":
    unittest.main()
