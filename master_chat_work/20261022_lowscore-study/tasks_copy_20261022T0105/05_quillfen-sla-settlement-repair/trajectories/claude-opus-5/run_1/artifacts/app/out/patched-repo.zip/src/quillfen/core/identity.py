"""Job identity across renames and reused names."""
from __future__ import annotations

import bisect
from dataclasses import dataclass, field

NEVER = -(10 ** 15)
ALWAYS = 10 ** 15


@dataclass
class Job:
    index: int
    names: list = field(default_factory=list)   # [name, held_from, held_to]
    canonical: str = ""


class Identity:
    def __init__(self, renames: list, spec_keys: list, period_end: int):
        self.jobs: list = []
        holder = {}
        for r in sorted(renames, key=lambda r: (r.effective, r.origin.ordinal)):
            if not r.old_key:
                job = self._new(r.new_key, r.effective)
            else:
                job = holder.get(r.old_key)
                if job is None:
                    job = self._new(r.old_key, NEVER)
                job.names[-1][2] = r.effective
                job.names.append([r.new_key, r.effective, ALWAYS])
                holder.pop(r.old_key, None)
            holder[r.new_key] = job
        known = {n[0] for j in self.jobs for n in j.names}
        for key in sorted(set(spec_keys)):
            if key not in known:
                self._new(key, NEVER)
                known.add(key)
        self.holders = {}
        for job in self.jobs:
            for name, frm, to in job.names:
                self.holders.setdefault(name, []).append((frm, to, job.index))
        for name in self.holders:
            self.holders[name].sort()
        closing = period_end - 1
        for job in self.jobs:
            held = [n for n in job.names if n[1] <= closing < n[2]]
            if held:
                job.canonical = "job:" + held[0][0]
            elif job.names[0][1] > closing:
                job.canonical = "job:" + job.names[0][0]
            else:
                job.canonical = "job:" + job.names[-1][0]

    def _new(self, name: str, frm: int) -> Job:
        job = Job(index=len(self.jobs), names=[[name, frm, ALWAYS]])
        self.jobs.append(job)
        return job

    def known(self, key: str) -> bool:
        return key in self.holders

    def resolve_key(self, key: str, at: int):
        """The job holding the key at `at`; failing that the last job to have held it before,
        failing that the first job to hold it after."""
        spans = self.holders.get(key)
        if not spans:
            return None
        for frm, to, idx in spans:
            if frm <= at < to:
                return self.jobs[idx]
        before = [(to, frm, idx) for frm, to, idx in spans if to <= at]
        if before:
            return self.jobs[max(before)[2]]
        after = [(frm, idx) for frm, to, idx in spans if frm > at]
        return self.jobs[min(after)[1]] if after else None

    def name_at(self, job: Job, at: int) -> str:
        for name, frm, to in job.names:
            if frm <= at < to:
                return name
        if at < job.names[0][1]:
            return job.names[0][0]
        return job.names[-1][0]

    def names_of(self, job: Job) -> set:
        return {n[0] for n in job.names}
