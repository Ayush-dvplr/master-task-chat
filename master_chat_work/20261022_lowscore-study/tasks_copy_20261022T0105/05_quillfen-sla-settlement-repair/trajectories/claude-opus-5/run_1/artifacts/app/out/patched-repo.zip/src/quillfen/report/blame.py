"""Blame for intervals excused by their upstream."""
from __future__ import annotations


def blame_parent(candidates: list):
    """candidates: (upstream key, landed_at or None, canonical job). The latest-landing upstream is to blame,
    an upstream that never landed counts as latest; ties go to the smaller canonical job id."""
    ranked = sorted(candidates, key=lambda c: (0 if c[1] is None else 1, -(c[1] or 0), c[2]))
    return ranked[0][0]


def root_of(key, parents: dict):
    """Follow blame parents until an interval that is not itself EXCUSED_UPSTREAM.

    `parents` holds exactly the EXCUSED_UPSTREAM intervals, so a key still in it has
    another step to take. The depth is the number of steps, one for a direct parent."""
    current = key
    depth = 0
    seen = {key}
    while current in parents:
        current = parents[current]
        depth += 1
        if current in seen:   # a blame cycle would otherwise never terminate
            break
        seen.add(current)
    return current, depth
