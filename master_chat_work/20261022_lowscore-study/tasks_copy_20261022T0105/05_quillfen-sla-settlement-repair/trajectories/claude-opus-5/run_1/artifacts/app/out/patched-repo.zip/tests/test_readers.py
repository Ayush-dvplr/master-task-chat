import tempfile
import unittest
from pathlib import Path

from quillfen.parsers.graph import read_producers, read_rates
from quillfen.parsers.workers import logfmt_pairs, read_heartbeats
from quillfen.records import Corpus


class ReaderTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.root = Path(self.dir.name)

    def tearDown(self):
        self.dir.cleanup()

    def test_rate_rows_and_rejects(self):
        p = self.root / "ratecard.fwf"
        p.write_text("TIER BUCKET EFFECTIVE_FROM          BASE      PER_MINUTE CUR\n"
                     "1    B0     2026-01-01T00:00:00Z 2         1          EUR\n"
                     "1    B30    2026-01-01T00:00:00Z 12,50     1          EUR\n", encoding="utf-8")
        c = Corpus()
        read_rates(p, c)
        self.assertEqual(len(c.rates), 1)
        self.assertEqual(c.rejects, [("ratecard.fwf", 2, "MALFORMED_RECORD")])

    def test_producer_rows(self):
        p = self.root / "dataset_producers.psv"
        p.write_text("dataset|producer_job|valid_from|valid_to\n"
                     "LAKE/Orders_Daily|Stage-Orders-Daily|2025-01-01T00:00Z|\n", encoding="utf-8")
        c = Corpus()
        read_producers(p, c)
        self.assertEqual((c.producers[0].dataset, c.producers[0].key, c.producers[0].valid_to),
                         ("lake.orders.daily", "stage.orders.daily", None))

    def test_plain_logfmt(self):
        kv = logfmt_pairs('ts=2026-03-04T05:00:00Z host=wk-a-01 event=commit msg="run commit finished"')
        self.assertEqual(kv["event"], "commit")
        self.assertEqual(kv["msg"], "run commit finished")

    def test_heartbeat_offset(self):
        p = self.root / "heartbeats.txt"
        p.write_text("host: wk-e-01\nsent: 2026-03-04T05:00:02.250Z\nreceived: 2026-03-04T05:00:00.250Z\n", encoding="utf-8")
        c = Corpus()
        read_heartbeats(p, c)
        self.assertEqual(c.clock_samples[0].offset_ms, 2000)


if __name__ == "__main__":
    unittest.main()
