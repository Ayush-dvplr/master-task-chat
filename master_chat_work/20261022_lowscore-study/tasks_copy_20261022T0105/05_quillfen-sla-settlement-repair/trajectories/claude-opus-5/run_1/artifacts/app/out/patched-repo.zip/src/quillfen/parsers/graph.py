"""Reference and relationship sources: zones, renames, dependencies, producers, SLA overrides, rates."""
from __future__ import annotations

import csv
import io
import re
from pathlib import Path

from ..keys import normalize_key
from ..records import Corpus, Dependency, Producer, RateRow, Rename, SlaOverride
from ..timebase import ZoneTable, parse_offset, parse_stamp
from .common import Reader, read_text, require, to_int


def read_zones(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    table = ZoneTable()
    rows = list(csv.reader(io.StringIO(read_text(path))))
    for row in rows[1:]:
        if not row:
            continue
        origin = reader.next()
        try:
            if len(row) != 3:
                raise ValueError("columns")
            zone, effective, offset = (c.strip() for c in row)
            require(zone)
            if offset.startswith("=>"):
                if effective:
                    raise ValueError("link rows carry no effective instant")
                table.links[zone] = require(offset[2:].strip())
                continue
            if not re.fullmatch(r"[+-]\d{2}:\d{2}", offset):
                raise ValueError("offset")
            table.add(zone, parse_stamp(require(effective), default_offset=None), parse_offset(offset))
        except ValueError:
            reader.malformed(origin)
    table.seal()
    corpus.zones = table


def read_renames(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    rows = list(csv.reader(io.StringIO(read_text(path))))
    for row in rows[1:]:
        if not row:
            continue
        origin = reader.next()
        try:
            if len(row) != 3:
                raise ValueError("columns")
            old, new, effective = row
            corpus.renames.append(Rename(
                old_key=normalize_key(old) if old.strip() else "",
                new_key=normalize_key(require(new)),
                effective=parse_stamp(require(effective), default_offset=None),
                origin=origin))
        except ValueError:
            reader.malformed(origin)


_EDGE = re.compile(r'^\s*"([^"]+)"\s*->\s*"([^"]+)"\s*(?:\[(.*)\])?\s*;?\s*$')
_ATTR = re.compile(r'(\w+)\s*=\s*("([^"]*)"|[^,\s\]]+)')


def read_dependencies(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if "->" not in line:
            continue
        origin = reader.next()
        try:
            m = _EDGE.match(line)
            if not m:
                raise ValueError("edge")
            attrs = {}
            for a in _ATTR.finditer(m.group(3) or ""):
                attrs[a.group(1)] = a.group(3) if a.group(3) is not None else a.group(2)
            corpus.dependencies.append(Dependency(
                upstream=normalize_key(m.group(1)),
                downstream=normalize_key(m.group(2)),
                lag=to_int(attrs.get("lag", "0"), lo=0),
                valid_from=parse_stamp(attrs["valid_from"], default_offset=None) if attrs.get("valid_from") else None,
                valid_to=parse_stamp(attrs["valid_to"], default_offset=None) if attrs.get("valid_to") else None,
                origin=origin))
        except ValueError:
            reader.malformed(origin)


def read_producers(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    lines = read_text(path).splitlines()
    for line in lines[1:]:
        if not line.strip():
            continue
        origin = reader.next()
        try:
            parts = line.split("|")
            if len(parts) != 4:
                raise ValueError("columns")
            dataset, key, frm, to = (p.strip() for p in parts)
            corpus.producers.append(Producer(
                dataset=normalize_key(require(dataset)),
                key=normalize_key(require(key)),
                valid_from=parse_stamp(require(frm), default_offset=None),
                valid_to=parse_stamp(to, default_offset=None) if to else None,
                origin=origin))
        except ValueError:
            reader.malformed(origin)


_PROP_KEY = re.compile(r"^sla\.(.+)\.(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)$")


def _split_property(line: str):
    key = []
    i = 0
    while i < len(line):
        ch = line[i]
        if ch == "\\" and i + 1 < len(line):
            key.append(line[i + 1])
            i += 2
            continue
        if ch in "=: \t":
            break
        key.append(ch)
        i += 1
    rest = line[i:].lstrip(" \t")
    if rest[:1] in ("=", ":"):
        rest = rest[1:]
    return "".join(key), rest.strip()


def read_sla_overrides(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for raw in read_text(path).splitlines():
        line = raw.strip()
        if not line or line[0] in "#!":
            continue
        origin = reader.next()
        try:
            key, value = _split_property(line)
            m = _PROP_KEY.match(key)
            if not m:
                raise ValueError("key")
            if value == "":
                minutes = None
            else:
                minutes = to_int(value, lo=0)
            corpus.sla_overrides.append(SlaOverride(
                key=normalize_key(m.group(1)),
                effective=parse_stamp(m.group(2), default_offset=None),
                minutes=minutes,
                origin=origin))
        except ValueError:
            reader.malformed(origin)


_MONEY = re.compile(r"^\d+(?:\.\d{1,2})?$")


def read_rates(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    lines = read_text(path).splitlines()
    for line in lines[1:]:
        if not line.strip():
            continue
        origin = reader.next()
        try:
            parts = line.split()
            if len(parts) != 6:
                raise ValueError("columns")
            tier, bucket, effective, base, per_minute, currency = parts
            if bucket not in ("B0", "B30", "B120") or currency != "EUR":
                raise ValueError("bucket or currency")
            if not _MONEY.match(base) or not _MONEY.match(per_minute):
                raise ValueError("amount")
            corpus.rates.append(RateRow(
                tier=to_int(tier, 1, 3), bucket=bucket,
                effective=parse_stamp(effective, default_offset=None),
                base=base, per_minute=per_minute, origin=origin))
        except ValueError:
            reader.malformed(origin)
