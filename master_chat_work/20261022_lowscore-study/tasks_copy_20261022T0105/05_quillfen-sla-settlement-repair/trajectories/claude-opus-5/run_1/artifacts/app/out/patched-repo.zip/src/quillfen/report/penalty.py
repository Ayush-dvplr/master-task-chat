"""Lateness, buckets and penalties."""
from __future__ import annotations

from .money import to_minor


def lateness_minutes(seconds_late: int) -> int:
    """Whole minutes late; any started minute counts as a whole minute."""
    return -(-seconds_late // 60)


def bucket(minutes: int) -> str:
    if minutes < 30:
        return "B0"
    if minutes < 120:
        return "B30"
    return "B120"


class RateCard:
    def __init__(self, rows: list):
        self.rows = {}
        for r in rows:
            self.rows.setdefault((r.tier, r.bucket), []).append(r)
        for lst in self.rows.values():
            lst.sort(key=lambda r: (r.effective, r.origin.ordinal))

    def price(self, tier: int, bucket_name: str, at: int, minutes: int) -> int:
        row = None
        for r in self.rows.get((tier, bucket_name), []):
            if r.effective <= at:
                row = r
        if row is None:
            return 0
        return to_minor(row.base) + to_minor(row.per_minute) * minutes
