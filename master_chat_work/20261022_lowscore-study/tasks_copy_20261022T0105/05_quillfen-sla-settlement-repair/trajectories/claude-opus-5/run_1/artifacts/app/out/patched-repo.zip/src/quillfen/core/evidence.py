"""Evidence tiers and the instant an interval's data landed."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .clock import ClockBook
from .identity import Identity
from .landing import governing_land
from .people import People

TIERS = ("physical", "worker", "scheduler", "operator", "none")


@dataclass
class Evidence:
    tier: str = "none"
    landed_at: Optional[int] = None
    candidates: int = 0
    unresolvable: str = ""
    datasets: set = field(default_factory=set)


def index_by_interval(records: list, identity: Identity, corpus) -> dict:
    """Group interval-referencing records by (job index, nominal); unknown keys are rejected."""
    out = {}
    for r in records:
        if not identity.known(r.key):
            corpus.reject(r.origin, "UNKNOWN_JOB")
            continue
        job = identity.resolve_key(r.key, r.nominal)
        out.setdefault((job.index, r.nominal), []).append(r)
    return out


def mark_accepted(mark, approvals: list, people: People) -> bool:
    """A mark counts when the interval carries an approval sent at or before it by a person
    the directory can place who is not the acting operator."""
    actor = people.person_of_handle.get(mark.actor)
    for a in approvals:
        if a.at > mark.at:
            continue
        sender = people.person_of_mail.get(a.sender)
        if sender is None or sender == actor:
            continue
        return True
    return False


def resolve(interval, producers, streams, workers, backfill_runs, clock: ClockBook, transitions, marks, approvals,
            people: People) -> Evidence:
    ev = Evidence()
    key = interval.key
    datasets = producers.datasets_for(interval.job, interval.nominal)
    ev.datasets = datasets
    if len(datasets) > 1 or any(len(producers.jobs_for(ds, interval.nominal)) > 1 for ds in datasets):
        ev.unresolvable = "AMBIGUOUS_PRODUCER"
        return ev
    stream = None
    if datasets:
        ds = next(iter(datasets))
        stream = streams.get((ds, interval.nominal))
    if stream:
        at, lands = governing_land(stream)
        if lands:
            ev.tier, ev.landed_at, ev.candidates = "physical", at, lands
            return ev
    commits = [w for w in workers.get(key, []) if w.event == "commit" and w.run_id not in backfill_runs]
    if commits:
        corrected = [clock.correct(w.host, w.local_ms) for w in commits]
        usable = [c for c in corrected if c is not None]
        ev.tier, ev.candidates = "worker", len(commits)
        if usable:
            ev.landed_at = min(usable)
        else:
            ev.unresolvable = "UNCALIBRATED_CLOCK"
        return ev
    successes = [t.at for t in transitions.get(key, []) if t.state == "success" and t.run_id not in backfill_runs]
    if successes:
        ev.tier, ev.landed_at, ev.candidates = "scheduler", min(successes), len(successes)
        return ev
    accepted = [m.at for m in marks.get(key, []) if m.action == "mark_success" and mark_accepted(m, approvals.get(key, []), people)]
    if accepted:
        ev.tier, ev.landed_at, ev.candidates = "operator", min(accepted), len(accepted)
    return ev
