"""Recurring calendar windows: change freezes, holidays and the on-call rota."""
from __future__ import annotations

from ..timebase import DAY, ZoneTable, civil, instant

WEEKDAYS = {"MO": 0, "TU": 1, "WE": 2, "TH": 3, "FR": 4, "SA": 5, "SU": 6}


def _until(text: str) -> int:
    t = text.rstrip("Z")
    return instant(int(t[0:4]), int(t[4:6]), int(t[6:8]), int(t[9:11]), int(t[11:13]), int(t[13:15]))


def occurrence_walls(start_wall: int, rule: dict, zones: ZoneTable, zone: str, horizon_wall: int) -> list:
    """Occurrence start wall times of a DAILY or WEEKLY rule; UNTIL is compared as an instant."""
    if not rule:
        return [start_wall]
    freq = rule.get("FREQ", "DAILY")
    interval = int(rule.get("INTERVAL", "1"))
    count = int(rule["COUNT"]) if "COUNT" in rule else None
    until = _until(rule["UNTIL"]) if "UNTIL" in rule else None
    y, mo, d, h, mi, s, wd = civil(start_wall)
    time_of_day = h * 3600 + mi * 60 + s
    first_day = start_wall - time_of_day
    out = []

    def stop(w):
        if w > horizon_wall:
            return True
        return until is not None and zones.instants_for_wall(zone, w)[:1] and zones.instants_for_wall(zone, w)[0] > until

    if freq == "DAILY":
        k = 0
        while True:
            w = first_day + k * interval * DAY + time_of_day
            if stop(w):
                break
            out.append(w)
            if count is not None and len(out) >= count:
                break
            k += 1
        return out
    if freq != "WEEKLY":
        raise ValueError("unsupported FREQ %s" % freq)
    days = sorted(WEEKDAYS[x] for x in rule["BYDAY"].split(",")) if "BYDAY" in rule else [wd]
    week = first_day - wd * DAY
    k = 0
    while True:
        for dw in days:
            w = week + k * interval * 7 * DAY + dw * DAY + time_of_day
            if w < start_wall:
                continue
            if stop(w):
                return out
            out.append(w)
            if count is not None and len(out) >= count:
                return out
        k += 1


def freeze_windows(events: list, zones: ZoneTable, horizon: int) -> list:
    """(start instant, end instant, tiers) for every occurrence after exceptions and overrides."""
    overrides = {}
    for ev in events:
        if ev.recurrence_id is not None:
            overrides[(ev.uid, ev.recurrence_id)] = ev
    windows = []
    for ev in events:
        if ev.recurrence_id is not None:
            continue
        length = ev.end_wall - ev.start_wall
        excluded = set(ev.exdates)
        for w in occurrence_walls(ev.start_wall, ev.rrule, zones, ev.zone, horizon):
            if w in excluded:
                continue
            o = overrides.get((ev.uid, w))
            if o is not None:
                if o.cancelled:
                    continue
                a, b = o.start_wall, o.end_wall
            else:
                a, b = w, w + length
            windows.append((zones.wall_to_instant(ev.zone, a), zones.wall_to_instant(ev.zone, b), set(ev.categories)))
    return windows


def rota_shifts(events: list, zones: ZoneTable, horizon: int) -> list:
    """(team, start instant, end instant, attendee address) for every rota occurrence."""
    overrides = {}
    for ev in events:
        if ev.recurrence_id is not None:
            overrides[(ev.uid, ev.recurrence_id)] = ev
    shifts = []
    for ev in events:
        if ev.recurrence_id is not None or ev.start_wall is None:
            continue
        length = ev.end_wall - ev.start_wall
        for w in occurrence_walls(ev.start_wall, ev.rrule, zones, ev.zone, horizon):
            attendee = ev.attendee
            o = overrides.get((ev.uid, w))
            if o is not None:
                if o.cancelled:
                    continue
                attendee = o.attendee or attendee
            shifts.append((ev.team, zones.wall_to_instant(ev.zone, w), zones.wall_to_instant(ev.zone, w + length), attendee))
    return shifts
