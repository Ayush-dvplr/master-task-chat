"""Dependency edges and the upstream interval a downstream interval waits on."""
from __future__ import annotations

import bisect

from .identity import Identity


class DependencyGraph:
    def __init__(self, edges: list, identity: Identity, corpus):
        self.identity = identity
        self.edges = []
        self.by_name = {}
        for e in edges:
            if not identity.known(e.upstream) or not identity.known(e.downstream):
                corpus.reject(e.origin, "UNKNOWN_JOB")
                continue
            self.edges.append(e)
            self.by_name.setdefault(e.downstream, []).append(e)

    def edges_into(self, job, nominal: int) -> list:
        out = []
        for name in self.identity.names_of(job):
            for e in self.by_name.get(name, []):
                if e.valid_from is not None and nominal < e.valid_from:
                    continue
                if e.valid_to is not None and nominal >= e.valid_to:
                    continue
                if self.identity.resolve_key(e.downstream, nominal) is job:
                    out.append(e)
        return out


def governing_upstream(nominals: list, nominal: int, lag: int):
    """Position in the upstream job's sorted interval nominals that a downstream interval waits on."""
    i = bisect.bisect_right(nominals, nominal) - 1 - lag
    return nominals[i] if i >= 0 else None


def upstream_intervals(graph: DependencyGraph, interval, nominals_by_job: dict) -> list:
    found = set()
    for e in graph.edges_into(interval.job, interval.nominal):
        up = graph.identity.resolve_key(e.upstream, interval.nominal)
        n = governing_upstream(nominals_by_job.get(up.index, []), interval.nominal, e.lag)
        if n is not None:
            found.add((up.index, n, e.lag))
    return sorted(found)
