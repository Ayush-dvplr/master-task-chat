"""Operations sources: pauses, operator audit, approvals, backfills, outages, incident register."""
from __future__ import annotations

import email.utils
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from ..keys import normalize_key, normalize_mail
from ..records import Approval, Backfill, Corpus, IncidentScope, OperatorAction, OutageNotice, PauseEvent
from ..timebase import instant, parse_stamp
from .common import Reader, read_text, require

EXCEL_EPOCH = instant(1899, 12, 30)


def _target(text: str):
    key, _, nominal = require(text).rpartition("@")
    return normalize_key(require(key)), parse_stamp(require(nominal), default_offset=None)


def read_pauses(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if not line.strip():
            continue
        origin = reader.next()
        try:
            fields = dict(part.split(":", 1) for part in line.split("\t") if ":" in part)
            action = require(fields.get("action"))
            if action not in ("pause", "unpause"):
                raise ValueError("action")
            corpus.pauses.append(PauseEvent(key=normalize_key(require(fields.get("job"))),
                                            at=parse_stamp(require(fields.get("time")), default_offset=None),
                                            action=action, origin=origin))
        except ValueError:
            reader.malformed(origin)


_SS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _sheet_rows(path: Path):
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
    for row in root.iter(_SS + "row"):
        cells = []
        for c in row.findall(_SS + "c"):
            if c.get("t") == "inlineStr":
                cells.append("".join(t.text or "" for t in c.iter(_SS + "t")))
            else:
                v = c.find(_SS + "v")
                cells.append(v.text if v is not None else "")
        yield cells


def read_operator(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    rows = list(_sheet_rows(path))
    for cells in rows[1:]:
        origin = reader.next()
        try:
            stamp, actor, action, target = cells[0], cells[1], cells[2], cells[3]
            if not re.fullmatch(r"\d+(\.\d+)?", stamp.strip()):
                raise ValueError("timestamp must be a spreadsheet serial")
            at = EXCEL_EPOCH + int(round(float(stamp) * 86400))
            key, nominal = _target(target)
            corpus.operator_actions.append(OperatorAction(at=at, actor=require(actor).strip().lower(),
                                                          action=require(action).strip(), key=key,
                                                          nominal=nominal, origin=origin))
        except (ValueError, IndexError):
            reader.malformed(origin)


def read_approvals(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    messages = []
    current = None
    previous_blank = True
    for line in read_text(path).splitlines():
        if line.startswith("From ") and previous_blank:
            current = []
            messages.append(current)
        elif current is not None:
            current.append(line)
        previous_blank = line.strip() == ""
    for msg in messages:
        origin = reader.next()
        try:
            headers = {}
            for line in msg:
                if line.strip() == "":
                    break
                if ":" in line:
                    k, v = line.split(":", 1)
                    headers[k.strip().lower()] = v.strip()
            parsed = email.utils.parsedate_to_datetime(require(headers.get("date")))
            if parsed is None or parsed.tzinfo is None:
                raise ValueError("date")
            key, nominal = _target(headers.get("x-quillfen-interval"))
            sender = email.utils.parseaddr(require(headers.get("from")))[1]
            corpus.approvals.append(Approval(sender=normalize_mail(require(sender)), at=int(parsed.timestamp()),
                                             key=key, nominal=nominal, origin=origin))
        except (ValueError, TypeError):
            reader.malformed(origin)


_EDN = re.compile(r'\{(.*)\}')
_EDN_PAIR = re.compile(r':([\w-]+)\s+(#inst\s+"[^"]*"|"(?:[^"\\]|\\.)*")')


def read_backfills(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        m = _EDN.search(line)
        if not m or line.lstrip().startswith(";"):
            continue
        origin = reader.next()
        try:
            pairs = {}
            for k, v in _EDN_PAIR.findall(m.group(1)):
                if v.startswith("#inst"):
                    v = parse_stamp(re.search(r'"([^"]*)"', v).group(1).replace(".000", ""), default_offset=None)
                else:
                    v = v[1:-1]
                pairs[k] = v
            corpus.backfills.append(Backfill(run_id=require(pairs.get("run-id")), key=normalize_key(require(pairs.get("job"))),
                                             nominal=require(pairs.get("nominal")), origin=origin))
        except (ValueError, AttributeError):
            reader.malformed(origin)


def read_outages(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    root = ET.fromstring(path.read_bytes())
    for item in root.iter("item"):
        origin = reader.next()
        try:
            guid = require(item.findtext("guid")).strip().split("/")[0]
            pub = email.utils.parsedate_to_datetime(require(item.findtext("pubDate")))
            if pub is None:
                raise ValueError("pubDate")
            desc = dict(p.split("=", 1) for p in require(item.findtext("description")).split(";") if "=" in p)
            a, b = require(desc.get("window")).split("/")
            status = require(desc.get("status")).strip()
            if status not in ("active", "retracted"):
                raise ValueError("status")
            corpus.outages.append(OutageNotice(guid=guid, published=int(pub.timestamp()),
                                               window_start=parse_stamp(a, default_offset=None),
                                               window_end=parse_stamp(b, default_offset=None),
                                               status=status, origin=origin))
        except (ValueError, TypeError):
            reader.malformed(origin)


def read_incidents(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        s = line.strip()
        if not s.startswith("|") or s.startswith("|---") or s.lower().startswith("| outage"):
            continue
        origin = reader.next()
        try:
            cells = [c.strip() for c in s.strip("|").split("|")]
            if len(cells) != 3:
                raise ValueError("columns")
            corpus.incidents.append(IncidentScope(outage=require(cells[0]), dataset=normalize_key(require(cells[1])),
                                                  origin=origin))
        except ValueError:
            reader.malformed(origin)
