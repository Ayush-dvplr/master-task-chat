"""Normalised records produced by the parsers and consumed by the settlement core."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Origin:
    source: str
    ordinal: int


@dataclass
class SpecRevision:
    key: str
    effective: int
    schedule: Optional[str]
    zone: str
    sla_minutes: int
    tier: int
    enabled: bool
    origin: Origin


@dataclass
class Rename:
    old_key: str
    new_key: str
    effective: int
    origin: Origin


@dataclass
class Dependency:
    upstream: str
    downstream: str
    lag: int
    valid_from: Optional[int]
    valid_to: Optional[int]
    origin: Origin


@dataclass
class Producer:
    dataset: str
    key: str
    valid_from: int
    valid_to: Optional[int]
    origin: Origin


@dataclass
class SlaOverride:
    key: str
    effective: int
    minutes: Optional[int]
    origin: Origin


@dataclass
class RateRow:
    tier: int
    bucket: str
    effective: int
    base: str
    per_minute: str
    origin: Origin


@dataclass
class OwnershipCommit:
    committed: int
    changes: list
    origin: Origin


@dataclass
class HandleBinding:
    handle: str
    team: str
    valid_from: Optional[int]
    valid_to: Optional[int]
    origin: Origin


@dataclass
class DirectoryPerson:
    employee: str
    uid: str
    mails: list
    origin: Origin


@dataclass
class DirectoryChange:
    uid: str
    op: str
    mail: str
    origin: Origin


@dataclass
class Contact:
    mails: list
    handles: list
    origin: Origin


@dataclass
class CalendarEvent:
    uid: str
    zone: str
    start_wall: Optional[int]
    end_wall: Optional[int]
    rrule: dict
    exdates: list
    categories: list
    recurrence_id: Optional[int]
    cancelled: bool
    attendee: Optional[str]
    team: Optional[str]
    origin: Origin


@dataclass
class Holiday:
    team: str
    date: tuple
    origin: Origin


@dataclass
class PauseEvent:
    key: str
    at: int
    action: str
    origin: Origin


@dataclass
class Transition:
    run_id: str
    key: str
    nominal: int
    state: str
    at: int
    origin: Origin


@dataclass
class WorkerEvent:
    host: str
    run_id: str
    key: str
    nominal: int
    event: str
    local_ms: int
    origin: Origin


@dataclass
class ClockSample:
    host: str
    at_ms: int
    offset_ms: int
    origin: Origin


@dataclass
class PartitionEvent:
    dataset: str
    nominal: int
    at: int
    kind: str
    origin: Origin


@dataclass
class OperatorAction:
    at: int
    actor: str
    action: str
    key: str
    nominal: int
    origin: Origin


@dataclass
class Approval:
    sender: str
    at: int
    key: str
    nominal: int
    origin: Origin


@dataclass
class OutageNotice:
    guid: str
    published: int
    window_start: int
    window_end: int
    status: str
    origin: Origin


@dataclass
class IncidentScope:
    outage: str
    dataset: str
    origin: Origin


@dataclass
class Backfill:
    run_id: str
    key: str
    nominal: int
    origin: Origin


@dataclass
class HostBinding:
    host: str
    zone: str
    valid_from: Optional[int]
    valid_to: Optional[int]
    origin: Origin


@dataclass
class Corpus:
    period_start: int = 0
    period_end: int = 0
    zones: object = None
    hosts: list = field(default_factory=list)
    specs: list = field(default_factory=list)
    renames: list = field(default_factory=list)
    dependencies: list = field(default_factory=list)
    producers: list = field(default_factory=list)
    sla_overrides: list = field(default_factory=list)
    rates: list = field(default_factory=list)
    ownership: list = field(default_factory=list)
    handles: list = field(default_factory=list)
    people: list = field(default_factory=list)
    directory_changes: list = field(default_factory=list)
    contacts: list = field(default_factory=list)
    freezes: list = field(default_factory=list)
    holidays: list = field(default_factory=list)
    rota: list = field(default_factory=list)
    pauses: list = field(default_factory=list)
    transitions: list = field(default_factory=list)
    worker_events: list = field(default_factory=list)
    clock_samples: list = field(default_factory=list)
    partition_events: list = field(default_factory=list)
    operator_actions: list = field(default_factory=list)
    approvals: list = field(default_factory=list)
    outages: list = field(default_factory=list)
    incidents: list = field(default_factory=list)
    backfills: list = field(default_factory=list)
    rejects: list = field(default_factory=list)

    def reject(self, origin: Origin, code: str) -> None:
        self.rejects.append((origin.source, origin.ordinal, code))
