import unittest

from quillfen.core.cron import Schedule


class ScheduleTests(unittest.TestCase):
    def test_steps_ranges_and_names(self):
        s = Schedule("*/15 1-23/4 * JAN-MAR MON-FRI")
        self.assertEqual(sorted(s.minutes), [0, 15, 30, 45])
        self.assertEqual(sorted(s.hours), [1, 5, 9, 13, 17, 21])
        self.assertEqual(sorted(s.months), [1, 2, 3])
        self.assertEqual(sorted(s.days_of_week), [1, 2, 3, 4, 5])

    def test_sunday_is_zero_or_seven(self):
        self.assertEqual(Schedule("0 0 * * 7").days_of_week, Schedule("0 0 * * 0").days_of_week)

    def test_weekday_only_schedule(self):
        s = Schedule("30 6 * * 1-5")
        self.assertTrue(s.day_matches(2026, 3, 2))
        self.assertFalse(s.day_matches(2026, 3, 1))

    def test_invalid_expression(self):
        with self.assertRaises(ValueError):
            Schedule("61 * * * *")


if __name__ == "__main__":
    unittest.main()
