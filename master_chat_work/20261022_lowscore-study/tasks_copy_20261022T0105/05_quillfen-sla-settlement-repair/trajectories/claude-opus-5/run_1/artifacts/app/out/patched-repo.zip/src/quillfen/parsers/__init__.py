"""Reads a settlement extract directory into a Corpus."""
from __future__ import annotations

from pathlib import Path

from ..records import Corpus
from . import graph, ical, landing, ops, org, scheduler, specs, workers

# Files the engine never reads.
NOT_INPUTS = ("scheduler_ticks.tsv", "sensor_waits.xml", "review_rulings.ods", "operations-runbook.md",
              "settlement-contract.md", "output-contract.md", "repo.zip")

READERS = [
    ("host_inventory.csv", org.read_hosts),
    ("job_renames.csv", graph.read_renames),
    ("jobs_platform.toml", specs.read_platform),
    ("jobs_analytics.json", specs.read_analytics),
    ("jobs_finance.xml", specs.read_finance),
    ("dependencies.dot", graph.read_dependencies),
    ("dataset_producers.psv", graph.read_producers),
    ("sla_overrides.properties", graph.read_sla_overrides),
    ("ratecard.fwf", graph.read_rates),
    ("ownership_history.gitlog", org.read_ownership),
    ("team_registry.hcl", org.read_handles),
    ("directory.ldif", org.read_directory),
    ("pager_contacts.vcf", org.read_contacts),
    ("freeze_windows.ics", ical.read_freezes),
    ("team_holidays.xcs", ical.read_holidays),
    ("oncall_rota.jcal", ical.read_rota),
    ("job_pauses.ltsv", ops.read_pauses),
    ("operator_audit.xlsx", ops.read_operator),
    ("approvals.mbox", ops.read_approvals),
    ("backfills.edn", ops.read_backfills),
    ("outages.rss", ops.read_outages),
    ("incident_register.md", ops.read_incidents),
    ("sched_us.sqlite", scheduler.read_us),
    ("sched_eu.ssv", scheduler.read_eu),
    ("sched_apac.jsonl", scheduler.read_apac),
    ("sched_legacy.syslog", scheduler.read_legacy),
    ("workers_a.logfmt", workers.read_logfmt),
    ("workers_b.cef", workers.read_cef),
    ("workers_c.w3c.log", workers.read_w3c),
    ("workers_d.evtx.xml", workers.read_evtx),
    ("workers_e.access.log", workers.read_access),
    ("workers_f.pbtxt", workers.read_pbtxt),
    ("clock_offsets.prom", workers.read_prometheus),
    ("heartbeats.txt", workers.read_heartbeats),
    ("landing_objectstore.csv.gz", landing.read_objectstore),
    ("landing_hdfs_audit.log", landing.read_hdfs),
    ("landing_warehouse.sql", landing.read_warehouse),
    ("landing_catalog.atom", landing.read_catalog),
    ("landing_partner.xferlog", landing.read_partner),
    ("partition_deletions.html", landing.read_deletions),
]


def read_corpus(directory: Path) -> Corpus:
    directory = Path(directory)
    corpus = Corpus()
    graph.read_zones(directory / "tz_transitions.csv", corpus)
    specs.read_period(directory / "jobs_platform.toml", corpus)
    for name, fn in READERS:
        fn(directory / name, corpus)
    specs.read_legacy(directory / "jobs_legacy.ini", directory / "crontab_legacy.cron", corpus)
    return corpus
