"""Scheduled commitments: spec timelines, SLA overrides and interval expansion."""
from __future__ import annotations

from dataclasses import dataclass

from ..timebase import DAY, MINUTE
from .cron import Schedule, fires_between
from .identity import Identity, Job

LOOKBACK = 8 * DAY


@dataclass
class Interval:
    job: Job
    nominal: int
    deadline: int
    tier: int
    sla_minutes: int
    zone: str
    suspension: str = ""

    @property
    def key(self):
        return (self.job.index, self.nominal)


class SpecTimeline:
    def __init__(self, identity: Identity, specs: list):
        self.by_job = {}
        for s in specs:
            job = identity.resolve_key(s.key, s.effective)
            self.by_job.setdefault(job.index, []).append(s)
        for revs in self.by_job.values():
            revs.sort(key=lambda s: s.effective)

    def windows(self, job: Job):
        revs = self.by_job.get(job.index, [])
        for i, s in enumerate(revs):
            end = revs[i + 1].effective if i + 1 < len(revs) else None
            yield s, s.effective, end


class SlaBook:
    def __init__(self, identity: Identity, overrides: list, corpus):
        self.by_job = {}
        for o in overrides:
            if not identity.known(o.key):
                corpus.reject(o.origin, "UNKNOWN_JOB")
                continue
            job = identity.resolve_key(o.key, o.effective)
            self.by_job.setdefault(job.index, []).append(o)
        for lst in self.by_job.values():
            lst.sort(key=lambda o: (o.effective, o.origin.ordinal))

    def effective_sla(self, job: Job, nominal: int, base_minutes: int) -> int:
        """Latest override at or before the nominal instant; a blank override cancels back to the base."""
        current = None
        for o in self.by_job.get(job.index, []):
            if o.effective > nominal:
                break
            current = o.minutes
        return base_minutes if current is None else current


def expand(identity: Identity, timeline: SpecTimeline, sla: SlaBook, zones, period_start: int, period_end: int) -> dict:
    intervals = {}
    lo = period_start - LOOKBACK
    for job in identity.jobs:
        for spec, start, end in timeline.windows(job):
            if not spec.enabled or not spec.schedule:
                continue
            a = max(start, lo)
            b = period_end if end is None else min(end, period_end)
            if a >= b:
                continue
            for t in fires_between(Schedule(spec.schedule), zones, spec.zone, a, b):
                minutes = sla.effective_sla(job, t, spec.sla_minutes)
                deadline = t + minutes * MINUTE
                if period_start <= deadline < period_end:
                    iv = Interval(job=job, nominal=t, deadline=deadline, tier=spec.tier, sla_minutes=minutes, zone=spec.zone)
                    intervals[iv.key] = iv
    return intervals
