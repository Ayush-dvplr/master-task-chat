"""Helpers shared by the source readers."""
from __future__ import annotations

import re
from pathlib import Path

from ..records import Corpus, Origin

MALFORMED = "MALFORMED_RECORD"
MONTHS = {m: i + 1 for i, m in enumerate("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split())}


class Reader:
    """Iterates records of one source and turns any read failure into a MALFORMED_RECORD reject."""

    def __init__(self, corpus: Corpus, source: str):
        self.corpus = corpus
        self.source = source
        self.ordinal = 0

    def next(self) -> Origin:
        self.ordinal += 1
        return Origin(self.source, self.ordinal)

    def malformed(self, origin: Origin) -> None:
        self.corpus.reject(origin, MALFORMED)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def require(value, message="missing field"):
    if value is None or (isinstance(value, str) and value.strip() == ""):
        raise ValueError(message)
    return value


def to_int(text, lo=None, hi=None) -> int:
    if isinstance(text, bool):
        raise ValueError("boolean is not an integer")
    if isinstance(text, int):
        v = text
    else:
        if not re.fullmatch(r"-?\d+", str(text).strip()):
            raise ValueError("not an integer: %r" % (text,))
        v = int(str(text).strip())
    if lo is not None and v < lo:
        raise ValueError("below range")
    if hi is not None and v > hi:
        raise ValueError("above range")
    return v


def host_instant(corpus: Corpus, host: str, wall: int) -> int:
    """A host wall-clock reading denotes the instant it reads in the zone of the host binding
    whose validity window contains that instant; the latest-starting such binding wins."""
    zones = corpus.zones
    best = None
    for b in corpus.hosts:
        if b.host != host:
            continue
        try:
            t = zones.wall_to_instant(b.zone, wall)
        except ValueError:
            continue
        lo = b.valid_from if b.valid_from is not None else -(10 ** 15)
        hi = b.valid_to if b.valid_to is not None else 10 ** 15
        if lo <= t < hi:
            if best is None or lo > best[0]:
                best = (lo, t)
    if best is None:
        raise ValueError("no host binding for %s" % host)
    return best[1]
