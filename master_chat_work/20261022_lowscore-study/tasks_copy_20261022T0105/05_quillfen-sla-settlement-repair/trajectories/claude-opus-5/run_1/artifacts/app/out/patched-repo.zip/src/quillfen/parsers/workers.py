"""Worker pool logs and clock calibration sources. Worker stamps are host clock readings."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

from ..keys import normalize_key
from ..records import ClockSample, Corpus, WorkerEvent
from ..timebase import instant, parse_offset, parse_stamp
from .common import MONTHS, Reader, read_text, require

EVENTS = {"start", "commit", "fail"}


def _event(text) -> str:
    e = require(text).strip().lower()
    if e not in EVENTS:
        raise ValueError("event")
    return e


def _worker(corpus, origin, host, run, job, nominal, event, local_ms):
    corpus.worker_events.append(WorkerEvent(host=require(host), run_id=require(run), key=normalize_key(require(job)),
                                            nominal=parse_stamp(require(nominal), default_offset=None),
                                            event=_event(event), local_ms=local_ms, origin=origin))


def logfmt_pairs(line: str) -> dict:
    """key=value pairs of one worker log line."""
    pairs = {}
    i, n = 0, len(line)
    while i < n:
        while i < n and line[i] == " ":
            i += 1
        start = i
        while i < n and line[i] not in "= ":
            i += 1
        key = line[start:i]
        if i >= n or line[i] != "=":
            continue
        i += 1
        if i < n and line[i] == '"':
            i += 1
            buf = []
            while i < n and line[i] != '"':
                if line[i] == "\\" and i + 1 < n and line[i + 1] in ('"', "\\"):
                    buf.append(line[i + 1])
                    i += 2
                    continue
                buf.append(line[i])
                i += 1
            i += 1
            value = "".join(buf)
        else:
            start = i
            while i < n and line[i] != " ":
                i += 1
            value = line[start:i]
        if key:
            pairs[key] = value
    return pairs


def read_logfmt(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if not line.strip():
            continue
        origin = reader.next()
        try:
            kv = logfmt_pairs(line)
            local = parse_stamp(require(kv.get("ts")), default_offset=None)
            _worker(corpus, origin, kv.get("host"), kv.get("run"), kv.get("job"), kv.get("nominal"), kv.get("event"), local * 1000)
        except ValueError:
            reader.malformed(origin)


_CEF_KEY = re.compile(r"(?<!\\)\s(\w+)=")
CEF_EVENTS = {"4100": "start", "4101": "commit", "4102": "fail"}


def read_cef(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if not line.startswith("CEF:"):
            continue
        origin = reader.next()
        try:
            head = line.split("|", 7)
            if len(head) != 8:
                raise ValueError("header")
            ext = " " + head[7]
            marks = [(m.start(), m.group(1), m.end()) for m in _CEF_KEY.finditer(ext)]
            fields = {}
            for idx, (pos, key, vstart) in enumerate(marks):
                vend = marks[idx + 1][0] if idx + 1 < len(marks) else len(ext)
                fields[key] = ext[vstart:vend].replace("\\=", "=").replace("\\\\", "\\")
            labels = {}
            for k, v in list(fields.items()):
                if k.endswith("Label"):
                    labels[v] = fields.get(k[:-5])
            rt = require(fields.get("rt"))
            if not re.fullmatch(r"\d+", rt):
                raise ValueError("rt")
            _worker(corpus, origin, fields.get("dhost"), labels.get("run"), labels.get("job"), labels.get("nominal"),
                    CEF_EVENTS.get(head[4]), int(rt))
        except ValueError:
            reader.malformed(origin)


def read_w3c(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    columns = []
    for line in read_text(path).splitlines():
        if line.startswith("#"):
            if line.startswith("#Fields:"):
                columns = line[len("#Fields:"):].split()
            continue
        if not line.strip():
            continue
        origin = reader.next()
        try:
            values = line.split(" ")
            if len(values) != len(columns):
                raise ValueError("columns")
            row = dict(zip(columns, values))
            local = parse_stamp("%s %s" % (row["date"], row["time"]), default_offset=0)
            _worker(corpus, origin, row.get("s-computername"), row.get("cs-run"), row.get("cs-job"), row.get("cs-nominal"),
                    row.get("x-event"), local * 1000)
        except (ValueError, KeyError):
            reader.malformed(origin)


EVTX_EVENTS = {"4100": "start", "4101": "commit", "4102": "fail"}
_SYSTIME = re.compile(r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d{1,7}))?Z$")


def read_evtx(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    root = ET.fromstring(path.read_bytes())
    for ev in root.iter("Event"):
        origin = reader.next()
        try:
            system = ev.find("System")
            m = _SYSTIME.match(require(system.find("TimeCreated").get("SystemTime")))
            if not m:
                raise ValueError("SystemTime")
            frac = (m.group(2) or "").ljust(3, "0")[:3]
            local_ms = parse_stamp(m.group(1) + "Z", default_offset=None) * 1000 + int(frac)
            data = {d.get("Name"): (d.text or "") for d in ev.iter("Data")}
            _worker(corpus, origin, system.findtext("Computer"), data.get("run"), data.get("job"), data.get("nominal"),
                    EVTX_EVENTS.get((system.findtext("EventID") or "").strip()), local_ms)
        except (ValueError, AttributeError):
            reader.malformed(origin)


_ACCESS = re.compile(r'^\S+ \S+ (\S+) \[(\d{2})/([A-Z][a-z]{2})/(\d{4}):(\d{2}):(\d{2}):(\d{2}) ([+-]\d{4})\] "POST (\S+) HTTP/1\.[01]"')


def read_access(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if not line.strip():
            continue
        origin = reader.next()
        try:
            m = _ACCESS.match(line)
            if not m or m.group(3) not in MONTHS:
                raise ValueError("access line")
            wall = instant(int(m.group(4)), MONTHS[m.group(3)], int(m.group(2)), int(m.group(5)), int(m.group(6)), int(m.group(7)))
            local = wall - parse_offset(m.group(8)) * 60
            url = urlsplit(m.group(9))
            parts = url.path.strip("/").split("/")
            if len(parts) != 3 or parts[0] != "runs":
                raise ValueError("path")
            q = parse_qs(url.query)
            _worker(corpus, origin, m.group(1), unquote(parts[1]), (q.get("job") or [None])[0], (q.get("nominal") or [None])[0],
                    parts[2], local * 1000)
        except ValueError:
            reader.malformed(origin)


_PB_FIELD = re.compile(r'^\s*(\w+):\s*(?:"((?:[^"\\]|\\.)*)"|(\S+))\s*$')
_PB_TIME = re.compile(r"^\s*local_time\s*\{\s*seconds:\s*(-?\d+)(?:\s+nanos:\s*(\d+))?\s*\}\s*$")


def read_pbtxt(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    block = None
    for line in read_text(path).splitlines():
        s = line.strip()
        if s == "event {":
            block = {}
            continue
        if block is None:
            continue
        if s == "}":
            origin = reader.next()
            try:
                seconds = int(require(block.get("seconds")))
                if seconds < 0:
                    raise ValueError("seconds")
                local_ms = seconds * 1000 + int(block.get("nanos", "0")) // 1000000
                _worker(corpus, origin, block.get("host"), block.get("run_id"), block.get("job"), block.get("nominal"),
                        block.get("kind"), local_ms)
            except ValueError:
                reader.malformed(origin)
            block = None
            continue
        t = _PB_TIME.match(line)
        if t:
            block["seconds"] = t.group(1)
            block["nanos"] = t.group(2) or "0"
            continue
        f = _PB_FIELD.match(line)
        if f:
            block[f.group(1)] = f.group(2).replace('\\"', '"') if f.group(2) is not None else f.group(3)


_PROM = re.compile(r'^node_timex_offset_seconds\{([^}]*)\}\s+(\S+)\s+(\d+)\s*$')


def read_prometheus(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if not line.startswith("node_timex_offset_seconds"):
            continue
        origin = reader.next()
        try:
            m = _PROM.match(line)
            if not m:
                raise ValueError("sample")
            labels = dict(re.findall(r'(\w+)="([^"]*)"', m.group(1)))
            try:
                seconds = Decimal(m.group(2))
            except InvalidOperation:
                raise ValueError("value")
            if not seconds.is_finite():
                raise ValueError("value")
            ms = seconds * 1000
            if ms != ms.to_integral_value():
                raise ValueError("sub-millisecond offset")
            corpus.clock_samples.append(ClockSample(host=require(labels.get("host")), at_ms=int(m.group(3)),
                                                    offset_ms=int(ms), origin=origin))
        except ValueError:
            reader.malformed(origin)


_MS = re.compile(r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})\.(\d{3})Z$")


def _ms(text) -> int:
    m = _MS.match(require(text).strip())
    if not m:
        raise ValueError("millisecond stamp")
    return parse_stamp(m.group(1) + "Z", default_offset=None) * 1000 + int(m.group(2))


def read_heartbeats(path: Path, corpus: Corpus) -> None:
    """Heartbeat offset = host clock at sending minus scheduler clock at receipt (latency ignored)."""
    reader = Reader(corpus, path.name)
    blocks = re.split(r"\n\s*\n", read_text(path))
    for block in blocks:
        if not block.strip():
            continue
        origin = reader.next()
        try:
            fields = dict((k.strip(), v.strip()) for k, v in (ln.split(":", 1) for ln in block.strip().splitlines() if ":" in ln))
            sent, received = _ms(fields.get("sent")), _ms(fields.get("received"))
            corpus.clock_samples.append(ClockSample(host=require(fields.get("host")), at_ms=received,
                                                    offset_ms=sent - received, origin=origin))
        except ValueError:
            reader.malformed(origin)
