"""Regression tests: one per clause repaired in this change.

Each test exercises the repaired function directly through its shipped signature and fails if
that clause's shipped defect is restored. No test reads a file.
"""
import unittest

from quillfen.core.clock import ClockBook
from quillfen.core.commitments import Interval, SlaBook
from quillfen.core.cron import Schedule, wall_to_fires
from quillfen.core.evidence import Evidence, mark_accepted
from quillfen.core.identity import Identity, Job
from quillfen.core.landing import governing_land
from quillfen.core.people import People
from quillfen.core.status import classify
from quillfen.parsers.ical import unfold
from quillfen.parsers.org import ldif_attributes
from quillfen.parsers.scheduler import eu_instant, syslog_year
from quillfen.parsers.workers import logfmt_pairs
from quillfen.records import (Approval, ClockSample, Contact, Corpus, DirectoryPerson, OperatorAction,
                              Origin, PartitionEvent, Rename, SlaOverride)
from quillfen.report.blame import root_of
from quillfen.report.chargeback import split
from quillfen.report.ledger import sort_key
from quillfen.report.money import to_minor
from quillfen.report.penalty import bucket, lateness_minutes
from quillfen.timebase import ZoneTable, instant


def origin(n=1, source="test"):
    return Origin(source, n)


def job(index=0, name="j", canonical="job:j"):
    return Job(index=index, names=[[name, -(10 ** 15), 10 ** 15]], canonical=canonical)


class SettlementRegressions(unittest.TestCase):

    # ----------------------------------------------------------------- sources

    def test_ical_unfolding_drops_only_the_single_leading_space(self):
        """Clause 2.2: the break and exactly one whitespace character are removed, nothing else."""
        folded = "BEGIN:VEVENT\nEXDATE:20260101T000000,2\n 0260201T000000\nEND:VEVENT"
        self.assertEqual(unfold(folded),
                         ["BEGIN:VEVENT", "EXDATE:20260101T000000,20260201T000000", "END:VEVENT"])

    def test_logfmt_quoted_values_honour_escapes(self):
        """Clause 2.3: inside quotes \\" stands for a quote and \\\\ for a backslash."""
        line = r'host=wk-1 msg="replayed \" event=start \" marker" event=commit'
        pairs = logfmt_pairs(line)
        self.assertEqual(pairs["host"], "wk-1")
        self.assertEqual(pairs["event"], "commit")
        self.assertEqual(pairs["msg"], 'replayed " event=start " marker')

    def test_syslog_year_takes_the_closest_reading_to_the_period(self):
        """Clause 2.4: the year, among the period year and the years either side, closest to
        period_start."""
        corpus = Corpus()
        corpus.period_start = instant(2026, 1, 5)
        self.assertEqual(syslog_year(corpus, 12, 31, 23, 0, 0), 2025)
        self.assertEqual(syslog_year(corpus, 1, 9, 0, 0, 0), 2026)

    def test_eu_export_stamps_are_berlin_wall_time(self):
        """Clause 2.5: at_local is DD.MM.YYYY HH:MM:SS in Europe/Berlin wall time."""
        corpus = Corpus()
        table = ZoneTable()
        table.add("UTC", instant(2000, 1, 1), 0)
        table.add("Europe/Berlin", instant(2000, 1, 1), 60)
        table.seal()
        corpus.zones = table
        self.assertEqual(eu_instant(corpus, "15.01.2026 01:00:00"), instant(2026, 1, 15, 0, 0, 0))

    def test_repeated_ldif_attributes_all_count(self):
        """Clause 2.6: an attribute may appear more than once in one entry and every occurrence counts."""
        record = ["dn: uid=znovak,ou=people", "uid: znovak", "employeeNumber: E1001",
                  "mail: zoe.novak@quillfen.example", "mail: znovak@quillfen.example"]
        self.assertEqual(ldif_attributes(record)["mail"],
                         ["zoe.novak@quillfen.example", "znovak@quillfen.example"])

    # ------------------------------------------------------- jobs and schedules

    def test_key_resolution_follows_the_instant(self):
        """Clause 3.2: a key denotes the job holding it at that instant, not the latest holder."""
        t1, t2, t3 = instant(2020, 1, 1), instant(2021, 1, 1), instant(2022, 1, 1)
        renames = [Rename("", "x", t1, origin(1)),
                   Rename("x", "y", t2, origin(2)),
                   Rename("", "x", t3, origin(3))]
        identity = Identity(renames, [], instant(2026, 4, 1))
        # While the first job still held "x" the key denotes that job, which now answers to "y".
        self.assertEqual(identity.resolve_key("x", t1 + 86400).canonical, "job:y")
        # Between the rename and the reuse the key denotes its most recent previous holder.
        self.assertEqual(identity.resolve_key("x", t2 + 86400).canonical, "job:y")
        # Once reused it denotes the new job.
        self.assertEqual(identity.resolve_key("x", t3 + 86400).canonical, "job:x")

    def test_restricted_day_fields_are_combined_with_or(self):
        """Clause 3.4: when day-of-month and day-of-week are both restricted, either qualifies."""
        both = Schedule("0 0 1 * MON")
        self.assertTrue(both.day_matches(2026, 4, 1))    # the 1st, a Wednesday
        self.assertTrue(both.day_matches(2026, 4, 6))    # a Monday, not the 1st
        self.assertFalse(both.day_matches(2026, 4, 7))   # neither
        # With only one of the two restricted the day must still satisfy both fields.
        self.assertTrue(Schedule("0 0 1 * *").day_matches(2026, 4, 1))
        self.assertFalse(Schedule("0 0 1 * *").day_matches(2026, 4, 6))

    def test_skipped_and_repeated_wall_times_fire_once(self):
        """Clause 3.6: a skipped reading fires at the jump, a repeated one on the second pass."""
        table = ZoneTable()
        table.add("Z", instant(2000, 1, 1), -480)
        table.add("Z", instant(2026, 3, 8, 10, 0, 0), -420)   # spring forward
        table.add("Z", instant(2026, 11, 1, 9, 0, 0), -480)   # fall back
        table.seal()
        skipped = wall_to_fires(table, "Z", instant(2026, 3, 8, 2, 30))
        self.assertEqual(skipped, [instant(2026, 3, 8, 10, 0, 0)])
        repeated = wall_to_fires(table, "Z", instant(2026, 11, 1, 1, 30))
        self.assertEqual(repeated, [instant(2026, 11, 1, 9, 30)])

    def test_zero_minute_sla_override_replaces_the_base(self):
        """Clause 3.8: an integer override replaces the base, zero included."""
        effective = instant(2026, 3, 1)
        identity = Identity([Rename("", "j", instant(2020, 1, 1), origin(1))], [], instant(2026, 4, 1))
        target = identity.resolve_key("j", effective)
        corpus = Corpus()
        zero = SlaBook(identity, [SlaOverride("j", effective, 0, origin(1))], corpus)
        self.assertEqual(zero.effective_sla(target, effective + 60, 90), 0)
        # An empty override cancels overriding, so the base applies again.
        blank = SlaBook(identity, [SlaOverride("j", effective, None, origin(1))], corpus)
        self.assertEqual(blank.effective_sla(target, effective + 60, 90), 90)

    # --------------------------------------------------------------- evidence

    def test_deletion_voids_the_landings_before_it(self):
        """Clause 5.3: the governing landing is the earliest one after the last deletion."""
        def event(at, kind):
            return PartitionEvent(dataset="d", nominal=0, at=at, kind=kind, origin=origin(at))
        relanded = [event(10, "land"), event(20, "retract"), event(30, "land"), event(40, "land")]
        self.assertEqual(governing_land(relanded), (30, 3))
        # Nothing survives a deletion that closes the stream.
        self.assertEqual(governing_land([event(10, "land"), event(20, "retract")]), (None, 1))
        # With no deletion the first landing governs.
        self.assertEqual(governing_land([event(10, "land"), event(40, "land")]), (10, 2))

    def test_host_offset_is_subtracted_from_the_reading(self):
        """Clause 5.4: the corrected instant is the reading minus the governing offset."""
        book = ClockBook([ClockSample(host="h", at_ms=10_000, offset_ms=5_000, origin=origin(1))])
        self.assertEqual(book.correct("h", 10_000), 5)
        # A sample more than a day older than the reading cannot calibrate it.
        self.assertIsNone(book.correct("h", 10_000 + 86_400_001))

    def test_a_mark_needs_a_prior_approval_from_someone_else(self):
        """Clause 5.7: a self-approval, an unplaceable sender or a later approval does not count."""
        directory = [DirectoryPerson(employee="E1", uid="u1", mails=["a@x"], origin=origin(1)),
                     DirectoryPerson(employee="E2", uid="u2", mails=["b@x"], origin=origin(2))]
        contacts = [Contact(mails=["a@x"], handles=["pg-a"], origin=origin(3))]
        people = People(directory, [], contacts)
        mark = OperatorAction(at=1000, actor="pg-a", action="mark_success", key="j", nominal=0,
                              origin=origin(4))

        def approval(sender, at):
            return Approval(sender=sender, at=at, key="j", nominal=0, origin=origin(5))

        self.assertTrue(mark_accepted(mark, [approval("b@x", 900)], people))
        self.assertFalse(mark_accepted(mark, [approval("a@x", 900)], people))
        self.assertFalse(mark_accepted(mark, [approval("b@x", 1100)], people))
        self.assertFalse(mark_accepted(mark, [approval("nobody@x", 900)], people))
        self.assertFalse(mark_accepted(mark, [], people))

    # ----------------------------------------------------------------- status

    def test_outage_is_tested_before_upstream(self):
        """Clause 6.1: EXCUSED_OUTAGE is tested before EXCUSED_UPSTREAM."""
        deadline = instant(2026, 3, 10, 6)
        interval = Interval(job=job(), nominal=deadline - 3600, deadline=deadline, tier=1,
                            sla_minutes=60, zone="UTC")
        evidence = Evidence(tier="none", landed_at=None, candidates=0, unresolvable="",
                            datasets={"ds"})
        outages = [(deadline - 60, deadline + 60, {"ds"})]
        self.assertEqual(classify(interval, evidence, outages, ["MISSED"], instant(2026, 4, 1)),
                         "EXCUSED_OUTAGE")

    def test_blame_root_walks_the_whole_chain(self):
        """Clause 6.4: follow blame parents until an interval that is not EXCUSED_UPSTREAM."""
        a, b, c = (0, 100), (1, 200), (2, 300)
        parents = {a: b, b: c}
        self.assertEqual(root_of(a, parents), (c, 2))
        self.assertEqual(root_of(b, parents), (c, 1))

    # ------------------------------------------------- money and accountability

    def test_any_started_minute_counts_whole(self):
        """Clause 7.1: lateness in whole minutes, any started minute counting as a whole one."""
        self.assertEqual(lateness_minutes(60), 1)
        self.assertEqual(lateness_minutes(61), 2)
        self.assertEqual(lateness_minutes(1), 1)
        self.assertEqual(lateness_minutes(0), 0)

    def test_bucket_boundaries_are_half_open(self):
        """Clause 7.2: under 30 is B0, 30 to under 120 is B30, 120 or more is B120."""
        self.assertEqual(bucket(29), "B0")
        self.assertEqual(bucket(30), "B30")
        self.assertEqual(bucket(119), "B30")
        self.assertEqual(bucket(120), "B120")

    def test_amounts_convert_to_minor_units_exactly(self):
        """Clause 7.3: decimal EUR amounts convert to integer minor units exactly."""
        self.assertEqual(to_minor("1.15"), 115)
        self.assertEqual(to_minor("8.29"), 829)
        self.assertEqual(to_minor("0.07"), 7)
        self.assertEqual(to_minor("12"), 1200)

    def test_leftover_units_go_one_per_team(self):
        """Clause 7.5: leftover minor units are handed out one per team in ascending team id order."""
        self.assertEqual(split(10, ["team:c", "team:a", "team:b"]),
                         {"team:a": 4, "team:b": 3, "team:c": 3})
        self.assertEqual(split(9, ["team:b", "team:a", "team:c"]),
                         {"team:a": 3, "team:b": 3, "team:c": 3})

    # ----------------------------------------------------------------- outputs

    def test_intervals_are_ordered_by_deadline_first(self):
        """Clause 8.1: interval order is deadline, then canonical job id, then nominal instant."""
        early = Interval(job=job(1, "z", "job:z"), nominal=200, deadline=400, tier=1,
                         sla_minutes=10, zone="UTC")
        late = Interval(job=job(0, "a", "job:a"), nominal=100, deadline=500, tier=1,
                        sla_minutes=10, zone="UTC")
        self.assertEqual([iv.job.canonical for iv in sorted([late, early], key=sort_key)],
                         ["job:z", "job:a"])


if __name__ == "__main__":
    unittest.main()
