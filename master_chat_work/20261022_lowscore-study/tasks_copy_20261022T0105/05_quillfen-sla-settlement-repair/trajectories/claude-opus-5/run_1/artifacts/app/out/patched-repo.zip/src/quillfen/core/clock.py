"""Host clock correction."""
from __future__ import annotations

import bisect

WINDOW_MS = 86_400_000


class ClockBook:
    def __init__(self, samples: list):
        self.by_host = {}
        for s in samples:
            self.by_host.setdefault(s.host, []).append((s.at_ms, s.offset_ms))
        for lst in self.by_host.values():
            lst.sort()
        self.keys = {h: [t for t, _ in lst] for h, lst in self.by_host.items()}

    def correct(self, host: str, local_ms: int):
        """Corrected instant in whole seconds, or None when no usable calibration sample exists.

        The governing sample is the latest one stamped at or before the uncorrected reading and no
        more than a day older than it. Offsets are the correction to apply to the local clock."""
        lst = self.by_host.get(host)
        if not lst:
            return None
        i = bisect.bisect_right(self.keys[host], local_ms) - 1
        if i < 0:
            return None
        at_ms, offset_ms = lst[i]
        if local_ms - at_ms > WINDOW_MS:
            return None
        return (local_ms - offset_ms) // 1000
