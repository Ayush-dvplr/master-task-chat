"""Command line entry point: python -m quillfen settle <input_dir> <output_dir>."""
from __future__ import annotations

import argparse
import sys


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="quillfen")
    sub = parser.add_subparsers(dest="command", required=True)
    s = sub.add_parser("settle", help="settle one extract directory")
    s.add_argument("input_dir")
    s.add_argument("output_dir")
    args = parser.parse_args(argv)
    if args.command == "settle":
        from .pipeline import settle
        from .report.writers import write
        write(settle(args.input_dir), args.output_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
