import unittest

from quillfen.timebase import ZoneTable, fmt, instant, parse_stamp


def berlin_2026():
    z = ZoneTable()
    z.add("Europe/Berlin", 0, 60)
    z.add("Europe/Berlin", instant(2026, 3, 29, 1), 120)
    z.add("Europe/Berlin", instant(2026, 10, 25, 1), 60)
    z.links["CET"] = "Europe/Berlin"
    z.seal()
    return z


class TimebaseTests(unittest.TestCase):
    def test_parse_with_offset(self):
        self.assertEqual(fmt(parse_stamp("2026-03-04 10:00:00+05:30", default_offset=None)), "2026-03-04T04:30:00Z")

    def test_parse_without_offset_uses_default(self):
        self.assertEqual(fmt(parse_stamp("2026-03-04 10:00:00", default_offset=0)), "2026-03-04T10:00:00Z")

    def test_offset_lookup_and_links(self):
        z = berlin_2026()
        self.assertEqual(z.offset_at("CET", instant(2026, 4, 1)), 120)
        self.assertEqual(z.offset_at("Europe/Berlin", instant(2026, 3, 29, 0, 59, 59)), 60)

    def test_repeated_wall_reading_takes_earlier_instant(self):
        z = berlin_2026()
        t = z.wall_to_instant("Europe/Berlin", instant(2026, 10, 25, 2, 30))
        self.assertEqual(fmt(t), "2026-10-25T00:30:00Z")


if __name__ == "__main__":
    unittest.main()
