"""Writes the settlement output set."""
from __future__ import annotations

import csv
import io
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from xml.sax.saxutils import quoteattr

from ..core.landing import governing_land
from ..keys import interval_id
from ..timebase import MINUTE, fmt
from .reconcile import identities

OUTPUTS = ["job_identity.tsv", "people.jsonl", "rejects.csv", "commitments.csv", "evidence.jsonl",
           "dependency_resolution.csv", "state_audit.csv", "ledger.csv", "blame.jsonl", "accountability.csv",
           "unresolvable.json", "chargeback.xml", "reconciliation.toml", "wall_clock.csv", "freeze_occurrences.csv",
           "partition_landings.tsv", "clock_corrections.csv", "mark_decisions.csv", "upstream_waits.xml",
           "oncall_shifts.jsonl", "team_tiers.json", "output_manifest.json"]
TIERS = (1, 2, 3)


def _iid(settlement, job_index, nominal):
    return interval_id(settlement.identity.jobs[job_index].canonical, fmt(nominal))


def _csv(rows, header, delimiter=","):
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=delimiter, lineterminator="\n")
    w.writerow(header)
    w.writerows(rows)
    return buf.getvalue()


def _num(v):
    return "" if v is None else str(v)


def _local(zones, zone, t):
    """Wall reading of an instant in a zone, with the offset in force: 2026-03-29T03:00:00+02:00."""
    offset = zones.offset_at(zone, t)
    sign = "-" if offset < 0 else "+"
    return "%s%s%02d:%02d" % (fmt(t + offset * MINUTE)[:-1], sign, abs(offset) // 60, abs(offset) % 60)


def _overlaps(a, b, s):
    return a < s.corpus.period_end and b > s.corpus.period_start


def record_count(name, text):
    """Records of one rendered output, as output_manifest.json counts them."""
    if name.endswith((".csv", ".tsv")):
        return len(list(csv.reader(io.StringIO(text), delimiter="\t" if name.endswith(".tsv") else ","))) - 1
    if name.endswith(".jsonl"):
        return sum(1 for line in text.splitlines() if line.strip())
    if name == "unresolvable.json":
        return len(json.loads(text))
    if name == "team_tiers.json":
        return len(json.loads(text)["teams"]) + 1
    if name.endswith(".xml"):
        return len(list(ET.fromstring(text)))
    return sum(1 for line in text.splitlines() if line.startswith("["))


def render(s) -> dict:
    ident = s.identity
    out = {}

    rows = []
    for job in ident.jobs:
        for name, frm, to in job.names:
            rows.append((job.canonical, name, "" if frm <= -(10 ** 14) else fmt(frm), "" if to >= 10 ** 14 else fmt(to)))
    rows.sort(key=lambda r: (r[0], r[2] != "", r[2], r[1]))
    out["job_identity.tsv"] = _csv(rows, ["canonical_job", "name", "held_from", "held_to"], delimiter="\t")

    lines = []
    for pid in sorted(s.people.mails):
        lines.append(json.dumps({"person": pid, "emails": sorted(s.people.mails[pid]),
                                 "pager_handles": sorted(s.people.handles.get(pid, ()))}, sort_keys=True))
    out["people.jsonl"] = "".join(l + "\n" for l in lines)

    rej = sorted(set(s.corpus.rejects), key=lambda r: (r[0], r[1]))
    out["rejects.csv"] = _csv(rej, ["source", "ordinal", "reason"])

    rows = []
    for iv in s.intervals:
        rows.append((_iid(s, iv.job.index, iv.nominal), iv.job.canonical, fmt(iv.nominal), fmt(iv.deadline), iv.tier,
                     iv.sla_minutes, iv.suspension))
    out["commitments.csv"] = _csv(rows, ["interval", "canonical_job", "nominal", "deadline", "tier", "sla_minutes", "suspension"])

    lines = []
    for iv in s.intervals:
        e = s.evidence[iv.key]
        lines.append(json.dumps({"interval": _iid(s, iv.job.index, iv.nominal), "tier": e.tier,
                                 "landed_at": fmt(e.landed_at) if e.landed_at is not None else None,
                                 "candidates": e.candidates}, sort_keys=True))
    out["evidence.jsonl"] = "".join(l + "\n" for l in lines)

    rows = []
    for iv in s.intervals:
        for u, n, lag in sorted(s.upstreams[iv.key], key=lambda x: (_iid(s, x[0], x[1]), x[2])):
            rows.append((_iid(s, iv.job.index, iv.nominal), _iid(s, u, n), lag))
    out["dependency_resolution.csv"] = _csv(rows, ["interval", "upstream_interval", "lag"])

    rows = sorted((ident.jobs[idx].canonical, fmt(nom), run, a, b, fmt(at)) for idx, nom, run, a, b, at in s.audit)
    rows.sort(key=lambda r: (r[0], r[1], r[2], r[5], r[3], r[4]))
    out["state_audit.csv"] = _csv(rows, ["canonical_job", "nominal", "run_id", "from_state", "to_state", "at"])

    rows = []
    for r in s.ledger:
        iv = r["interval"]
        rows.append((_iid(s, iv.job.index, iv.nominal), r["status"], r["reason"], fmt(r["landed_at"]),
                     _num(r["minutes"]), r["bucket"] or "", _num(r["penalty"])))
    out["ledger.csv"] = _csv(rows, ["interval", "status", "reason", "landed_at", "lateness_minutes", "bucket", "penalty_minor"])

    lines = []
    for iv, parent, root, depth, teams in s.blame:
        lines.append(json.dumps({"interval": _iid(s, iv.job.index, iv.nominal), "parent": _iid(s, *parent),
                                 "root": _iid(s, *root), "depth": depth, "root_teams": list(teams)}, sort_keys=True))
    out["blame.jsonl"] = "".join(l + "\n" for l in lines)

    rows = [(_iid(s, iv.job.index, iv.nominal), team, person) for iv, team, person in s.accountability]
    out["accountability.csv"] = _csv(rows, ["interval", "team", "person"])

    entries = [{"interval": _iid(s, r["interval"].job.index, r["interval"].nominal), "reason": r["reason"]}
               for r in s.ledger if r["status"] == "UNRESOLVABLE"]
    out["unresolvable.json"] = json.dumps(entries, indent=2, sort_keys=True) + "\n"

    p0, p1 = s.corpus.period_start, s.corpus.period_end
    xml = ['<?xml version="1.0" encoding="utf-8"?>', "<chargeback period_start=%s period_end=%s>" % (quoteattr(fmt(p0)), quoteattr(fmt(p1)))]
    for team in sorted(s.chargeback):
        c = s.chargeback[team]
        xml.append('  <team id=%s penalty_minor="%d" late="%d" missed="%d" blamed_downstream="%d"/>' % (
            quoteattr(team), c["penalty"], c["late"], c["missed"], c["blamed"]))
    u = s.unowned
    xml.append('  <unowned penalty_minor="%d" late="%d" missed="%d"/>' % (u["penalty"], u["late"], u["missed"]))
    xml.append("</chargeback>")
    out["chargeback.xml"] = "\n".join(xml) + "\n"

    toml = []
    for name, lhs, rhs in identities(out):
        toml += ["[identity.%s]" % name, "lhs = %d" % lhs, "rhs = %d" % rhs, "residual = %d" % (lhs - rhs), ""]
    out["reconciliation.toml"] = "\n".join(toml)

    zones = s.corpus.zones
    rows = [(_iid(s, iv.job.index, iv.nominal), iv.zone, _local(zones, iv.zone, iv.nominal), _local(zones, iv.zone, iv.deadline))
            for iv in s.intervals]
    out["wall_clock.csv"] = _csv(rows, ["interval", "zone", "local_nominal", "local_deadline"])

    rows = sorted((fmt(a), fmt(b), ";".join(str(t) for t in sorted(tiers))) for a, b, tiers in s.freezes if _overlaps(a, b, s))
    out["freeze_occurrences.csv"] = _csv(rows, ["start", "end", "tiers"])

    rows = []
    for (dataset, nominal), stream in s.streams.items():
        landed_at, lands = governing_land(stream)
        if lands:
            retracts = sum(1 for e in stream if e.kind == "retract")
            rows.append((dataset, fmt(nominal), lands, retracts, fmt(landed_at)))
    rows.sort(key=lambda r: (r[0], r[1]))
    out["partition_landings.tsv"] = _csv(rows, ["dataset", "nominal", "lands", "retracts", "governing_landed_at"], delimiter="\t")

    rows = []
    for (job_index, nominal), w in s.commits:
        corrected = s.clock.correct(w.host, w.local_ms)
        rows.append((_iid(s, job_index, nominal), w.host, w.local_ms, fmt(corrected)))
    rows.sort(key=lambda r: (r[0], r[1], r[2], r[3]))
    out["clock_corrections.csv"] = _csv(rows, ["interval", "host", "local_ms", "corrected_at"])

    rows = []
    for (job_index, nominal), m, accepted in s.mark_decisions:
        rows.append((_iid(s, job_index, nominal), m.actor, fmt(m.at),
                     "true" if accepted else "false"))
    rows.sort()
    out["mark_decisions.csv"] = _csv(rows, ["interval", "actor", "marked_at", "accepted"])

    status_of = {r["interval"].key: r["status"] for r in s.ledger}
    position = {iv.key: i for i, iv in enumerate(s.intervals)}
    waits = sorted(s.waits, key=lambda w: (position[w[0].key], w[1].canonical, w[2], -1 if w[3] is None else w[3]))
    xml = ['<?xml version="1.0" encoding="utf-8"?>', "<upstream_waits>"]
    for iv, up, lag, waited in waits:
        waited_id = "" if waited is None else _iid(s, up.index, waited)
        state = "" if waited is None else status_of.get((up.index, waited), "")
        xml.append("  <wait interval=%s upstream_job=%s lag=\"%d\" waited_on=%s status=%s/>" % (
            quoteattr(_iid(s, iv.job.index, iv.nominal)), quoteattr(up.canonical), lag, quoteattr(waited_id), quoteattr(state)))
    xml.append("</upstream_waits>")
    out["upstream_waits.xml"] = "\n".join(xml) + "\n"

    rows = []
    for team, a, b, attendee in s.shifts:
        if not _overlaps(a, b, s):
            continue
        rows.append((team or "", fmt(a), fmt(b), (s.people.by_mail(attendee) if attendee else None) or ""))
    rows.sort()
    out["oncall_shifts.jsonl"] = "".join(json.dumps({"team": t, "start": a, "end": b, "person": p or None}, sort_keys=True) + "\n"
                                         for t, a, b, p in rows)

    def cells(by_tier):
        return {str(t): {"late": by_tier.get(t, {}).get("late", 0), "missed": by_tier.get(t, {}).get("missed", 0),
                         "penalty_minor": by_tier.get(t, {}).get("penalty", 0)} for t in TIERS}
    tiers_doc = {"teams": {team: cells(s.tier_charge["teams"].get(team, {})) for team in sorted(s.chargeback)},
                 "unowned": cells(s.tier_charge["unowned"])}
    out["team_tiers.json"] = json.dumps(tiers_doc, indent=2, sort_keys=True) + "\n"

    manifest = {name: record_count(name, text) for name, text in out.items()}
    out["output_manifest.json"] = json.dumps({"outputs": manifest}, indent=2, sort_keys=True) + "\n"
    return out


def write(settlement, output_dir) -> None:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    for name, text in render(settlement).items():
        (output_dir / name).write_text(text, encoding="utf-8", newline="\n")
