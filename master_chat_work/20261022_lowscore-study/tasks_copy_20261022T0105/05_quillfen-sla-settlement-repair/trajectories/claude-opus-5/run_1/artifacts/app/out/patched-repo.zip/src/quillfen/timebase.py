"""Instants, wall clocks and the shipped zone table."""
from __future__ import annotations

import bisect
import calendar
import re
from dataclasses import dataclass, field

MINUTE = 60
HOUR = 3600
DAY = 86400
FOREVER = 10 ** 15

_ISO = re.compile(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?\s*(Z|[+-]\d{2}:?\d{2})?$")


def instant(year: int, month: int, day: int, hour: int = 0, minute: int = 0, second: int = 0) -> int:
    """Whole seconds since the epoch for a UTC civil time (raises on impossible dates)."""
    if not (1 <= month <= 12) or not (1 <= day <= calendar.monthrange(year, month)[1]):
        raise ValueError("impossible date")
    if not (0 <= hour < 24 and 0 <= minute < 60 and 0 <= second < 60):
        raise ValueError("impossible time")
    return calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))


def civil(t: int) -> tuple:
    import time
    s = time.gmtime(t)
    return s.tm_year, s.tm_mon, s.tm_mday, s.tm_hour, s.tm_min, s.tm_sec, s.tm_wday


def fmt(t: int | None) -> str:
    if t is None:
        return ""
    y, mo, d, h, mi, s, _ = civil(t)
    return "%04d-%02d-%02dT%02d:%02d:%02dZ" % (y, mo, d, h, mi, s)


def parse_offset(text: str) -> int:
    """'+05:30', '-0800', 'Z' -> minutes east of UTC."""
    text = text.strip()
    if text in ("Z", "z", "UTC", "GMT"):
        return 0
    m = re.match(r"^([+-])(\d{2}):?(\d{2})$", text)
    if not m:
        raise ValueError("bad offset %r" % text)
    minutes = int(m.group(2)) * 60 + int(m.group(3))
    return -minutes if m.group(1) == "-" else minutes


def parse_stamp(text: str, default_offset: int | None = 0) -> int:
    """ISO-like timestamp with optional offset; fractional seconds are dropped."""
    m = _ISO.match(text.strip())
    if not m:
        raise ValueError("bad timestamp %r" % text)
    y, mo, d, h, mi = (int(m.group(i)) for i in range(1, 6))
    s = int(m.group(6) or 0)
    off = m.group(8)
    base = instant(y, mo, d, h, mi, s)
    if off is None:
        if default_offset is None:
            raise ValueError("timestamp without offset %r" % text)
        return base - default_offset * 60
    return base - parse_offset(off) * 60


@dataclass
class ZoneTable:
    """Offsets per zone from tz_transitions.csv; link rows alias one zone name to another."""

    transitions: dict = field(default_factory=dict)
    links: dict = field(default_factory=dict)

    def add(self, zone: str, effective: int, offset_minutes: int) -> None:
        self.transitions.setdefault(zone, []).append((effective, offset_minutes))

    def seal(self) -> None:
        for z in self.transitions:
            self.transitions[z].sort()

    def target(self, zone: str) -> str:
        hops = 0
        while zone in self.links and hops < 16:
            zone = self.links[zone]
            hops += 1
        return zone

    def knows(self, zone: str) -> bool:
        return self.target(zone) in self.transitions

    def offset_at(self, zone: str, t: int) -> int:
        rows = self.transitions[self.target(zone)]
        i = bisect.bisect_right(rows, (t, 10 ** 9)) - 1
        return rows[max(i, 0)][1]

    def wall(self, zone: str, t: int) -> int:
        """Wall clock of `zone` at instant `t`, expressed as seconds on a UTC-like scale."""
        return t + self.offset_at(zone, t) * MINUTE

    def instants_for_wall(self, zone: str, wall: int) -> list:
        """Every instant whose wall clock in `zone` reads `wall` (0, 1 or 2 of them)."""
        rows = self.transitions[self.target(zone)]
        seen = set()
        out = []
        for _, off in rows:
            if off in seen:
                continue
            seen.add(off)
            t = wall - off * MINUTE
            if self.offset_at(zone, t) == off:
                out.append(t)
        return sorted(set(out))

    def wall_to_instant(self, zone: str, wall: int) -> int:
        """Source timestamps written as wall time: a repeated reading takes its earlier instant."""
        found = self.instants_for_wall(zone, wall)
        if not found:
            raise ValueError("wall time does not occur in %s" % zone)
        return found[0]

    def transition_before(self, zone: str, wall: int):
        """For a wall time that does not occur: (instant of the jump, offset before, offset after)."""
        rows = self.transitions[self.target(zone)]
        for i in range(1, len(rows)):
            t, off = rows[i]
            prev = rows[i - 1][1]
            if off > prev and t + prev * MINUTE <= wall < t + off * MINUTE:
                return t, prev, off
        return None


def wall_parts(wall: int) -> tuple:
    return civil(wall)
