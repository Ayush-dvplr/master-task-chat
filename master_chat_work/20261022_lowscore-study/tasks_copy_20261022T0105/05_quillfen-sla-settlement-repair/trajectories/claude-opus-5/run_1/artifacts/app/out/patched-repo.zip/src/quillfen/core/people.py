"""People from the directory and pager contacts."""
from __future__ import annotations


class People:
    def __init__(self, directory: list, changes: list, contacts: list):
        self.mails = {}
        self.handles = {}
        self.person_of_mail = {}
        by_uid = {}
        for p in directory:
            pid = "emp:" + p.employee
            by_uid[p.uid] = pid
            self.mails.setdefault(pid, set()).update(p.mails)
            self.handles.setdefault(pid, set())
        for c in changes:
            pid = by_uid.get(c.uid)
            if pid is not None and c.op == "add":
                self.mails[pid].add(c.mail)
        for pid, mails in self.mails.items():
            for m in mails:
                self.person_of_mail[m] = pid
        self.person_of_handle = {}
        for card in contacts:
            pid = None
            for m in card.mails:
                if m in self.person_of_mail:
                    pid = self.person_of_mail[m]
            if pid is None:
                continue
            for h in card.handles:
                self.person_of_handle[h] = pid
                self.handles[pid].add(h)

    def by_mail(self, mail: str):
        return self.person_of_mail.get(mail)
