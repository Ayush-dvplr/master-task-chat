"""Reconciliation identities computed from the rendered outputs themselves."""
from __future__ import annotations

import csv
import io
import json
import xml.etree.ElementTree as ET


def _csv_rows(text):
    return list(csv.DictReader(io.StringIO(text)))


def identities(out: dict) -> list:
    ledger = _csv_rows(out["ledger.csv"])
    commitments = _csv_rows(out["commitments.csv"])
    blame = [l for l in out["blame.jsonl"].splitlines() if l.strip()]
    accountability = _csv_rows(out["accountability.csv"])
    unresolvable = json.loads(out["unresolvable.json"])
    root = ET.fromstring(out["chargeback.xml"])
    charged = sum(int(t.get("penalty_minor")) for t in root.iter("team")) + sum(int(u.get("penalty_minor")) for u in root.iter("unowned"))
    settled = sum(int(r["penalty_minor"]) for r in ledger if r["penalty_minor"])
    owning_pairs = sum(int(t.get("late")) + int(t.get("missed")) for t in root.iter("team"))
    return [
        ("intervals", len(commitments), len(ledger)),
        ("penalty", settled, charged),
        ("blame", sum(1 for r in ledger if r["status"] == "EXCUSED_UPSTREAM"), len(blame)),
        ("accountability", owning_pairs, len(accountability)),
        ("unresolvable", sum(1 for r in ledger if r["status"] == "UNRESOLVABLE"), len(unresolvable)),
    ]
