"""Suspensions, outages and the settled status of every interval."""
from __future__ import annotations

from ..timebase import civil

SETTLED = ("SUSPENDED", "UNRESOLVABLE", "MET", "EXCUSED_OUTAGE", "EXCUSED_UPSTREAM", "LATE", "MISSED")


def pause_windows(pauses: list, identity, corpus) -> dict:
    """Pause state machine per job: a pause while paused is ignored, an unpause while running is an orphan."""
    events = []
    for p in pauses:
        if not identity.known(p.key):
            corpus.reject(p.origin, "UNKNOWN_JOB")
            continue
        job = identity.resolve_key(p.key, p.at)
        events.append((p.at, p.origin.ordinal, job.index, p))
    windows = {}
    open_since = {}
    for at, _, idx, p in sorted(events, key=lambda e: (e[0], e[1])):
        if p.action == "pause":
            open_since.setdefault(idx, at)
        elif idx in open_since:
            windows.setdefault(idx, []).append((open_since.pop(idx), at))
        else:
            corpus.reject(p.origin, "ORPHAN_TRANSITION")
    for idx, at in open_since.items():
        windows.setdefault(idx, []).append((at, None))
    return windows


def suspension_of(interval, freezes: list, pauses: dict, holidays: dict, owners, zones) -> str:
    t = interval.nominal
    for a, b, tiers in freezes:
        if a <= t < b and interval.tier in tiers:
            return "FREEZE"
    for a, b in pauses.get(interval.job.index, []):
        if a <= t and (b is None or t < b):
            return "PAUSE"
    if interval.tier == 3:
        y, mo, d = civil(zones.wall(interval.zone, t))[:3]
        for team in owners(interval.job, interval.deadline):
            if (y, mo, d) in holidays.get(team, ()):
                return "HOLIDAY"
    return ""


def active_outages(notices: list, incidents: list) -> list:
    """Latest published revision of each outage governs; a retracted outage excuses nothing."""
    latest = {}
    for n in notices:
        cur = latest.get(n.guid)
        if cur is None or (n.published, n.origin.ordinal) > (cur.published, cur.origin.ordinal):
            latest[n.guid] = n
    scope = {}
    for i in incidents:
        scope.setdefault(i.outage, set()).add(i.dataset)
    return [(n.window_start, n.window_end, scope.get(guid, set())) for guid, n in sorted(latest.items()) if n.status == "active"]


def classify(interval, evidence, outages: list, upstream_statuses: list, period_end: int) -> str:
    if interval.suspension:
        return "SUSPENDED"
    if evidence.unresolvable:
        return "UNRESOLVABLE"
    if evidence.landed_at is not None and evidence.landed_at < interval.deadline:
        return "MET"
    if any(a <= interval.deadline < b and (evidence.datasets & scope) for a, b, scope in outages):
        return "EXCUSED_OUTAGE"
    if any(s not in ("MET", "SUSPENDED") for s in upstream_statuses):
        return "EXCUSED_UPSTREAM"
    if evidence.landed_at is not None and evidence.landed_at < period_end:
        return "LATE"
    return "MISSED"
