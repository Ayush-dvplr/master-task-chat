"""Scheduler state machine audit."""
from __future__ import annotations

LEGAL = {
    ("none", "queued"), ("queued", "running"), ("queued", "removed"), ("running", "success"),
    ("running", "failed"), ("failed", "up_for_retry"), ("up_for_retry", "queued"),
    ("success", "cleared"), ("failed", "cleared"), ("cleared", "queued"),
}


def illegal_transitions(transitions_by_interval: dict) -> list:
    """(job index, nominal, run id, from state, to state, instant) for every illegal step."""
    runs = {}
    for (idx, nominal), rows in transitions_by_interval.items():
        for t in rows:
            runs.setdefault((idx, nominal, t.run_id), []).append(t)
    out = []
    for (idx, nominal, run_id), rows in runs.items():
        rows.sort(key=lambda t: (t.at, t.origin.source, t.origin.ordinal))
        state = "none"
        for t in rows:
            if (state, t.state) not in LEGAL:
                out.append((idx, nominal, run_id, state, t.state, t.at))
            state = t.state
    return out
