import unittest

from quillfen.keys import interval_id, normalize_handle, normalize_key, normalize_mail


class KeyTests(unittest.TestCase):
    def test_separators_collapse(self):
        self.assertEqual(normalize_key(" Stage-Orders_Daily "), "stage.orders.daily")
        self.assertEqual(normalize_key("stage/orders..daily"), "stage.orders.daily")

    def test_dataset_names_share_the_rule(self):
        self.assertEqual(normalize_key("LAKE/orders_daily"), "lake.orders.daily")

    def test_handles_and_mail(self):
        self.assertEqual(normalize_handle("@Quillfen/Ingest-Core"), "quillfen/ingest-core")
        self.assertEqual(normalize_mail("mailto:A.Rao@Quillfen.example"), "a.rao@quillfen.example")

    def test_interval_id(self):
        self.assertEqual(interval_id("job:a.b", "2026-03-01T00:00:00Z"), "job:a.b@2026-03-01T00:00:00Z")


if __name__ == "__main__":
    unittest.main()
