"""Key normalisation."""
from __future__ import annotations

import re

_SEPARATORS = re.compile(r"[-_./ ]+")


def normalize_key(raw: str) -> str:
    """Job keys and dataset names compare only after this normalisation."""
    return _SEPARATORS.sub(".", raw.strip().lower()).strip(".")


def normalize_handle(raw: str) -> str:
    return raw.strip().lower().lstrip("@")


def normalize_mail(raw: str) -> str:
    raw = raw.strip()
    if raw.lower().startswith("mailto:"):
        raw = raw[7:]
    return raw.lower()


def interval_id(canonical_job: str, nominal_text: str) -> str:
    return "%s@%s" % (canonical_job, nominal_text)
