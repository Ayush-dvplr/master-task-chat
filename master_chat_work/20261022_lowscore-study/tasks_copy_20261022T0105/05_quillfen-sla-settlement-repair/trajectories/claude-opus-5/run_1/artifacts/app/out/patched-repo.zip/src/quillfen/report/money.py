"""Monetary amounts in integer minor units."""
from __future__ import annotations

from decimal import Decimal


def to_minor(amount: str) -> int:
    """Rate card amount -> integer minor units."""
    # Decimal, not float: 1.15 * 100 is 114.99999... in binary floating point.
    return int((Decimal(str(amount).strip()) * 100).to_integral_value())
