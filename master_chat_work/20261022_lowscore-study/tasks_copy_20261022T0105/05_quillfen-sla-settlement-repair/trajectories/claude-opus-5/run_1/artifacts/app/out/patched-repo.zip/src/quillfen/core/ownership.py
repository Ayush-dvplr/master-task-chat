"""Owning teams from the CODEOWNERS history and the team handle registry."""
from __future__ import annotations

import bisect
import re
from functools import lru_cache

from .identity import Identity, Job


def _pattern(glob: str):
    return re.compile("^" + "".join("[^/]*" if ch == "*" else re.escape(ch) for ch in glob) + "$")


class Ownership:
    def __init__(self, commits: list, handles: list, identity: Identity):
        self.identity = identity
        ordered = sorted(commits, key=lambda c: (c.committed, -c.origin.ordinal))
        self.times = []
        self.snapshots = []
        lines = []
        for c in ordered:
            for op, glob, hs in c.changes:
                if op == "+":
                    lines.append((glob, _pattern(glob), tuple(hs)))
                else:
                    for i, existing in enumerate(lines):
                        if existing[0] == glob:
                            del lines[i]
                            break
            self.times.append(c.committed)
            self.snapshots.append(list(lines))
        self.handles = {}
        for h in handles:
            self.handles.setdefault(h.handle, []).append(h)
        self._cache = {}

    def team_for_handle(self, handle: str, at: int):
        for b in self.handles.get(handle, []):
            lo = b.valid_from if b.valid_from is not None else -(10 ** 15)
            hi = b.valid_to if b.valid_to is not None else 10 ** 15
            if lo <= at < hi:
                return b.team
        return None

    def teams(self, job: Job, at: int) -> list:
        key = (job.index, at)
        if key in self._cache:
            return self._cache[key]
        i = bisect.bisect_right(self.times, at) - 1
        result = []
        if i >= 0:
            path = "jobs/" + self.identity.name_at(job, at)
            winner = None
            # CODEOWNERS semantics: the last matching line takes precedence.
            for glob, rx, hs in self.snapshots[i]:
                if rx.match(path):
                    winner = hs
            if winner:
                result = sorted({t for t in (self.team_for_handle(h, at) for h in winner) if t})
        self._cache[key] = result
        return result
