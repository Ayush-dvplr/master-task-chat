"""Penalty split across owning teams."""
from __future__ import annotations


def split(amount: int, teams: list) -> dict:
    """Equal shares in minor units; leftover units go one per team in ascending team id order."""
    ordered = sorted(teams)
    share, leftover = divmod(amount, len(ordered))
    return {team: share + (1 if i < leftover else 0) for i, team in enumerate(ordered)}
