"""Job definition sources: platform TOML, analytics JSON, finance XML, legacy INI with its crontab."""
from __future__ import annotations

import configparser
import datetime as _dt
import json
import re
import tomllib
import xml.etree.ElementTree as ET
from pathlib import Path

from ..core.cron import Schedule
from ..keys import normalize_key
from ..records import Corpus, SpecRevision
from ..timebase import instant, parse_offset, parse_stamp
from .common import Reader, read_text, require, to_int


def _aware(value) -> int:
    if not isinstance(value, _dt.datetime) or value.tzinfo is None:
        raise ValueError("effective must be an offset date-time")
    return int(value.timestamp())


def _zone(corpus: Corpus, text) -> str:
    text = require(text).strip()
    if not corpus.zones.knows(text):
        raise ValueError("unknown zone %s" % text)
    return text


def _schedule(text) -> str:
    text = " ".join(require(text).split())
    Schedule(text)
    return text


def read_period(path: Path, corpus: Corpus) -> None:
    data = tomllib.loads(read_text(path))
    s = data["settlement"]
    corpus.period_start = _aware(s["period_start"])
    corpus.period_end = _aware(s["period_end"])


def read_platform(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    data = tomllib.loads(read_text(path))
    for row in data.get("revision", []):
        origin = reader.next()
        try:
            corpus.specs.append(SpecRevision(
                key=normalize_key(require(row.get("job"))),
                effective=_aware(row.get("effective")),
                schedule=_schedule(row.get("schedule")),
                zone=_zone(corpus, row.get("zone")),
                sla_minutes=to_int(row.get("sla_minutes"), lo=0),
                tier=to_int(row.get("tier"), 1, 3),
                enabled=_bool(row.get("enabled")),
                origin=origin))
        except (ValueError, TypeError, KeyError):
            reader.malformed(origin)


def _bool(v) -> bool:
    if isinstance(v, bool):
        return v
    raise ValueError("enabled must be a boolean")


def read_analytics(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    data = json.loads(read_text(path))
    for row in data.get("revisions", []):
        origin = reader.next()
        try:
            seconds = to_int(row.get("sla_seconds"), lo=0)
            if seconds % 60:
                raise ValueError("sla must be whole minutes")
            tier = re.fullmatch(r"T([123])", str(row.get("tier")))
            if not tier:
                raise ValueError("tier")
            state = row.get("state")
            if state not in ("active", "disabled"):
                raise ValueError("state")
            corpus.specs.append(SpecRevision(
                key=normalize_key(require(row.get("job"))),
                effective=to_int(row.get("effective_ms"), lo=0) // 1000,
                schedule=_schedule(row.get("cron")),
                zone=_zone(corpus, row.get("tz")),
                sla_minutes=seconds // 60,
                tier=int(tier.group(1)),
                enabled=state == "active",
                origin=origin))
        except (ValueError, TypeError):
            reader.malformed(origin)


_DURATION = re.compile(r"^PT(?:(\d+)H)?(?:(\d+)M)?$")


def read_finance(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    root = ET.fromstring(path.read_bytes())
    for el in root.iter("revision"):
        origin = reader.next()
        try:
            m = _DURATION.match(require(el.findtext("sla")).strip())
            if not m or not (m.group(1) or m.group(2)):
                raise ValueError("sla must be an ISO 8601 duration")
            minutes = int(m.group(1) or 0) * 60 + int(m.group(2) or 0)
            enabled = (el.findtext("enabled") or "").strip()
            if enabled not in ("yes", "no"):
                raise ValueError("enabled")
            corpus.specs.append(SpecRevision(
                key=normalize_key(require(el.get("job"))),
                effective=parse_stamp(require(el.get("effective")), default_offset=None),
                schedule=_schedule(el.findtext("schedule")),
                zone=_zone(corpus, el.findtext("zone")),
                sla_minutes=minutes,
                tier=to_int(el.findtext("tier"), 1, 3),
                enabled=enabled == "yes",
                origin=origin))
        except (ValueError, TypeError):
            reader.malformed(origin)


_SECTION = re.compile(r"^(.+?)\s+@\s+(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2}) ([+-]\d{4})$")
_SLA = re.compile(r"^(?:(\d+)h)?(?:(\d+)m)?$")
_REV = re.compile(r"^#\s*rev\s+(\S+)\s+(\S+)\s*$")


def read_legacy(ini_path: Path, cron_path: Path, corpus: Corpus) -> None:
    """Legacy definitions: the crontab governs the schedule, the INI governs every other field."""
    schedules = {}
    reader = Reader(corpus, cron_path.name)
    lines = read_text(cron_path).splitlines()
    i = 0
    while i < len(lines):
        m = _REV.match(lines[i].strip())
        if not m:
            i += 1
            continue
        origin = reader.next()
        body = lines[i + 1].strip() if i + 1 < len(lines) else ""
        i += 2
        try:
            parts = body.split()
            if len(parts) < 7:
                raise ValueError("crontab entry")
            expr = " ".join(parts[:5])
            Schedule(expr)
            key = normalize_key(m.group(1))
            if normalize_key(parts[-1]) != key:
                raise ValueError("entry names a different job")
            schedules[(key, parse_stamp(m.group(2), default_offset=None))] = expr
        except ValueError:
            reader.malformed(origin)

    reader = Reader(corpus, ini_path.name)
    cp = configparser.ConfigParser(interpolation=None, strict=False, comment_prefixes=(";", "#"))
    cp.read_string(read_text(ini_path))
    for section in cp.sections():
        origin = reader.next()
        try:
            m = _SECTION.match(section.strip())
            if not m:
                raise ValueError("section")
            y, mo, d, h, mi, s = (int(m.group(k)) for k in range(2, 8))
            effective = instant(y, mo, d, h, mi, s) - parse_offset(m.group(8)) * 60
            key = normalize_key(m.group(1))
            body = cp[section]
            sla = _SLA.match(require(body.get("sla")).strip())
            if not sla or not (sla.group(1) or sla.group(2)):
                raise ValueError("sla")
            disabled = require(body.get("disabled")).strip()
            if disabled not in ("yes", "no"):
                raise ValueError("disabled")
            corpus.specs.append(SpecRevision(
                key=key,
                effective=effective,
                schedule=schedules.get((key, effective)),
                zone=_zone(corpus, body.get("zone")),
                sla_minutes=int(sla.group(1) or 0) * 60 + int(sla.group(2) or 0),
                tier=to_int(body.get("tier"), 1, 3),
                enabled=disabled == "no",
                origin=origin))
        except (ValueError, TypeError):
            reader.malformed(origin)
