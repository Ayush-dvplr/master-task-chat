"""Settlement run: corpus in, settled tables out."""
from __future__ import annotations

from dataclasses import dataclass, field

from .core import audit, calendars, deps, evidence, status
from .core.clock import ClockBook
from .core.commitments import SlaBook, SpecTimeline, expand
from .core.identity import Identity
from .core.landing import Producers, partition_streams
from .core.ownership import Ownership
from .core.people import People
from .parsers import read_corpus
from .report import blame as blame_mod
from .report.chargeback import split
from .report.ledger import sort_key
from .report.penalty import RateCard, bucket, lateness_minutes
from .timebase import DAY


@dataclass
class Settlement:
    corpus: object
    identity: object
    intervals: list
    evidence: dict
    statuses: dict
    upstreams: dict
    ledger: list
    blame: list
    accountability: list
    chargeback: dict
    unowned: dict
    audit: list
    people: object
    teams: list = field(default_factory=list)
    mark_decisions: list = field(default_factory=list)
    streams: dict = field(default_factory=dict)
    commits: list = field(default_factory=list)
    clock: object = None
    waits: list = field(default_factory=list)
    freezes: list = field(default_factory=list)
    shifts: list = field(default_factory=list)
    tier_charge: dict = field(default_factory=dict)


def settle(input_dir) -> Settlement:
    corpus = read_corpus(input_dir)
    zones = corpus.zones
    p0, p1 = corpus.period_start, corpus.period_end

    identity = Identity(corpus.renames, [s.key for s in corpus.specs], p1)
    timeline = SpecTimeline(identity, corpus.specs)
    sla = SlaBook(identity, corpus.sla_overrides, corpus)
    intervals = expand(identity, timeline, sla, zones, p0, p1)

    producers = Producers(corpus.producers, identity, corpus)
    streams = partition_streams(corpus.partition_events, producers, corpus)
    backfill_runs = {b.run_id for b in _known(corpus.backfills, identity, corpus)}
    clock = ClockBook(corpus.clock_samples)
    workers = evidence.index_by_interval(corpus.worker_events, identity, corpus)
    transitions = evidence.index_by_interval(corpus.transitions, identity, corpus)
    marks = evidence.index_by_interval(corpus.operator_actions, identity, corpus)
    approvals = evidence.index_by_interval(corpus.approvals, identity, corpus)
    people = People(corpus.people, corpus.directory_changes, corpus.contacts)
    mark_decisions = []
    for key, actions in marks.items():
        for m in actions:
            if m.action != "mark_success":
                continue
            accepted = evidence.mark_accepted(m, approvals.get(key, []), people)
            mark_decisions.append((key, m, accepted))
            if not accepted:
                corpus.reject(m.origin, "UNAPPROVED_MARK")
    pauses = status.pause_windows(corpus.pauses, identity, corpus)
    graph = deps.DependencyGraph(corpus.dependencies, identity, corpus)

    ownership = Ownership(corpus.ownership, corpus.handles, identity)
    horizon = p1 + 60 * DAY
    freezes = calendars.freeze_windows(corpus.freezes, zones, horizon)
    holidays = {}
    for h in corpus.holidays:
        holidays.setdefault(h.team, set()).add(h.date)
    for iv in intervals.values():
        iv.suspension = status.suspension_of(iv, freezes, pauses, holidays, ownership.teams, zones)

    ordered = sorted(intervals.values(), key=sort_key)
    ev = {}
    for iv in ordered:
        ev[iv.key] = evidence.resolve(iv, producers, streams, workers, backfill_runs, clock, transitions, marks,
                                      approvals, people)

    nominals = {}
    for iv in intervals.values():
        nominals.setdefault(iv.job.index, []).append(iv.nominal)
    for lst in nominals.values():
        lst.sort()
    upstreams = {iv.key: deps.upstream_intervals(graph, iv, nominals) for iv in ordered}
    waits = []
    for iv in ordered:
        seen = set()
        for e in graph.edges_into(iv.job, iv.nominal):
            up = identity.resolve_key(e.upstream, iv.nominal)
            waited = deps.governing_upstream(nominals.get(up.index, []), iv.nominal, e.lag)
            if (up.index, e.lag, waited) not in seen:
                seen.add((up.index, e.lag, waited))
                waits.append((iv, up, e.lag, waited))

    outages = status.active_outages(corpus.outages, corpus.incidents)
    statuses = {}
    for iv in sorted(intervals.values(), key=lambda i: i.nominal):
        ups = [statuses[(u, n)] for u, n, _ in upstreams[iv.key] if (u, n) in statuses]
        statuses[iv.key] = status.classify(iv, ev[iv.key], outages, ups, p1)

    rates = RateCard(corpus.rates)
    ledger = []
    for iv in ordered:
        st = statuses[iv.key]
        row = {"interval": iv, "status": st, "reason": ev[iv.key].unresolvable if st == "UNRESOLVABLE" else "",
               "landed_at": ev[iv.key].landed_at, "minutes": None, "bucket": None, "penalty": None}
        if st in ("LATE", "MISSED"):
            end = ev[iv.key].landed_at if st == "LATE" else p1
            minutes = lateness_minutes(end - iv.deadline)
            row["minutes"] = minutes
            row["bucket"] = bucket(minutes)
            row["penalty"] = rates.price(iv.tier, row["bucket"], iv.deadline, minutes)
        ledger.append(row)

    parents = {}
    for iv in ordered:
        if statuses[iv.key] != "EXCUSED_UPSTREAM":
            continue
        cands = []
        for u, n, _ in upstreams[iv.key]:
            if (u, n) in statuses and statuses[(u, n)] not in ("MET", "SUSPENDED"):
                cands.append(((u, n), ev[(u, n)].landed_at, identity.jobs[u].canonical))
        parents[iv.key] = blame_mod.blame_parent(cands)
    blame_rows = []
    for iv in ordered:
        if iv.key in parents:
            root, depth = blame_mod.root_of(iv.key, parents)
            blame_rows.append((iv, parents[iv.key], root, depth, ownership.teams(identity.jobs[root[0]], intervals[root].deadline)))

    teams = sorted({h.team for h in corpus.handles})
    charge = {t: {"penalty": 0, "late": 0, "missed": 0, "blamed": 0} for t in teams}
    unowned = {"penalty": 0, "late": 0, "missed": 0}
    tier_charge = {"teams": {t: {} for t in teams}, "unowned": {}}
    shifts = calendars.rota_shifts(corpus.rota, zones, horizon)
    accountability = []
    for row in ledger:
        if row["status"] not in ("LATE", "MISSED"):
            continue
        iv = row["interval"]
        owning = ownership.teams(iv.job, iv.deadline)
        field_name = "late" if row["status"] == "LATE" else "missed"
        if not owning:
            unowned["penalty"] += row["penalty"]
            unowned[field_name] += 1
            cell = tier_charge["unowned"].setdefault(iv.tier, {"penalty": 0, "late": 0, "missed": 0})
            cell["penalty"] += row["penalty"]
            cell[field_name] += 1
            continue
        for team, amount in split(row["penalty"], owning).items():
            entry = charge.setdefault(team, {"penalty": 0, "late": 0, "missed": 0, "blamed": 0})
            entry["penalty"] += amount
            entry[field_name] += 1
            cell = tier_charge["teams"].setdefault(team, {}).setdefault(iv.tier, {"penalty": 0, "late": 0, "missed": 0})
            cell["penalty"] += amount
            cell[field_name] += 1
        for team in owning:
            accountability.append((iv, team, on_call(shifts, people, team, iv.deadline)))
    for _, _, _, _, root_teams in blame_rows:
        for team in root_teams:
            charge.setdefault(team, {"penalty": 0, "late": 0, "missed": 0, "blamed": 0})["blamed"] += 1

    return Settlement(corpus=corpus, identity=identity, intervals=ordered, evidence=ev, statuses=statuses,
                      upstreams=upstreams, ledger=ledger, blame=blame_rows, accountability=accountability,
                      chargeback=charge, unowned=unowned,
                      audit=audit.illegal_transitions(transitions), people=people, teams=teams,
                      mark_decisions=mark_decisions, streams=streams,
                      commits=[(key, w) for key, events in workers.items() for w in events
                               if w.event == "commit" and w.run_id not in backfill_runs],
                      clock=clock, waits=waits, freezes=freezes, shifts=shifts, tier_charge=tier_charge)


def _known(records, identity, corpus):
    out = []
    for r in records:
        if identity.known(r.key):
            out.append(r)
        else:
            corpus.reject(r.origin, "UNKNOWN_JOB")
    return out


def on_call(shifts: list, people, team: str, at: int) -> str:
    """The rota occurrence covering the instant; overlapping occurrences go to the latest start, then the
    smaller person id. Attendees the directory cannot place are ignored."""
    best = None
    for tm, a, b, attendee in shifts:
        if tm != team or not (a <= at < b):
            continue
        pid = people.by_mail(attendee) if attendee else None
        if pid is None:
            continue
        cand = (-a, pid)
        if best is None or cand < best:
            best = cand
    return best[1] if best else "UNASSIGNED"
