# quillfen-settle

Settlement engine for the Quillfen data platform's scheduled commitments. It reads one settlement extract (the
exports of the schedulers, worker pools, landing systems, calendars, directory and ownership history) and writes the
settled output set described by the settlement contract.

## Running

```
PYTHONPATH=src python3 -m quillfen settle /path/to/extract /path/to/output
```

## Layout

- `src/quillfen/parsers` reads each export into normalised records
- `src/quillfen/core` identity, schedules, calendars, evidence, dependencies and status
- `src/quillfen/report` money, blame, chargeback and the output writers

## Tests

```
PYTHONPATH=src python3 -m unittest discover -s tests -t .
```

The engine uses the Python standard library only.
