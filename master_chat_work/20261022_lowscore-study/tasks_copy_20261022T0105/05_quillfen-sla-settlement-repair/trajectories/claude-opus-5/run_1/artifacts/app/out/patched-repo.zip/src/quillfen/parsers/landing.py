"""Physical partition evidence: object store, HDFS audit, warehouse registry, catalog, partner transfers, deletions."""
from __future__ import annotations

import csv
import gzip
import io
import re
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path

from ..keys import normalize_key
from ..records import Corpus, PartitionEvent
from ..timebase import instant, parse_stamp
from .common import MONTHS, Reader, host_instant, read_text, require


def _event(corpus, origin, dataset, nominal, at, kind="land"):
    corpus.partition_events.append(PartitionEvent(dataset=normalize_key(require(dataset)), nominal=nominal, at=at,
                                                  kind=kind, origin=origin))


_TS = re.compile(r"ts=(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})Z")


def read_objectstore(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    text = gzip.decompress(path.read_bytes()).decode("utf-8")
    rows = list(csv.reader(io.StringIO(text)))
    for row in rows[1:]:
        if not row:
            continue
        origin = reader.next()
        try:
            if len(row) != 5:
                raise ValueError("columns")
            key = row[1]
            m = _TS.search(key)
            if not m or not key.endswith("/_SUCCESS"):
                raise ValueError("object key")
            dataset = key[: m.start()].rstrip("/")
            nominal = instant(*(int(g) for g in m.groups()))
            _event(corpus, origin, dataset, nominal, parse_stamp(require(row[3]), default_offset=0))
        except ValueError:
            reader.malformed(origin)


_HDFS = re.compile(r"^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2}),\d{3} INFO FSNamesystem\.audit: (.*)$")
_HDFS_SRC = re.compile(r"^/warehouse/(.+)/(\d{4})/(\d{2})/(\d{2})/(\d{2})(\d{2})/_SUCCESS$")


def read_hdfs(path: Path, corpus: Corpus) -> None:
    """Only creations of a partition's _SUCCESS marker are landings; other audit lines carry no evidence."""
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if not line.strip():
            continue
        origin = reader.next()
        try:
            m = _HDFS.match(line)
            if not m:
                raise ValueError("audit line")
            kv = dict(p.split("=", 1) for p in m.group(7).split() if "=" in p)
            if kv.get("cmd") != "create" or not str(kv.get("src", "")).endswith("/_SUCCESS"):
                continue
            src = _HDFS_SRC.match(kv["src"])
            if not src:
                raise ValueError("src")
            wall = instant(*(int(m.group(k)) for k in range(1, 7)))
            at = host_instant(corpus, require(kv.get("host")), wall)
            nominal = instant(*(int(src.group(k)) for k in range(2, 7)))
            _event(corpus, origin, src.group(1), nominal, at)
        except ValueError:
            reader.malformed(origin)


_TUPLE = re.compile(r"\(\s*'((?:[^']|'')*)'\s*,\s*'((?:[^']|'')*)'\s*,\s*'((?:[^']|'')*)'\s*\)")


def read_warehouse(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    text = read_text(path)
    for stmt in re.finditer(r"INSERT INTO partition_registry \(dataset, partition_ts, registered_at\) VALUES(.*?);", text, re.S):
        for tup in _TUPLE.finditer(stmt.group(1)):
            origin = reader.next()
            try:
                dataset, part, registered = (g.replace("''", "'") for g in tup.groups())
                _event(corpus, origin, dataset, parse_stamp(part, default_offset=0), parse_stamp(registered, default_offset=0))
            except ValueError:
                reader.malformed(origin)


_ATOM = "{http://www.w3.org/2005/Atom}"


def read_catalog(path: Path, corpus: Corpus) -> None:
    """Catalog notices: 'published' marks a landing; a 'withdrawn' notice is catalogue metadata only."""
    reader = Reader(corpus, path.name)
    root = ET.fromstring(path.read_bytes())
    for entry in root.iter(_ATOM + "entry"):
        origin = reader.next()
        try:
            cat = entry.find(_ATOM + "category")
            term = cat.get("term") if cat is not None else None
            if term != "published":
                continue
            title = require(entry.findtext(_ATOM + "title")).split()
            if len(title) != 2:
                raise ValueError("title")
            _event(corpus, origin, title[0], parse_stamp(title[1], default_offset=None),
                   parse_stamp(require(entry.findtext(_ATOM + "updated")), default_offset=None))
        except ValueError:
            reader.malformed(origin)


_XFER_FILE = re.compile(r"^/incoming/(.+)_(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})\.csv\.gz$")


def read_partner(path: Path, corpus: Corpus) -> None:
    """xferlog: only completed ('c') incoming transfers are landings."""
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if not line.strip():
            continue
        origin = reader.next()
        try:
            f = line.split()
            if len(f) != 18:
                raise ValueError("fields")
            mon, day, clock, year = f[1], int(f[2]), f[3], int(f[4])
            if mon not in MONTHS:
                raise ValueError("month")
            h, mi, s = (int(x) for x in clock.split(":"))
            if f[17] != "c" or f[11] != "i":
                continue
            fm = _XFER_FILE.match(f[8])
            if not fm:
                raise ValueError("filename")
            at = host_instant(corpus, f[6], instant(year, MONTHS[mon], day, h, mi, s))
            nominal = instant(*(int(fm.group(k)) for k in range(2, 7)))
            _event(corpus, origin, fm.group(1), nominal, at)
        except ValueError:
            reader.malformed(origin)


class _Table(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows = []
        self._row = None
        self._cell = None
        self._in_table = False

    def handle_starttag(self, tag, attrs):
        if tag == "table" and dict(attrs).get("id") == "deletions":
            self._in_table = True
        elif self._in_table and tag == "tr":
            self._row = []
        elif self._in_table and tag == "td" and self._row is not None:
            self._cell = []

    def handle_endtag(self, tag):
        if tag == "table":
            self._in_table = False
        elif tag == "td" and self._cell is not None:
            self._row.append("".join(self._cell).strip())
            self._cell = None
        elif tag == "tr" and self._row is not None:
            if self._row:
                self.rows.append(self._row)
            self._row = None

    def handle_data(self, data):
        if self._cell is not None:
            self._cell.append(data)


def read_deletions(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    table = _Table()
    table.feed(read_text(path))
    for cells in table.rows:
        origin = reader.next()
        try:
            if len(cells) != 4:
                raise ValueError("columns")
            m = re.fullmatch(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) UTC", cells[2])
            if not m:
                raise ValueError("deleted at")
            _event(corpus, origin, cells[0], parse_stamp(require(cells[1]), default_offset=None),
                   parse_stamp(m.group(1), default_offset=0), kind="retract")
        except ValueError:
            reader.malformed(origin)
