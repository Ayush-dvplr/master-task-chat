"""Five-field cron schedules evaluated on a zone's wall clock."""
from __future__ import annotations

import calendar

from ..timebase import DAY, HOUR, MINUTE, ZoneTable, civil, instant

_MONTH_NAMES = {n: i + 1 for i, n in enumerate("JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC".split())}
_DAY_NAMES = {n: i for i, n in enumerate("SUN MON TUE WED THU FRI SAT".split())}


def _value(token: str, names: dict | None) -> int:
    if names and token.upper() in names:
        return names[token.upper()]
    if not token.isdigit():
        raise ValueError("cron value %r" % token)
    return int(token)


def _field(text: str, lo: int, hi: int, names: dict | None = None) -> frozenset:
    values = set()
    for part in text.split(","):
        if not part:
            raise ValueError("empty cron list item")
        step = 1
        if "/" in part:
            part, step_text = part.split("/", 1)
            if not step_text.isdigit() or int(step_text) == 0:
                raise ValueError("cron step")
            step = int(step_text)
        if part == "*":
            first, last = lo, hi
        elif "-" in part:
            a, b = part.split("-", 1)
            first, last = _value(a, names), _value(b, names)
        else:
            first = _value(part, names)
            last = hi if step > 1 else first
        if first < lo or last > hi or first > last:
            raise ValueError("cron range")
        values.update(range(first, last + 1, step))
    return frozenset(values)


class Schedule:
    def __init__(self, expression: str):
        parts = expression.split()
        if len(parts) != 5:
            raise ValueError("cron needs five fields")
        self.expression = expression
        self.minutes = _field(parts[0], 0, 59)
        self.hours = _field(parts[1], 0, 23)
        self.days_of_month = _field(parts[2], 1, 31)
        self.months = _field(parts[3], 1, 12, _MONTH_NAMES)
        self.days_of_week = frozenset(0 if d == 7 else d for d in _field(parts[4], 0, 7, _DAY_NAMES))
        self.dom_restricted = not parts[2].startswith("*")
        self.dow_restricted = not parts[4].startswith("*")

    def day_matches(self, year: int, month: int, day: int) -> bool:
        """A day qualifies when it satisfies the month, day-of-month and day-of-week fields."""
        if month not in self.months:
            return False
        weekday = (calendar.weekday(year, month, day) + 1) % 7
        by_dom = day in self.days_of_month
        by_dow = weekday in self.days_of_week
        return by_dom and by_dow

    def wall_times(self, first_day_wall: int, last_day_wall: int):
        day = first_day_wall - first_day_wall % DAY
        while day <= last_day_wall:
            y, mo, d = civil(day)[:3]
            if self.day_matches(y, mo, d):
                for h in sorted(self.hours):
                    for mi in sorted(self.minutes):
                        yield day + h * HOUR + mi * MINUTE
            day += DAY


def wall_to_fires(zones: ZoneTable, zone: str, wall: int) -> list:
    """Instants at which the scheduler fires for one scheduled wall time."""
    found = zones.instants_for_wall(zone, wall)
    if len(found) == 1:
        return found
    if not found:
        # The clock jumped over this reading; keep the pre-jump offset so the run keeps its place.
        jump = zones.transition_before(zone, wall)
        return [wall - jump[1] * 60] if jump else []
    return [found[0]]


def fires_between(schedule: Schedule, zones: ZoneTable, zone: str, lo: int, hi: int) -> list:
    """Distinct fire instants in [lo, hi)."""
    out = set()
    for wall in schedule.wall_times(lo - 2 * DAY, hi + 2 * DAY):
        for t in wall_to_fires(zones, zone, wall):
            if lo <= t < hi:
                out.add(t)
    return sorted(out)
