"""Monetary amounts in integer minor units."""
from __future__ import annotations


def to_minor(amount: str) -> int:
    """Rate card amount -> integer minor units."""
    return int(float(amount) * 100)
