"""Scheduler exports: US (SQLite), EU (semicolon text), APAC (JSON lines), legacy cron hosts (syslog)."""
from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path

from ..keys import normalize_key
from ..records import Corpus, Transition
from ..timebase import instant, parse_stamp
from .common import MONTHS, Reader, host_instant, read_text, require

STATES = {"queued", "running", "success", "failed", "up_for_retry", "removed", "cleared"}


def _state(text) -> str:
    s = require(text).strip()
    if s not in STATES:
        raise ValueError("state")
    return s


def read_us(path: Path, corpus: Corpus) -> None:
    con = sqlite3.connect("file:%s?mode=ro" % path.as_posix(), uri=True)
    try:
        rows = con.execute("SELECT rowid, run_id, job, nominal_utc, state, at_utc FROM task_transitions ORDER BY rowid").fetchall()
    finally:
        con.close()
    reader = Reader(corpus, path.name)
    for rowid, run_id, job, nominal, state, at in rows:
        origin = reader.next()
        try:
            corpus.transitions.append(Transition(run_id=require(run_id), key=normalize_key(require(job)),
                                                 nominal=parse_stamp(require(nominal), default_offset=None),
                                                 state=_state(state), at=parse_stamp(require(at), default_offset=0),
                                                 origin=origin))
        except ValueError:
            reader.malformed(origin)


_EU_STAMP = re.compile(r"^(\d{2})\.(\d{2})\.(\d{4}) (\d{2}):(\d{2}):(\d{2})$")


def eu_instant(corpus: Corpus, text: str) -> int:
    """The EU exporter writes day-first UTC stamps."""
    m = _EU_STAMP.match(require(text).strip())
    if not m:
        raise ValueError("eu stamp")
    d, mo, y, h, mi, s = (int(g) for g in m.groups())
    return corpus.zones.wall_to_instant("UTC", instant(y, mo, d, h, mi, s))


def read_eu(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    lines = read_text(path).splitlines()
    for line in lines[1:]:
        if not line.strip():
            continue
        origin = reader.next()
        try:
            parts = line.split(";")
            if len(parts) != 5:
                raise ValueError("columns")
            run_id, job, nominal, state, at = parts
            corpus.transitions.append(Transition(run_id=require(run_id), key=normalize_key(require(job)),
                                                 nominal=parse_stamp(require(nominal), default_offset=None),
                                                 state=_state(state), at=eu_instant(corpus, at), origin=origin))
        except ValueError:
            reader.malformed(origin)


def read_apac(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if not line.strip():
            continue
        origin = reader.next()
        try:
            row = json.loads(line)
            ts = row.get("ts_ms")
            nominal = row.get("nominal_ms")
            if not isinstance(ts, int) or not isinstance(nominal, int) or isinstance(ts, bool):
                raise ValueError("epoch millis")
            corpus.transitions.append(Transition(run_id=require(row.get("run")), key=normalize_key(require(row.get("job"))),
                                                 nominal=nominal // 1000, state=_state(row.get("state")),
                                                 at=ts // 1000, origin=origin))
        except (ValueError, AttributeError):
            reader.malformed(origin)


_SYSLOG = re.compile(r"^([A-Z][a-z]{2}) +(\d{1,2}) (\d{2}):(\d{2}):(\d{2}) (\S+) qf-sched\[\d+\]: (.*)$")


def syslog_year(corpus: Corpus, month: int, day: int, hour: int, minute: int, second: int) -> int:
    """Syslog stamps carry no year: a legacy export only covers its own settlement year."""
    year = time_year(corpus.period_start)
    instant(year, month, day, hour, minute, second)
    return year


def time_year(t: int) -> int:
    import time
    return time.gmtime(t).tm_year


def read_legacy(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for line in read_text(path).splitlines():
        if not line.strip():
            continue
        origin = reader.next()
        try:
            m = _SYSLOG.match(line)
            if not m or m.group(1) not in MONTHS:
                raise ValueError("syslog line")
            mo = MONTHS[m.group(1)]
            d, h, mi, s = (int(m.group(k)) for k in range(2, 6))
            y = syslog_year(corpus, mo, d, h, mi, s)
            at = host_instant(corpus, m.group(6), instant(y, mo, d, h, mi, s))
            kv = dict(p.split("=", 1) for p in m.group(7).split() if "=" in p)
            corpus.transitions.append(Transition(run_id=require(kv.get("run")), key=normalize_key(require(kv.get("job"))),
                                                 nominal=parse_stamp(require(kv.get("nominal")), default_offset=None),
                                                 state=_state(kv.get("state")), at=at, origin=origin))
        except ValueError:
            reader.malformed(origin)
