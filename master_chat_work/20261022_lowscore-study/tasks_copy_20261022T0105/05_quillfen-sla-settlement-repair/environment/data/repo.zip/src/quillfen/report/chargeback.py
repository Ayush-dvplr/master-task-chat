"""Penalty split across owning teams."""
from __future__ import annotations


def split(amount: int, teams: list) -> dict:
    """Equal shares in minor units; the leftover stays with the first owning team."""
    share, leftover = divmod(amount, len(teams))
    return {team: share + (leftover if i == 0 else 0) for i, team in enumerate(teams)}
