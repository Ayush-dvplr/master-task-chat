"""Blame for intervals excused by their upstream."""
from __future__ import annotations


def blame_parent(candidates: list):
    """candidates: (upstream key, landed_at or None, canonical job). The latest-landing upstream is to blame,
    an upstream that never landed counts as latest; ties go to the smaller canonical job id."""
    ranked = sorted(candidates, key=lambda c: (0 if c[1] is None else 1, -(c[1] or 0), c[2]))
    return ranked[0][0]


def root_of(key, parents: dict):
    """The interval an excused interval waited on is where its blame lands."""
    return parents[key], 1
