"""Calendar sources: freeze windows (iCalendar), team holidays (xCal), on-call rota (jCal)."""
from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

from ..keys import normalize_mail
from ..records import CalendarEvent, Corpus, Holiday
from ..timebase import instant
from .common import Reader, read_text, require

_LOCAL = re.compile(r"^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})$")
_XLOCAL = re.compile(r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})$")


def unfold(text: str) -> list:
    """Logical content lines of an iCalendar file."""
    out = []
    for raw in text.replace("\r\n", "\n").split("\n"):
        if raw[:1] in (" ", "\t") and out:
            out[-1] += raw
        else:
            out.append(raw)
    return out


def _wall(text: str) -> int:
    m = _LOCAL.match(text.strip())
    if not m:
        raise ValueError("local date-time")
    return instant(*(int(g) for g in m.groups()))


def _prop(line: str):
    head, value = line.split(":", 1)
    parts = head.split(";")
    params = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            params[k.upper()] = v
    return parts[0].upper(), params, value


def rrule_dict(text: str) -> dict:
    out = {}
    for part in text.split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.upper()] = v
    return out


def read_freezes(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    event = None
    for line in unfold(read_text(path)):
        if line == "BEGIN:VEVENT":
            event = []
            continue
        if line == "END:VEVENT":
            origin = reader.next()
            try:
                corpus.freezes.append(_freeze(event, origin, corpus))
            except (ValueError, KeyError):
                reader.malformed(origin)
            event = None
            continue
        if event is not None and ":" in line:
            event.append(_prop(line))


def _freeze(props, origin, corpus) -> CalendarEvent:
    uid = None
    zone = None
    start = end = rid = None
    rule = {}
    exdates = []
    cats = []
    cancelled = False
    for name, params, value in props:
        if name == "UID":
            uid = value.strip()
        elif name in ("DTSTART", "DTEND", "RECURRENCE-ID"):
            zone = params.get("TZID", zone)
            w = _wall(value)
            if name == "DTSTART":
                start = w
            elif name == "DTEND":
                end = w
            else:
                rid = w
        elif name == "RRULE":
            rule = rrule_dict(value)
        elif name == "EXDATE":
            for v in value.split(","):
                m = _LOCAL.match(v.strip())
                if m:
                    exdates.append(instant(*(int(g) for g in m.groups())))
        elif name == "CATEGORIES":
            for c in value.split(","):
                m = re.fullmatch(r"TIER([123])", c.strip().upper())
                if m:
                    cats.append(int(m.group(1)))
        elif name == "STATUS":
            cancelled = value.strip().upper() == "CANCELLED"
    require(uid)
    if rid is None:
        if start is None or end is None or end <= start:
            raise ValueError("series needs DTSTART before DTEND")
    elif not cancelled and (start is None or end is None):
        raise ValueError("override needs times")
    if not corpus.zones.knows(require(zone)):
        raise ValueError("zone")
    return CalendarEvent(uid=uid, zone=zone, start_wall=start, end_wall=end, rrule=rule, exdates=exdates,
                         categories=cats, recurrence_id=rid, cancelled=cancelled, attendee=None, team=None,
                         origin=origin)


_NS = "{urn:ietf:params:xml:ns:icalendar-2.0}"


def read_holidays(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    root = ET.fromstring(path.read_bytes())
    for ev in root.iter(_NS + "vevent"):
        origin = reader.next()
        try:
            date = require(ev.findtext("%sproperties/%sdtstart/%sdate" % (_NS, _NS, _NS)))
            team = require(ev.findtext("%sproperties/%sx-team/%stext" % (_NS, _NS, _NS)))
            y, m, d = (int(x) for x in re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", date.strip()).groups())
            instant(y, m, d)
            corpus.holidays.append(Holiday(team="team:" + team.strip(), date=(y, m, d), origin=origin))
        except (ValueError, AttributeError):
            reader.malformed(origin)


def read_rota(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    cal = json.loads(read_text(path))
    for comp in cal[2]:
        if comp[0] != "vevent":
            continue
        origin = reader.next()
        try:
            props = {}
            params = {}
            for p in comp[1]:
                props[p[0]] = p[3]
                params[p[0]] = p[1]
            uid = require(props.get("uid"))
            rid = None
            zone = None
            start = None
            if "recurrence-id" in props:
                zone = params["recurrence-id"].get("tzid")
                rid = _xwall(props["recurrence-id"])
            if "dtstart" in props:
                zone = params["dtstart"].get("tzid")
                start = _xwall(props["dtstart"])
            if rid is None and start is None:
                raise ValueError("dtstart")
            days = 0
            if "duration" in props:
                m = re.fullmatch(r"P(\d+)D", props["duration"])
                if not m:
                    raise ValueError("duration")
                days = int(m.group(1))
            rule = {}
            for k, v in (props.get("rrule") or {}).items():
                if k == "until":
                    v = v.replace("-", "").replace(":", "")
                rule[k.upper()] = str(v)
            cancelled = str(props.get("status", "")).upper() == "CANCELLED"
            attendee = normalize_mail(props["attendee"]) if props.get("attendee") else None
            if zone is not None and not corpus.zones.knows(zone):
                raise ValueError("zone")
            corpus.rota.append(CalendarEvent(uid=uid, zone=zone or "UTC", start_wall=start,
                                             end_wall=start + days * 86400 if start is not None else None,
                                             rrule=rule, exdates=[], categories=[], recurrence_id=rid,
                                             cancelled=cancelled, attendee=attendee,
                                             team=("team:" + props["x-team"]) if props.get("x-team") else None,
                                             origin=origin))
        except (ValueError, KeyError, TypeError):
            reader.malformed(origin)


def _xwall(text: str) -> int:
    m = _XLOCAL.match(str(text))
    if not m:
        raise ValueError("date-time")
    return instant(*(int(g) for g in m.groups()))
