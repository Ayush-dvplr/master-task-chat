"""Physical partition events and the land event that governs a partition."""
from __future__ import annotations

from .identity import Identity


class Producers:
    def __init__(self, rows: list, identity: Identity, corpus):
        self.identity = identity
        self.by_dataset = {}
        self.by_name = {}
        for r in rows:
            if not identity.known(r.key):
                corpus.reject(r.origin, "UNKNOWN_JOB")
                continue
            self.by_dataset.setdefault(r.dataset, []).append(r)
            self.by_name.setdefault(r.key, []).append(r)

    @staticmethod
    def _live(r, at):
        return r.valid_from <= at and (r.valid_to is None or at < r.valid_to)

    def jobs_for(self, dataset: str, at: int) -> set:
        out = set()
        for r in self.by_dataset.get(dataset, []):
            if self._live(r, at):
                out.add(self.identity.resolve_key(r.key, at).index)
        return out

    def datasets_for(self, job, at: int) -> set:
        out = set()
        for name in self.identity.names_of(job):
            for r in self.by_name.get(name, []):
                if self._live(r, at) and self.identity.resolve_key(r.key, at) is job:
                    out.add(r.dataset)
        return out


def partition_streams(events: list, producers: Producers, corpus) -> dict:
    """Per (dataset, nominal): merged land and retract events ordered by instant, lands first on ties."""
    streams = {}
    for e in events:
        if not producers.jobs_for(e.dataset, e.nominal):
            corpus.reject(e.origin, "UNMAPPED_DATASET")
            continue
        streams.setdefault((e.dataset, e.nominal), []).append(e)
    for key, evs in streams.items():
        evs.sort(key=lambda e: (e.at, 0 if e.kind == "land" else 1, e.origin.source, e.origin.ordinal))
        landed = False
        kept = []
        for e in evs:
            if e.kind == "land":
                landed = True
            elif not landed:
                corpus.reject(e.origin, "ORPHAN_TRANSITION")
                continue
            kept.append(e)
        streams[key] = kept
    return streams


def governing_land(stream: list):
    """(instant of the governing land event or None, number of land events).

    A partition is available from its first landing; later landings only refresh data already there."""
    lands = [e for e in stream if e.kind == "land"]
    if not lands:
        return None, 0
    return lands[0].at, len(lands)
