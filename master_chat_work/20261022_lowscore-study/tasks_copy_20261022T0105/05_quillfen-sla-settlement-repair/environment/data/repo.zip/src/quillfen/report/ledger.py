"""Row ordering shared by the per-interval outputs."""
from __future__ import annotations


def sort_key(interval):
    return (interval.job.canonical, interval.nominal)
