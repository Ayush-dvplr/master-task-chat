"""Organisation sources: ownership history, team handle registry, directory, pager contacts, hosts."""
from __future__ import annotations

import csv
import datetime as _dt
import io
import re
from pathlib import Path

from ..keys import normalize_handle, normalize_mail
from ..records import Contact, Corpus, DirectoryChange, DirectoryPerson, HandleBinding, HostBinding, OwnershipCommit
from ..timebase import parse_stamp
from .common import Reader, read_text, require


def read_hosts(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    rows = list(csv.reader(io.StringIO(read_text(path))))
    for row in rows[1:]:
        if not row:
            continue
        origin = reader.next()
        try:
            if len(row) != 5:
                raise ValueError("columns")
            host, pool, zone, frm, to = (c.strip() for c in row)
            if not corpus.zones.knows(require(zone)):
                raise ValueError("zone")
            corpus.hosts.append(HostBinding(
                host=require(host), zone=zone,
                valid_from=parse_stamp(frm, default_offset=None) if frm else None,
                valid_to=parse_stamp(to, default_offset=None) if to else None,
                origin=origin))
        except ValueError:
            reader.malformed(origin)


def read_ownership(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    blocks = re.split(r"(?m)^(?=commit [0-9a-f]{40}$)", read_text(path))
    for block in blocks:
        if not block.startswith("commit "):
            continue
        origin = reader.next()
        try:
            date = re.search(r"(?m)^Date:\s+(.+)$", block)
            committed = int(_dt.datetime.strptime(require(date.group(1) if date else None).strip(),
                                                  "%a %b %d %H:%M:%S %Y %z").timestamp())
            changes = []
            for line in block.splitlines():
                if line.startswith("+jobs/") or line.startswith("-jobs/"):
                    parts = line[1:].split()
                    changes.append((line[0], parts[0], [normalize_handle(h) for h in parts[1:]]))
            corpus.ownership.append(OwnershipCommit(committed=committed, changes=changes, origin=origin))
        except (ValueError, AttributeError):
            reader.malformed(origin)


_BLOCK = re.compile(r'handle\s+"([^"]+)"\s*\{(.*?)\}', re.S)
_FIELD = re.compile(r'(\w+)\s*=\s*"([^"]*)"')


def read_handles(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for m in _BLOCK.finditer(read_text(path)):
        origin = reader.next()
        try:
            fields = dict(_FIELD.findall(m.group(2)))
            frm, to = fields.get("valid_from", ""), fields.get("valid_to", "")
            corpus.handles.append(HandleBinding(
                handle=normalize_handle(m.group(1)),
                team="team:" + require(fields.get("team")).strip(),
                valid_from=parse_stamp(frm, default_offset=None) if frm else None,
                valid_to=parse_stamp(to, default_offset=None) if to else None,
                origin=origin))
        except ValueError:
            reader.malformed(origin)


def _ldif_records(text: str):
    lines = []
    for raw in text.splitlines():
        if raw.startswith(" ") and lines:
            lines[-1] += raw[1:]
        else:
            lines.append(raw)
    record = []
    for line in lines + [""]:
        if line.strip() == "":
            if record:
                yield record
            record = []
        elif not line.startswith("#"):
            record.append(line)


def ldif_attributes(record):
    """Attribute name -> list of values for one LDIF entry."""
    attrs = {}
    for line in record:
        if line == "-" or ":" not in line:
            continue
        name, value = line.split(":", 1)
        attrs[name.strip().lower()] = [value.strip()]
    return attrs


def read_directory(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    for record in _ldif_records(read_text(path)):
        if len(record) == 1 and record[0].lower().startswith("version:"):
            continue
        origin = reader.next()
        try:
            attrs = ldif_attributes(record)
            uid = require((attrs.get("uid") or [None])[0] or _uid_from_dn(attrs))
            if "changetype" in attrs:
                if attrs["changetype"][0] != "modify":
                    raise ValueError("changetype")
                op = "add" if "add" in attrs else ("delete" if "delete" in attrs else None)
                for mail in attrs.get("mail", []):
                    corpus.directory_changes.append(DirectoryChange(uid=uid, op=require(op), mail=normalize_mail(mail), origin=origin))
                continue
            employee = require((attrs.get("employeenumber") or [None])[0])
            mails = [normalize_mail(m) for m in attrs.get("mail", [])]
            corpus.people.append(DirectoryPerson(employee=employee, uid=uid, mails=mails, origin=origin))
        except ValueError:
            reader.malformed(origin)


def _uid_from_dn(attrs):
    dn = (attrs.get("dn") or [""])[0]
    m = re.match(r"uid=([^,]+)", dn)
    return m.group(1) if m else None


def read_contacts(path: Path, corpus: Corpus) -> None:
    reader = Reader(corpus, path.name)
    text = read_text(path).replace("\r\n", "\n")
    text = re.sub(r"\n[ \t]", "", text)
    for m in re.finditer(r"BEGIN:VCARD\n(.*?)END:VCARD", text, re.S):
        origin = reader.next()
        try:
            mails, handles = [], []
            for line in m.group(1).splitlines():
                if ":" not in line:
                    continue
                name, value = line.split(":", 1)
                name = name.split(";")[0].upper()
                if name == "EMAIL" and value.strip():
                    mails.append(normalize_mail(value))
                elif name == "X-PAGER-HANDLE" and value.strip():
                    handles.append(value.strip().lower())
            if not mails or not handles:
                raise ValueError("contact needs an address and a handle")
            corpus.contacts.append(Contact(mails=mails, handles=handles, origin=origin))
        except ValueError:
            reader.malformed(origin)
