"""Cold-chain backbone quoting."""
import sys

sys.dont_write_bytecode = True  # the command writes nowhere but --out

VERSION = "2.18.5"
