"""Migration planning over (schema, field state)."""

from __future__ import annotations

import heapq

from ..errors import MigrationError
from ..parser.contracts import Edge, Registry
from .operations import apply_operations
from .records import ABSENT, NULL, FieldView, edge_allowed

_STAND_IN_VALUE = "<value>"


def state_signature(registry: Registry, schema_id: str, payload: dict) -> dict[str, str]:
    """State of every prerequisite field of the record's domain, sorted by name."""
    domain = registry.domain_of(schema_id)
    return FieldView.from_payload(payload).signature(registry.prerequisite_fields(domain))


def _stand_in(names: list[str], state: tuple[str, ...]) -> dict:
    return {
        name: (None if value == NULL else _STAND_IN_VALUE)
        for name, value in zip(names, state)
        if value != ABSENT
    }


def _advance(
    registry: Registry, domain: str, names: list[str], state: tuple[str, ...], edge: Edge
) -> tuple[str, ...]:
    record = apply_operations(registry, domain, _stand_in(names, state), edge.operations)
    return FieldView.from_payload(record).states(names)


def plan_migration(registry: Registry, schema_id: str, payload: dict) -> list[str]:
    """Cheapest feasible plan to the canonical schema; ties go to the smallest edge-id list."""
    domain = registry.domain_of(schema_id)
    target = registry.canonical.get(domain)
    if target is None:
        raise MigrationError("E_UNREACHABLE", f"domain {domain} has no canonical schema")
    if schema_id == target:
        return []
    rest = _cost_to_target(registry, target)
    if schema_id not in rest:
        raise MigrationError("E_UNREACHABLE", f"no feasible plan from {schema_id} to {target}")
    names = registry.named_fields(domain)
    start = FieldView.from_payload(payload).states(names)
    # Ordered by spent cost plus the cheapest possible remainder, then by edge-id list.
    frontier: list[tuple[int, tuple[str, ...], int, str, tuple[str, ...]]] = [(rest[schema_id], (), 0, schema_id, start)]
    settled: set[tuple[str, tuple[str, ...]]] = set()
    while frontier:
        _, path, cost, node, state = heapq.heappop(frontier)
        if (node, state) in settled:
            continue
        settled.add((node, state))
        if node == target:
            return list(path)
        view = FieldView(dict(zip(names, state)))
        for edge in registry.edges_from.get(node, ()):
            if edge.target not in rest or not edge_allowed(registry, domain, view, edge):
                continue
            following = _advance(registry, domain, names, state, edge)
            if (edge.target, following) in settled:
                continue
            spent = cost + edge.cost
            heapq.heappush(frontier, (spent + rest[edge.target], path + (edge.edge_id,), spent, edge.target, following))
    raise MigrationError("E_UNREACHABLE", f"no feasible plan from {schema_id} to {target}")


def _cost_to_target(registry: Registry, target: str) -> dict[str, int]:
    """Cheapest edge-cost sum from each schema to the target, prerequisites left aside."""
    incoming: dict[str, list[Edge]] = {}
    for edge in registry.edges.values():
        if edge.source != target:
            incoming.setdefault(edge.target, []).append(edge)
    rest = {target: 0}
    queue = [(0, target)]
    while queue:
        cost, node = heapq.heappop(queue)
        if cost > rest[node]:
            continue
        for edge in incoming.get(node, ()):
            reach = cost + edge.cost
            if edge.source not in rest or reach < rest[edge.source]:
                rest[edge.source] = reach
                heapq.heappush(queue, (reach, edge.source))
    return rest
