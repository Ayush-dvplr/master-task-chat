"""Migration planning over (schema, field state) nodes.

The planner never enumerates paths. What a record can still do depends only on
the schema it sits at and the state (absent, explicit null, value) of the fields
that can still decide a prerequisite, so the search runs over those finitely
many nodes and is unaffected by how many distinct paths the graph holds (K14).
"""

from __future__ import annotations

import heapq

from ..errors import MigrationError
from ..parser.contracts import Edge, Registry, _operation_fields
from .operations import apply_operations
from .records import ABSENT, NULL, FieldView, edge_allowed

_STAND_IN_VALUE = "<value>"
_UNCACHED = object()


def state_signature(registry: Registry, schema_id: str, payload: dict) -> dict[str, str]:
    """State of every prerequisite field of the record's domain, sorted by name (M10)."""
    domain = registry.domain_of(schema_id)
    return FieldView.from_payload(payload).signature(registry.prerequisite_fields(domain))


class _Transitions:
    """Prerequisite checks and state transitions of one domain's edges.

    An edge reads and writes only the fields its prerequisites and operations
    name, so its effect is memoised against the state of just those fields and
    then written into the search state. The memo is kept on the registry, so a
    run over many records pays for each distinct edge situation once.
    """

    def __init__(self, registry: Registry, domain: str) -> None:
        self.registry = registry
        self.domain = domain
        self.names = registry.relevant_fields(domain)
        position = {name: index for index, name in enumerate(self.names)}
        self.touched: dict[str, tuple[int, ...]] = {}
        for edge in registry.edges_of_domain(domain):
            fields = {name for _, name in edge.requires}
            for operation in edge.operations:
                fields.update(_operation_fields(operation))
            self.touched[edge.edge_id] = tuple(
                sorted(position[name] for name in fields if name in position)
            )
        self.memo: dict[tuple[str, tuple[str, ...]], tuple[str, ...] | None] = {}

    def step(self, state: tuple[str, ...], edge: Edge) -> tuple[str, ...] | None:
        """The state after ``edge``, or None when one of its prerequisites fails (M6)."""
        indices = self.touched[edge.edge_id]
        local = tuple([state[index] for index in indices])
        key = (edge.edge_id, local)
        result = self.memo.get(key, _UNCACHED)
        if result is _UNCACHED:
            result = self._compute(indices, local, edge)
            self.memo[key] = result
        if result is None:
            return None
        if result == local:
            return state
        following = list(state)
        for index, value in zip(indices, result):
            following[index] = value
        return tuple(following)

    def _compute(
        self, indices: tuple[int, ...], local: tuple[str, ...], edge: Edge
    ) -> tuple[str, ...] | None:
        names = self.names
        view = FieldView({names[index]: value for index, value in zip(indices, local)})
        if not edge_allowed(self.registry, self.domain, view, edge):
            return None
        record = {
            names[index]: (None if value == NULL else _STAND_IN_VALUE)
            for index, value in zip(indices, local)
            if value != ABSENT
        }
        record = apply_operations(self.registry, self.domain, record, edge.operations)
        after = FieldView.from_payload(record)
        return tuple(after.state(names[index]) for index in indices)


def _transitions(registry: Registry, domain: str) -> _Transitions:
    cached = registry.planner_cache.get(domain)
    if cached is None:
        cached = _Transitions(registry, domain)
        registry.planner_cache[domain] = cached
    return cached


def _explore(
    registry: Registry, start: tuple[str, tuple[str, ...]], target: str, transitions: _Transitions
) -> tuple[dict, bool]:
    """Dijkstra from ``start``, stopping once the canonical schema is settled.

    Edge costs are positive, so every node of a cheapest plan but its last is
    settled strictly before the canonical schema is, and therefore carries its
    full set of outgoing transitions in the result.
    """
    adjacency: dict[tuple[str, tuple[str, ...]], list[tuple[str, int, tuple]]] = {}
    distance = {start: 0}
    heap = [(0, start)]
    arrived = False
    while heap:
        cost, node = heapq.heappop(heap)
        if node in adjacency or cost > distance[node]:
            continue
        if node[0] == target:
            adjacency[node] = []
            arrived = True
            break
        state = node[1]
        outgoing: list[tuple[str, int, tuple]] = []
        for edge in registry.edges_from.get(node[0], ()):
            following = transitions.step(state, edge)
            if following is None:
                continue
            following_node = (edge.target, following)
            outgoing.append((edge.edge_id, edge.cost, following_node))
            candidate = cost + edge.cost
            if candidate < distance.get(following_node, candidate + 1):
                distance[following_node] = candidate
                heapq.heappush(heap, (candidate, following_node))
        adjacency[node] = outgoing
    return adjacency, arrived


def _remaining(adjacency: dict, target: str) -> dict:
    """Cheapest cost from each explored node to the canonical schema."""
    incoming: dict[tuple, list[tuple[int, tuple]]] = {}
    nodes = set(adjacency)
    for node, outgoing in adjacency.items():
        for _, cost, following in outgoing:
            nodes.add(following)
            incoming.setdefault(following, []).append((cost, node))
    distance = {node: 0 for node in nodes if node[0] == target}
    heap = [(0, node) for node in distance]
    heapq.heapify(heap)
    while heap:
        cost, node = heapq.heappop(heap)
        if cost > distance[node]:
            continue
        for step_cost, previous in incoming.get(node, ()):
            candidate = cost + step_cost
            if candidate < distance.get(previous, candidate + 1):
                distance[previous] = candidate
                heapq.heappush(heap, (candidate, previous))
    return distance


def _descend(adjacency: dict, remaining: dict, start: tuple, target: str) -> list[str]:
    """The cheapest plan, smallest list of edge ids among the cheapest ones (M8).

    At each node every edge that keeps the record on a cheapest plan is a
    candidate, so taking the smallest such edge id at each step builds the list
    that compares smallest element by element. Positive costs shrink the
    remaining budget at every step, so the descent ends.
    """
    plan: list[str] = []
    node = start
    while node[0] != target:
        budget = remaining[node]
        choice: tuple[str, tuple] | None = None
        for edge_id, cost, following in adjacency[node]:
            if following in remaining and cost + remaining[following] == budget:
                if choice is None or edge_id < choice[0]:
                    choice = (edge_id, following)
        if choice is None:
            raise MigrationError("E_UNREACHABLE", f"no cheapest step out of {node[0]}")
        plan.append(choice[0])
        node = choice[1]
    return plan


def plan_migration(registry: Registry, schema_id: str, payload: dict) -> list[str]:
    """Cheapest plan from ``schema_id`` to the domain's canonical schema (M6 to M9)."""
    domain = registry.domain_of(schema_id)
    target = registry.canonical.get(domain)
    if target is None:
        raise MigrationError("E_UNREACHABLE", f"domain {domain} has no canonical schema")
    if schema_id == target:
        return []
    transitions = _transitions(registry, domain)
    start = (schema_id, FieldView.from_payload(payload).states(transitions.names))
    adjacency, arrived = _explore(registry, start, target, transitions)
    if not arrived:
        raise MigrationError("E_UNREACHABLE", f"no feasible plan from {schema_id} to {target}")
    return _descend(adjacency, _remaining(adjacency, target), start, target)
