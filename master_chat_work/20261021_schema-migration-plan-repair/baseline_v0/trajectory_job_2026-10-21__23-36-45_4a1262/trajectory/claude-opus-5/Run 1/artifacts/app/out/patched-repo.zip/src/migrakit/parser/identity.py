"""Canonical partner identity (P rules)."""

from __future__ import annotations

from ..errors import MigrationError
from .contracts import Registry


def resolve_partner(registry: Registry, value: object) -> str:
    """Map a partner id or alias to its canonical partner id.

    P1 finds the partner (an id first, else an alias text), P2 follows every
    merge link until a partner that is merged into no other partner, and P3
    rejects a merge chain that returns to a partner already visited.
    """
    if not isinstance(value, str):
        raise MigrationError("E_UNKNOWN_PARTNER", repr(value))
    if value in registry.partners:
        partner_id = value
    elif value in registry.aliases:
        partner_id = registry.aliases[value]
    else:
        raise MigrationError("E_UNKNOWN_PARTNER", value)
    seen = {partner_id}
    while partner_id in registry.merges:
        partner_id = registry.merges[partner_id]
        if partner_id in seen:
            raise MigrationError("E_ALIAS_CYCLE", value)
        seen.add(partner_id)
    return partner_id
