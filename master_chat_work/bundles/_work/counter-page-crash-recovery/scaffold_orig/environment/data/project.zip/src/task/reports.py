from __future__ import annotations

from .core import summarize

DEFAULT_LABEL = "/"


def render_report(entries: list[dict]) -> str:
    summary = summarize(entries)
    lines = [f"TASK manifest report: {summary['count']} entries"]
    lines.append(f"average={summary['average']:.2f}")
    for item in summary["items"]:
        lines.append(f"- {item['name']}: {item['bucket']} ({item['score']})")
    return "\n".join(lines)
