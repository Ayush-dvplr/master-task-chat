# TASK build triage package

This small project should provide a package named `task` for scoring
 manifests emitted by . It is currently in
included smoke tests do not pass.

Intended public API:

- `__version__`
- `load_manifest(path)`
- `score_entry(entry)`
- `score_batch(entries)`
- `summarize(entries)`
- `render_report(entries)`

Keep the repair stdlib-only.
